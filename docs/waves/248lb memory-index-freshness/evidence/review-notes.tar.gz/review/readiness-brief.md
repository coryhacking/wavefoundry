# Readiness review brief (wave 248lb)

Wave `248lb memory-index-freshness` holds one spec, `2475t-bug memory-search-falls-back-during-index-build`, in `docs/waves/248lb memory-index-freshness/`. It is track 2 of the arc `docs/arcs/244cm memory-quality/244cm-arc memory-quality.md`. The track 1 baseline is in the closed wave `docs/waves/245na memory-eval-production-path/`.

## Problem
While a docs index build is running, memory search silently falls back to lexical with `semantic_index_unavailable`. In wave 245na, a 14-minute run of `wf_memory_eval` through MCP lost 7 to 15 of its 606 production probes this way. The same run through the CLI lost none.

The planner reproduced the root cause:
- `indexer.py` sets `build_state.status='building'` before its first write and keeps it until `finalize_build_epoch`.
- During that window, `build_epoch_token` returns None, and `WaveIndex._ensure_loaded` (through `_index_meta_signature`) raises `IndexNotReadyError`.
- `memory_handlers._memory_query_records` calls that path outside any read snapshot, and its catch-all turns the error into the fallback.
- `docs_search` survives the same window, because `_partial_index_read` wraps its reads in `sqlite_vector_store.read_snapshot`.

## The plan
- Wrap the memory load and the dense read in the same `read_snapshot`, and end the snapshot before the reranker runs.
- `index_health` reports memory coverage, with stale separate from missing, from `memory_vector_coverage`. The body-path builder moves to a shared module first.
- No monitor change: its staleness walk already covers the memory files.

## Operator decisions (2026-11-23)
- `memory_search` stays read-only and never triggers a refresh.
- AC-10 runs on a temporary corpus. No test or live run edits a real memory record.

## Review setup
- Receipt: `review-policy-3b26314ee8580a10949f`.
- Lanes: code-reviewer, qa-reviewer, architecture-reviewer, docs-contract-reviewer.
- Seats: red-team (fixed), security-reviewer (rotating).

## Your task, as a fresh, independent reviewer of your lane
1. **Read.** Load the MCP tools via ToolSearch first and use code_* retrieval first. Read the spec, its Decision Log and the arc's track 2 row.
2. **Verify against the code, not the spec's prose.**
   - Check that every cited anchor resolves and that the root-cause chain holds. Reproduce it on a throwaway copy if you can.
   - Check that holding a `read_snapshot` across the load and the dense read is safe: no writer starvation, correct WAL behavior, Windows file locking, and nothing held while the reranker runs.
   - Check that the ACs can fail.
3. **Make no repo edits.**
   - You may run `python3 -B .wavefoundry/framework/scripts/run_tests.py --file <f>` under the default profile and under `--profile second`, plus probes on a throwaway copy.
   - Never run the full suite.
   - Do not run `wf_memory_eval`.
   - Do not mutate memory records.
4. **Record the result in the typed ledger** (`wf_review_event`, wave `248lb`). Dry-run first, then create.
   - A blocking defect gets a finding: `run_kind='readiness'`, `cycle=0`, `actor=<lane>`, `context_id='248lb-<lane>-readiness'`, with an honest `execution_status`.
   - A required lane with no blocker records a readiness approval: `signoff_key=<lane>`, `approval_phase='readiness'`, `fresh_context=true`, `independent=true`, executed, with your OWN `integrity_checks`.
   - Council seats write notes, plus findings if they find a blocker.
5. **Write notes** to `.wavefoundry/work/248lb/review/<lane>-readiness.md`. No em-dashes.
6. **Reply** in under 100 words.
