# Code review, focused readiness round 2 (wave 248lb)

Reviewer: code-reviewer, fresh and independent context `248lb-code-reviewer-focused-r2`. I wrote neither the finding nor the repair.
Verdict: the repair for `248lb-code-embed-inside-snapshot-repair-constraint` holds. Lane cleared; readiness approval recorded.

## Probe (executed, scratchpad only)
`probe-r2/p2.py`: an apsw backup of `.wavefoundry/index/index.sqlite` (generation 6381, complete) and a copy of `docs/agents/memory/`, with `build_state` set to `building`. It used a real `WaveIndex` and the real query embedder. No repository file was touched.

| Step | Observed |
| --- | --- |
| Cold `WaveIndex`, before load | `_meta` is `{}` |
| First `read_snapshot`, `_ensure_loaded` | partial load, token `('partial', ...)` |
| After the first snapshot exits | `_meta` docs version kept (`...arctic-embed-s@full@...`), `snapshot_active` False |
| Real `_embed_query` | (384,) in 0.38 s, snapshot inactive, `_meta` filled when `_get_embedder` ran |
| Model change between snapshots (second connection sets docs to `other/model@int8`, finalizes gen+1) | second `_ensure_loaded` reloads; version differs: True. `_ensure_loaded` did not raise, so the Requirement 4 comparison is the guard that catches it |
| Same-model completion (gen+2) | version differs: False, partial False |

`run_tests.py --file test_memory_eval.py`: 48 tests OK, 0 skipped.

## The four checks
1. **Precision from the first load.** `_get_embedder` (lines 1939 to 2047) reads `self._meta` model_versions at call time and caches by model name. The first snapshot fills `_meta`, and it survives the context exit, so the embedding after it chooses the index's precision. Holds.
1. **Model-change reload in the second snapshot.** `_ensure_loaded` reloads whenever the signature changes, and a completed epoch's token differs from the partial token. The comparison is required, because a complete epoch with another recorded model still loads. For the implementer: capture the first-load version before the second `_ensure_loaded` overwrites `_meta`, and compare the full string. The full string also catches a precision-only rebuild (`@full` to `@int8`). Holds.
1. **No outer snapshot.** Outside the tests, `read_snapshot` is entered only by `_partial_index_read`, for `docs_search`, `code_search` and `code_ask`. The callers of `memory_search_response` are the tool at `server_impl.py` 27416 and `memory_eval.py` at lines 187, 1284 and 1500. None of them holds a snapshot. Holds.
1. **`memory_eval` startup.** Running the load at line 1405 inside a snapshot fills `_meta` and sets `_docs_vector_layer`, and both persist afterwards. Each later `memory_search_response` opens its own snapshots. `dense_stream` does not call `_ensure_loaded`, and `_memory_candidate_scores` does not check build state, so it works with no outer snapshot. Its embedding uses the `_meta` filled at startup. Holds.

## Advisory (non-blocking)
- `memory_eval._StubIndex` is used by the hermetic `run` through `memory_search_response`. It has no `index_dir`, and it has only the unsplit `_memory_candidate_scores`. It needs an `index_dir`, the split method names, and a `read_snapshot` patch in the hermetic tests. Requirement 13 does not name it, but `test_ac14_hermetic_run_is_unchanged` and AC-11 will force the change.
- The INT8 accel branch was not exercised end to end, because this index records `@full`. The precision rule was confirmed by reading the code and by the contrast with an empty `_meta`.
