# Code-reviewer delivery notes (wave 248lb, change 2475t)

Verdict: APPROVE. No defect found. Four advisories below.

## Executed checks
- Focused suites `test_memory_records.py`, `test_memory_eval.py`, `test_inference_provider.py`, `test_tensorwell_integration.py`:
  - default profile: 347 tests, OK (`code-reviewer/default.log`)
  - `--profile second`: 0 of 4 files failed (`code-reviewer/second.log`)
- Mutants, one at a time on a scratch git copy (scratchpad `mut/`, script `mutate.py`):
  - builder duplicate-path check removed: caught by shipped AC-6 test
  - model recheck neutralized (`first_model is object()`): caught by shipped AC-3 model-change test
  - second `epoch_out` assignment removed: SURVIVES shipped tests; killed by probe P1 (build begins between the snapshots, response must carry `index_coverage`)
  - `complete: False` instead of `null` on failure: SURVIVES shipped tests; killed by probe P2 (no store, `_memory_coverage_block` returns `complete` null)
  - diagnostic tests only `missing_paths`: SURVIVES shipped tests; killed by probe P4 (stale-only coverage must raise `memory_vector_coverage_incomplete`)
  - `run_curated` startup snapshot removed: SURVIVES shipped tests; killed by probe P3 (`run_curated` on a building store must not report `semantic index unavailable`)
  - All four probes pass on the unmutated code.

## Correctness review
- Two-snapshot sequence: load and model identity capture in snapshot 1; body hashes and query embedding with no snapshot; reload, identity recheck and `dense_path_scores` in snapshot 2; reranker after both. Correct.
- Model recheck compares the docs `model_versions` entry with the first load's. A build that starts between snapshots without a recorded docs identity drops the docs layer and falls back; this is fail-closed.
- `epoch_out` takes the last loaded token. The advisory condition matches `_is_partial_epoch`.
- Shared builder: one definition in `memory_records.py`; `ValueError` maps to `memory_candidate_state_unavailable`, `OSError` to `memory_source_state_stale`.
- `index_health` memory block: model-free, one snapshot, fixed reason tokens, `complete` null on failure.
- Nesting: no production caller runs `memory_search_response` inside an outer snapshot. Callers are the MCP tool, `memory_eval` target retrievability and the production arm. The `run_curated` startup snapshot closes before any probe. `_partial_index_read` wraps only `docs_search`, `code_search` and `code_ask`.

## Advisories (non-blocking)
1. Four correct behaviors are not pinned by the shipped tests (see the surviving mutants). Consider adding P1 to P4.
2. A lexical fallback during a build reports `source: stored_rows`. Its message says the results come from stored index rows, but the records come from memory files. This is a documented deviation.
3. If the second load raises `IndexNotReadyError`, the token stays from snapshot 1. A fallback in that narrow window may then lack the advisory.
4. The `memory_eval` dense-arm streams (`dense_stream`) still read dense rows outside any snapshot. This behavior predates the change and does not affect the production arm.
