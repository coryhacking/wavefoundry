# Red-team readiness notes, wave 248lb

Seat: red-team (fixed, primer, standard depth). Fresh, independent context. No approval recorded.

Spec under attack: `2475t-bug memory-search-falls-back-during-index-build`. Claim attacked: wrapping the memory load and dense read in `read_snapshot` ends the build-window fallback.

## Verdict

The fix ends the measured fallback. One blocking plan defect: Requirement 1 as written puts the query embedding inside the snapshot, which breaks Requirement 2, and no AC can catch it. The ledger already holds this defect as `248lb-sec-query-embed-inside-snapshot` and `248lb-code-embed-inside-snapshot-repair-constraint`. I confirmed it independently with an executed probe (below) and did not record a third duplicate finding (dry-run only, context `248lb-red-team-readiness`). Everything else below is non-blocking. Probe 5 (the Decision Log rationale) is new and is not in the ledger.

## Method

All probes ran on a scratch copy, never on this repository's store or records:

- Store copied with an apsw page backup of `.wavefoundry/index/index.sqlite` (build_state complete, generation 6375) into a scratch repo, with `docs/agents/memory/` copied beside it (174 surfaced records).
- Interpreter: `~/.wavefoundry/venv/bin/python -B`, the same apsw the MCP server loads.
- Real `WaveIndex(scratch_root)` and real query embedder. The reranker is stubbed and records `snapshot_active`.
- Scripts live in the session scratchpad under `rt/probes/` (p1 to p5) and are not retained.

## Probes and results

1. **Root cause holds** (p1, executed). In the complete state the query path gives `hybrid_rrf` with fallback None. With build_state `building` it gives `lexical_policy` with `semantic_index_unavailable`. With the spec's wrapping (load, docs check and `_memory_candidate_scores` in one `read_snapshot`) it gives `hybrid_rrf` with fallback None and 5 selected. The AC-1 known-bad direction can fail.
2. **Blocking: model inference inside the snapshot** (p1, executed). Wrapped as Requirement 1 says, the real `_embed_query` ran with `snapshot_active == True` and took 0.34 s, in a fresh process. `WaveIndex._memory_candidate_scores` (`server_impl.py` line 2155) embeds the query and then calls `dense_path_scores`, so "the dense read in `_memory_candidate_scores`" includes inference. Requirement 2 says model inference must never run while the memory path holds a read transaction. AC-4 checks only the reranker, and AC-1 stubs the query embedder, so a literal implementation passes every AC and still breaks Requirement 2. With a Tensorwell or service embedder, `embed_query` is a cross-process call, so the read transaction lasts as long as that call. Repair: embed the query before entering the snapshot (pass the vector in, or split `_memory_candidate_scores`), and extend AC-4 so the stub embedder also records `snapshot_active == False`. The other option is to narrow Requirement 2 to the reranker and say that the query embedding is accepted inside the snapshot, as `docs_search` already does inside `_partial_index_read`.
3. **Other fallback windows remain, all fail-closed by design** (p3, executed, wrapped). Each gave `semantic_index_unavailable`:
   1. build_state `uninitialized`, the state after a version-gated store reset or a first build.
   2. `building` with no `model_versions` row.
   3. `building` with `model_versions` naming another model, as in a model-upgrade rebuild.

   A schema-mismatched store makes `read_snapshot` raise `StorageRecoveryRequired`, which Requirement 5 maps to fallback. So the fix ends the fallback only for ordinary incremental and full builds of a store that already holds a current-model publication. The Decision Log names the empty-store case. It should also name the model-upgrade rebuild, where the fallback lasts for the whole rebuild. Not blocking.
4. **Stale pin and WAL** (p2, executed). Inside one snapshot, a second connection committed a `layer_path_state` change and a finalize to `complete`. The snapshot kept reading `building` and the old hash. After the context exited, readers saw `complete`. While the snapshot was held, `wal_checkpoint(TRUNCATE)` returned busy `[1, 2, 0]` and PASSIVE could not reset the WAL `[0, 2, 0]`. After exit, TRUNCATE returned `[0, 0, 0]`. The writer was never blocked. Routine maintenance uses PASSIVE (`index_state_store.py` line 5326). TRUNCATE appears only in `sqlite_storage_migration.py` and waits up to the 5 s busy timeout. The whole wrapped query measured 0.55 s, so the pin is short. An interrupted epoch (`building` with no lock holder) serves the last committed rows indefinitely, but each served record is hash-verified and a new unpublished record trips `memory_vector_coverage_incomplete`. Acceptable.
5. **Decision Log rationale is factually wrong** (p4, executed). The rejected alternative "Treat `building` as servable without a snapshot" claims the hash check and vector read "would run as separate reads that a publication could split". They do not. `dense_path_scores` runs both inside one `with conn:` transaction. A publication committed from another connection between its hash SELECT and its vector SELECT was invisible: the old hash still matched and the old score was returned. The next call saw `source_current: false`. AC-2's known-bad direction (score differs with the snapshot removed) shows only that a later commit is visible. That is a valid committed state, not a mix of epochs. What the snapshot actually adds is consistency between `_ensure_loaded`'s model-identity read and the dense read. The Decision Log and the AC-2 rationale should say so. Not blocking, because the chosen design is still sound.
6. **Reranker on records whose source changed** (p5, executed). `memory_search_response` parses records at t0. `_memory_query_records` hashes the disk bytes at t1. I edited a record file between the two and published its new hash. The query returned `hybrid_rrf` with no stale fallback, while `records` still held the t0 parse. So the hash check verifies disk at t1 against the snapshot, not the parsed text the reranker scores and the response returns. The window is milliseconds, the behavior predates this wave, and the wave does not widen it. The reranker runs after the snapshot ends, on the t0 parse, which the hash check already accepted. Not blocking. Optional hardening: have the shared `memory_body_paths` hash the bytes that `load_memory_records` parsed.
7. **Windows locking** (not executed: macOS host). Reasoned from code only. WAL readers and writers do not block each other there either. `_delete_store_files` (`index_state_store.py` line 357) swallows `OSError` from `os.unlink`. On Windows, a store reset that runs while any reader holds the file open fails silently. This affects `docs_search` today and is not specific to this wave. The snapshot is 0.55 s, about as long as the existing `_open`-per-call reads, so the exposure is unchanged. A Windows run of AC-1 under `--profile second` would confirm it.

## Strongest alternative

Keep the snapshot design, and embed the query before entering the snapshot: pass the vector into a `dense_path_scores` call made inside the snapshot. This satisfies Requirement 2 literally, keeps AC-1 to AC-3, and costs one function split.

A leaner alternative: stop gating the memory path on `_ensure_loaded`, and check docs model identity in the same single `dense_path_scores` transaction. Probe 5 shows that transaction already makes the hash check and the vector read atomic. That would also stop memory queries from flipping the shared `WaveIndex` into partial mode. It is new code rather than reuse of the 215sy mechanism, so the planner's choice is defensible once the embedding is moved out.
