# Council chair, readiness, wave 248lb

Context: `248lb-council-chair-readiness`, fresh and independent. I wrote no finding, repair or lane approval.

## State checked

- `wf_review_wave(phase='prepare')`: code-reviewer, qa-reviewer, architecture-reviewer and docs-contract-reviewer approvals all current; lint passed.
- Ledger: 4 findings, all `do_now`, repair completed, terminal, no unresolved lanes: `248lb-sec-query-embed-inside-snapshot`, `248lb-code-embed-inside-snapshot-repair-constraint`, `248lb-arch-partial-read-contract-docs`, `248lb-qa-existing-mock-tests`.
- Read: spec `2475t` with its Decision Log, arc `244cm` track 2, every readiness and focused-r2 note in this folder.

## Seats

- red-team (fixed): `red-team-readiness.md`. Confirmed the embed-inside-snapshot defect independently, corrected the Decision Log rationale (probe 5), named the leaner alternative.
- security-reviewer (rotating): `security-reviewer-readiness.md` and `security-reviewer-focused-r2.md`. Owned the embed finding; the r2 probe showed both inference calls outside the snapshot, holds of a few ms, and fail-closed on a model change between snapshots.

## Strongest challenge and alternative

Red-team's leaner alternative: drop the `_ensure_loaded` gate and check docs model identity inside the one `dense_path_scores` transaction.

My executed check (below) shows why the plan is still the better choice:

1. `dense_path_scores` already serves a `building` store with no snapshot (`source_current` True, 20 scores), so the leaner path is feasible for the dense read.
1. But `dense_path_scores` reads no model identity, and a cold `WaveIndex` has an empty `_meta`. The leaner path therefore needs new model-identity SQL in the store layer and a separate source for query precision, or it caches full precision on a cold index (the Requirement 2 hazard).
1. It also leaves no partial token for `_attach_partial_index_coverage`, so AC-12's shared advisory would need its own epoch read.

The planned design reuses the shipped 215sy snapshot and the shared advisory helper. The leaner alternative is defensible, not better. Not adopted.

## Executed check

Script `/private/tmp/claude-502/-Users-coryhacking-Developer-wavefoundry/c49d4915-53cc-460a-9250-80578e2c9abc/scratchpad/chair/c.py`, run with `~/.wavefoundry/venv/bin/python -B` on a fresh scratch root (apsw backup of the index at generation 6387, complete, then `build_state` set to `building`; memory records copied). No repository file was touched.

| Step | Observed |
| --- | --- |
| Cold `WaveIndex` | `_meta` empty |
| `dense_path_scores` on `building`, no snapshot, no load | `source_current` True, 20 scores, complete |
| `dense_path_scores` source mentions `model_versions` | False |
| `_ensure_loaded` outside a snapshot (known-bad) | `IndexNotReadyError` |
| `_ensure_loaded` inside `read_snapshot` | loads, signature `('partial', ..., 'building', 6387, ...)` |
| `snapshot_active` after exit | False |

## Carry-forwards for implementation (non-blocking)

1. 39 mock tests break without the patch, not 25: `run_curated`'s snapshot adds 14 in `test_memory_eval.py`.
1. Patch `read_snapshot` on the module returned by `_load_script("sqlite_vector_store")`, not the public import.
1. `memory_eval._StubIndex` and other stubs need `index_dir`, `_meta` and the split methods.
1. AC-4 records every embedder call, not only the last.
1. AC-9 reads its build times from `build_state` (`read_build_state`), not the lock block.
1. Keep `_get_memory_reranker` outside both snapshots.
1. Compare model identity against a local value captured at the first load, not a re-read of `index._meta`.
1. The docs passages say memory uses two read transactions.
1. Note that memory fallbacks during a build show `source: stored_rows` from `_attach_partial_index_coverage`; decide and record whether fallbacks carry the advisory and with which `source`.
1. Add a Progress Log note that the two-snapshot Decision Log row also covers the model-identity recheck.

## Intent fit

Track 2 goal: memory search must not silently degrade to lexical during index builds, and `index_health` must show memory coverage.

- Change `2475t`: Requirements 1 to 7 and AC-1, AC-9, AC-12 address the build window; Requirement 9 and AC-7, AC-10 put coverage in `index_health`. The remaining fallbacks (empty store, model-change rebuild, stale source) are explicit and reported, not silent. Establishes.
- Wave Objective: same two outcomes, ranking unchanged. Establishes.

Worst verdict: `establishes`, at plan level. AC-9 is the live proof and stays the implementer's obligation.

## Verdict

Approve `council-readiness`.
