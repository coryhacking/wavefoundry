# Security reviewer (rotating council seat), readiness, wave 248lb

Context: `248lb-security-reviewer-readiness`, fresh and independent. No approval recorded. One finding recorded: `248lb-sec-query-embed-inside-snapshot` (do_now, blocking, execution_status inferred).

## Finding: query embedding runs inside the read snapshot

- Requirement 1 puts `index._memory_candidate_scores` inside `read_snapshot`.
- That method calls `self._embed_query` first (`server_impl.py` 2155-2158, then 2050). The call can cold-load the docs embedding model or make a Tensorwell service call.
- Requirement 2 says model inference must never run while the memory path holds an SQLite read transaction. The two requirements contradict each other.
- AC-4 records `snapshot_active` only in the reranker stub, so no AC catches the violation.
- Impact: availability only, and low. Lock hold time grows with inference latency. A held reader stops a checkpoint from advancing past its mark, so the WAL grows, and on Windows the reader delays any replacement of `index.sqlite`. The spec's own AC-4 rationale names these effects. No data is exposed.
- `docs_search` already embeds inside its snapshot, so this is not a new class of risk. It is a contradiction in the spec, and the fix is cheap.
- Suggested fix: compute the query vector before entering `read_snapshot`. Either split the embedding out of `_memory_candidate_scores` or pass it a vector. Then extend AC-4 to assert `snapshot_active` is False in the query-embedding stub too.

## Focus areas that hold

**Stale or deleted records through the snapshot: safe.**
- Candidates come from `memory_records.load_memory_records`, which walks the files on disk with a containment check. A deleted file is never a candidate, even when its vectors remain in the snapshot.
- Expected hashes come from the current file bytes. `dense_path_scores` compares them with `layer_path_state` in the same connection and returns early with `source_current: False` on any mismatch.
- So a record edited to remove a secret falls back with `memory_source_state_stale` until the edit is reindexed. Requirement 3 and AC-3 keep this rule.
- Only scores keyed by path leave the store. The returned records and the reranker texts come from the parsed files, never from chunk text.
- The snapshot does not weaken this. The hash and the vectors are read in one transaction, which AC-2 pins.
- Residual, pre-existing and out of scope: `docs_search` can still serve chunk text from a memory file whose secret was removed, until the next reindex.

**`index_health` coverage: no leak as specified.**
- `memory_vector_coverage` returns four integer counts, and the diagnostic names counts only. No ids, paths or bodies are returned.
- Non-blocking advice: make `coverage_unavailable_reason` a fixed token, not `str(exc)`. An `OSError` message carries a file path, and a parse error could quote record text.

**Read-only search: holds.**
- Requirement 8 and the Decision Log rule out any refresh from the read path.
- `read_snapshot` opens a read-only connection and ends with ROLLBACK.
- The current `_memory_query_records` triggers no refresh. Only the write handlers call `_trigger_background_index_refresh_for_paths`.
- AC-10 checks that `index_build_status` starts no new build.

**Lock behavior: no writer starvation.**
- WAL mode means a reader does not block the publication commit.
- The routine checkpoint is `PASSIVE` (`index_state_store.py` 5326), which never waits for readers. `TRUNCATE` runs only in storage migration.
- The `busy_timeout` values are bounded.
- The one duration risk is the finding above. Apart from it, the hold covers `_ensure_loaded` and one dense SQL query, the same as `docs_search`.
- Windows behavior matches the spec's Platform Behavior section, provided the hold stays short.

## Verification performed

- Read-only reads of `memory_handlers.py` 1629-1720, `server_impl.py` 1789-1870, 2050-2080, 2155-2162 and 5780-5806, and `sqlite_vector_store.py` 200-470.
- Read `memory_records.load_memory_records` and searched the tree for checkpoint modes.
- Ran no tests and made no repo edits. No memory records were touched, and `wf_memory_eval` was not run.
