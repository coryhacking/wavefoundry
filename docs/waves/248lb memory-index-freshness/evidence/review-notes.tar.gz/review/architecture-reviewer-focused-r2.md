# Architecture review, focused round 2 (wave 248lb)

Reviewer: architecture-reviewer, fresh and independent context `248lb-architecture-reviewer-focused-r2`. I wrote neither the round-1 finding nor the repair.

Verdict: `248lb-arch-partial-read-contract-docs` is repaired. Readiness approval recorded. Two non-blocking advisories for the implementer follow.

## Finding reverification
- The spec names all three closed-list passages in Affected Architecture Docs (line 166), in Scope (line 84) and in the docs task (line 120). The docs task says each passage lists four tools: `docs_search`, `code_search`, `code_ask` and `memory_search`.
- `docs/architecture/chunking-and-indexing-pipeline.md` is now a Serialization Point.
- The passages exist where the spec cites them: chunking line 925, search-architecture line 450 and mcp-tool-surface lines 1643 to 1662.

## AC-12 shape against the other three tools
I ran a probe on a scratch copy: `scratchpad/arch-r2-scripts/q.py` run on `scratchpad/arch-r2/root`. It called the real `server_impl._attach_partial_index_coverage` on a memory-shaped envelope with tool `memory_search`. Result:
- `index_coverage.complete` is false and `source` is `stored_rows`.
- The diagnostics hold exactly one `index_coverage_incomplete` entry.
- `retrieval` comes back unchanged (`hybrid_rrf`, `fallback_reason` None).

This matches what `_partial_index_read` attaches for `docs_search`, `code_search` and `code_ask`. Reusing the helper is the right layer, because it adds no second advisory shape.

## Two-snapshot design and model-change reload
- **Layering.** Load, then embed, then the dense read, then the rerank. Each SQLite read transaction stays one short read in the store layer, and inference stays in the handler. The probe confirmed that `snapshot_active` is False between the two contexts.
- **Model recheck.** In the probe, a model-change rebuild completed between the snapshots (generation +1, docs `model_versions` changed):
  - The second `_ensure_loaded` reloaded, because the signature changed.
  - `index._meta` exposed the new identity, so the planned comparison detects the change.
  - `dense_path_scores` returned with no error under the changed identity. That confirms the hash check alone does not catch a model change, so the recheck is needed and not redundant.
  - On a complete epoch, `_ensure_loaded` does not call `_layer_model_matches`, so the handler-level comparison is the only guard there. It belongs in the handler, which owns both snapshots. The `model@version` string comparison is conservative and acceptable.
- Baseline: `run_tests.py --file test_memory_records.py` ran 245 tests, OK.

## Advisories (non-blocking)
1. All three passages say partial reads come "from one SQLite read transaction". `memory_search` uses two. When the implementer adds it to the list, the passages must say that its load and its dense read are two snapshots. Otherwise the docs task's "list four tools" wording would make those passages false.
1. The existing contract says every response read during a partial epoch carries the advisory, including refusals and zero matches. AC-12 covers only the success path. The probe also showed that `_attach_partial_index_coverage` reads `data.fallback_reason` and `data.search_mode`, but memory nests them under `data.retrieval`. So a memory fallback during a build (stale or coverage incomplete) would report `source: stored_rows` while its results are lexical. The implementer should decide whether memory fallbacks during a build carry the advisory, and should pass or derive the right `source`. That choice belongs in the Progress Log and the docs.

No repository file was edited.
