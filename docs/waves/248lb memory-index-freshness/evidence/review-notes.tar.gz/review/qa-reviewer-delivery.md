# QA delivery review, wave 248lb (change 2475t)

Verdict: one blocking finding, `248lb-qa-class-wide-null-snapshot-masks-hermetic-path` (do_now, test-only repair). No approval recorded. Context `248lb-qa-reviewer-delivery`.

## Executed checks (scratch copy of the working tree)

- Focused suites, default and `--profile second`: `test_memory_records.py` 257, `test_memory_eval.py` 48, `test_inference_provider.py` 11, `test_tensorwell_integration.py` 31, `test_line_ending_census.py` 16. All OK under both profiles, 0 skipped, so `MemorySearchDuringBuildTests` ran with APSW.
- Null-patch census: with every `_null_read_snapshot` made a no-op, 38 distinct tests fail across the four files. This matches the implementer's count, minus two names in the list that pass unpatched (`test_curated_pass_never_rebinds_the_shared_commit_times_global`, `test_dense_ties_use_production_sort_order`), so the listed 38 is approximate but the patch target is right. The patch hits the `_load_script("sqlite_vector_store")` instance, and the flat `server_impl` alias resolves to `wf_server.server_impl`, so it is the same module. (`RealChildProcessCoherenceTests` also failed under bare `unittest`. It fails the same way on the unmutated copy. The cause is a `sys.path` artifact, and it passes under `run_tests.py`.)
- AC-2: an instrumented run shows the publication hook firing in `dense_path_scores`, inside its `execute`. The undisturbed and disturbed scores match, and a fresh read sees the rewrite.
- AC-4: the stub replaces `index._embed_query`. That is the only embed path, reached through `_memory_query_vector`. Every call is appended, and the assertions cover the whole list. The reranker records every `rerank` call.
- AC-10: I re-ran `impl/ac10.py` independently on a scratch temporary root, with the real indexer and model. Coverage went 3/3, then 2 covered and 1 stale with the diagnostic, `memory_source_state_stale`, and no new build (generation 1, same attempt, lock not held), then 3/3 again. The run calls the changed handlers in-process: the new `index_health` memory block and the two-snapshot search.
- AC-9 records are consistent. The epochs 1795486991.245 and 1795486998.310 convert to 02:23:11Z and 02:23:18Z on 2026-11-24, which is inside the 02:15:52Z to about 02:29Z run window. 606 model-screened plus 0 fallback matches the 606-probe corpus, and 174 covered matches the pre-run `index_health`. Limitations:
  - The end time is approximate ("before 02:30:03Z").
  - Generation 6395 is not described.
  - The brief says the generation-6396 build was a docs build, but the store recorded scope `all`.
  - The build was started by the coordinator, not by the server's own monitor.
  - Nothing shows that individual probes ran during the 7 s window. The AC only requires the timestamps to fall inside the run.

## Mutants (scratch copy, `run_tests.py --file test_memory_records.py --file test_memory_eval.py`)

| Mutant | Caught by |
| --- | --- |
| `_StubIndex` given a wrong `index_dir` | none (FINDING); caught by 2 hermetic tests once the class-wide patch is scoped |
| Advisory attached on any tuple token | AC-5 and others |
| Duplicate-path check removed | AC-6 |
| OSError mapped to candidate-unavailable | AC-6 |
| `complete` = covered > 0 | AC-7 |
| `index_health` snapshot removed | AC-7 unreadable-store test |
| `run_curated` startup snapshot removed (Req 13) | none, advisory |
| `_get_memory_reranker()` called inside the second snapshot | none, advisory (AC-4 records `rerank`, not model construction) |
| Diagnostic fires on stale only (Req 9.3) | none, advisory (the AC-7 fixture has stale and missing together) |
| Epoch token taken only from the first snapshot | none, advisory |

## Finding

`MemoryEvalTests.setUp` and `SituationQueryEvalTests.setUp` apply the null snapshot to every test in those classes. That includes the hermetic `evalh.run()` tests, whose `_StubIndex` reads a seeded store. Requirement 15 limits the patch to storeless stubs, and the Progress Log says the hermetic tests run unpatched, which is not true for the suite. Repair:

1. Scope the patch to the tests that need it: in `MemoryEvalTests`, only `test_available_memory_eval_preserves_repository_files`; in `SituationQueryEvalTests`, the storeless-stub tests.
2. Correct the Progress Log sentence.

Advisories, not blocking:

- Add a test for the `run_curated` startup snapshot.
- Add a missing-only coverage case.
- Optionally record `_get_memory_reranker` snapshot state in the AC-4 stub.
