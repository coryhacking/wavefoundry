# qa-reviewer focused readiness verification, round 2 (wave 248lb, change 2475t)

Fresh, independent context (`248lb-qa-reviewer-focused-r2`). I wrote neither the finding nor the repair. No repo edits: every probe ran on a throwaway git copy of `.wavefoundry/framework/` at `/private/tmp/claude-502/-Users-coryhacking-Developer-wavefoundry/c49d4915-53cc-460a-9250-80578e2c9abc/scratchpad/qa248r2/repo`, with `python3 -B` and `run_tests.py --file` or `--profile second --file` only.

## Verdict

`248lb-qa-existing-mock-tests` is repaired. The fixture rule in Requirement 13 keeps every broken existing test green without making the snapshot optional, and the real-snapshot ACs still discriminate. Readiness approval recorded. Five non-blocking advisories follow; none needs a re-ready round.

## What I applied to the copy

1. The planned production change, as Requirements 1 to 4 and 12 describe it:
   1. First `read_snapshot`: `_ensure_loaded`, docs-layer check, docs `model_versions` captured.
   2. Query embedding with no snapshot (`WaveIndex._memory_query_vector`).
   3. Second `read_snapshot`: `_ensure_loaded` again, model identity compared (fall back with `semantic_index_unavailable` on change), then `_memory_dense_scores`.
   4. Reranker outside both. `_memory_candidate_scores` split and removed; `memory_eval.dense_stream` uses the split; `run_curated` startup load inside a snapshot.
2. The fixture rule: mock-index tests patch `read_snapshot` to `contextlib.nullcontext`, and their stubs move to the split form.

## Executed results

| Run | Result |
| --- | --- |
| Wrap applied, tests unpatched | 39 distinct tests fail: 10 `test_memory_records.py`, 18 `test_memory_eval.py`, 1 `test_inference_provider.py`, 10 `test_tensorwell_integration.py` |
| Wrap applied, fixture rule applied, default profile | 245, 48, 11, 31 tests OK; `test_line_ending_census.py` 16 OK |
| Same, `--profile second` (5 files) | 351 tests, 0 of 5 files failed |
| AC probe (`test_qa_r2_acs.py`, real producer build, real `WaveIndex`, real `read_snapshot`), fix applied | 6 of 6 pass, both profiles |
| AC probe, production files reverted to the base tree | AC-1, AC-3 (stale record), AC-3 (model change between snapshots) and AC-4 FAIL; AC-2 and AC-3 (no model identity) pass |
| AC probe, model recheck removed | only AC-3 (model change) fails, so the recheck, not the compatibility check, catches it |
| AC probe, first snapshot removed | AC-1, AC-3 (stale), AC-4 fail |
| AC probe, embedding moved inside the second snapshot | AC-3 (model change), AC-4 fail |
| AC probe, embedding before the first load | AC-3 (model change), AC-4 fail (after the probe recorded every embedder call; see advisory 4) |

AC-2 passing on reverted code matches the spec: it is labelled a regression guard on the one-transaction dense read, and its known-bad control is AC-1's.

Probe: `/private/tmp/claude-502/-Users-coryhacking-Developer-wavefoundry/c49d4915-53cc-460a-9250-80578e2c9abc/scratchpad/qa248r2/probe/test_qa_r2_acs.py`. Logs: `/private/tmp/claude-502/-Users-coryhacking-Developer-wavefoundry/c49d4915-53cc-460a-9250-80578e2c9abc/scratchpad/qa248r2/*.log`.

## Advisories (non-blocking)

1. **The breakage count is now 39, not 25.** Requirement 12 puts `run_curated`'s startup load in a snapshot, so every `run_curated` case with `_ArmIndex` and the hermetic `evalh.run` (through `memory_eval._StubIndex`) now enter `read_snapshot`. `test_memory_eval.py` goes from 4 to 18. The fixture rule covers all of them, and the Task already asks the implementer to list exact names, so the stale "25" in the Tasks is informational.
2. **The null patch alone is not enough for stubs without `index_dir` or `_meta`.** `index.index_dir` is evaluated before the patched call, so `__new__`-built `WaveIndex` objects (`test_inference_provider.py`, `test_tensorwell_integration.py`), `_DeterministicIndex` in `test_memory_eval.py` and `memory_eval._StubIndex` need an `index_dir`. The Requirement 4 model recheck reads `index._meta`, which `_ArmIndex` and `_StubIndex` lack. `memory_eval._StubIndex` is production-module code, not a test, and also needs the split form; the Tasks name only test stubs.
3. **Patch the loaded module instance.** `memory_handlers` reaches `read_snapshot` through `server_impl._load_script("sqlite_vector_store")`, which is a different module object from `import sqlite_vector_store` (executed: `is` returned False). Patching the public import leaves the tests red.
4. **AC-4 must check every embedder call.** A recorder that keeps only the last call misses an embedding that runs before the first load, because the later in-order call overwrites it. Recording each call and asserting all of them caught it.
5. **AC-9's timing source.** `index_build_status` exposes the epoch's `status`, `generation` and `scope` only. `started_at` and `completed_at` are in the store's `build_state` row (`index_state_store.read_build_state`); the lock block carries `started_at` and `ended_at`, which span the lock, not the epoch. The epoch's begin to finalize is exactly the `building` window, so a recorded epoch inside the run window does prove overlap with the continuous probe stream. Naming the source would avoid the implementer using the lock times.

## AC-12 and sizing

- AC-12 is implementable as written: `_attach_partial_index_coverage(result, root, epoch_state, tool)` needs the partial token that the second snapshot's `_ensure_loaded` stores in `index._loaded_meta_signature["project"]`, so the implementer threads it from `_memory_query_records` to `memory_search_response`. Its known-bad (advisory absent) is stated. Inspected, not executed.
- Twelve ACs suit a bug fix with a health block and a contract advisory. AC-5 and AC-12 are complementary (complete epoch carries no advisory; building epoch carries it), and AC-2 and AC-5 are labelled regression guards. No sizing defect.
