# docs-contract-reviewer focused r2 notes (wave 248lb)

Verdict: no blocker. Readiness approval re-recorded on receipt review-policy-9654c09f6aba26ad5cf6.

Read: spec Requirements 4, 6, 14-15, Scope, ACs 1-12, AC Priority, Decision Log, Affected Architecture Docs; arc track 2 row.

1. Doc scope. The three partial-read passages exist where the spec says: `chunking-and-indexing-pipeline.md` line 925, `search-architecture.md` line 450 (lists `code_search`, `code_ask`, `docs_search`), and `mcp-tool-surface.md` near line 1655. `_attach_partial_index_coverage(result, root, epoch_state, tool)` exists in `server_impl.py` with the signature Requirement 6 assumes. CHANGELOG has `### Fixed` sections.
2. AC-12 and AC priority table agree with Requirement 6 and the Decision Log row on the advisory.
3. Arc track 2 row states the follow-up for `_index_chunk_matching_address` and matches the spec's Out of scope and Decision Log.
4. Advisory, no block: the Decision Log row for the two-snapshot read says the build between snapshots is guarded by the hash check, and omits the model-identity recheck that Requirement 4 and AC-3 add. Requirement 4 opens with "needs no special handling" before adding the recheck. Fix wording at implementation or in a Progress Log note; do not edit the spec after readiness.
5. No em-dashes in the spec. `wf_validate_docs`: passed, no errors or warnings.
