# qa-reviewer readiness notes (wave 248lb, change 2475t)

Fresh, independent context. No repo edits. Probes ran on a throwaway copy of `.wavefoundry/framework/` under the session scratchpad, with `python3 -B`.

## Verdict
Two blocking findings, both small plan repairs. The core mechanism and the AC-1 and AC-2 known-bad controls hold.

## Executed checks
- Baselines, default and `--profile second`: `test_memory_records.py` (245), `test_memory_eval.py` (48), `test_line_ending_census.py` (16) all pass. `test_inference_provider.py` (11) and `test_tensorwell_integration.py` (31) pass on default.
- AC-1 probe, real indexer with fake embedder, real `WaveIndex`, stub query vector and reranker. Records `r1` and `r2` under `docs/agents/memory/`.
  - Original code, `complete`: hybrid_rrf, `[r1, r2]`.
  - Original code, after `begin_build_epoch`: `None`, `semantic_index_unavailable`.
  - Copy with the load, the hash loop and `_memory_candidate_scores` wrapped in `read_snapshot`, in `building`: hybrid_rrf, `[r1, r2]`. The reranker saw `snapshot_active == False`.
  - AC-1 discriminates.
- AC-2 probe. A hook in `dense_path_scores` runs `begin_build_epoch`, then commits an UPDATE of `r1`'s `vectors_docs` rows from a second read-write connection (`BEGIN IMMEDIATE`).
  - Original code: `r1` score went from 0.9558 to 0.0, and `fallback_reason` stayed `None`.
  - Wrapped copy: the score was unchanged (0.9558), and the writer committed while the reader held its snapshot (no writer starvation).
  - AC-2 discriminates, and only through the score assertion, as the spec says.

## Findings
1. **248lb-qa-existing-mock-tests** (blocking). With the planned wrap applied to the copy, 25 existing tests fail across four files:
   - 10 in `test_memory_records.py`
   - 4 in `test_memory_eval.py`
   - 1 in `test_inference_provider.py`
   - 10 in `test_tensorwell_integration.py`

   They use `MagicMock` or stub indexes with no store. Under Requirement 5, `read_snapshot` then fails and the query falls back. `test_inference_provider.py` and `test_tensorwell_integration.py` are named nowhere in Scope or Serialization Points, and `test_memory_eval.py` is missing from Serialization Points. The plan does not say how these fixtures adapt. An implementer could keep them green by making the snapshot optional. AC-11 cannot pass inside the declared scope.

   Repair: add the three files to Scope and Serialization Points, and state the fixture rule. Mock-index tests patch `read_snapshot` to a null context. AC-1 to AC-4 keep the real snapshot.
2. **Query embedding inside the snapshot** (not recorded as a separate qa finding, because `248lb-sec-query-embed-inside-snapshot` and `248lb-code-embed-inside-snapshot-repair-constraint` already record it, with the same AC-4 blind spot; qa concurs). `WaveIndex._memory_candidate_scores` (`server_impl.py` line 2158) calls `_embed_query` before `dense_path_scores`, so Requirement 1 puts query-embedding inference inside the read transaction. That contradicts Requirement 2, "Model inference must never run while the memory path holds an SQLite read transaction". AC-4 records `snapshot_active` only in the reranker stub, so it cannot detect the violation.

   Repair: embed the query before entering `read_snapshot` (pass the vector in, or split the method), and have AC-4 also record `snapshot_active` in the query-embedding stub. Alternatively, narrow Requirement 2 to the reranker and say why, citing `_partial_index_read`, which embeds and reranks inside its snapshot.

## Non-blocking observations
- AC-9 cannot pass vacuously on the build condition. `generation` increments only at `finalize_build_epoch` (`index_state_store.py` line 3331), so an advance means a build finished during the run. A build could still overlap no probe. Recording the build's `started_at` and `completed_at` against the run window would close that gap.
- AC-10 proves that `index_health` detects an outside edit as stale, that search stays read-only, and that `index_build` update re-covers the record. It does not exercise the monitor; AC-8 covers that by unit test, and the pair is adequate.
  - MCP tools are bound to the server root, so AC-10 on a temporary root needs handler-level calls (`index_health_response(root)` and similar) or a second server. The AC should name which.
- AC-3's second clause is a negative control that also holds with the fix reverted. Its first clause (stale while building) fails when the fix is reverted. That is acceptable.
- Size: 11 ACs suit a bug fix plus a health block. AC-5 could fold into AC-1, but the count is not a defect.
