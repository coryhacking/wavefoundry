# Council-chair delivery notes, wave 248lb (change 2475t)

Context `248lb-council-chair-delivery`, fresh and independent. Verdict: APPROVE, intent_fit `establishes`. No repo edits besides this file and the ledger event.

## State checked
- `wf_review_wave(phase='implementation')`: code, qa, architecture and docs-contract delivery approvals current. Pending: council-delivery and operator-signoff.
- Ledger chain summary: all 7 findings terminal (6 `do_now` completed, `248lb-arch-arc-track2-row-stale` `maybe_later` completed), no unresolved lanes, 0 `security_unsettled`.
- Spec: 12 ACs and all tasks `[x]`; Change Status `implemented` in spec and wave.md.

## Executed checks
- `run_tests.py --file test_memory_records.py`: 263 tests OK.
- Own mutant on a scratch rsync copy: removed the second-snapshot docs model identity recheck in `_memory_query_records`. Killed by `test_ac3_model_change_between_snapshots_falls_back` (1 of 263 failed). Scratch copy deleted; repo tree unchanged.
- `arc_row_probe.py`: PASS on the live arc; FAIL (9 items) on `stale_arc_copy.md`.
- Relied on, not rerun: `full-suite-2.log` 13,444 OK; `second-2.log` 0 of 258 failed; AC-9 live run (0 of 606 fallbacks, `production_measured: true`, build 6396 inside the run window).

## Seats
- red-team: read the `memory_handlers` diff. Load and identity capture in snapshot 1, hashing and embedding with no snapshot, reload, identity recheck and dense read in snapshot 2, rerank after both. Mutant above killed.
- security-reviewer: search stays read-only (no refresh trigger); `memory_body_paths` refuses paths outside the root and duplicates; health block emits fixed tokens only; `index_dir` matches `WaveIndex` (`root/.wavefoundry/index`); no inference inside a read transaction (AC-4).

## Strongest challenge
AC-9's overlapping build was started by the coordinator and lasted 7 s; nothing shows individual probes ran inside it. Answer: the AC requires only timestamps inside the run; 0 of 606 fallbacks versus 7 to 15 before; AC-1 to AC-4 prove the building-state path deterministically on a real store.

## Strongest alternative
Embed inside one snapshot, as `docs_search` does. Rejected in the Decision Log: a cold model load would hold the read transaction for seconds.

## intent_fit
`establishes`. Track 2 goal: memory search no longer silently degrades to lexical during builds (AC-1, AC-9, AC-12 advisory), and `index_health` shows memory coverage with stale apart from missing (AC-7, AC-10). Wave Objective holds: ranking, threshold and admission unchanged; held-out metrics equal the 245na baseline.

## Advisories (non-blocking)
- Arc row 63 still says "repair cycle 2 is in progress"; refresh at close.
- `docs/architecture/chunking-and-indexing-pipeline.md` Last verified needs gardening.
- Windows and WSL2 behavior inferred from the shared `read_snapshot` path, not executed.
