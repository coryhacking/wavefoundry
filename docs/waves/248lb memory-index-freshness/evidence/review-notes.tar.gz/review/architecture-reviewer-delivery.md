# architecture-reviewer delivery notes, wave 248lb (change 2475t)

Context: `248lb-architecture-reviewer-delivery`, fresh and independent. No repo edits other than this file. No memory record touched. Full suite and `wf_memory_eval` not run.

## Verdict

Approval withheld for now. I recorded two findings. Both are non-blocking, `do_now`, low impact and bounded. Once they are repaired, the lane can approve without further code review.

1. `248lb-arch-arc-track2-row-stale`: the arc 244cm Progress row for 248lb still says "Planned 2026-11-23, not readied ... awaiting reverification". The wave is `implementing` and AC-9 is met. "Nothing in this arc is delivered yet" and the Next step text ("then plans track 2") are stale too. Ledger note: this record defaulted to `execution_status: executed`, but the check was a read-only comparison, so `inferred` is the honest label.
2. `248lb-arch-health-complete-stale-only-unpinned`: a mutant that sets `complete = missing_paths == 0` survives all 257 tests. The AC-7 fixture never has stale above 0 with missing at 0. Suggested fix: add a subTest where only one record is stale, and assert `complete is None` in the unreadable-store test. The `record_unreadable` token is also untested.

Outside this lane: the spec header and wave.md still show `Change Status: planned`.

## Layering

- `memory_records.memory_body_paths` adds no imports. It uses `hashlib`, which the module already imports. Probe: importing `memory_records` and `sqlite_vector_store` in a fresh `python3 -B` loads no `memory_eval`, `wf_server`, `indexer`, `numpy`, `onnxruntime`, `torch` or `tokenizers`. The builder is model-free.
- `index_handlers._memory_coverage_block` imports `wf_server.server_impl` lazily and goes through `_load_script`, the same pattern as the rest of the module. It creates no new import edge at module load, so there is no cycle.
- `memory_eval` reaches the builder through `srv._memory_mod()` and `mem`. Its own copy is deleted. AC-6 holds: there is one definition.
- The `server_impl` split into `_memory_query_vector` (inference only) and `_memory_dense_scores` (one store read) is clean. `memory_handlers` owns the snapshot choreography and the store module keeps the transaction. That fits the existing layering.

## index_health `data.memory`

- The block is added after `state_store` and `capacity` on the success path only. The `docs_health()` error path returns before it, which is consistent with the other blocks.
- Shape: `{memory_vector_coverage: {requested_paths, covered_paths, stale_paths, missing_paths}, complete}`. On failure it is `{memory_vector_coverage: null, complete: null, coverage_unavailable_reason: store_unreadable|record_unreadable}`. This matches the tool-surface row.
- Minor: a repository with no index store reports `store_unreadable`, which reads as corruption rather than absence. This is not a finding. Other `index_health` diagnostics already cover a missing layer.
- Each call now hashes every surfaced memory body, about 174 files here. That is acceptable.
- Mutants on a scratch copy of `_memory_coverage_block`: loading `memory_eval` was caught, exception text in the reason was caught, and removing the snapshot was caught (only through the raising-snapshot test). The stale-only `complete` mutant survived (finding 2).

## Docs

All three partial-read passages list four tools and say that memory uses two read transactions:

- `docs/specs/mcp-tool-surface.md`: the partial-epoch paragraph names four tools and two transactions. The `index_health` row gains `memory`.
- `docs/architecture/search-architecture.md`: the partial-read passage names `memory_search` as the fourth tool and says it uses two read transactions. The Agent memory retrieval paragraph describes both snapshots, the model recheck and the `stored_rows` fallback note.
- `docs/architecture/chunking-and-indexing-pipeline.md`: the advisory section adds `memory_search` and a two-transaction paragraph.

CHANGELOG Added and Fixed entries are accurate.

## Portability

The spec's Platform Behavior claims hold for the code as built:

- Each snapshot holds one read with no inference inside it. The embedder and the reranker run outside both snapshots (AC-4 test and implementer mutants).
- WAL reader semantics on macOS and Linux, and `LockFileEx` on Windows, are the same path `docs_search` uses.
- The health block opens one short snapshot.
- Path keys are POSIX `relative_to(...).as_posix()`, so Windows separators normalize.
- Hashes are of raw bytes, so CRLF checkouts compare against their own index.
- WSL2 under `/mnt/` keeps SQLite's existing locking limits.

Not executed on Windows or WSL2. These are inferred from the code and the shared read path.

## Executed checks

- `run_tests.py --file test_memory_records.py`, default profile: 257 tests, OK.
- `--profile second`: 0 of 1 files failed.
- Scratch-copy baseline: 257 OK. Four mutants: three caught, one survived.
