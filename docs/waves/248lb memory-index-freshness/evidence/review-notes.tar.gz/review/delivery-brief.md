# Delivery review (wave 248lb, change 2475t)

The change `2475t-bug memory-search-falls-back-during-index-build` is implemented. Its spec is in `docs/waves/248lb memory-index-freshness/`, and it is track 2 of the arc `docs/arcs/244cm memory-quality/244cm-arc memory-quality.md`.

## Delivered
- **Memory search keeps semantic retrieval during an index build.**
  - The index loads inside a first `read_snapshot`, which fixes model identity and precision.
  - The query is embedded outside any snapshot.
  - `dense_path_scores` runs inside a second snapshot. If the docs model changed between the two snapshots, the search reloads and falls back.
  - The reranker runs outside both snapshots.
- **Advisory:** a read during a build carries the `index_coverage_incomplete` advisory, the same as `docs_search`, `code_search` and `code_ask`. A fallback during a build also carries `source: stored_rows`.
- **Coverage in `index_health`:** `data.memory` reports memory coverage, with stale counted separately from missing. When the store or a record can't be read, `complete` is null. The body-path and source-hash builder moved to `memory_records.py`.
- **Eval startup:** `memory_eval` startup loads inside a snapshot.
- **Read-only search:** `memory_search` stays read-only, by operator decision.
- **Files changed:** `memory_records.py`, `memory_eval.py`, `wf_server/memory_handlers.py`, `wf_server/index_handlers.py`, `wf_server/server_impl.py`, four test files, the CHANGELOG, `docs/specs/mcp-tool-surface.md`, `docs/architecture/search-architecture.md` and `docs/architecture/chunking-and-indexing-pipeline.md`.

## Verification so far
- **Tests:**
  - The full suite ran 13,438 tests, OK. The second profile failed 0 of 258 files.
  - The logs are `.wavefoundry/work/248lb/impl/full-suite-1.log` and `second-1.log`.
- **Mutants:** these were caught on a scratch copy:
  - the first snapshot removed
  - the embedding moved inside a snapshot
  - the embedding moved before the first load
  - the reranker moved inside a snapshot
  - the model recheck removed
  - the advisory not attached

  AC-2 is a regression guard.
- **AC-9 (live):**
  - `wf_memory_eval` ran through MCP after a restart, from 02:15:52Z to about 02:29Z.
  - A docs build, generation 6396, ran from 02:23:11Z to 02:23:18Z, inside the run window.
  - Result: `production_measured: true`, 606 probes model-screened, 0 fallbacks.
  - Before this change, the same overlap lost 7 to 15 probes.
- **AC-10:** passed on a temporary corpus.

## Implementer deviations to check
- 38 mock tests needed the null-context patch, not 39. The hermetic eval tests read through the real snapshot.
- `_memory_query_records` gains an optional `epoch_out`.
- A fallback during a build carries the advisory.
- `memory.complete` is null on a read failure.

## Your task, as a FRESH, independent reviewer of your lane
1. **Read.** Load the MCP tools via ToolSearch first, and use code_* MCP-first. Read the spec, its Progress and Decision Logs, and `git diff` for your remit.
2. **Verify each AC in your remit with EXECUTED checks.**
   - Use mutants on a scratch copy, probes, and focused tests through `run_tests.py --file`, under both the default profile and `--profile second`.
   - Never run the full suite. Do not run `wf_memory_eval`.
   - Make NO repo edits, and do NOT mutate memory records.
3. **Record in the typed ledger** (`wf_review_event`, wave `248lb`). Dry-run first, then create.
   - For a defect, record a finding: `run_kind='initial_delivery'`, cycle 0, `actor=<lane>`, `context_id='248lb-<lane>-delivery'`.
   - Otherwise record the approval: `signoff_key=<lane>`, `approval_phase='delivery'`, `fresh_context=true`, `independent=true`, executed, with your OWN honest `integrity_checks`.
4. **Write notes** to `.wavefoundry/work/248lb/review/<lane>-delivery.md`. No em-dashes.
5. **Reply** in under 100 words.
