# Focused readiness verification, round 2 (wave 248lb)

Round 1 recorded four blocking findings against 2475t:

| Finding | Recorded by |
| --- | --- |
| `248lb-sec-query-embed-inside-snapshot` | security-reviewer |
| `248lb-code-embed-inside-snapshot-repair-constraint` | code-reviewer |
| `248lb-arch-partial-read-contract-docs` | architecture-reviewer |
| `248lb-qa-existing-mock-tests` | qa-reviewer |

The planner (context `248lb-planner-repair-1`, cycle 1) repaired the spec. It now has 12 ACs.

## The repair

All decisions below are recorded in the Decision Log.

**Embedding.**
- Load the index (`_ensure_loaded`, model identity, precision) inside a first `read_snapshot`.
- Embed the query outside any snapshot.
- Run `dense_path_scores` inside a second snapshot.
- The second snapshot reloads the index and falls back if the docs model changed between the two snapshots (Requirement 4, AC-3). This part is new: it is the planner's addition, and you should review it.
- The reranker runs outside both snapshots.
- AC-4 uses a stub embedder and a stub reranker, and each asserts that no snapshot is active.

**Partial-read contract.** `memory_search` reports `index_coverage_incomplete` when it reads during a build (AC-12). The three docs now list four tools.

**Mock tests.**
- The Serialization Points gain `tests/test_inference_provider.py`, `tests/test_tensorwell_integration.py` and `tests/test_memory_eval.py`.
- Mock-index tests without a store patch `read_snapshot` to a null context.
- AC-1 to AC-4 keep the real snapshot.

**Other changes.**
- The startup load in `memory_eval` moves inside a snapshot.
- AC-9 records the build's start and end against the run window.
- AC-10 names how it calls the handlers on a temporary root.
- The Decision Log is corrected: `dense_path_scores` is already a single transaction. The snapshot's real gain is consistency of the model identity.
- The model-change rebuild is named.
- The Windows wording now covers checkpoint growth and `_delete_store_files`.
- AC-5 now guards the complete epoch, with no advisory. AC-2 is a regression guard, rated important.
- `_index_chunk_matching_address` is declined for this wave and recorded in arc track 2.

Get the current receipt from `wf_review_wave(wave_id='248lb', phase='prepare')`.

## Your task, as a FRESH, independent reviewer who wrote neither the finding nor the repair

1. Load the MCP tools via ToolSearch first, and use code_* MCP-first. Read your lane's round-1 notes in this folder and the changed spec sections.
2. Verify the repair against the code with an executed probe on a scratch copy.
   - You may reuse the round-1 code-reviewer probe at `/private/tmp/claude-502/-Users-coryhacking-Developer-wavefoundry/c49d4915-53cc-460a-9250-80578e2c9abc/scratchpad/probe/p.py`, adapted.
   - Make NO repo edits.
   - Run `run_tests.py --file` only, never the full suite.
3. If you own a finding, record its reverification:
   - `event='finding'`, `run_kind='reverification'`, with the cycle that `wf_review_wave` recommends
   - `blocking_required_lanes=[]` only if the repair holds
   - `fresh_context=true`, `independent=true`, `actor=<lane or seat>`, `context_id='248lb-<lane>-focused-r2'`
   - executed evidence
   - dry-run first, then create
4. Required lanes (code-reviewer, qa-reviewer, architecture-reviewer and docs-contract-reviewer) then record a readiness approval on the current receipt, as executed, with their OWN honest `integrity_checks`. The security seat records only its reverification. A new blocking defect gets a finding.
5. Write notes to `.wavefoundry/work/248lb/review/<lane>-focused-r2.md`. No em-dashes.
6. Reply in under 80 words.
