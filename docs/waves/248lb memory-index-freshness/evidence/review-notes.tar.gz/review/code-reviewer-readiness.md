# Code review, readiness (wave 248lb)

Reviewer: code-reviewer, fresh and independent context.
Verdict: one blocking finding, `248lb-code-embed-inside-snapshot-repair-constraint`. It is the same defect as the security seat's `248lb-sec-query-embed-inside-snapshot`, plus a constraint on the repair: the repair that finding proposes is unsafe on a cold index. No approval until it is repaired.

## Root cause, executed on a throwaway copy
I made an apsw backup of `.wavefoundry/index/index.sqlite` (generation 6375, complete) and copied `docs/agents/memory/` into the scratchpad. I set `build_state.status='building'` on the copy. I ran a real `WaveIndex` with only `_embed_query` and `_get_memory_reranker` stubbed, on 174 surfaced records. No repository file was touched.

| Run | Result |
| --- | --- |
| `_memory_query_records`, no snapshot | `None`, `semantic_index_unavailable`, `lexical_policy` |
| Same call inside `read_snapshot` | 5 records, `fallback_reason None`, `hybrid_rrf` |
| Inside snapshot, one record file edited | `None`, `memory_source_state_stale` |

The chain in the spec holds. Every anchor resolves: `begin_build_epoch` line 3281, `finalize_build_epoch` 3314, `build_epoch_token` 3597, `read_snapshot` 238, `_index_meta_signature` 1789, `_ensure_loaded` 1815, `_memory_query_records` 1629, `_partial_index_read` 5780, `_maybe_refresh_if_stale` 8426.

## read_snapshot and _ensure_loaded
- **Reentrant.** A nested `read_snapshot` on the same file yields inside the outer one. The context variable lives in `sqlite_runtime`, so both module instances share it. `index_state_store` (lines 396, 1002) and `sqlite_vector_store._open` borrow the snapshot connection.
- **Savepoints are safe.** `dense_path_scores` uses `with conn:` on the borrowed connection. With apsw that is a savepoint, so the outer read transaction survives.
- **Load compatibility.** Inside the snapshot `_index_meta_signature` returns `('partial', ...)`, so `_ensure_loaded` loads with `_partial=True`. After the context ends, the next call outside a snapshot sees `None` and raises again. No partial state leaks out of the snapshot.
- **Caveat (non-blocking).** If a caller ever wraps `memory_search_response` in its own snapshot, the nested context does not end at the reranker. Requirement 2 then fails silently. No caller does this today.

## The per-record hash check inside the snapshot
`dense_path_scores` reads `layer_path_state` and the vectors over the same connection. Inside the snapshot that is one read transaction. The indexer writes hashes in its single publication transaction (lines 6170 to 6178). The reaper deletes chunks and hashes together (line 2618). No writer updates a hash apart from its vectors in a way a snapshot could split. The stale probe above confirms the guard still fires.

## Blocking: query embedding inside the snapshot, and the repair constraint
- **The defect.** `_memory_candidate_scores` (line 2155) calls `_embed_query` before `dense_path_scores`. Requirement 1 puts that call inside the snapshot. Requirement 2 says no model inference runs inside it. AC-4 stubs only the reranker, so it cannot catch this.
- **Why it matters.** `_get_embedder` notes a first-query CoreML compile of about 40 s. On a cold server, the memory path would hold a read transaction that long.
- **The repair constraint.** The obvious repair is to embed before entering the snapshot. On a cold `WaveIndex` that is wrong. `_get_embedder` (lines 1944 and 1990) chooses the query precision from `self._meta` model_versions, and `_ensure_loaded` fills `_meta`. Called before the load, it takes the full-precision path. It caches that embedder in `self._embedders` for the life of the process. On an INT8 index, query and index precision then stay mismatched.
- **Repair options.** The spec must choose one:
  1. Run `_ensure_loaded` in a first snapshot, then embed outside it. Then open a second snapshot for `_ensure_loaded` again and `dense_path_scores` alone. AC-2's consistency only needs the hash check and the vector read in one snapshot, and `dense_path_scores` has both. Extend AC-4 so the embedding stub also records `snapshot_active`, and add `server_impl.py` to the Serialization Points if `_memory_candidate_scores` is split.
  1. Or narrow Requirement 2 to the reranker, with the 40 s first-call cost stated and accepted. `docs_search` already embeds inside its snapshot.

## Other callers with the same unprotected pattern (non-blocking, out of scope)
- `memory_eval.run_curated` line 1405 calls `_ensure_loaded` outside any snapshot. If a build is `building` when the run starts, the whole report is unavailable. The architecture reviewer noted this for AC-9 as well.
- `memory_eval.dense_stream` (line 1213) calls `_memory_candidate_scores` with no load check and no snapshot. It reads during a build, hash-checked but not snapshot-consistent. It is sanity floor and ablation only.
- `index_handlers._index_chunk_matching_address` (line 1044) returns `None` during any build. It serves address lookup at `server_impl.py` line 7432.
- `search_docs`, `search_code` and `search_combined` are reached only through the three tools that `_partial_index_read` wraps.

## AC falsifiability
- AC-1, AC-2 and AC-3 can fail, and their known-bad runs are well defined. The AC-1 reranker stub returns 0.0, above `MEMORY_QUERY_MIN_LOGIT = -4.0`, so "returns both records" is reachable.
- AC-4 can fail for the reranker only (see the blocker).
- AC-5 passes before and after the fix, because `memory_search` is never routed through `_partial_index_read`. It is a regression guard, which suits its `important` priority.

## Platform
- **WAL.** Readers and the writer do not block each other on POSIX or Windows. A held reader only stops a checkpoint from moving past its mark.
- **Windows file replacement.** I agree with the architecture reviewer: no build path replaces `index.sqlite`, so that bullet should cite checkpoint growth instead.
- **Fallback on storage errors.** The existing `except Exception` already turns `StorageRecoveryRequired` and `RuntimeUnavailable` from `read_snapshot` into a fallback, as Requirement 5 asks.
