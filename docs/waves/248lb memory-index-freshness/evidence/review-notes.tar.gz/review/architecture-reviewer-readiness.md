# Architecture review, readiness (wave 248lb)

Reviewer: architecture-reviewer, fresh and independent context.
Verdict: one blocking finding (`248lb-arch-partial-read-contract-docs`). I corroborate the security seat's finding `248lb-sec-query-embed-inside-snapshot` and record no approval until both are repaired.

## Root cause, executed on a throwaway copy
I copied `.wavefoundry/index/`, `docs/agents/memory/` and `.wavefoundry/framework/` into the scratchpad and set `build_state.status='building'` on the copy. No repository file was touched.
- Outside a snapshot, `WaveIndex._ensure_loaded` raised `IndexNotReadyError`. That confirms the chain in the spec.
- Inside `sqlite_vector_store.read_snapshot`, the index loaded with signature `('partial', ...)` and `_docs_vector_layer` was set. `memory_vector_coverage` returned 174/174 covered.
- After the context closed, `_ensure_loaded` raised again. The snapshot is the right lever.

## Snapshot boundary
- **Right layer.** `_index_meta_signature` already serves the partial token only inside `read_snapshot`, so wrapping the memory read reuses the 215sy mechanism with no new state.
- **No shared helper with docs_search, correctly.** `_partial_index_read` raises `StorageRecoveryRequired` where memory must fall back (Requirement 5). It attaches the `index_coverage` warning, which Requirement 4 removes. It also holds the snapshot through inference. A direct `read_snapshot` call in `_memory_query_records` is the simplest fit.
- **Corroborated blocker.** `_memory_candidate_scores` (`server_impl.py` line 2155) calls `_embed_query` before `dense_path_scores`. So Requirement 1, which puts that call inside the snapshot, contradicts Requirement 2's rule that no model inference runs inside it. AC-4 stubs only the reranker and cannot catch this. My preferred repair:
  1. Embed the query before entering the snapshot, and call `sqlite_vector_store.dense_path_scores` inside it.
  1. Add `server_impl.py` to the Serialization Points if `_memory_candidate_scores` changes.
  1. Extend AC-4 to the embedding stub.

  Narrowing Requirement 2 to the reranker would also be honest. `docs_search` already embeds inside its snapshot.
- **Platform note (non-blocking).** The Windows bullet says a build that must replace `index.sqlite` waits for readers. No build path replaces that file: I found no `os.replace` or rename on it in `sqlite_vector_store`, `index_state_store` or `indexer`. The bullet should cite WAL checkpoint growth, or be dropped.

## Shared module
Placing `memory_body_paths` in `memory_records.py` is right:
- It is a leaf module that already imports `hashlib` and reads record files.
- Both callers load it.
- It removes the health check's dependency on `memory_eval`.
- It is also the natural home for the target-resolution primitive that tracks 3 and 4 will share.

Requirement 6's ValueError and OSError mapping preserves today's fallback reasons.

## index_health shape
`data.memory` sits as a sibling of `graph`, `state_store` and `reap`, which matches the existing summary-block pattern. It reads published state inside one snapshot, so it is consistent during a build. The diagnostic reuses the `memory_vector_coverage_incomplete` token with the same meaning as the search fallback, which is good. The null-plus-reason degradation keeps `status: ok`, consistent with other advisory blocks. No change needed.

## Fit with the arc
- **Track 1 signals.** `fallback_probes` and `index_signals.memory_vector_coverage` are measured unchanged. The eval keeps calling the shared builder, so production and eval hash the same paths.
- **Advisory, AC-9.** `memory_eval.run_curated` itself calls `index._ensure_loaded()` outside any snapshot at start (line 1405). So if a build is already `building` when the run starts, the whole report is `_unavailable`. That fails loudly and does not violate AC-9. The eval's own `dense_stream` and ablation arms also still read outside a snapshot. The implementer should start the AC-9 run on a complete epoch and expect the build to begin mid-run.
- **Tracks 3 and 4.** No conflict. The read-only search decision and the reliance on the monitor leave revalidation to track 4.

## Architecture docs (the blocking finding)
The spec lists only `search-architecture.md` "Agent memory retrieval" and the `index_health` row. Three other passages state the partial-read contract as a closed list of tools, each carrying an `index_coverage_incomplete` warning:
- `docs/architecture/chunking-and-indexing-pipeline.md` "Advisory partial retrieval versus completed publication" (around line 930).
- `docs/specs/mcp-tool-surface.md`, the partial-epoch paragraph (around lines 1645 to 1662).
- `docs/architecture/search-architecture.md` line 450.

After this change, `memory_search` reads a `building` store with no warning (Requirement 4). Unless those passages name it as the hash-verified exception, they misdescribe the system.

Repair: add these passages to Affected Architecture Docs and the Serialization Points, and to the docs task. `docs/specs/mcp-tool-surface.md` is already a serialization point; add `docs/architecture/chunking-and-indexing-pipeline.md`.
