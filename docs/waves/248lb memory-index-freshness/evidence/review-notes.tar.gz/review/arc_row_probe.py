import re, sys, pathlib
root = pathlib.Path("/Users/coryhacking/Developer/wavefoundry")
arc = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else root/"docs/arcs/244cm memory-quality/244cm-arc memory-quality.md"
wd = root/"docs/waves/248lb memory-index-freshness"
wave = (wd/"wave.md").read_text()
spec = (wd/"2475t-bug memory-search-falls-back-during-index-build.md").read_text()
text = arc.read_text()
fails = []
status = re.search(r"^Status:\s*(\w+)", wave, re.M).group(1)
assert status in ("implementing", "active", "implemented", "closed"), status
ac9 = [l for l in spec.splitlines() if l.startswith("| 2026") and "AC-9 met" in l]
assert ac9 and '"fallback_probes": 0' in ac9[0] and "`production_measured: true`" in ac9[0].replace("production_measured: true", "`production_measured: true`") or "production_measured: true" in ac9[0], "spec AC-9 not recorded"
rows = [l for l in text.splitlines() if "248lb memory-index-freshness" in l and l.startswith("|")]
if len(rows) != 1: fails.append(f"row count {len(rows)}")
row = rows[0] if rows else ""
for bad in ("Planned 2026-11-23, not readied", "not readied", "awaiting reverification", "nothing delivered", "Nothing in this arc is delivered"):
    if bad.lower() in text.lower(): fails.append("stale wording: " + bad)
for need in ("Implemented", "AC-9 met", "production_measured: true", "0 fallback probes"):
    if need not in row: fails.append("row missing: " + need)
nxt = text.split("## Next step", 1)[1] if "## Next step" in text else ""
if "then plans track 2" in nxt: fails.append("next step still plans track 2")
if "248lb" not in nxt: fails.append("next step omits 248lb")
print("FAIL" if fails else "PASS", status, fails)
sys.exit(1 if fails else 0)
