# Security reviewer, focused readiness round 2, wave 248lb

Context: `248lb-security-reviewer-focused-r2`, fresh and independent. Owns `248lb-sec-query-embed-inside-snapshot`. Records the reverification only, no approval.

## Verdict

The repair holds. The finding is reverified with `blocking_required_lanes=[]`.

## Executed probe

Script: `/private/tmp/claude-502/-Users-coryhacking-Developer-wavefoundry/c49d4915-53cc-460a-9250-80578e2c9abc/scratchpad/sec-r2/p2.py`, run on a scratch copy of the repo index and memory records with `build_state` set to `building`. The stub embedder and the stub reranker each record `snapshot_active(index_dir)` and sleep 0.5 s. A wrapper times each `read_snapshot` hold.

| Arm | Shape | Result |
| --- | --- | --- |
| A, known-bad | today's code under one outer snapshot (the round-1 shape) | 5 results; embed active True, rerank active True; hold 1.317 s |
| B, known-bad | planned shape without the first snapshot | fallback `semantic_index_unavailable` |
| B2, repair | load in snapshot 1, embed outside, `_ensure_loaded` plus `dense_path_scores` in snapshot 2, rerank outside | 5 results, `hybrid_rrf`; embed active False, rerank active False; holds 3.6 ms, 0.2 ms, 3.6 ms, 0.2 ms, 6.4 ms |
| C | a hook between the snapshots rewrites the docs `model_versions` entry | no results, fail closed |

In arm C the probe's own exception path gave `memory_candidate_state_unavailable`. Requirement 4 makes the implementer return `semantic_index_unavailable`, and AC-3 asserts it.

Nesting check: the only production `read_snapshot` caller is `server_impl._partial_index_read`, used by `docs_search`, `code_search` and `code_ask`. No production path calls `memory_search` inside an outer snapshot. The `ContextVar` reuse therefore cannot turn the inner snapshots into no-ops and leave inference inside a transaction.

## Advisories (non-blocking)

1. AC-4's reranker stub replaces `_get_memory_reranker`, so it would not catch a cold `StaticShapeReranker` construction placed inside snapshot 2. Current code calls it after the dense read, and Requirement 3 covers it, so the risk is low. The implementer should keep `_get_memory_reranker` outside both snapshots.
1. The model-identity recheck should compare against a value captured in a local variable at the first load. It should not re-read `index._meta`, because a concurrent tool call on the shared `WaveIndex` can reload that field.
