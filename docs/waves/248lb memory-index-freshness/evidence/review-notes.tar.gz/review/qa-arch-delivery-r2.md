# qa-reviewer and architecture-reviewer delivery reverification, wave 248lb (cycle 2)

Contexts: `248lb-qa-reviewer-delivery-r2` and `248lb-architecture-reviewer-delivery-r2`. Both are fresh and independent of the repair context `248lb-implementer-delivery-repair-1`. I made no repository edits other than this file and the ledger events.

## Method

A full `run_tests.py` suite was running, so I made an rsync scratch copy of the working tree and used bare `python3 -B -m unittest`. Each mutant was applied to the scratch copy, then reverted, and I diffed the files against the repo to confirm they matched.

- Baseline: `test_memory_eval` ran 48 tests, OK. `test_memory_records` ran 263 tests with 1 failure, `RealChildProcessCoherenceTests.test_child_process_sees_live_fence_and_clear`. It fails with `ModuleNotFoundError: index_compatibility`, the same bare-unittest `sys.path` artifact that QA's first pass saw on the unmutated copy, and it passes under `run_tests.py`.
- Mutant 1 sets `_StubIndex(case["semantic_order"], root / ".wavefoundry" / "wrong-index")` in `memory_eval.py`. Three tests fail: `test_all_policy_invariants_pass`, `test_recorded_baseline_and_candidate_controls_are_complete` and `test_ac14_hermetic_run_is_unchanged`. The mutant is killed.
- Mutant 2 sets `"complete": coverage["missing_paths"] == 0` in `_memory_coverage_block`. `test_ac7_stale_only_coverage_is_incomplete` fails, plus the same artifact. The mutant is killed.

## Findings

| Finding | Lane | Result |
| --- | --- | --- |
| `248lb-qa-class-wide-null-snapshot-masks-hermetic-path` | qa-reviewer | Reverified, executed, lanes `[]`. The head is now completed. |
| `248lb-arch-health-complete-stale-only-unpinned` | architecture-reviewer | Reverified, executed, lanes `[]`. The head is now completed. |
| `248lb-arch-arc-track2-row-stale` | architecture-reviewer | The repair holds on reading. The reverification as `inferred` was refused: `invalid_review_event`, because inferred evidence cannot complete a repair. Nothing was appended, and the head stays `pending` at cycle 2. |

Arc check (read-only): row 63 of `docs/arcs/244cm memory-quality/244cm-arc memory-quality.md` says the change is implemented and that AC-9 was met with generation 6396, 606 model-screened probes, 0 fallback probes and coverage 174 of 174. Those figures match the spec's AC-9 Progress Log row. The row also records 3 delivery findings and that cycle 2 is in progress. Line 67 and the Next step are no longer stale. The row keeps a "Plan:" sentence that now reads as history, which is not a defect.

## Approvals

- qa-reviewer delivery approval recorded (`ev-approval-qa-reviewer-2`). Its integrity checks are all true, and the known-bad method is both mutants.
- architecture-reviewer delivery approval recorded (`ev-approval-architecture-reviewer-2`). Its integrity checks are all true, and the known-bad method is mutant 2. The approval states that the arc finding's head is still pending.

## Advisories

- The Progress Log correction row says the null snapshot runs in 14 tests. There are 15 call sites. The 15th is `test_curated_code_only_index_is_unavailable_not_empty_semantic_success`, which uses a storeless `WaveIndex`, so the call is correct and only the count is off.
- Change Status is still `planned` in the spec header and in `wave.md`.

## Open for the coordinator

`248lb-arch-arc-track2-row-stale` needs a terminal head before close. One option is an operator decision, such as reclassifying it to `dont_do_later` with repair `not_required`. Another is a check that actually executes and bears on the row. A read-only document comparison cannot be relabeled as executed.
