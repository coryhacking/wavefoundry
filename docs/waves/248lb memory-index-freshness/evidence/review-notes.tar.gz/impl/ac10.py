"""AC-10: coverage recovers after an edit outside the tools, on a temporary corpus."""
import contextlib, io, json, subprocess, sys, tempfile, time
from pathlib import Path
SCRIPTS = Path("/Users/coryhacking/Developer/wavefoundry/.wavefoundry/framework/scripts")
sys.path.insert(0, str(SCRIPTS))
import venv_bootstrap; venv_bootstrap.activate_tool_venv()
import wf_server.server_impl as server_impl
import wf_server.index_handlers as index_handlers
import wf_server.memory_handlers as memory_handlers
indexer = server_impl._load_script("indexer")
mem = server_impl._load_script("memory_records")
iss = server_impl._load_script("index_state_store")

tmp = Path(tempfile.mkdtemp(prefix="ac10-", dir=sys.argv[1]))
root = tmp / "repo"
(root / "docs").mkdir(parents=True)
(root / "docs" / "workflow-config.json").write_text(json.dumps(
    {"lifecycle_id_policy": {"epoch_utc": "2020-02-02T02:02:00Z", "hour_offset": 0}}))
(root / "docs" / "plain.md").write_text("# Plain\n\nAn ordinary document.\n")
topics = {"r1": "Restart the MCP host after changing server code.",
          "r2": "Rebuild the docs index after a model change.",
          "r3": "Keep framework edits behind the edit gate."}
for mid, summary in topics.items():
    mem.write_memory_record(root, mem.render_memory_record(
        memory_id=mid, kind="review_finding", summary=summary,
        evidence=["`1abcd-bug some-change` - observed"], targets=["src/a.py"],
        title=f"Lesson {mid}", confidence=0.8, status="active", supersedes="",
        date="2026-07-13"), mid)

def build():
    t0 = time.time()
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        indexer.build_index(root, content="docs", verbose=False)
    return round(time.time() - t0, 1)

def coverage():
    r = index_handlers.index_health_response(server_impl.WaveIndex(root))
    return r["data"]["memory"], [d["code"] for d in r["diagnostics"] if d["code"].startswith("memory")]

def state():
    s = iss.read_build_state(root / ".wavefoundry" / "index")
    return {k: s.get(k) for k in ("status", "generation", "attempt_id")}

out = {"root": str(root)}
out["build1_seconds"] = build()
out["reading_1"] = coverage()
before = state()
rec = root / "docs" / "agents" / "memory" / "r1.md"
subprocess.run(["sh", "-c", f"printf '\\nEdited outside the tools.\\n' >> '{rec}'"], check=True)
out["reading_2"] = coverage()
index = server_impl.WaveIndex(root)
resp = memory_handlers.memory_search_response(root, query="restart the host after code changes", index=index)
out["search_fallback_reason"] = resp["data"]["retrieval"]["fallback_reason"]
status = index_handlers.index_build_status_response(root)
after = state()
out["build_state_before_search"] = before
out["build_state_after_search"] = after
out["index_build_status_lock_held"] = (status["data"].get("lock") or {}).get("held")
out["no_new_build_started"] = before == after and not out["index_build_status_lock_held"]
out["build2_seconds"] = build()
out["reading_3"] = coverage()
print(json.dumps(out, indent=2, default=str))
