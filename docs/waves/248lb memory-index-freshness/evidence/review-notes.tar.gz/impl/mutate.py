import sys
from pathlib import Path
R = Path(sys.argv[1]); name = sys.argv[2]
mh = R/".wavefoundry/framework/scripts/wf_server/memory_handlers.py"
t = mh.read_text()
FIRST = '''        with vectors.read_snapshot(index.index_dir):
            index._ensure_loaded()
            if epoch_out is not None:
                epoch_out["token"] = (getattr(index, "_loaded_meta_signature", None) or {}).get("project")
            if index._docs_vector_layer is None:
                return None, retrieval
            first_model = _docs_model_identity(index)
'''
NOFIRST = '''        if True:
            index._ensure_loaded()
            if epoch_out is not None:
                epoch_out["token"] = (getattr(index, "_loaded_meta_signature", None) or {}).get("project")
            if index._docs_vector_layer is None:
                return None, retrieval
            first_model = _docs_model_identity(index)
'''
EMB = '''        vector = index._memory_query_vector(query)
        retrieval["fallback_reason"] = "semantic_index_unavailable"
        with vectors.read_snapshot(index.index_dir):
            index._ensure_loaded()
'''
def sub(a, b):
    global t
    assert t.count(a) == 1, name
    t = t.replace(a, b)
if name == "no_first_snapshot":
    sub(FIRST, NOFIRST)
elif name == "embed_inside_second":
    sub(EMB, '''        retrieval["fallback_reason"] = "semantic_index_unavailable"
        with vectors.read_snapshot(index.index_dir):
            vector = index._memory_query_vector(query)
            index._ensure_loaded()
''')
elif name == "embed_before_load":
    sub(FIRST, "        vector = index._memory_query_vector(query)\n" + FIRST)
    sub(EMB, EMB.replace("        vector = index._memory_query_vector(query)\n", ""))
elif name == "rerank_inside_second":
    sub('''            dense = index._memory_dense_scores(
                vector, list(body_paths), expected_hashes=expected_hashes,
            )
''', '''            dense = index._memory_dense_scores(
                vector, list(body_paths), expected_hashes=expected_hashes,
            )
            _r = index._get_memory_reranker()
            _r.rerank(query, ["x"])
''')
elif name == "no_model_recheck":
    sub("if index._docs_vector_layer is None or _docs_model_identity(index) != first_model:",
        "if index._docs_vector_layer is None:")
elif name == "no_advisory":
    sub('''        result = server_impl._attach_partial_index_coverage(
            result, root, signature[1:], "memory_search")''', "        pass")
elif name == "no_second_snapshot":
    sub(EMB, EMB.replace("        with vectors.read_snapshot(index.index_dir):\n", "        if True:\n"))
else:
    raise SystemExit("unknown")
mh.write_text(t)
