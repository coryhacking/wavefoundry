"""AC-9 helper (wave 248lb): read the store's build_state epoch row.

Run once before and once after the MCP `wf_memory_eval` call:

    python3 -B ac9_build_window.py /path/to/repo

It prints status, generation, attempt_id, started_at and completed_at from
`index_state_store.read_build_state` (the epoch row, not the lock block). AC-9
passes when the generation advanced and the build's started_at and completed_at
both fall inside the eval run window recorded by the caller. Read-only.
"""
import json
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT / ".wavefoundry" / "framework" / "scripts"))
import venv_bootstrap  # noqa: E402

venv_bootstrap.activate_tool_venv()
import wf_server.server_impl as server_impl  # noqa: E402

state = server_impl._load_script("index_state_store").read_build_state(ROOT / ".wavefoundry" / "index") or {}
print(json.dumps({key: state.get(key) for key in
                  ("status", "generation", "attempt_id", "scope", "started_at", "completed_at")},
                 default=str))
