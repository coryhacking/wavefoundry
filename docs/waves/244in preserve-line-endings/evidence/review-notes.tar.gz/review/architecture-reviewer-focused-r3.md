# Architecture-reviewer focused round 3 (wave 244in)

Context: `244in-architecture-reviewer-focused-r3`. Fresh and independent: I wrote neither the finding nor the repair.

## Result

1. `244in-arch-census-transitive-class-gap`: the repair holds. Reverified in cycle 1 and the lane is cleared.
2. Readiness approval recorded on the current receipt.

## Probe

I ran a stdlib AST probe (`python3 -I probe.py`) over a scratchpad rsync copy of the non-test `.wavefoundry/framework/scripts/` tree (HEAD 9293a89a plus the working tree). It treats the 19 wrappers named in Requirement 10.4 as the wrapper set. Calls resolve by bare name, by `module.attr`, and by `from M import f` / `as g`, both at module level and inside a function. The repo was not edited, and no tests were run while the 244fi full suite was running.

| Measure | Value |
| --- | --- |
| Functions scanned | 5668 |
| Named wrappers found | 19 of 19 |
| Direct primitive writers | 142 |
| Writers only through a wrapper call | 40 |
| Writers under the repaired rule | 182 |
| Wrapper call sites | 53 |
| Writers under the old full closure, same resolver | 463 (27 `main()`) |
| `register_mcp_surface` closures that are writers under the new rule | 0 |
| `main()` writers under the new rule | 4, each with its own direct primitive |

Each of the 40 caller-only writers calls a named wrapper and fits one of the classes `in_place`, `in_place_raw`, `generated` or `wrapper`. Examples:

- `sqlite_storage_migration._write` and `retire_prestaging_noop` reach `_durable_json_replace` through a function-local from-import.
- `migrate_council_role_renames` and `migrate_lifecycle_document_renames` reach `_write_review_carrier_text`.

## Known-bad copy

I added one module to a second scratch copy. It contains a module-level `from upgrade_lib import _durable_json_replace as djr` caller, a caller that does the from-import inside the function, and a plain caller of `docs_gardener.refresh_last_verified`.

- The new rule flagged both from-import callers.
- The new rule did not flag the plain caller of the `in_place` writer.
- The old closure flagged all three (466 = 463 + 3).

## AC-14 and AC-10

- AC-14 is checkable. Under the repaired rule the writer set is finite and decidable, about 182 functions plus 53 wrapper call sites, and every member fits a declared class. A fixture table can therefore hold the complete set. Until the census exists, this is a claim that AC-14 can be decided, not that it passes.
- AC-10 is consistent with Requirement 4. The three transforms have no entry. Their writing callers are the `in_place` keys, and the two migrations are `in_place_raw`.

## Advisories (non-blocking)

1. `wf_server.server_impl._atomic_replace_text` also wraps `_atomic_replace_bytes`. The spec names only `memory_records._atomic_replace_text`. The census will report the `server_impl` one, so it needs no spec edit.
2. `install_log_lib.write_install_log` has no static non-test caller. It is reached through dynamic loads, which the census leaves unresolved by design.
3. My primitive matcher finds 142 direct writers, against 146 in round 2. The delivered census, not this probe, is the authority on the exact count.
