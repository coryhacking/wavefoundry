# Code-reviewer focused re-review, round 2 (wave 244in, spec 244fj)

Lane: code-reviewer. Context: `244in-code-reviewer-focused-r2`. Fresh and independent: I wrote neither the round-1 finding nor the repair.

Finding owned: `244in-cr-writer-census-incomplete`. Verdict: the census design now holds, but the writer list still misses in-place writers. The lane stays blocking.

Per the coordinator's instruction, no readiness approval was recorded on this receipt.

## What the repair fixed

1. All five round-1 writers are now in Requirement 4: `setup_wavefoundry._provision_workflow_defaults_if_absent`, `upgrade_wavefoundry.materialize_lifecycle_policy`, `render_agent_surfaces.reconcile_context_efficiency_surface`, the two `review_policy_reconcile` writers and `secrets_validators.save_exceptions`.
2. Requirement 10 now resolves writers transitively, keys every wrapper call site separately, names the wrappers from round 1, and AC-9 item 2 adds the wrapper known-bad. That closes the census blind spot.

## Method

I ran two stdlib AST sweeps (scratchpad `census.py` and `w.py`) over every non-test `.py` under `.wavefoundry/framework/scripts/`. The first lists functions that both read and write, and the second lists every function that calls a write primitive or a named wrapper. I read each candidate that was not in the 50 and decided whether it edits an existing repository file in place.

## Writers still missing

1. **`render_platform_surfaces.render_codex_mcp_config` (`.codex/config.toml`).** It reads the operator-owned TOML raw (`translate_newlines=False`), upserts the framework region through `render_agent_surfaces.upsert_codex_mcp_config`, and writes the result verbatim. This is the fifth MCP host config. `_merge_mcp_server` covers only the four JSON configs (`.mcp.json`, Junie, Cursor, Antigravity). I executed `upsert_codex_mcp_config` on a 3-line CRLF config: the output has 3 CRLF and 6 bare LF, so the appended region is LF inside a CRLF file. This is the same line-inserting class as round-1 items 3 and 4.
2. **`review_policy_upgrade.refresh_review_status_blocks` (every live wave record).** It reads with `contained_files.read_contained`, calls `review_evidence.render_review_status_projection(original, ...)` and writes with `write_contained_bytes`. When the projection inserts a new block (`review_evidence.py` around 3969-3970), the block takes the ending of the line before it, not the file's majority, so on a mixed record it breaks Requirement 2. The spec routes the sibling `plan_review_policy_upgrade` but does not name this function. Upgrade calls it at `upgrade_wavefoundry.py:6621` and `upgrade_extensions.py:3358`. (Code read only, not executed.)
3. **Link-repair writers with no named classification.** `migrate_council_role_renames` and `migrate_lifecycle_document_renames` in `render_agent_surfaces.py` rewrite operator documents in place through `_council_role_link_plan`, which splices replacement link destinations into raw text. That is raw substitution within lines, so `in_place_raw` is the right class. Requirement 10.3, however, allows `in_place_raw` only for writers "named in Requirement 4", and Requirement 4 names only three.
4. **Classification not stated: `design_token_build.update_manifest_parity`.** It reserializes an existing design-system `manifest.json` with `json.dumps` and plain `write_text` (Pattern B). The file is in Serialization Points but has no classification. If the manifest is operator-authored, the governing rule makes it `in_place`. If it is generated, it should be named as generated.

Checked and correctly out of the list: hook JSON renderers (generated), `materialize_secrets_policy` (new file only), the baseline reconcilers (missing-only), the `memory_consolidate_response` rollback (byte restore), scan and index state under `.wavefoundry/index/` (gitignored), `_update_upgrade_state`, `upgrade_lib` locks, `repair_ppol_memory_staging` (pinned bytes), `create_wave` and `new_change` (new files), `_move_change_doc` (rename only).

## Why this still blocks

Requirement 10 would flag items 1, 2 and 3 as unclassified writers during implementation, so nothing would land silently. But Requirement 4 claims the 50 as the full set, and AC-1 and AC-10 enumerate from it, so items 1 and 2 get no CRLF matrix case. The rule also leaves item 3 with no legal classification. Adding these during implementation would edit the change document after readiness. The spec is being edited now anyway, so the cheap fix is to add them now:

1. Add `render_codex_mcp_config` and `refresh_review_status_blocks` to Requirement 4 (52 writers).
2. Name the two link-repair migrations as `in_place_raw`.
3. Classify `update_manifest_parity`.

## Limitations

The AST sweeps match calls by name and do not follow dynamic loads. Item 2's mixed-file behaviour comes from reading the code, not from running it. No `run_tests.py` was run and no repository file was edited.
