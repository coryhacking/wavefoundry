# qa-reviewer readiness notes (wave 244in)

Verdict: two blocking findings recorded; no approval.

Context: fresh and independent. The 244fi full suite was running (pgrep matched), so I did not run run_tests.py. Evidence comes from read-only inspection and stdlib probes in the session scratchpad.

## Confirmed

- The 30 listed writers read and write as the spec says. I spot-checked the server_impl handlers, the memory_records, render_platform_surfaces, upgrade_extensions, gen_codebase_map and build_pack writers by AST.
- The back-reference claim reproduces. A pure CRLF spec never matches. A mixed spec gains `\r\r\n` under the Path.open Windows simulation.
- The fail-today claims for AC-1 to AC-7 match each writer's pattern:
  - Pattern A writers (CRLF to LF) fail the CRLF cases.
  - Pattern B writers (`Path.write_text` default, `os.linesep`) fail the LF-under-simulation cases.
  - AC-12 passes today by design.
- The simulation is concrete enough for the primitives the routed writers use today. `Path.write_text` calls `self.open` on Python 3.11, 3.13 and 3.14, and the planned `os.linesep` patch covers `_write_handoff_text` and `_write_repo_text_platform_newlines`. Builtin `open`, `os.fdopen` and `NamedTemporaryFile` are not patched, but no routed writer uses them.
- Generated-file writers will not be flagged, because the census table classifies them `generated`.

## Findings

1. `244in-qa-census-wrapper-blindspot`
   - The census keys only on the primitive names it lists. A write through any wrapper not on that list is invisible, for example `upgrade_wavefoundry._atomic_write_json`, `_atomic_write_text`, `wave_lint_lib/helpers.write_if_changed`, `memory_records.write_memory_record` or `render_agent_surfaces._write_text_exclusive`.
   - Two in-place writers that Requirement 4 does not list already go through such a wrapper. Both reserialize `docs/workflow-config.json` with Pattern B: `upgrade_wavefoundry.materialize_lifecycle_policy` and `setup_wavefoundry._provision_workflow_defaults_if_absent`.
   - Two calls to the same primitive in one classified function share one key, so a second write there is not caught.
   - Fix: route both writers; add the wrappers to the census, or resolve wrappers transitively; count calls per key; add an AC-9 known-bad that writes through a wrapper.
2. `244in-qa-crlf-simulation-quadrant`
   - AC-1 tests CRLF natively and AC-2 tests LF under the simulation. Only AC-3 tests CRLF under the simulation.
   - A routed writer that still writes text mode passes AC-1 on POSIX (exact CRLF) but writes `\r\r\n` on Windows. The Pattern B wave-record writers must change primitive, so this regression is likely.
   - Fix: run {LF, CRLF} x {native, simulated} for every writer, and assert there is no `\r\r\n`.
