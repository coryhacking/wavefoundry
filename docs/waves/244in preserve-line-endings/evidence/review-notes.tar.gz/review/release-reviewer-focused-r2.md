# release-reviewer focused r2 (wave 244in)

Finding 244in-f-upgrade-ext-import: repair holds, reverification recorded (cycle 1, context 244in-release-reviewer-focused-r2).

Probe (scratchpad r2/probe.py, python3 -I): the real upgrade_extensions.py exec'd from a zip the way the old runner does (relative __file__, no line_endings.py beside it) loads. _incoming_framework_module('line_endings', zip) returns the zip's helper. With no zip it raises _IncomingModuleUnavailable, the planned skip-with-warning path. A copy with a top-level import fails with ModuleNotFoundError.

build_pack.update_manifest_revision and upgrade_wavefoundry._stamp_manifest_revision write only docs/prompts/prompt-surface-manifest.json, which is not in the pack, so release bytes are unchanged. Routing them keeps the file's own ending.

Caveat: line_endings.py is not written yet; the real helper must be stdlib-only and avoid sys.modules lookups.

Readiness approval: NOT recorded; coordinator is rotating the receipt and will name the new one.
