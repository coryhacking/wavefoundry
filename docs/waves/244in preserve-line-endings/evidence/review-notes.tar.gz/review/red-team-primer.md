# Red-team primer, wave 244in (readiness, standard depth)

Verdict: one blocking finding (RT-1, do_now). The rest of the plan holds. I recorded no approval.

Method: I read the spec, the wave record and the code with MCP retrieval plus `grep`. A 244fi full suite (`run_tests.py --no-cache`) was running, so I ran no tests. I ran one stdlib probe in the scratchpad.

## RT-1 (recorded): a missed in-place writer and a census wrapper hole

- `upgrade_wavefoundry.materialize_lifecycle_policy` reads the operator-owned `docs/workflow-config.json` with `read_text`. It rewrites the file through `_atomic_write_json`, which calls `tmp.write_text` in text mode. That is Pattern B, and the writer is not in Requirement 4.
- `_atomic_write_json` and `_atomic_write_text` are not on the Requirement 9 primitive list. The census sees only their internal `write_text` call and never their callers, so a new in-place writer that goes through either wrapper passes AC-9. The qa-reviewer's `244in-qa-census-wrapper-blindspot` covers the same hole, so treat the two as one repair.
- `_stamp_manifest_revision` writes `docs/prompts/prompt-surface-manifest.json` with a text-mode `write_text`, so on Windows it writes CRLF. Requirement 8 says generated writers already keep byte-stable LF, and this one does not. Render's `_write_prompt_manifest` preserves the file's ending, so the two writers of this file disagree.
- Recording error: I recorded RT-1 with `execution_status: executed`. The evidence came from reading code, so `inferred` is the honest value. The ledger is append-only; the coordinator should note this when the finding is repaired or reverified.

## Attack 1: can "any CRLF means CRLF" damage a mostly-LF file with one stray CRLF?

Yes. Probe: a 200-line LF `.gitignore` plus one CRLF line, the kind `echo x >> .gitignore` leaves from cmd.exe, then an edit to the managed block. Under the any-CRLF rule, 201 of 201 lines change. Under a majority rule, 2 change. Git's text normalization (`* text=auto`, `eol=lf`) hides this in commits, but a repo without text attributes gets a whole-file diff. That is the churn this change exists to remove. The damage is cosmetic: no content is corrupted, and the result is stable after one rewrite.

Not blocking. The decision is recorded as a reversible default and matches the 9 existing preserving writers (I counted 9 in non-test code, plus per-line handling in `_close_change_rewrite_block` and `upgrade_extensions._bullet`).

**Strongest alternative:** in `detect`, choose the majority ending among terminated lines, with ties going to CRLF. Route the existing whole-file preserving writers (`patch_root_bridge`, the review-protocol and review-policy regions, the prompt manifests, `_merge_claude_agent`, `_tier3_write`, `review_policy_upgrade`, `docs_gardener.ensure_manifest`) through the helper as well, so every writer still agrees. That meets "we should be consistent" with less churn. It costs a wider scope, about 8 more sites that are already easy to route.

## Attack 2: can routing 30 writers regress a writer that already preserves?

Mostly no. Requirement 2 keeps the per-line writers out. Three risks remain:
- A routed writer that decides whether a file changed by comparing raw bytes would rewrite a mixed file to all-CRLF even when its content did not change. A writer that compares LF text would not. The spec should say "write only when the LF content changes". `_merge_mcp_server` writes unconditionally today.
- `patch_thin_pointer` and the `.mdc` update compare `updated != disk_text` on translated text. Routing must keep that comparison on LF text.
- `PrepareCRLFPublicationTests.test_prepare_publication_keeps_existing_all_lf_policy` pins the old all-LF Prepare behavior. AC-1 inverts it on purpose, but the Tasks should name it (see DC-1).

## Attack 3: is the byte-exact small-change digest right?

Yes. `small_change_lane.py:298-307` already binds each file's size, sha256, mode and `_reviewed_file_id`, plus a `(st_dev, st_ino, mtime, ctime)` identity. The digest is tied to one working tree, not portable across checkouts, so normalizing the bytes alone would buy nothing. A lapse fails closed: it asks for more review, never less. Line endings are functional for `.sh` and `.cmd` files. One cost the spec does not mention: an editor or `git add --renormalize` that only rewrites endings lapses the narrow approval. That is acceptable.

## Attack 4: does a Windows user still see churn from a source the spec leaves out?

Yes, in three places:
1. `_stamp_manifest_revision`: a text-mode write gives CRLF on Windows (in RT-1).
2. On an `autocrlf=true` checkout, a re-render rewrites every generated file outside `docs/**` (`AGENTS.md`, `.claude/skills`, `.codex`) to LF. Git status stays clean because the clean filter matches the index, but mtimes change and the `--manifest` written list reports every file on every render. This is a declared out-of-scope decision, and I accept it.
3. Generated writers that use text-mode `write_text`, for example `upgrade_wavefoundry.py:5615` creating `docs/scan-rules.toml`. Requirement 7 (new files are LF) binds only routed writers, so these still write CRLF on Windows. The census `generated` and `new_file` classes should require a byte or `newline=""` primitive, not just a label.

## Confirmed claims

- `\r\r\n`: a text-mode write of `"a\r\nWave: x\n"` with `newline="\r\n"` produces `b'a\r\r\nWave: x\r\n'`. Confirmed by execution.
- Gate census arithmetic: 5 + 1 + 6 = 12, and the rows match.

## Strongest challenge

The plan's guarantee depends on the census, and the census keys on primitive names. Every wrapper outside the list (`_atomic_write_json`, `_atomic_write_text`, and any future one) hides its callers. Until the census treats the wrappers as primitives, either transitively or by listing them, AC-9 cannot keep a new writer from bypassing the helper, and the routed list is already short by at least one writer.
