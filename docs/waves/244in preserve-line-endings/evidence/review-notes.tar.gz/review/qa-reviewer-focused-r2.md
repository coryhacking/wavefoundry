# qa-reviewer focused round 2 (wave 244in)

Context: `244in-qa-reviewer-focused-r2`, fresh and independent. No repo edits. Probes ran with `python3 -I -B` from the session scratchpad against the live tree (AST only, read-only). No readiness approval recorded, on the coordinator's instruction (receipt about to rotate).

## 244in-qa-crlf-simulation-quadrant: repair holds, lane cleared

- AC-1 now runs every `in_place` writer on LF, CRLF and mixed inputs, each natively and under the shared simulation, asserting exact bytes and no `\r\r\n`. That covers the missing CRLF-under-simulation quadrant for every writer, not only AC-3.
- The simulation patches `Path.open` and `os.linesep`; builtin `open`, `os.fdopen` and `NamedTemporaryFile` fall to the census rule that fails any text-mode write with `newline` unset (Requirement 10.5). Together they close the regression I named: a routed writer left in text mode writes `\r\r\n` under the simulation and fails AC-1.

## 244in-qa-census-wrapper-blindspot: repair mostly holds, lane still blocking

Holds:
- `materialize_lifecycle_policy` and `_provision_workflow_defaults_if_absent` are routed (Requirement 4 items 7 and 8).
- Writers are classified transitively, wrapper call sites are keyed (caller, wrapper, ordinal), and call counts are recorded, so a second write in a classified function is caught.
- All 18 named wrappers exist (probe: each has a definition).

Residual defect: Requirement 10.2 resolves calls "by bare name within the module and by `module.name` attribute". A name bound by `from M import f` is neither, and four wrapper call sites in the tree use exactly that form, so a literal implementation does not key them:
- `wave_lint_lib/cli.py:441` `_emit` calls `write_if_changed` (relative `from .helpers import`); this is the example I named in round 1.
- `sqlite_storage_migration.py:216` and `:1189` call `_durable_json_replace` (function-local `from upgrade_lib import`).
- `review_policy_upgrade.py:210` calls `apply_reconciliation` (top-level `from review_policy_reconcile import`).
Probe 2 (fixed-point resolver implementing the literal rule) also reports 27 caller functions that reach a writer only through a from-imported name.

Fix: in Requirement 10.2, resolve `from M import f [as g]` (top level and function-local, absolute and package-relative) to `M.f`, and add an AC-9 known-bad case: a new caller of a wrapper through a from-import.

## AC-9 known-bad cases, checked against Requirement 10.5

1. Unclassified `Path.write_text` in a new function: unclassified writer function. Fails.
2. New caller of `upgrade_wavefoundry._atomic_write_json`: unclassified wrapper call site and unclassified writer. Fails (in-module bare call or `upgrade_wavefoundry.` attribute). It would not fail through a from-import, per the residual above.
3. `merge` call removed from an `in_place` function: fails. Note for implementation: in `upgrade_extensions.py` the helper arrives as a parameter, so the check must match the `.merge` attribute on that parameter, not only the literal `line_endings.merge`.
4. Second write call in a classified function: call count differs. Fails.
5. `generated` `write_text(..., encoding="utf-8")` with `newline` omitted: text-mode primitive with `newline` unset. Fails.
6. Table entry whose function no longer writes: stale entry. Fails.
