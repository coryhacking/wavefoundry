# Architecture-reviewer focused round 2 (wave 244in)

Context: `244in-architecture-reviewer-focused-r2`. Fresh, independent; wrote neither the finding nor the repair.

## Result

1. `244in-arch-census-wrapper-and-generated-gap`: reverified in cycle 1, lane cleared, terminal.
2. New blocking finding `244in-arch-census-transitive-class-gap` (readiness, cycle 0). The census rule as repaired contradicts itself.
3. No readiness approval recorded. The coordinator said to wait for the rotated receipt, and the lane is also blocked by item 2.

## Reverification of the round-1 finding

1. Wrapper blind spot: Requirement 10.3 adds a `wrapper` class, and 10.4 keys each wrapper call site (caller, wrapper, ordinal) with its own class. All 19 named wrappers exist in the stated modules (checked by grep).
2. Generated writers on Windows: Requirement 9 requires LF bytes. Requirement 10.5 fails any text-mode primitive whose `newline` is omitted or `None`, outside exempt process logs. AC-9 item 5 is the known-bad.
3. Prompt-surface manifest: in place (Decision Log, Requirement 4 items 7 and 13), consistent with `docs_gardener.ensure_manifest`.
4. Round-1 advisories, all repaired: Requirement 3 sets one read form per transaction; `reconcile_upgrade_policy_surface` is routed; `apply_reconciliation` is a wrapper; AC-1 inverts the all-LF Prepare test; the docs list includes build-and-verification.md and supersedes the 20b39 row.

## New finding: census transitive class gap

Requirement 10.2 makes a function a writer if it calls any other writer, iterated to a fixed point. A stdlib AST probe over the non-test scripts, resolving only same-module bare names, found:

- 146 functions that call a primitive directly
- 363 writer functions after the closure

The 217 caller-only writers include several `main()` functions, handler closures in `register_mcp_surface`, and render orchestrators. None of them fits a Requirement 10.3 class:

- not `in_place`: they do not call merge
- not `generated`: they write nothing themselves
- not `wrapper`: they do not write to a path the caller names
- not `exempt`: they are not binary, log or pid writers

Also, `_upsert_review_protocol_region`, `_upsert_review_policy_region` and `_merge_claude_agent` are pure text transforms that return a string. Requirement 10.5 fails a table entry whose function does not write, so AC-10 ("every writer in Requirement 4 is classified `in_place`") cannot hold for these three.

Bounded repair, spec wording only:

1. Propagate writer status only through `wrapper` functions. The caller of an `in_place`, `generated` or `exempt` writer is not itself a writer, because the callee owns the write.
2. Name the writing callers of the three transforms (`render_agent_surfaces` 2018, 2028, 4855, 5510, 5683) as the `in_place` census keys.

## Layering judgment: routing the 9 existing preservers

This is sound. All 11 inline `"\r\n" if "\r\n" in ...` copies (the 9 preservers plus `_backfill_role_field_on_agent_docs` and `_close_change_rewrite_block`) sit in functions Requirement 4 already routes. Each one already holds the original text, so swapping its inline rule for `merge` changes no seam and no write primitive.

The change also has no effect on files with a single line ending. For a pure-LF or pure-CRLF file, `merge` gives the same bytes as the old rule, because every existing line keeps its ending and new lines take the file's only ending. Behavior changes only on mixed files, which is the purpose of the change. Leaving the 9 preservers on their own rule would keep two disagreeing rules and leave the census no honest class for them.

One caution follows from the finding above. For the three pure text transforms, `merge` belongs in the caller that has `original`, not inside the transform.
