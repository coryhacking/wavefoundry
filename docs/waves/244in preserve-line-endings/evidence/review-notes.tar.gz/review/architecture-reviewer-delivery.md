# Architecture-reviewer delivery notes (wave 244in, change 244fj)

Fresh, independent context. No repo edits beyond this notes file.

## Readiness re-record (r4)

Read the implementer's Decision Log rows and the expanded Serialization Points list. No plan defect:

- Planner merge (deviation 1). `plan_reconciliation` and `plan_review_policy_upgrade` merge on each file as read, and the apply steps compare the same planned bytes in their "changed after preflight" checks (`review_policy_upgrade.py` 128, 187-188, 209, 222; `review_policy_reconcile.py` 437, 465). The census accepts the apply step only through a named `merged_by` planner that itself calls merge, with a reason. This is a sound boundary.
- `_write_handoff_text` reads the handoff itself, the routed readers use `to_lf`, and `upgrade_extensions.py` writers take an optional `line_endings` argument. Each is consistent with Requirements 3 to 5.
- The Serialization Points paths match the diff file set.

Recorded as a readiness approval, context `244in-architecture-reviewer-readiness-r4`.

## Delivery

### Layering: sound

- `line_endings.py` imports only `difflib` and `pathlib`. It sits beside the other stdlib-only siblings.
- `upgrade_extensions.py` has no top-level import. It loads the helper through `_incoming_framework_module` (lines 645, 878, 3668, 3787, 4209).
- No module loaded through `_incoming_framework_module` imports `line_endings`.
- The incoming-runner path extracts the whole framework tree, and `validate_feature_pack` stages every `.py`. The new top-level imports in `upgrade_wavefoundry.py`, `review_policy_*` and the render modules therefore resolve.
- `setup_wavefoundry` imports lazily, matching its existing `upgrade_wavefoundry` lazy import.

### Census: one structural gap (finding `244in-arch-exempt-wrapper-blindspot`)

The engine pins callers for every `generated` entry, which is the council advisory. It does not pin them for `exempt` entries. A new caller of an `exempt` function is not a writer, so the census never reports it.

Two `exempt` entries have exactly the Requirement 10.3 `wrapper` shape, because they write caller-supplied bytes to a caller-named path:

- `setup_readiness:_write_stamp_exclusive(path, data)`
- `upgrade_extensions:_write_journal_exclusive(destination, data, dir_fd)`

Executed probe. The probe ran in memory through `extra_sources`, with no repo edit. A new module that read a file with `read_text`, transformed it, and published it through `setup_readiness._write_stamp_exclusive` produced zero census failures. So did a new caller of `_write_journal_exclusive`. The same probe against the `generated` callee `build_pack.write_pack_version` failed with `GENERATED_CALLERS`, as designed.

The existing callers are all verbatim copies (temp-file bytes and vetted journal bytes), so the tree misbehaves nowhere today. The gap is in maintainability: the inventory is meant to be authoritative, and this route lets a future in-place writer bypass it.

Smallest repair, either of:

1. Apply the `generated` caller pinning to `exempt` entries as well.
2. Reclassify the two functions as `wrapper` and classify their 3 call sites.

Related accuracy point, which needs no separate finding. Several `exempt` reasons say "Binary payload copied verbatim." for text content written as bytes:

- the release notes and `SHA256SUMS` in `build_pack:_run_release_orchestration`
- the bytecode stamp in `bytecode_cache:_flush_if_stale`
- the JSON stamp copy in `setup_readiness:_write_stamp_exclusive`
- the MANIFEST snapshot in `upgrade_wavefoundry:phase_pruning`

These writes are LF-safe, because they write bytes. A reason that states what is written would keep the table readable as an inventory.

### Classification table otherwise: sound

- The counts in the table are 53 `in_place`, 7 `in_place_raw`, 71 `generated`, 24 `wrapper` and 37 `exempt`. The brief's 72/36 predates the `graph_quality_eval` repair that the Progress Log records.
- The 11 `writer_callers_reason` entries are each a fixed-path generator called by an orchestrator, so each is correctly `generated` and not a wrapper. The pinned callers list makes every new caller fail.
- The `dynamic_mode_reason` (`runtime_lock`), `newline_unset_reason` (`graph_quality_eval`) and `process_log` exemptions are each narrow and have a stated reason.

### Docs: accurate, with one overstatement (advisory)

The three docs and the CHANGELOG match the delivered rule.

`native-windows-support.md` says "No writer uses `os.linesep` or the default text-mode translation". Process logs (`process_log` exemptions), `child_tee` console output and the `graph_quality_eval` scratch corpus do translate. The surrounding sentence is about tools that edit files, so this is wording only.

### Platforms: the claims hold

Routed writers publish `encode(merge(...))` or `write_text(..., newline="")`. The census statically requires `newline` in `("\n", "")` for every `generated` text write. The bytes are therefore identical on Windows, macOS, Linux and WSL2 `/mnt/c`. Windows is proven by simulation only, and the docs and Progress Log say so.

### Executed

- `python3 -B -m unittest test_line_ending_census test_line_endings` from `tests/`: 29 OK. `run_tests.py` was locked by another reviewer's run, so this was a gapfill run.
- In-memory census probes for the `exempt` and `generated` callees, as described above.

## Verdict

Readiness re-recorded. Delivery approval withheld pending `244in-arch-exempt-wrapper-blindspot`.
