# Focused readiness verification, round 2 (wave 244in)

Round 1 recorded seven blocking findings against 244fj:

| Finding | Raised by |
|---|---|
| `244in-f-upgrade-ext-import` | release-reviewer |
| `244in-qa-census-wrapper-blindspot` | qa-reviewer |
| `244in-qa-crlf-simulation-quadrant` | qa-reviewer |
| `244in-arch-census-wrapper-and-generated-gap` | architecture-reviewer |
| `244in-cr-writer-census-incomplete` | code-reviewer |
| RT-1, the red-team seat's finding | red-team |
| DC-1, the docs-contract seat's finding | docs-contract-reviewer |

Get the exact ids from `wf_review_event(wave_id='244in', event='list')`.

## The repair

The implementer (context `244in-implementer-repair-1`) recorded a `repair_start` in cycle 1 for each finding and repaired the spec. The writer list grew to 50:
- 8 writers the reviewers found
- 9 existing "any CRLF" preservers, routed through the helper (the coordinator confirmed this)
- 3 writers that insert lines

The census rule now gives every function that writes, directly or through another writer, one entry: `in_place` (must call `merge`), `in_place_raw`, `generated`, `wrapper` or `exempt`. Every wrapper call site and its call count is recorded. The census fails on:
- an unclassified function or call site
- a stale entry or a changed count
- an `in_place` function that does not call `merge`
- any text-mode write with `newline` unset

AC-9 lists six known-bad cases.

Other changes:
- **upgrade_extensions:** no top-level import. It loads the helper through `_incoming_framework_module` from `ctx.zip_path`. AC-7 is the zip-load test.
- **Testing:** every in-place writer gets a CRLF case and a Windows-translation case.
- **Generated writers:** write LF bytes explicitly on every platform.
- **Docs:** the 20b39 row is marked superseded, build-and-verification.md is updated, and the all-LF Prepare test is inverted.
- **Mixed-file rule, a coordinator decision:** existing lines keep their own ending, and inserted or replaced lines take the file's majority ending, with ties going to CRLF. A file with no ending yet gets LF. AC-2 pins this.

## Your task

As a FRESH independent reviewer, who wrote neither the finding nor the repair:
1. Load the MCP tools via ToolSearch first and use code_* MCP-first. Read the round-1 notes and the changed spec sections. Get the current receipt from `wf_review_wave(wave_id='244in', phase='prepare')`.
2. Verify the repair against the code, in your remit. Make NO repo edits. You may run `python3 -B .wavefoundry/framework/scripts/run_tests.py --file <f>` and probes on a throwaway copy, but never the full suite.
3. For each finding you own, record a reverification:
   - `event='finding'`, `run_kind='reverification'`, with the cycle `wf_review_wave` recommends
   - `blocking_required_lanes=[]` only if the repair holds
   - `fresh_context=true`, `independent=true`, `actor=<lane or seat>`, `context_id='244in-<lane>-focused-r2'`
   - executed evidence, which is required to clear a lane

   Dry-run first, then create.
4. Required lanes (code-reviewer, qa-reviewer, architecture-reviewer, release-reviewer) then record a readiness approval on the current receipt, as executed, with your OWN honest `integrity_checks`. The council seats record only their reverification. A new blocking defect gets a finding.
5. Write notes to `.wavefoundry/work/244in/review/<lane>-focused-r2.md`. No em-dashes.
6. Reply in under 80 words.
