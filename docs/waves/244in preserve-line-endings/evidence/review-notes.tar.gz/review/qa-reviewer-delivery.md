# qa-reviewer delivery notes (wave 244in, change 244fj)

Fresh, independent context. Verdict: no blocker in the QA lane. Readiness re-recorded on receipt `review-policy-213cec54a9859a91285e` (context `244in-qa-reviewer-readiness-r4`), then delivery approval.

## Readiness re-record

Read the implementer's Decision Log rows (planner merge through `merged_by`, `_write_handoff_text` reading raw itself, the `to_lf` read form, the optional `line_endings` argument in `upgrade_extensions.py`) and the grown Serialization Points list. No plan defect for this lane: every AC stays testable, and the added paths are bare and match touched files. `graph_quality_eval.py` is listed although its edit was reverted; that is harmless.

## Focused runs on the real tree

- `run_tests.py --file test_line_ending_census.py`: 14 OK.
- `run_tests.py --file test_line_endings.py`: 15 OK.
- `run_tests.py --file test_line_ending_writers.py`: 11 OK three times. One earlier run reported `FAILED (framework bytecode beside the sources)` with all 11 tests OK. No `__pycache__` was found afterwards, and three reruns passed. Concurrent reviewer and MCP processes were running, so this is most likely a transient from another process, not from this change.
- Scratch-copy baseline: 40 line-ending tests across the upgrade, render, Prepare, review-policy and memory classes passed.

## Per-AC test evidence

- **AC-1 matrix.** Every `in_place` writer named in Requirement 4 has a test with LF, CRLF and mixed inputs, run natively and under `windows_text_writes()`, with exact bytes and a `\r\r\n` check. The test is either `line_ending_support.run_matrix` or an equivalent loop. Server writers go through one public lifecycle in `test_line_ending_writers.py`, with remove, handoff and escalation tested separately. The other writers are tested in their own modules. The platform tests add an LF-majority shape with one CRLF line.
- **Inverted Prepare test.** `PrepareCRLFPublicationTests.test_prepare_publication_keeps_the_record_line_endings` asserts that a CRLF record stays CRLF, natively and under the simulation. It fails under the "merge returns LF" mutant. Limitation: this Prepare transform only deletes one line, so it does not exercise the majority ending for inserted lines. The lifecycle matrix covers insertions (heading-spacing fix, status and review blocks).
- **AC-2, AC-3, AC-4, AC-8.** Exact-byte tests exist and pass (200-line stray CRLF, pure CRLF back-reference repair, mixed spec with no `\r\r\n`, new handoff LF, helper cases).
- **AC-9.** All eight known-bad copies fail as claimed. Each one stops failing when its detector is disabled:
  - merge check forced true: the in-place-without-merge and carrier-without-merge tests fail;
  - `NEWLINE_UNSET` rule off: the generated-without-newline test fails;
  - from-import resolution off: the from-import test and the delivered-tree test fail;
  - `STALE` check off: the stale-entry test fails;
  - `COUNT` renamed: the second-write test fails.
- **AC-14.** The delivered tree has zero census failures. Deleting a writer entry from the table in memory (`render_gitignore_block`, `_write_handoff_text`, `_rewrite_legacy_config_keys`) gives `UNCLASSIFIED`. Deleting a wrapper site gives `UNCLASSIFIED_SITE`.
- **AC-11, AC-12.** Both pins exist and pass.

## Mutants requested by the brief (scratch copy)

1. **Break `merge`.**
   - Equal lines take the majority ending: matrices fail in every writer module. Prepare stays green because the inputs are pure LF or CRLF, as expected.
   - `merge` returns `new_lf`: the Prepare, admission, handoff, escalation and remove tests fail.
   - Inserted lines are always LF: the helper, lifecycle, render and review-policy tests fail.
2. **Drop one writer's routing.**
   - `render_gitignore_block` writes `new_lf` (Pattern A): its CRLF, mixed and LF-majority subtests fail, and the census reports `IN_PLACE_WITHOUT_MERGE` and `IN_PLACE_SITE_WITHOUT_MERGE`.
   - `_write_handoff_text` writes with `os.linesep` (Pattern B): the handoff test fails, including the LF and missing-file cases under the simulation, and the census reports `IN_PLACE_WITHOUT_MERGE`.
3. **Relabel a wrapper as `generated`.**
   - `render_platform_surfaces:write_text` gives `GENERATED_CALLERS`, `STALE` x11 and `STALE_SITE` x13.
   - `memory_records:_atomic_replace_text` gives `GENERATED_CALLERS`, `STALE` and `STALE_SITE`.
   - `server_impl:_atomic_replace_bytes` gives `GENERATED_CALLERS`, `GENERATED_CALLED_BY_WRITER`, `COUNT`, `STALE` and `STALE_SITE`.

## Non-blocking observations

- The census checks `merge` per function, not per write. An `in_place` function with several wrapper sites passes if any one of its writes merges. The behavioral tests cover the multi-site writers (close change, review-policy apply).
- The census does not check that the `merge` result is what gets written; a merge call whose result is unused would pass. The behavioral matrices catch that for the named writers.
- The architecture lane's open finding `244in-arch-exempt-wrapper-blindspot` (exempt entries pin no callers) is a related census gap. It is not duplicated here.
- Windows is verified by simulation only (`Path.open` patch plus `os.linesep`). No native run was made.
- Deviation 8 (no rewrite when content is unchanged): the full suite passed (13,402), so no test depends on an unconditional write. I did not audit every caller's `changed` or `written` reporting by hand.
