# Architecture-reviewer delivery reverification (wave 244in, cycle 2)

Context `244in-architecture-reviewer-delivery-r2`. Fresh and independent; I did not write the finding or the repair. No repo edits beyond this notes file.

## Finding `244in-arch-exempt-wrapper-blindspot`: repaired

- The fixture now classifies `setup_readiness:_write_stamp_exclusive` and `upgrade_extensions:_write_journal_exclusive` as `wrapper`. Their 3 call sites are classified: `write_setup_stamp` as `generated`, and the two journal callers as `in_place_raw`.
- `census()` now pins callers for `exempt` entries as well as `generated` ones (`EXEMPT_CALLERS`), and requires `writer_callers_reason` when a caller is itself a writer.
- In-place writers may pass only `newline=""` (`IN_PLACE_NEWLINE`).

## Executed probes (in memory, `scan_tree(extra_sources=...)`)

- Baseline tree: no failures.
- New module that reads with `read_text`, transforms, and publishes through `_write_stamp_exclusive`, plus one that publishes transformed bytes through `_write_journal_exclusive`: `UNCLASSIFIED` and `UNCLASSIFIED_SITE` for both. The original probe produced zero failures.
- Same through a `from setup_readiness import _write_stamp_exclusive as w` alias: fails the same way.
- New caller of the exempt `contained_files:_write_all`: `EXEMPT_CALLERS`.
- `python3 -B -m unittest discover -s tests -p "test_line_ending*.py"`: 42 tests OK. I did not run `run_tests.py` because another full run was in progress.

## Recorded caller reasons (6)

Each one names a step that writes at its own fixed or owned path, called by its orchestrator. None writes bytes that a caller supplies to a path that a caller names. All six are sound:

- `embedded_model_bundle:retain`
- `model_bundle:_normalize_refs_in_place`
- `model_bundle:materialize_bundle`
- `model_bundle:materialize_source`
- `upgrade_bridge_bootstrap:_retain_feature_archive`
- `wave_work:publish_snapshot`

## Accuracy points from the first pass

- No exempt reason still says "Binary payload copied verbatim". The release notes, bytecode stamp and MANIFEST snapshot reasons now state what is written.
- `native-windows-support.md` now limits the no-translation claim to tools that edit or generate repository files, and names the three writers that still translate.

## Residual

The author of a future caller could still misclassify it, for example as `generated`. Catching that is a review judgment, not a gap in the census.

## Verdict

Reverification recorded with no blocking lanes. Delivery approval recorded.
