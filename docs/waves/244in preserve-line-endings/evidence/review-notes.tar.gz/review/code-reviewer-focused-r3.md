# Code-reviewer focused re-review, round 3 (wave 244in, spec 244fj)

Lane: code-reviewer. Context: `244in-code-reviewer-focused-r3`. Fresh and independent: I wrote neither the round-2 finding nor the repair.

Finding owned: `244in-cr-writer-census-incomplete`. Verdict: the repair holds. The lane clears.

## Round-2 writers, now

1. `render_platform_surfaces.render_codex_mcp_config`: Requirement 4 item 5.
2. `review_policy_upgrade.refresh_review_status_blocks`: Requirement 4 item 10.
3. `migrate_council_role_renames` and `migrate_lifecycle_document_renames`: named `in_place_raw` in Requirement 4; AC-10 counts five raw writers.
4. `design_token_build.update_manifest_parity`: Requirement 4 item 15, `in_place`.

## Executed probe

A stdlib AST probe (scratchpad `r3/probe.py`) on a throwaway copy of `.wavefoundry/framework/scripts/` (tests excluded) implements Requirement 10.2: direct primitives, or calls to the 10.4 wrappers, with `from M import f as g` resolution and no propagation through classified writers.

1. With the render modules' `write_text` treated as a wrapper: 194 writer functions. All five round-2 functions are writers: `render_codex_mcp_config` (0 primitive, 1 wrapper call), `refresh_review_status_blocks` (1, 0), `update_manifest_parity` (1, 0), both migrations (0, 1, through `_write_review_carrier_text`).
2. AC-14 check: a table equal to the full set reports no unclassified or stale entry. A table missing `update_manifest_parity` and `render_codex_mcp_config` (a writer missed in review) reports exactly those two as UNCLASSIFIED.
3. Known-bad copies: a new function with `p.write_text(...)` and a new function calling `_durable_json_replace` through `from upgrade_lib import _durable_json_replace as _djr` are each reported UNCLASSIFIED.
4. The callers of `render_codex_mcp_config` (lines 3186 and 3294) do not become writers through that call.

So a writer missed in review fails AC-14 at delivery, and the inventory is checkable.

## Advisory, not blocking

Requirement 9 calls the render modules' own `write_text` "a bytes writer". It must be classified `wrapper`, not `generated`; otherwise `render_codex_mcp_config` and the other render callers would not be writers. AC-10 already forces this, because those functions must appear as `in_place` and the census refuses an entry whose function does not write. Delivery reviewers should confirm the `wrapper` entry.

## Limitations

The probe is my own implementation of the rule, not the delivered census. It matches calls by name and does not follow dynamic loads, as the spec states. No tests were run (the 244fi full suite was running) and no repository file was edited.
