# release-reviewer focused r3 (wave 244in)

Remit rechecked against receipt review-policy-ac27848cef964a33ddb1. I own no open finding.

- Spec Requirement 5 is unchanged in substance: upgrade_extensions.py gets line_endings only through _incoming_framework_module("line_endings", ctx.zip_path); no top-level import; skip-with-warning on _IncomingModuleUnavailable. AC-7 still pins the zip-load and the known-bad top-level import.
- Probe (python3 -I, build_pack.should_exclude): scripts/tests/fixtures/line-ending-census.json -> excluded (True); scripts/tests/test_line_ending_census.py -> excluded; scripts/line_endings.py and scripts/upgrade_extensions.py ship (False). So the census fixture and test do not ship, and the helper does.
- build_pack.py is itself in EXCLUDED_REL_PATHS; its stampers write docs/prompts/prompt-surface-manifest.json (not in the pack) and the README badge (source repo only), so release bytes are unaffected.
- The census is test-only; no runtime path reads the fixture.
- Not run: tests (the 244fi full suite was running). Caveat from r2 stands: line_endings.py is not yet written; it must be stdlib-only with no sys.modules lookups.
