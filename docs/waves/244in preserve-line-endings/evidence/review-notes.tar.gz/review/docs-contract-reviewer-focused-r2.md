# Docs-contract focused reverification, round 2 (wave 244in)

Verdict: DC-1 repaired. Reverified at cycle 1 with no blocking lanes. No new blocking finding. No approval recorded.

## DC-1 checks

| DC-1 repair item | Spec now | Holds |
| --- | --- | --- |
| List the 20b39 row's "Prepare all-LF publication" for update | Affected Architecture Docs: mark that phrase superseded in `docs/architecture/testing-architecture.md`; the row still reads "Prepare all-LF publication" at line 75 today | Yes |
| Name `PrepareCRLFPublicationTests.test_prepare_publication_keeps_existing_all_lf_policy` as a test to invert | Named under AC-1 and as its own Task | Yes |
| The test is the current all-LF pin | Executed `python3 -B -m unittest test_server_tools_lifecycle.PrepareCRLFPublicationTests -v`: 1 test, OK; it asserts `assertNotIn(b"\r", ...)` | Yes |

## Earlier non-blocking points

- CHANGELOG task now covers the pure-CRLF `Wave: TBD` skip and the Prepare CRLF behavior change.
- The false "byte-stable LF" claim is gone; Requirement 9 now requires it.
- The "9 existing preservers" count matches between the Progress Log and Decision Log; Requirement 2 no longer claims the old rule.
- `docs/contributing/build-and-verification.md` is now in Affected Architecture Docs and Serialization Points.
