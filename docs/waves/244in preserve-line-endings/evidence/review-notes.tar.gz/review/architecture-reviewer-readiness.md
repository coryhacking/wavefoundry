# Architecture-reviewer readiness notes (wave 244in)

Verdict: one blocking finding, `244in-arch-census-wrapper-and-generated-gap`. No approval recorded.

Method: read the spec, then verified it against the code with read-only inspection. A 244fi `run_tests.py --no-cache` run was active, so no repo tests ran. Probes ran in the session scratchpad: a stdlib AST scan of the non-test framework scripts (165 write-primitive keys, plus every function that both reads and writes), and a stdlib newline probe.

## Seam: `line_endings.py`

This is the right seam. `contained_files.py` owns path containment and atomic publication and has no text policy. `markdown_layout._split_lines` is a per-line ending model for Markdown structure edits (the heading repair). The gardener reads with `newline=""` and substitutes raw text. The new module is a pure text-rule layer above all three, and each writer keeps its own primitive. The Decision Log reasoning holds.

Advisory points (not blocking):

1. Requirement 1 says the helper "owns the rule", but about nine inline copies of `"\r\n" if "\r\n" in text else "\n"` stay in place: `render_agent_surfaces` 2488, 2566, 2601, 3350, 4320, 4818 and 5725, `docs_gardener` 451, `review_policy_upgrade` 147 and `upgrade_extensions` 3338/3345. Point them at `line_endings.detect`, which changes no behavior, or give them their own census class. Without that, the census has to mislabel them `raw_substitution`.
2. `_read_wave_record_text` reads with universal newlines, so a lone `\r` becomes `\n`. `to_lf` keeps a lone `\r`. If one transaction compares the old read with the sibling, it can fail spuriously on a lone `\r`: `_publish_prepare_policy_state` checks `live != wave_text`. One writer transaction should use one read form.
3. `review_policy_reconcile.apply_reconciliation` and `reconcile_upgrade_policy_surface` edit files in place on raw decoded text. Name them in Requirement 2's raw-substitution list.
4. `PrepareCRLFPublicationTests.test_prepare_publication_keeps_existing_all_lf_policy` (`test_server_tools_lifecycle.py` 17854) pins the 20b39 all-LF rule this change supersedes. Name it as a test to invert.

## Generated versus in-place: the blocking part

The census in Requirement 9 keys direct primitive calls by enclosing function. Writes through content-forwarding wrappers are then attributed to the wrapper, not to the caller. None of these wrappers is in the primitive list: `_replace_artifacts_transactionally` (it carries the Prepare projection, change docs and the generated `events.jsonl` under one key), `_write_review_carrier_text` (21 callers), `_write_text_exclusive(_identity)`, `_write_bytes_atomic_exclusive(_identity)`, `_atomic_replace` (review_policy_upgrade and review_policy_reconcile), `_atomic_write_json`, `upgrade_lib._durable_json_replace`, `_write_handoff_text`, `write_install_log` and `_write_upgrade_review_log`. As specified, the census cannot verify the Prepare projection, and it cannot catch a new bypassing caller of any wrapper. That falsifies the AC-9 and AC-10 claims.

Requirement 8 says generated writers "keep their current byte-stable LF behavior". That is false on native Windows for writers that use default `Path.write_text(encoding="utf-8")`: `upgrade_wavefoundry._stamp_manifest_revision` (825), `build_pack.update_manifest_revision` (293), `gen_codebase_map` (1605, 1794), `design_token_build` (385, 427) and `wave_lint_lib.helpers.write_if_changed` (455). They emit `os.linesep`, and the `generated` class would accept them unchecked.

`docs/prompts/prompt-surface-manifest.json` is ambiguous. The gardener preserves its endings (`docs_gardener` 432, the 20dkl contract), but the upgrade stamp rewrites it with Pattern B. The spec counts it as generated.

Repair (spec only):

1. Add a `wrapper` class. Key and classify the callers of each wrapper.
2. Either check that `generated` keys never write in text mode with `newline=None`, or scope that out explicitly with a reason.
3. Classify the prompt-surface manifest the same way the gardener contract does.

## Architecture docs

The two planned rows are fine, but the plan is incomplete:

1. `docs/contributing/build-and-verification.md` lines 523-527 is the current normative newline-policy prose, and it covers the gardener only. Generalize it to all in-place writers.
2. Row 75 of `docs/architecture/testing-architecture.md` (20b39) says "Prepare all-LF publication". The new row must say it supersedes that, or the old row needs a note.

Add both to Affected Architecture Docs and Serialization Points.

## Verified claims

1. Under Windows translation, `\r\r\n` holds: the probe wrote `"Wave: X\r\nb\n"` with `newline="\r\n"` and got `b"Wave: X\r\r\nb\r\n"`.
2. A pure CRLF spec does not match the `(?m)^Wave: TBD$` regex.
3. `to_lf` plus `encode` repairs the pure CRLF spec with no `\r\r\n`.
4. A lone `\r` is kept.
5. The callers of `_write_repo_text_platform_newlines` are exactly `patch_thin_pointer` (2472) and the Cursor block (5744).
6. `_write_handoff_text` uses `os.linesep` (16519).
7. `create_wave` writes new files only.
