# Delivery review (wave 244in, change 244fj)

The change `244fj-bug preserve-line-endings-on-in-place-writes` is implemented. Its spec is in `docs/waves/244in preserve-line-endings/`.

**The operator's goal, "we should be consistent".** Every framework writer that edits an existing file in place keeps that file's line endings, the same way on Windows, macOS, Linux and WSL2. Fully generated files are LF bytes everywhere.

The mixed-file rule: existing lines keep their own ending, and inserted or replaced lines take the majority ending, with ties going to CRLF. A file with no line ending yet gets LF.

## Delivered

Paths are under `.wavefoundry/framework/scripts/` unless noted.

**New files:**
- `line_endings.py`, stdlib only
- `tests/line_ending_census_engine.py`, `tests/line_ending_support.py`, `tests/test_line_endings.py`, `tests/test_line_ending_census.py` and `tests/test_line_ending_writers.py`
- `tests/fixtures/line-ending-census.json`, the authoritative inventory (AC-14)

**Edited:** about 35 framework modules, about 15 existing test files, `.claude/hooks/pre-edit.py` (rendered through `wf_sync_surfaces`), CHANGELOG, `docs/architecture/testing-architecture.md`, `docs/contributing/build-and-verification.md` and `docs/references/native-windows-support.md`.

**Census totals:**
- Functions: 53 `in_place`, 7 `in_place_raw`, 72 `generated`, 24 `wrapper`, 36 `exempt`.
- Wrapper call sites: 34 `in_place`, 8 `in_place_raw`, 30 `generated`, 12 `wrapper`.

## Implementer-reported deviations to check

1. **Planner merge.** The two review-policy writers merge line endings in their planners, so the apply step's byte checks compare final bytes. The census accepts a `merged_by` planner when a reason is recorded.
2. **Council advisory.** Each `generated` entry pins its callers. A caller that is itself a writer needs a recorded reason; there are 11 orchestrator cases. A test relabels a wrapper as `generated`, and the census fails.
3. **Lifecycle check.** Each lifecycle output must equal its own LF content put back in the input's shape.
4. **AC-12 location.** The AC-12 test is in `test_line_ending_writers.py`.
5. **Handoff read.** `_write_handoff_text` reads the existing handoff itself before it merges.
6. **`upgrade_extensions.py` writers** take an optional `line_endings` argument and fall back to loading the module through `_incoming_framework_module`.
7. **Census rule refinements.** A `.open()` call with a non-literal first argument counts as a read, and a non-literal file mode needs a recorded reason.
8. **Behavior change.** Writers no longer rewrite files whose content is unchanged. CHECK that this does not break a caller that relies on mtime or a write happening, such as gardening stamps, receipts or the `changed` and `updated` flags.
9. **Windows.** Windows behavior is verified by simulation only. No native run was made.

## Your task

As a FRESH, independent reviewer of your lane:
1. **Read.** Load MCP tools via ToolSearch first and use code_* MCP-first. Read the spec, its Progress and Decision Logs, and `git diff` for the files in your remit.
2. **Verify each AC in your remit** against the code with EXECUTED checks: mutants on a scratch copy, probes and focused tests (`python3 -B .wavefoundry/framework/scripts/run_tests.py --file <f>`). Never run the full suite.
   - Make NO repo edits.
   - Before running tests, check `pgrep -f "run_tests.py --no-cache"`. If the full suite is running, wait for it, or use read-only inspection and scratch-copy probes only.
3. **Record in the typed ledger.** Use `wf_review_event`, wave `244in`: dry-run first, then create.
   - For each real defect, record a delivery finding: `run_kind='initial_delivery'`, cycle 0, `actor=<lane>`, `context_id='244in-<lane>-delivery'`, with honest `execution_status`.
   - If you find no blocker, record your delivery approval: `event='approval'`, `signoff_key=<lane>`, `approval_phase='delivery'`, `fresh_context=true`, `independent=true`, as executed, with your OWN honest `integrity_checks`.
4. **Write notes** to `.wavefoundry/work/244in/review/<lane>-delivery.md`. No em-dashes.
5. **Reply** in under 100 words.

## Also, before your delivery verdict: re-record readiness

The receipt rotated to `review-policy-213cec54a9859a91285e` during implementation. The implementer added Decision Log rows and Serialization Points paths. That made your lane's readiness approval stale.

1. Read the changed Decision Log and Serialization Points sections.
2. Re-record your readiness approval on the current receipt: `event='approval'`, `signoff_key=<lane>`, `approval_phase='readiness'`, `context_id='244in-<lane>-readiness-r4'`, `fresh_context=true`, `independent=true`, executed, with your own honest `integrity_checks`. Run it as `dry_run` first, then `create`.
3. If those sections reveal a plan defect, record a finding instead.

Then do the delivery review.

The initial_delivery run is already recorded (`run-initial-delivery`). The full suite passed: 13,402 tests OK, log `.wavefoundry/work/244in/impl/full-suite-2.log`.
