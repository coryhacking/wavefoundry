# Docs-contract readiness notes, wave 244in

Verdict: one blocking finding (DC-1, do_now, low). I recorded no approval.

## Contract statements of the newline policy

| Source | Statement | After 244fj |
| --- | --- | --- |
| Memory `1svek` | Generated surfaces are byte-stable LF; in-place patches keep the file's newline style | Accurate. The spec extends the same rule. Optionally add `line_endings.py` as a target at close |
| Wave 22yox (`22y1k`) | The heading fix keeps each document's endings | Accurate. It is a raw-substitution writer and is not routed |
| `docs/contributing/build-and-verification.md` 523-533 | The gardener preserves LF and CRLF; new manifests and handoffs are LF; JSONL is LF-only | Accurate |
| `docs/specs/mcp-tool-surface.md` (796, 824, 1986, 2170, 2184, 2582) | CRLF is read as LF for comparisons; Prepare's heading fix keeps endings | Accurate. No tool-surface text states the LF output that changes |
| Seeds 160 and 209 | Templates compared after normalization; JSONL is LF-only | Accurate |
| `docs/architecture/testing-architecture.md:75` (20b39 row) | "Prepare all-LF publication" | **Becomes false.** The spec supersedes 20b39, but Affected Architecture Docs only adds a new row (DC-1) |
| `docs/references/native-windows-support.md` | No current statement | The spec adds one, as planned |

**DC-1 repair:** list the 20b39 row's "Prepare all-LF publication" for update in Affected Architecture Docs. Name `PrepareCRLFPublicationTests.test_prepare_publication_keeps_existing_all_lf_policy` (`test_server_tools_lifecycle.py:17855`) under AC-1 or the Tasks as a test to invert.

## CHANGELOG task

The bullet should also cover:
- the silent skip: a pure-CRLF spec's `Wave: TBD` line was never repaired; this is more common than `\r\r\n`
- that Prepare and the lifecycle tools now keep a CRLF wave record CRLF instead of publishing all-LF, which is a visible change to documented 20b39 behavior

This is not blocking.

## Writing guide

The prose generally leads with the answer and states each claim precisely. Points to fix:
- Requirement 8 says generated writers "keep their current byte-stable LF behavior". That is not true on Windows for text-mode writers such as `_stamp_manifest_revision` (see RT-1). Reword it to "keep their current behavior", or make them byte-stable.
- "Planner default" and "Coordinator decision" in the Decision Log are process labels. They are acceptable in a Decision Log.
- Requirement 2 says "the rule that the existing preserving writers already apply". The Decision Log says "at least nine". State 9 in both places; I counted 9 in non-test code.

Evidence: `grep` across docs/specs, docs/architecture, docs/references, docs/contributing and the seeds, plus reads of the memory record and the 22yox spec. The 244fi suite was running, so I ran no tests. DC-1 is recorded with `execution_status: inferred`.
