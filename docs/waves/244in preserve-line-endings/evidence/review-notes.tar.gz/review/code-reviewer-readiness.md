# Code-reviewer readiness notes (wave 244in, spec 244fj)

Lane: code-reviewer. Context: `244in-code-reviewer-readiness`. Fresh, independent.
The full 244fi suite (`run_tests.py --no-cache`, pid 37966) was running, so no `run_tests.py` was invoked. Evidence is read-only inspection plus stdlib probes on temp files in the session scratchpad.

## Verdict

One blocking finding: `244in-cr-writer-census-incomplete`. The helper API and the `\r\r\n` claim hold. The writer list and the census design do not cover every in-place writer.

## Claims that hold

1. **`\r\r\n` claim (executed).** The probe simulated Windows text mode with `io.TextIOWrapper(newline="\r\n")`, which is what `newline=None` does on Windows.
   1. A pure CRLF spec does not match `(?m)^Wave: (?:...|TBD)$`, because `\r` sits before `$`. The repair is skipped.
   2. A mixed spec with an LF `Wave:` line matches. The Windows write gives `b'# T\r\r\nWave: 244in x\r\nbody\r\r\n'`. On POSIX the bytes are kept.
   3. The read is raw. `_read_member_doc_text` decodes `contained_files.read_contained` bytes, so `\r` survives. This is confirmed at `lifecycle_gate_support.py:515` and `server_impl.py:9426-9438`.
2. **Helper API.** `detect`, `to_lf` (lone `\r` kept) and `encode` round-trip. `\r\r\n` round-trips as `\r\n` after `to_lf` and back as `\r\r\n` after `encode`, so no new corruption is possible. Whole-file CRLF for a mixed file matches the existing preservers (`render_agent_surfaces` 2488/2566/2601/3350/4320/5725, `docs_gardener` 451, `review_policy_upgrade` 147, `upgrade_extensions` 3345). The per-line preservers (`wf_close_change` at 15679, mark tools, `_upsert_review_protocol_region` and `_upsert_review_policy_region`) correctly stay outside the helper.
3. **Write primitives and containment.** Routing keeps each writer's current atomicity and containment. `_atomic_replace_bytes` is a same-directory temp plus `os.replace`. `write_contained_bytes` is contained. The plain `write_text` sites (`wf_add_change`, `wf_remove_change`, `wf_implement_wave`, `wf_close_wave`, `wf_pause_wave`, `wf_reopen_wave`, `wf_prepare_wave`) are neither atomic nor contained today. Switching them to `write_bytes(encode(...))` keeps that, and does not regress anything.
4. **Windows simulation.** The `Path.open` patch in `test_docs_gardener.py` does catch `Path.write_text` on Python 3.11, 3.13 and 3.14 (executed: `b'x\r\ny\r\n'`).

## Blocking: writer census incomplete, and the census misses wrapper call sites

These writers meet Requirement 4's rule but are not listed:

1. `setup_wavefoundry.py:260-291` reads `docs/workflow-config.json` with `json.loads(read_text)` and writes it through `upgrade_wavefoundry._atomic_write_json`, which uses `tmp.write_text`, a text-mode write. This is Pattern B on an operator-owned config.
2. `upgrade_wavefoundry.materialize_lifecycle_policy` (5672-5754) reserializes the same file the same way. Executed with the real `_atomic_write_json`:
   1. On POSIX, a CRLF config becomes `b'{\n  "a": 1,\n  "b": 2\n}\n'`.
   2. Under the Windows simulation, an LF config becomes `b'{\r\n  "a": 1,\r\n  "b": 2\r\n}\r\n'`.
3. `render_agent_surfaces.reconcile_context_efficiency_surface` (5524-5556) reads raw and calls `context_efficiency.replace_carrier_block`, which inserts an LF block. On CRLF input the file becomes mixed. Executed: an append gives 3 CRLF and 15 bare LF; a replace gives 4 CRLF and 13 bare LF.
4. `review_policy_reconcile.plan_reconciliation`/`apply_reconciliation` and `reconcile_upgrade_policy_surface` (342-351, 466-485) insert LF blocks into raw text. Executed: an upgrade-policy append on CRLF input gives 2 CRLF and 48 bare LF.
5. `wave_lint_lib/secrets_validators.save_exceptions` reserializes `docs/scan-findings.json`, which is committed and holds operator confirmations, with `write_text` (Pattern B). It needs either routing or an explicit `generated` classification with a stated reason.

The census in Requirement 9 keys on the function that encloses a primitive call. Its primitive list omits the wrappers `upgrade_wavefoundry._atomic_write_json`, `render_agent_surfaces._write_review_carrier_text`, `review_policy_reconcile._atomic_replace`, `review_policy_upgrade._atomic_replace`, `upgrade_lib._durable_json_replace`, `save_exceptions`, `wave_lint_lib.helpers.write_if_changed`, `context_efficiency._write_exclusive` (raw `os.write`) and binary `os.fdopen(..., "wb")`. As a result:

- `setup_wavefoundry`'s call is not a census key at all.
- The one wrapper key (`_atomic_write_json`) serves both new-file and in-place callers, so a single classification cannot be right.
- A new in-place writer that calls an existing wrapper passes AC-9.

**Fix:** add items 1 to 4 to Requirement 4 and classify item 5. Make the census key wrapper call sites, by treating each module-local write wrapper as a primitive or by requiring wrappers to appear in a closed list. Add an AC-9 known-bad copy that writes through a wrapper.

## Non-blocking notes

1. Requirement 3 says no routed writer opens text mode. `memory_records._atomic_replace_text` is `NamedTemporaryFile(mode="w", newline="")` and takes `str`. The memory writers need a bytes variant, or the requirement needs a carve-out for `newline=""`.
2. The memory writers (`record_memory_validation`, `reconcile_memory_record`, `archive`) already write with `newline=""`. That is Pattern A, so AC-5's "LF record under the Windows simulation fails today" does not hold for them. Only the CRLF half fails today.
3. `lifecycle_gate_support._read_wave_record_text` uses `read_text` (universal newline), not raw bytes, despite its "raw-read boundary" docstring. The new sibling must read bytes.
4. The simulation patches `Path.open` only. It does not cover builtin `open`, `os.fdopen` or `NamedTemporaryFile` text writes (executed: those stay LF). Any routed writer test that relies on it must use a `Path` write.
5. Out of scope, for the record: new-file writers that use plain `write_text`, such as `gen_codebase_map.scaffold_area_contexts`, still create CRLF files on native Windows. Requirement 7 binds only routed writers.
6. `upgrade_wavefoundry._atomic_write_text` (2556) has no callers.
