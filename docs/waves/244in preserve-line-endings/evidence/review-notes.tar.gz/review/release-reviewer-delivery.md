# release-reviewer delivery notes (wave 244in)

- Real pack (build_pack.collect_files, 277 files): ships line_endings.py; no tests or line-ending-census fixture; should_exclude True for scripts/tests and its census files.
- Exec of the real upgrade_extensions.py from a zip (relative __file__), no line_endings.py beside it: loads; _incoming_framework_module("line_endings", zip) works, private, not in sys.modules. No zip: _IncomingModuleUnavailable; _load_line_endings returns None with a warning.
- ctx-holding callers pass the module. Old upgrade_wavefoundry.py writers run on the first upgrade, so the CHANGELOG caveat is accurate.
- CHANGELOG entry: user-facing, no build numbers.
- Non-blocking: _strip_pycache_row_legacy_single_path (no internal callers) would raise unguarded if called outside a zip load.
- Readiness r4 re-recorded; delivery approval recorded.
