# release-reviewer readiness notes (wave 244in)

Verdict: one blocking finding (upgrade old-code window). Everything else in my lane holds.

## build_pack._stamp_readme_version_badge
- Writes the repo-root README.md, which is not a pack member (the pack walks only the framework dir; `.wavefoundry/README.md` is a separate arcname). Routing it through the helper cannot change pack bytes, MANIFEST, protocol metadata or provenance.
- It runs once in the release flow, before `git add -A` and the stamp commit. Preserving the README's own ending changes only the stamp commit's bytes, and only toward a smaller diff: today POSIX flips a CRLF README to LF and Windows flips an LF README to CRLF (whole-file diff). The tag, push and `gh release` steps are untouched. Return value (changed or not) and never-raises contract stay if the helper read and write are inside the existing try blocks.
- `build_pack.py` is in EXCLUDED_REL_PATHS (source-host only), so it adds no old-window exposure. It already inserts SCRIPTS_DIR on sys.path, so a top-level `import line_endings` works.

## Pack inclusion
- `collect_files` os.walks the whole framework dir and excludes only the listed names, so `scripts/line_endings.py` ships automatically and `write_manifest` lists it. No exclusion edit needed.
- `FRAMEWORK_SCRIPT_MODULE_NAMES` is census-pinned to the directory (spec task covers it). The `.claude/hooks/pre-edit.py` digest refresh is covered by `wf_sync_surfaces`.

## Old-code window (finding)
- `upgrade_wavefoundry._load_extension_module` exec()s the NEW pack's `upgrade_extensions.py` source from the zip as a standalone module. Its sibling imports resolve against the target's INSTALLED scripts dir, which in the old-code window has no `line_endings.py`.
- Executed probe (scratchpad, throwaway zip): a module with top-level `import line_endings` loads as `upgrade_extensions.py load error - skipping: No module named 'line_endings'` and returns None. The whole extension, with every migration in `post_extract`, is silently skipped. This also hits the dry-run preview, which runs before extraction.
- The spec routes four `upgrade_extensions.py` writers (Requirement 4 item 6) and says nothing about import mode. A conventional top-level import is the natural implementation and would break upgrades from every older release.
- Required: state in the spec that `upgrade_extensions.py` must not top-level import `line_endings` and must stay self-contained (a private inline copy of the 3-line rule, or `_incoming_framework_module('line_endings', zip_path)`), plus a test that execs the module from a zip with no `line_endings.py` beside it. `_rewrite_legacy_config_keys(repo_root)` has no ctx or zip_path, so inline is simpler.
- A lazy in-function import is weaker: it works only after extraction, and a dry-run or pre-extract call path would raise.
- Server-side writers (server_impl, memory_records, render_*) run from the installed new code after extraction, so a normal top-level import is safe there; the reload purge registration covers hot reload.

## What cannot reach the installing upgrade
- The old `upgrade_wavefoundry.py` runner stays in force for that upgrade: its own writers (for example the prompt-surface-manifest `framework_revision` stamp at line 825, a generated file) and the old render and memory steps keep old behavior until the next upgrade. The spec's `upgrade_extensions.py` fixes DO reach the installing upgrade because that module comes from the new pack. Worth one sentence in the CHANGELOG or spec so the first upgrade from an old release is not expected to preserve every ending.
- `upgrade_wavefoundry.py` has no in-place writer of an existing operator file in this list that the spec misses (825 is generated; 5615 creates a new file; `_atomic_write_json` writes the state/progress files). No census gap found in this lane.
