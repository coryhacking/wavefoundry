# Council-chair readiness synthesis (wave 244in)

Context: `244in-council-chair-readiness`. Fresh and independent: I wrote no finding, repair or lane note.

## Verdict

Approve readiness. intent_fit: establishes.

- Receipt `review-policy-ac27848cef964a33ddb1`; code-reviewer, qa-reviewer, architecture-reviewer and release-reviewer approvals are current.
- All 8 findings are terminal in `wf_review_event(event='list')` chain_summary, with no unresolved lanes.

## Seats

| Seat | Finding | Evidence |
| --- | --- | --- |
| red-team | RT-1 cleared, cycle 1 | `red-team-focused-r2.md`: executed reimplementation of `to_lf`, `majority`, `merge` over nine cases |
| docs-contract-reviewer | DC-1 cleared, cycle 1 | `docs-contract-reviewer-focused-r2.md`: executed `PrepareCRLFPublicationTests` run |

## Strongest challenge

Three rounds each found more writers by hand. The operator-approved answer is AC-14, census as inventory. Under Requirement 10.2 a function is a writer when it calls a primitive or a classified wrapper. From-imports resolve, and status propagates only through wrappers. Every direct primitive caller is therefore reported unclassified. The open question is what lies behind each wrapper.

The remaining trust point is classification. A wrapper misclassified as `generated` (bytes, so it passes the LF rule) hides every caller behind it. AC-10 limits this: if a known in-place writer sits behind the misclassified wrapper, its `in_place` entry fails as "no longer writes". A misclassified wrapper with no known writer behind it is caught only by delivery review of the table.

Advisory for delivery: check every `generated` entry whose write path and content both come from parameters; it is probably a `wrapper`.

## Strongest alternative

Use a single line-ending-aware write primitive that calls `merge` itself. The census would then only have to prove that nothing bypasses it. The Decision Log rejects this because writers use many containment and atomic primitives. The helper-plus-census design is a reasonable trade-off.

## Chair probes (executed, scratchpad, no repo edits, no tests)

1. `chair/probe/census.py` on an rsync copy of the non-test scripts tree:
   1. 5597 functions and 128 direct writers.
   2. 167 writers under the rule with the 18 distinct named wrappers.
   3. Five unnamed wrapper-shaped direct writers, which the census forces into the table: `render_agent_surfaces._write_repo_bytes`, `render_platform_surfaces.write_text`, `server_impl._write_handoff_text`, `upgrade_extensions._write_preview_log` and `qualification_report.write_report`.
   4. Known-bad: without `write_text` and `_write_repo_bytes` as wrappers, 16 writers disappear, including `patch_root_bridge`, `render_codex_mcp_config` and `render_gitignore_block`. AC-10 would catch that.
2. `chair/probe/merge.py`, the Requirement 1 rule on stdlib `difflib`. Each case gave the expected bytes, with no `\r\r\n`:
   1. Missing final ending plus an append.
   2. Duplicate-line alignment.
   3. A pure CRLF `Wave: TBD` repair, which stays CRLF.
   4. A deletion.
   5. An empty file, which gives LF.
   6. Unchanged mixed content, which is not rewritten.

## intent_fit

The operator's goal is "we should be consistent".

- In-place edits keep each line's ending through `merge` and `encode`, never `os.linesep`. This is identical on Windows, macOS, Linux and WSL2.
- New and generated files are LF.
- The wave Objective states the same.

Verdict: establishes.

## Records

1. The first approval, `244in-council-chair-readiness` (`ev-approval-council-readiness`), did not use the canonical `Prepare-phase Wave Council PASS (...)` verdict line.
2. A second approval, `244in-council-chair-readiness-v2` (`ev-approval-council-readiness-2`), restates the same verdict in that format.
3. `wf_prepare_wave(mode='ready')` returned `readied: true`, `transitioned_to_active: false`, `pending_readiness_lanes: []`, and lint and garden passed.
4. `council_verdict_present` and `council_verdict_valid` stay false. They come from `_prepare_council_verdict_info`, which reads a prose verdict in the wave text. On this ledger-authority wave that prose is optional and is not authority.

## Limitations

The probes implement the spec rule, not the delivered census or `line_endings.py`, which do not exist yet. Call matching is by name, and dynamic loads are unresolved by design.
