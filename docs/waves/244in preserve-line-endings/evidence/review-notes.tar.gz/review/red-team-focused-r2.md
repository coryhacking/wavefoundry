# Red-team focused reverification, round 2 (wave 244in)

Verdict: RT-1 repaired. Reverified at cycle 1 with no blocking lanes. No new blocking finding. No approval recorded.

## RT-1 parts against the repaired spec

| RT-1 part | Repair in the spec | Holds |
| --- | --- | --- |
| `materialize_lifecycle_policy` rewrites `docs/workflow-config.json` through `_atomic_write_json` and was not routed | Requirement 4 item 7 routes it; the code still has one caller at `upgrade_wavefoundry.py:5754` | Yes |
| `_atomic_write_json` and `_atomic_write_text` hid their callers from the census | Requirement 10.2 makes writer detection transitive; 10.4 lists both as wrappers and keys each call site; AC-9 case 2 is a new caller of `_atomic_write_json` | Yes |
| `_stamp_manifest_revision` writes CRLF on Windows and disagrees with `_write_prompt_manifest` | Both are routed `in_place` (Requirement 4 items 4 and 7; Decision Log row on the prompt manifest) | Yes |
| Requirement 8 claimed generated writers were already byte-stable LF | Requirement 9 now requires LF bytes or an explicit `newline`; the census fails any text-mode write with `newline` unset (10.5); AC-6 | Yes |
| Attack 2 risks (raw-byte change checks, live compares) | Requirement 3: compare `new_lf` with `to_lf(original)`, one read per transaction; AC-5 | Yes |

## Mixed-file probe against the new rule

I reimplemented `to_lf`, `majority` and `merge` exactly as Requirement 1 states them (`difflib.SequenceMatcher(autojunk=False)` over LF lines) in the scratchpad and ran it with `python3 -I`.

| Case | Result |
| --- | --- |
| 200 LF lines plus one stray CRLF line, one line edited | Only line 50 differs; the stray CRLF line is kept; no `\r\r\n` |
| Same file, one line inserted | 1 line changed; the new line takes LF (majority) |
| Known-bad: old "any CRLF" rule on the same edit | 200 of 201 lines differ |
| More CRLF than LF, line appended | New line CRLF |
| Tie (1 CRLF, 1 LF) | New line CRLF |
| No terminated line | LF; a missing final ending stays missing |
| Unchanged content on a mixed file | Byte-identical output |
| `\r\r\n` input, unchanged | Round-trips byte-identical |
| All-CRLF wave record, one line edited | Stays all CRLF; 1 line changed |

## Non-blocking observations

- A replaced line takes the majority ending, so editing the stray CRLF line itself turns it LF. This follows Requirement 2 and is acceptable.
- `to_lf` is a single-pass replace, so it is not idempotent on `\r\r\n` (`\r\r\n` becomes `\r\n`). Writers must apply it once per read, as Requirement 3 says. AC-8 covers the round-trip.

Limit: the probe exercises the spec's rule, not shipped code; `line_endings.py` does not exist yet.
