# code-reviewer delivery notes (wave 244in, change 244fj)

Fresh, independent code-reviewer. No repo edits. Mutants and probes ran on a scratch copy of `.wavefoundry/framework` under the session scratchpad.

## Readiness re-record (r4)

I read the changed Decision Log rows and the Serialization Points path list. Each new row matches the delivered code:

- `plan_reconciliation` and `plan_review_policy_upgrade` merge against the raw read.
- `_write_handoff_text` reads the existing handoff raw and merges `to_lf(text)`.
- The `to_lf` reads are in place.
- The `upgrade_extensions` optional `line_endings` argument is present.

I found no plan defect in this lane.

## Helper merge rule (`line_endings.py`)

The code matches the stated rule:

- Equal lines keep their own ending.
- Inserted or replaced lines take the majority ending, and a tie goes to CRLF.
- With no terminated line, the default is LF.
- A previously unterminated line that gains a successor takes the majority ending.
- `to_lf` keeps a lone `\r`.

`merge(o, to_lf(o)) == o` holds, including for `\r\r\n`.

Mutants, each killed by `test_line_endings`:

- A: tie goes to LF (`crlf > lf`). 2 failures.
- B: equal lines drop their original ending. 5 failures.

Performance: a 20,000-line CRLF file with two edits merges in 0.02 s. A pathological file of 5,000 identical lines takes 1.9 s, because `SequenceMatcher` runs with `autojunk=False`. Real records are about 100 lines, so this is not a defect.

## Routed writers: double merge and skipped merge

I read every non-test `line_endings.merge` call site. Each merges the raw original with LF text computed on `to_lf(original)`. The census reports no function outside `in_place` that calls merge. Spot checks:

- `wf_close_change_response`: 3 wrapper calls, which are 2 merged writes plus a raw restore.
- `wf_review_event` `transact`: `events.jsonl` LF plus the merged projection.
- `ensure_manifest`: the second write creates a new LF file.
- The review-policy planners: `config_after` and the carrier/wave bytes are merged against the raw reads, and apply publishes the planned bytes.

`_write_handoff_text` applies `to_lf` to its input, so a caller passing already-merged text cannot double-merge. Its callers read through `_decode_repo_text`, which turns a lone `\r` into `\n`. That pre-existing behavior is unchanged from `read_text`.

Writer mutants (census result and behavior result):

- C: `memory_records.reconcile_memory_record` with `newline="\r\n"`. Census: passes. Behavior: `test_memory_records` has 22 failures.
- D: `docs_gardener.ensure_manifest` with a double merge `merge(old, merge(old, new))`. Census: passes. Behavior: `test_docs_gardener` has 5 failures (crlf and mixed).
- E: `gen_codebase_map._refresh_repo_index_modules` with merge called but its result discarded. Census: passes. Behavior: `test_gen_codebase_map` has 4 failures.

## Deviation 8: unchanged writes are skipped

New skips were added in these writers:

- `build_pack.update_manifest_revision`
- `design_token_build.update_manifest_parity`
- `docs_gardener.ensure_manifest`
- `save_exceptions`
- `_stamp_manifest_revision`
- the `render_platform_surfaces` JSON and ignore writers

The `render_platform_surfaces.write_text` path already skipped byte-identical writes through `write_contained_bytes` (wave 1zuq3), and `_manifest_record` still records only changed content.

Callers:

- `ensure_manifest` returns `changed=False` only when the LF content is equal, which is correct. Before this change, a CRLF manifest reported `changed=True` on every run.
- `_stamp_manifest_revision` returns early when the revision is equal, which predates this change.
- The `save_exceptions` callers write only on `exceptions_changed` or an absent file. An absent file still gets `original == ""` and is created.
- `update_manifest_revision` has one caller in the build, and nothing there reads its mtime.

The framework test receipt and gardening `Last verified` stamps do not pass through these writers. I found no caller that relies on mtime, `changed` or `updated`. AC-5 pins the `_merge_mcp_server` mtime.

## Census engine loopholes (advisory, not blocking)

- `calls_merge` is function-wide and is not tied to the written value. Mutants D and E pass the census, so the behavior matrices are the real oracle for the shape of each merge. AC-9.3 only claims detection of a removed merge, so it is met.
- The census does not check the `newline` value for `in_place` writers (mutant C passes). Only `generated` entries are value-checked. The behavior matrices catch it.
- Static blind spots, executed with probe module `zz_probe` (current tree: no instances, checked by AST walk):
  - `p.open(mode_var)` writes, from deviation 7.
  - a bound-method alias (`w = p.write_text; w(...)`).
  - `builtins.open(p, "w")`.
  - `**kwargs` is treated as `newline` set.
- `merged_by` and `newline_unset_reason` are honored on any entry that carries a reason string. They are guarded only by table review. The two `merged_by` uses and the one `newline_unset_reason` use (`graph_quality_eval:materialize`, a scratch corpus) are justified.

## Verdict

No blocker in the code-correctness lane. The delivered census reports zero failures, and the `test_line_endings` and `test_line_ending_census` files pass on the scratch copy (29 tests OK).
