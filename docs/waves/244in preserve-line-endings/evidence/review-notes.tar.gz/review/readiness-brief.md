# Readiness review brief (wave 244in)

Wave `244in preserve-line-endings` holds one spec: `244fj-bug preserve-line-endings-on-in-place-writes`, in `docs/waves/244in preserve-line-endings/`.

**The operator's decision (2026-11-22), in their words: "we should be consistent".** Every framework writer that edits an EXISTING file in place must preserve that file's own line endings, the same way on Windows, macOS, Linux and WSL2. Fully generated files keep the byte-stable LF policy (memory record 1svek). Operator-owned files the framework reserializes count as in-place edits, for example `.mcp.json`, host configs and the managed `.gitignore` block.

**The plan:**
- A new `line_endings.py` helper (`detect`, `to_lf`, `encode`, `read`).
- 30 in-place writers routed through it, each keeping its own write primitive.
- An AST census test that classifies every write call.
- A verified census of 12 gating digests. Each is stated correct as it is, and the small-change content digest stays byte-exact on purpose, because line endings can be functional.

**Coordinator decisions:**
- A mixed file counts as CRLF if it holds any CRLF.
- A change to a product file that touches only line endings still lapses a narrow approval.
- A re-render of a generated file on a CRLF checkout is out of scope.

Implementation waits for wave 244fi to close; both change `memory_records.py`.

**Review setup.** The receipt is `review-policy-e4956ec0ef8bd1491b59`. The required lanes are code-reviewer, qa-reviewer, architecture-reviewer and release-reviewer (`build_pack.py` is in scope). The council seats are red-team (primer, standard depth) and docs-contract-reviewer (rotating).

As a fresh, independent reviewer of your lane:
1. **Read the plan.** Load the MCP tools via ToolSearch first, and use code_* retrieval MCP-first. Read the spec, its Decision Log and its two censuses.
2. **Verify against the code.** Check the load-bearing claims against the code, not the spec's prose:
   - every listed writer reads and writes as claimed, and no in-place writer is missing; check upgrade_wavefoundry.py, setup and the renderers
   - the `\r\r\n` mixed-file claim holds on Windows translation
   - the helper design covers per-line preservation where existing writers need it
   - the AST census is feasible and would catch a new bypassing writer
   - each digest's current behavior in the 12-gate census is correct
3. **Make no edits.** Make NO repo edits. A full test suite for wave 244fi may be running in this tree. Before running any test, check with `pgrep -f "run_tests.py --no-cache"`. If it is running, use read-only inspection and stdlib probes on a throwaway copy only, and do not run `run_tests.py`. Once it is gone, you may run `python3 -B .wavefoundry/framework/scripts/run_tests.py --file <f>`, but never the full suite.
4. **Record your result.** For each blocking defect, record a typed readiness finding: `wf_review_event(wave_id='244in', event='finding', run_kind='readiness', cycle=0, actor=<lane>, context_id='244in-<lane>-readiness', ...)`. Dry-run first, then create. State `evidence.execution_status` honestly.

   A required lane with no blocker records a readiness approval instead (`event='approval'`, `signoff_key=<lane>`, `approval_phase='readiness'`, `fresh_context=true`, `independent=true`), with your OWN honest `integrity_checks`. Approvals need executed evidence, so run a probe.

   Council seats write notes only, plus a finding when one blocks.
5. **Write notes** to `.wavefoundry/work/244in/review/<lane>-readiness.md`. No em-dashes.
6. **Reply** in under 100 words.
