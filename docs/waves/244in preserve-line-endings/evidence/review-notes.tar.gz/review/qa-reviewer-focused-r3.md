# qa-reviewer focused round 3 (wave 244in)

Context: `244in-qa-reviewer-focused-r3`, fresh and independent. I made no repo edits. The probes ran with `python3 -I -B` in the session scratchpad (`qa-r3-17112`), on a throwaway copy of `.wavefoundry/framework/scripts`. I ran no tests, because the 244fi full suite was running.

## 244in-qa-census-wrapper-blindspot: repair holds, lane cleared

Requirement 10.2 now resolves `from M import f [as g]` to `M.f`. This covers module-level and function-local imports, absolute and package-relative. AC-9 item 7 adds the known-bad from-import caller.

The probe (`qaprobe.py`) implements the rule as written, with bare-name, `module.attr` and from-import resolution against the 19 named wrappers.
- Delivered-tree copy: 54 wrapper call sites, 4 of them through a from-import. They are exactly the four named sites:
  - `wave_lint_lib.cli._emit:441` calls `wave_lint_lib.helpers.write_if_changed` (relative import).
  - `sqlite_storage_migration._write:216` and `retire_prestaging_noop:1189` call `upgrade_lib._durable_json_replace` (function-local import).
  - `review_policy_upgrade.apply_review_policy_upgrade:210` calls `review_policy_reconcile.apply_reconciliation` (top-level import).
- Known-bad copy: I appended an aliased module-level from-import caller and a function-local caller of `_durable_json_replace`. The probe found 56 sites, 6 through a from-import, and both new callers were reported.
- Wrapper-only propagation: 165 writer functions, against 503 under full transitive closure. `wave_lint_lib.cli.main` and `upgrade_wavefoundry.main` are not writers under the rule, so ordinary callers stay unmarked.

## AC-14 is checkable

The census keys writer functions and wrapper call sites, and the table location is fixed (`tests/fixtures/line-ending-census.json`). That makes "zero unclassified" a mechanical assertion. Delivery reviewers can verify the table entry by entry against a census run.

## Limitation

The probe is my own resolver of the spec rule, not the census test, which does not exist yet. Its `open()` mode detection is approximate and was used only for the writer counts.
