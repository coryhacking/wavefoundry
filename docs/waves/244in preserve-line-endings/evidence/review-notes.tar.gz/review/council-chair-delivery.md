# Council-chair readiness r4 and delivery (wave 244in)

Fresh and independent: I wrote no finding, repair or lane note.

## Readiness re-record (r4)

- Receipt `review-policy-213cec54a9859a91285e`. The four required lanes re-recorded readiness with context `-readiness-r4` and found no plan defect.
- I read the new Decision Log rows: planner merge through `merged_by`, `_write_handoff_text` reading raw itself, `to_lf` reads, and the optional `line_endings` argument in `upgrade_extensions.py`. I also read the Serialization Points list. No plan defect.
- Recorded `council-readiness`, context `244in-council-chair-readiness-r4` (`ev-approval-council-readiness-3`), intent_fit establishes. The readiness packet now shows all five readiness approvals current.

## Delivery

- Ledger: all 9 findings are terminal, with no unresolved lanes, including `244in-arch-exempt-wrapper-blindspot` at cycle 2.
- `wf_review_wave(phase='implementation')`: code-reviewer, qa-reviewer, architecture-reviewer and release-reviewer are current. Before my record, only council-delivery and operator-signoff were missing.

| Seat | Finding | Evidence |
| --- | --- | --- |
| red-team | RT-1 cleared, cycle 1 | `red-team-focused-r2.md` |
| docs-contract-reviewer | DC-1 cleared, cycle 1 | `docs-contract-reviewer-focused-r2.md` |

## Executed by the chair

1. Full suite `full-suite-3.log`: Ran 13404 tests across 258 files, OK. `test-cache.json` has `result` `ok`.
2. `run_tests.py --file test_line_ending_census.py`: 16 OK. `--file test_line_endings.py`: 15 OK. The receipt was byte-unchanged afterwards, and there was no `__pycache__` under `.wavefoundry/framework/`.
3. Scratchpad probe `chair/probe.py` against the delivered `line_endings.merge`:
   1. CRLF, LF, a 200-line LF file with one stray CRLF line, and `x\r\r\n` each round-trip byte for byte.
   2. One edit plus one append changes exactly one existing line, with no new `\r\r\n`.
   3. Known-bad: a naive whole-file CRLF rewrite of the mixed file changes 200 lines.

## Strongest challenge

The census proves classification, not merge shape. `calls_merge` is function-wide, so a double merge, a discarded merge result, or an in-place `newline` value other than `""` all pass the census alone (code-reviewer mutants C, D and E). `merged_by` and `newline_unset_reason` are guarded only by table review.

Three controls cover this:

- The writer behavior matrices kill each of those mutants.
- `IN_PLACE_NEWLINE` now rejects a translating newline.
- `exempt` entries now pin their callers.

The residual is a future author misclassifying a new caller, which is a review judgment.

## Strongest alternative

A single line-ending-aware write primitive that calls `merge` itself. It is still rejected: writers use many containment and atomic primitives, and the planner `merged_by` boundary keeps the review-policy "changed after preflight" byte checks working.

## intent_fit: establishes

The operator's goal is "we should be consistent".

- In-place writers publish `encode(merge(...))` or `newline=""` writes, never `os.linesep`. Each file keeps its own line endings, identically on Windows, macOS, Linux and WSL2.
- The census statically requires generated writers to write LF.
- This matches the wave Objective.

Honest limit: Windows is verified only by simulation (a `Path.open` patch plus `os.linesep`), with no native Windows or WSL2 run.

## Remaining

- `operator-signoff` is not recorded. I did not record it, as briefed.
- `wf_close_wave(mode='dry_run')` passes lint and garden, and reports the framework test receipt as proven (13404 tests). Two items still block close:
  1. `operator-signoff` is missing.
  2. Change `244fj` still has status `planned` in the wave record. Update its Change Status before close.
