from __future__ import annotations
from dataclasses import dataclass


@dataclass
class Row:
    x: int


VALUE = Row(1)
