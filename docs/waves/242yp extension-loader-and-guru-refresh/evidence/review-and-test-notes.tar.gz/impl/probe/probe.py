"""AC-2 probe for 241l1: load a dataclass module through the real helper."""
import sys
from pathlib import Path

scripts, module = Path(sys.argv[1]), Path(sys.argv[2])
sys.path.insert(0, str(scripts))
import upgrade_extensions as u  # noqa: E402

name = "_wf_upgrade_journal_hook_hookmod"
print(sys.version.split()[0])
try:
    loaded = u._exec_module_from_file(name, module)
    print("OK", loaded.VALUE, "registered_after:", name in sys.modules)
except Exception as exc:  # noqa: BLE001
    print(type(exc).__name__, exc)
