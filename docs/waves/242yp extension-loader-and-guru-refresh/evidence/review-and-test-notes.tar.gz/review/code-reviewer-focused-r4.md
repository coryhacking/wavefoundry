# code-reviewer focused r4 (wave 242yp, spec 242yq)

Context: `242yp-code-reviewer-focused-r4`, fresh and independent (wrote neither the finding nor the repair). Receipt `review-policy-5e41c61d92b7b2d240a2`. No repo edits; `run_tests.py` not run. Probe in the session scratchpad (`r4cr/probe.py`) with `python3 -B -I` on Python 3.14.8.

Verdict: `242yq-CR-R3-1-duplicate-subtest-skip-identity` is repaired. Readiness approval recorded.

## Checks

1. Unique identities. Requirement 4 now requires a label unique within its test, and the helper refuses a repeated label at call time with or without a declaration. AC-3.3 tests the refusal; AC-7 runs a routed census worker through `qualification_worker` and `worker_detail` and proves the duplicate is caught with the refusal removed. Probe: a helper doing `subTest(timing_budget=label)` + `skipTest` with the planned labels, run through the real `qualification_worker.QualificationResult`, gave 7 distinct skip ids for tests 1, 8, 4 and 5 (the shared `100K-row drift detection` label differs by test id), skipped count equal to the row count, `wasSuccessful()` true. A test calling the same label twice produced one duplicate id, the exact shape `worker_detail` (qualification_report.py 141-142) and `validate` (207-208) refuse.
2. AC-2 table versus tree. Read every census test body:
   - test 1 (`test_server_context_efficiency.py` 3703): `budget_checks` gets `10-source warm`, `50-source warm` and `lifecycle flush/projection warm`, asserted in one loop with `assertLessEqual`. 3 bounds.
   - test 2 (1039): one `assertLess(elapsed, 2.0)`. 1.
   - test 3 (`test_memory_eval.py` 390): `assert_operation_within_budget(..., "1000-record memory lexical evaluation", ...)`. 1.
   - tests 4 and 5 (`test_indexer.py` 4190-4191): each calls `_scale` once, which asserts `"100K-row drift detection"`. 1 each.
   - test 6 (`test_graph_indexer.py` 2322): `"20000-def line scan"`. 1.
   - test 7 (`test_lexical_ranking_eval.py` 228): one `assertLess(elapsed, RUNNER_BUDGET_SECONDS)`. 1.
   - test 8 (`test_memory_records.py` 2158): two `assertLess(..., 0.5)` for the first and warm calls. 2.
   Total 11; labels match where the site already names one, and are new and distinct where it does not.
3. Classification. The 8 compare a duration of ordinary work against a fixed ceiling. The 9 excluded tests are pathological or maximum-size guards: 40 `**` segments, bounded parse counts, regex backtracking ceilings and wedge patterns, a symlink cycle, a near-cap decoded scan with a timeout ceiling, and bounded quantifiers. Matches the operator decision.

## Advisories (non-blocking)

- Test 6's docstring calls its fixture "maximum-size" and its budget guards a multi-pass regression, so it sits near the complexity-guard line. The operator scoped it as throughput; I agree it is a regression budget on ordinary lines, not a pathological input.
- Test 4 (10K rows) inherits the `100K-row drift detection` label from `_scale`. Harmless for identity; the implementer may pass the count into the label for readable skip output.
- `QualificationResult.addSkip` looks up `default_profile_only` markers by `test.id()`, so a subtest id never inherits a parent marker. Irrelevant here (bypass skips must match in both runs, not be marked), but worth knowing.

241l1 and 241l2 are unchanged; the earlier code-reviewer notes (`code-reviewer-readiness.md`, `code-reviewer-focused-r2.md`, `code-reviewer-readiness-r3.md`) stand by reference.
