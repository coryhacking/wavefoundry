import re, sys
sys.path.insert(0, "/Users/coryhacking/Developer/wavefoundry/.wavefoundry/framework/scripts")
import render_agent_surfaces as r, vocabulary_profile as vp

KEYS = {"plan": "plan-change", "implement": "implement-wave", "close": "close-wave", "prepare": "prepare-wave"}
TPL = {"@PLAN@": "plan", "@IMPLEMENT@": "implement", "@CLOSE@": "close", "@PREPARE@": "prepare"}
GEN = r"[^,()\r\n]+"

def forms():
    # earlier forms recovered from the current code's literals
    src = open(r.__file__).read()
    return None

def earlier_forms():
    # reconstruct via current code with a sentinel shortcut table
    sent = {v: "{" + k + "}" for k, v in KEYS.items()}
    texts = r.previous_guru_descriptions(lambda key: sent[key])
    out = []
    for t in texts:
        if "{" in t:
            out.append(t)
    # short form with Implement wave/Close wave slotted
    short = ("PROACTIVELY use when the user asks how this repository's source code or project "
             "documentation works. Do not use for wave lifecycle commands ({plan}, {implement}, "
             "{close}, etc.).")
    long_ = [t for t in out if "where to find" in t and t.count("{")==4][0]
    inv = [t for t in out if "investigation" in t and t.count("{")==4][0]
    return [long_, inv, short]

def build(form, shortcut, template=False):
    parts = re.split(r"(@PLAN@|@IMPLEMENT@|@CLOSE@|@PREPARE@)" if template else r"(\{plan\}|\{implement\}|\{close\}|\{prepare\})", form)
    rx = ""
    for p in parts:
        name = TPL.get(p) if template else (p[1:-1] if p.startswith("{") and p.endswith("}") else None)
        if name:
            rx += "(?:" + re.escape(shortcut(KEYS[name])) + "|" + GEN + ")"
        else:
            rx += re.escape(p)
    return re.compile(rx)

def managed(value, shortcut=None):
    shortcut = shortcut or vp.shortcut
    pats = [build(f, shortcut) for f in earlier_forms()] + [build(r._CLAUDE_GURU_TEMPLATE_DESCRIPTION, shortcut, True)]
    return any(p.fullmatch(value) for p in pats)

def table(d):
    return lambda key: d.get(key, vp.shortcut(key))

fails = 0
def check(label, cond):
    global fails
    print(("OK  " if cond else "FAIL"), label)
    if not cond: fails += 1

tables = {
    "default": vp.shortcut,
    "renamed": table({"plan-change": "Plan task", "implement-wave": "Build batch", "close-wave": "Close batch", "prepare-wave": "Prepare batch"}),
    "paren": table({"plan-change": "Plan (spec)"}),
    "comma": table({"implement-wave": "Implement, then verify", "close-wave": "Close (set)", "prepare-wave": "Prepare (x), y"}),
}
# Requirement 4: every text current code recognizes, under that table as active
for name, sc in tables.items():
    for t in r.previous_guru_descriptions(sc):
        check(f"[{name}] current-known replaced", managed(t, sc))
# renamed-table texts rendered under default profile (AC-4 case 2)
for t in r.previous_guru_descriptions(tables["renamed"]):
    check("[renamed under default] replaced", managed(t, vp.shortcut))
# AC-1
tpl = r._CLAUDE_GURU_TEMPLATE_DESCRIPTION
ac1 = tpl.replace("@PLAN@","Plan wave").replace("@IMPLEMENT@","Implement set").replace("@CLOSE@","Close set").replace("@PREPARE@","Prepare set")
check("AC-1 departing profile replaced", managed(ac1))
check("AC-1 in-slot exclusion replaced", managed(r.CLAUDE_GURU_DESCRIPTION.replace("Prepare wave,", "Prepare wave or security reviews,") if "Prepare wave," in r.CLAUDE_GURU_DESCRIPTION else r.CLAUDE_GURU_DESCRIPTION.replace(vp.shortcut("prepare-wave"), vp.shortcut("prepare-wave")+" or security reviews")))
# customizations kept
cur = r.CLAUDE_GURU_DESCRIPTION
check("fixed-prose edit kept", not managed(cur.replace("indexing", "indexng")))
check("trailing text kept", not managed(cur + " extra"))
check("slot with comma kept (default)", not managed(cur.replace(vp.shortcut("close-wave"), "Close wave, Ship it")))
check("slot with paren kept (default)", not managed(cur.replace(vp.shortcut("close-wave"), "Close (wave)")))
check("empty slot kept", not managed(cur.replace(vp.shortcut("plan-change") + ",", ",")))
check("whitespace-only-free empty literal default not matched", not managed(cur.replace(vp.shortcut("plan-change"), "")))
check("departing paren profile kept (fails safe)", not managed(tpl.replace("@PLAN@","Plan (spec)").replace("@IMPLEMENT@","Implement wave").replace("@CLOSE@","Close wave").replace("@PREPARE@","Prepare wave"), vp.shortcut))
# current under default equals current; current under renamed also matches (equality check handles)
check("current matches template (equality check must precede)", managed(cur))
# known-bad generic-only fails AC-4 case 3
GEN_ONLY = lambda v, sc: any(re.compile(build(f, sc).pattern.replace("(?:"+re.escape(sc("plan-change"))+"|", "(?:")).fullmatch(v) for f in earlier_forms())
paren_texts = [t for t in r.previous_guru_descriptions(tables["paren"]) if "Plan (spec)" in t]
check("generic-only known-bad misses Plan (spec) texts", paren_texts and not any(GEN_ONLY(t, tables["paren"]) for t in paren_texts))
print("default shortcuts:", [vp.shortcut(k) for k in KEYS.values()])
print("fails", fails)
