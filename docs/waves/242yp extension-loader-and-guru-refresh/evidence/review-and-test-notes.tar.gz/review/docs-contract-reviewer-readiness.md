# docs-contract-reviewer readiness notes (wave 242yp, rotating council seat)

Verdict: no blocking defect. No approval and no finding recorded (council seat).

## Docs that describe the changed behavior

- Journal hook loading: `docs/architecture/data-and-control-flow.md` line 417 and
  `docs/architecture/layering-rules.md` line 40 describe the import context. Neither says the
  private module is absent while it executes; both say prior `sys.modules` identities are
  restored and new matching modules removed. The fix keeps that. No update needed.
  A grep for "never registered", "not registered in" and "without registering" across
  architecture, specs, contributing, references and framework docs found no contract claim.
- `docs/specs/mcp-tool-surface.md` (EXTENSION_JOURNAL_* rows, lines 322, 836-860) describes
  declaration constants and trigger policy only, not module registration. No update needed.
- Guru description refresh: seed 160 lines 576 and 849 and
  `docs/prompts/upgrade-wavefoundry.prompt.md` lines 484 and 600 say "equal to a previously
  shipped Guru description". The text stays accurate, since a profile-filled text was shipped
  under that profile. Out-of-scope call in 241l2 is right.
- Non-blocking spec inaccuracy: 241l2 says seed 050 prose says a description "equal to a
  previously shipped Guru description" is replaced. Seed 050 has no such sentence (it holds
  only the template description at line 234). Seeds 160 and the upgrade prompt do. Suggest
  rewording to "Seed 160 and the upgrade prompt" via a Progress Log note, not a re-ready.

## Docstring and comment

- `_exec_module_from_file` docstring (currently "never registered in sys.modules") is planned
  as Requirement 4 and the task "Update the helper's docstring and the comment above
  `_JOURNAL_DECLARATION_MODULE`". The comment at line 2331 also says "nothing loaded here is
  left registered", still true after the fix but worth the planned touch-up. Planned.

## CHANGELOG

- 241l1 task 6 adds a Fixed entry. 241l2 task 5 and in-scope list add one bullet. Both planned.
  `[Unreleased]` exists in `CHANGELOG.md`.

## Writing guide

- Both specs lead with the answer, state observed and expected results, and use numbered
  AC sub-points (`1.` items, not nested bullets). Rationale and decision logs are concrete.
  No em-dashes found. No prose defects that block.
