import sys, io, unittest
sys.path.insert(0, "/Users/coryhacking/Developer/wavefoundry/.wavefoundry/framework/scripts")
import qualification_worker as qw
def budget(tc, op):
    with tc.subTest(timing_budget=op):
        tc.skipTest("timing-budget bypass: declared by tests/fixtures/profiles/x.json: r")
class T(unittest.TestCase):
    def test_nested(self):
        for g in (1,2):
            with self.subTest(groups=g):
                budget(self, "op")
        self.assertTrue(True)
    def test_dup(self):
        budget(self, "op"); budget(self, "op")
    def test_after_skip_runs(self):
        budget(self, "op")
        self.assertEqual(1, 2)
s = unittest.defaultTestLoader.loadTestsFromTestCase(T)
buf = io.StringIO()
r = qw.QualificationResult(buf, True, 1)
s.run(r)
for x in r.exact_skips: print(x)
print("skipped", len(r.skipped), "failures", len(r.failures), "run", r.testsRun)
ids=[x["id"] for x in r.exact_skips]; print("dups", len(ids)-len(set(ids)))
