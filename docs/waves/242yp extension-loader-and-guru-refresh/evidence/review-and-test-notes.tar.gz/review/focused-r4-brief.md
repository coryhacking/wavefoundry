# Focused readiness verification for 242yq (wave 242yp)

The 242yq readiness round recorded three blocking findings, all with one cause: two skips that share a label share one identity, so qualification refuses the worker as incomplete. AC-2 also asked only for "at least one skip" in each test. The three findings are:
- `242yq-qa-r3-per-bound-skip-oracle` (qa-reviewer)
- `242yq-CR-R3-1-duplicate-subtest-skip-identity` (code-reviewer)
- `242yq-bypass-skip-identity-collision` (red-team)

The implementer (context `242yp-implementer-repair-r3`) recorded a `repair_start` in cycle 2 for each and repaired the spec:
- Requirement 4 requires a label that is unique within its test, and the helper refuses a repeated label.
- AC-2 now has a table of the exact 11 skip ids and labels.
- A new AC-7 runs a routed census worker through `qualification_worker` and `worker_detail`.
- A test pins the census.
- An accident guard rejects any shipped asset that declares the key.
- The reader never turns the inactive-asset error into `None`.
- Both testing-architecture sections are now doc targets.

**Operator decision, 2026-11-22.** The bypass covers only the throughput budgets: 8 tests holding 11 bounds. The 9 complexity and hang guards stay always on, as do the 27 liveness sites.

The current receipt is `review-policy-5e41c61d92b7b2d240a2`.

As a FRESH independent reviewer (you wrote neither the finding nor the repair):
1. Load the MCP tools via ToolSearch first, and use code_* retrieval MCP-first. Read the round-3 notes in this folder (`*-r3.md`) and the changed sections of the 242yq spec.
2. Check the repair against the tree. Use a throwaway copy and `python3 -B` for probes. Make no repo edits. Do NOT run `run_tests.py`; wave 241lr is being implemented in this tree. Confirm three things:
   - unique identities now hold
   - the AC-2 table matches the actual bounds in the throughput tests
   - the 8 tests are throughput budgets and the excluded 9 are complexity or hang guards
3. If you own a finding, record its reverification:
   - **Event:** `event='finding'`, `run_kind='reverification'`, with the cycle that `wf_review_wave(wave_id='242yp', phase='prepare')` recommends.
   - **Lanes:** `blocking_required_lanes=[]` only if the repair holds.
   - **Context:** `fresh_context=true`, `independent=true`, `actor=<your lane or seat>`, `context_id='242yp-<lane>-focused-r4'`.
   - Dry-run first, then create.
4. Required lanes (code-reviewer, qa-reviewer, architecture-reviewer) then record a readiness approval on the current receipt with your OWN honest `integrity_checks`. That approval covers all three specs; 241l1 and 241l2 are unchanged, so cite them by reference. Red-team records only its reverification. A new blocking defect gets a finding, not an approval.
5. Write notes to `.wavefoundry/work/242yp/review/<lane>-focused-r4.md`. No em-dashes.
6. Reply in under 80 words.
