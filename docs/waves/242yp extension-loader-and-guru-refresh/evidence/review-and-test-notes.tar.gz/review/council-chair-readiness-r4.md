# council-chair readiness verdict r4 (wave 242yp)

Verdict: Prepare-phase Wave Council PASS. Recorded `council-readiness` (context `242yp-council-chair-readiness-r4`) on receipt `review-policy-5e41c61d92b7b2d240a2`, for 241l1, 241l2 and the late-admitted 242yq.

Checked before recording: `wf_review_wave(phase='prepare')` shows code-reviewer, qa-reviewer and architecture-reviewer readiness approvals current, lint passed, all four findings terminal with no unresolved lanes, and council-readiness the only pending action.

Seats: red-team (primer, standard depth), docs-contract-reviewer (rotating), code-reviewer, qa-reviewer, architecture-reviewer.

Intent fit: partially (worst across the three specs and the Objective). 241l1 and 242yq establish their clauses. 241l2 keeps, rather than refreshes, a departing profile whose shortcut contains `,`, `(` or `)` (fails safe).

Strongest challenge (red-team r3): several of the original 17 timed tests were complexity, hang and DoS guards, so the bypass would hide slow-but-terminating regressions. Resolved by the operator narrowing the bypass to throughput budgets.

Strongest alternative (red-team r3): scale guard bounds 10x under the bypass instead of skipping. Declined by the coordinator.

Advisories carried:
1. Operator decision: the bypass covers only throughput budgets (8 tests, 11 bounds). Complexity and hang guards and liveness bounds stay always on.
2. Architecture-reviewer: the Performance-Test Budget Policy section should warn authors not to route a guard or liveness bound through the helper.
3. New unrouted budgets are not auto-detected; declined in the Decision Log.
4. The 241l1 and 241l2 advisories in `council-chair-readiness.md` still stand.

Integrity: the chair ran no probes. It read every r3 and r4 lane note, the earlier chair note, the 242yq spec and the wave Objective, and relied on the lanes' executed probes and known-bad controls.
