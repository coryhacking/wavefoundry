# architecture-reviewer focused r4 (wave 242yp)

Verdict: APPROVE readiness for all three specs on receipt `review-policy-5e41c61d92b7b2d240a2`. I own no finding. 241l1 and 241l2 are unchanged since my r3 approval (`architecture-reviewer-readiness-r3.md`), and I cite them by reference.

## Throughput-only scope

The narrowed scope is coherent.

- Requirement 6 gives one rule: a throughput budget measures ordinary work against a fixed upper bound. Exclusions 1 and 2 cover the two correctness signals, liveness and complexity/hang/DoS, for the same reason. A slow machine is a performance criterion. A hang or a super-linear blowup is a defect.
- Census against the tree (AST probe, `python3 -B`, read only). The 8 tests exist and hold exactly 11 wall-clock upper bounds:
  - test 1 has three bounds (10-source, 50-source, lifecycle flush), checked in one `assertLessEqual` loop at line 3808;
  - tests 2, 3, 6 and 7 have one bound each;
  - tests 4 and 5 each have one bound through `_scale` (line 4189);
  - test 8 has two bounds (lines 2208 and 2209).
  This matches the AC-2 table.
- The 9 excluded tests are guards. Each one times adversarial or maximum-size input: nested `**`, nested call parsing, backtracking at the ceiling, cubic subject length, a `?*` pathological pattern, a symlink cycle, input at the decode cap, or quadratic quantifiers. Their docstrings and comments name hang or ReDoS intent.
- Borderline: test 6 (`20000-def line scan`) uses a "maximum-size fixture". The input is ordinary lines, and the comment says the bound separates a multi-pass regression from contention. That makes it a throughput bound, not a pathological-input guard, so keeping it in the census is right.

## Unique identities

I probed a subtest skip on Python 3.14: `addSkip` receives `<test id> (timing_budget='<label>')`, one skip per label, and the test continues. Labels are unique within each test, and tests 4 and 5 have different parent ids. Each of the 11 skips therefore has its own identity, so `qualification_report` line 142 does not fire.

## Doc targets

Both `docs/architecture/testing-architecture.md` targets exist: the Default-profile-only (line 359) and Expected profile (line 372) entries under "Profile-Aware Fixtures and the Second-Profile Run" (line 323), and "Performance-Test Budget Policy" (line 642). `build-and-verification.md` "Packaging profile qualification" exists (line 177). The Affected Architecture Docs section and AC-5 name the same places.

## Advisories (no finding; Progress Log note at most)

1. The Performance-Test Budget Policy section now says "Every wall-clock budget in the suite follows the policy" and routes budgets through `assert_within_budget`. Once that helper honors the bypass, the section must also tell authors not to route a guard or liveness bound through it, or the bypass would silently cover a new guard. AC-5 covers this through "the census rule with its exclusions". Make the warning explicit.
2. `test_perf_budget_policy.py` calls `assert_operation_within_budget` directly (lines 32, 45, 61) and pins its name in the routed sources (line 69). The task to keep threshold tests on the assertion core needs a separate core entry point. Otherwise AC-3.1 (no skip under a declaration) fails. Keep the line-69 pin true.
3. Keep the duplicate-label state on the test-case instance, so it resets per test and per subTest parent, not per module.
