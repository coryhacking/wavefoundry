# qa-reviewer delivery notes (wave 242yp)

Verdict: approve. No blocking defect found.

Method: focused runs and mutation checks on a scratch copy of `.wavefoundry/framework` (plus `docs/evals` and `docs/workflow-config.json` so source-repository fixtures resolve). No repo edits. Full suite not run.

## 241l1 (journal hook dataclass import)

Baseline: `ExecModuleFromFileTests` and `JournalIncomingRunnerTests` 10 tests OK.

| Mutation | Result |
| --- | --- |
| HEAD helper (never registers) | 5 fail, including the journal-level dataclass hook test (AC-1) and the SEEN_SELF checks (AC-3) |
| `except Exception` restore, no `finally` | both SystemExit subtests fail (AC-3) |
| always pop, prior not restored | 3 identity-restore cases fail (AC-3) |
| leave module registered | 8 fail |

## 241l2 (Guru description slot matcher)

Baseline: `GuruDescriptionRefreshTests` and `StaleDefaultSkillNameTests` 12 tests OK.

| Mutation | Result |
| --- | --- |
| HEAD matcher | AC-1 departing-profile and in-slot exclusion cases fail; AC-4 case 2 renamed-table texts fail |
| slot accepts empty text | AC-3 both empty-slot cases fail |
| slot `.+` (crosses `,` and `(`) | AC-2 comma and parenthesis cases fail |
| slot allows `,` only / `(` only | the matching AC-2 case fails in each |
| `re.match` instead of `fullmatch` | AC-2 trailing-text cases fail |
| equality check for current text dropped | AC-5 fails |
| generic slot only (no own-shortcut literal) | AC-4 case 3 fails in all 4 encodings |

## 242yq (timing-budget bypass)

Baseline: `test_perf_budget_policy`, `TimingBudgetBypassDeclarationTests`, `TimingBudgetBypassCompareTests`, `TimingBudgetBypassWorkerTests`: 25 tests OK.

Default run executes all 11 bounds: an instrumented `timing_budget` logged each `check()` that ran and passed with no declaration. The 8 census tests ran directly and logged exactly 11 labels, matching the Requirement 6 table. No skip was reported.

| Mutation | Result |
| --- | --- |
| `lifecycle flush/projection warm` unrouted | AC-1 (forced=3) and AC-2 fail |
| label renamed | AC-2 fails |
| extra helper call | AC-2 fails |
| guard test routed / census test unrouted | census pin fails each way (AC-3.2) |
| duplicate-label refusal removed | refusal test fails with and without declaration (AC-3.3) |
| inactive asset key accepted | AC-4.1 tests fail |
| reader maps ProfileInvalid to None | AC-4.1 reader test fails |
| skip whole test instead of a subtest | helper and AC-2 tests fail |
| non-budget assertion in the real warm-path test forced to fail under bypass | AC-2 fails |
| refusal removed and a label repeated (AC-7) | worker report shows `duplicate skipped-test identity`; worker test fails |
| reader never declares (AC-7) | worker test fails (no skips) |

## Limitations

- AC-3 point 1 has no durable runtime test for the two liveness tests (`test_review_evidence`, `test_subprocess_util`) under a declared bypass. The Progress Log records an ad hoc run. They do not call the helper (unchanged files), so they cannot skip. The static pin covers the 9 guards, not the liveness tests. Not a defect.
- AC-4.3 compare uses existing `qualification_report.compare`; the pair test passes. Not mutated.
- AC-4 and AC-6 suite and docs claims rest on the implementer's full-suite log (13,301 tests OK) and the receipt (`result` ok). I did not rerun the full suite or `wf_validate_docs`.
