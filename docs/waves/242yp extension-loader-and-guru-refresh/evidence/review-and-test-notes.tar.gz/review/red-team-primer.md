# Red-team readiness primer (wave 242yp, standard depth)

Seat: red-team (council). No approval recorded. No blocking defect found, so no finding recorded.

## Item 1: `241l1` temporary registration in `_exec_module_from_file`

Verified against the tree:

- `_exec_module_from_file` (`upgrade_extensions.py:2407`) executes without registering. Its two callers are `_load_journal_hook` (2457) and `_load_journal_declaration` (2496). The private names are `_wf_upgrade_journal_declaration` and `_wf_upgrade_journal_hook_<module>`, and neither can equal the other.
- The older runner loads the incoming `upgrade_extensions.py` from the zip (`upgrade_wavefoundry.py:1317-1369`), and `pre_docs_gate` calls `_load_journal_declaration` inside `_journal_incoming_imports` (3401). So the fix applies on the upgrade TO the fixed version. The spec's Risks row marks this `inferred`, but the code confirms it.
- `_journal_incoming_imports` only purges names whose top-level part is a file or directory in the incoming scripts directory. The private names are never in that set, so the helper's own `finally` restore is the only thing that removes them. The spec requires that restore on success and on `BaseException`, which is the correct requirement.

Attacks:

1. **Stale cached module answering:** not possible. The entry exists only during `exec_module` and under a private name that no runner imports. A retry pops the entry and re-executes the file.
2. **Leak:** closed by the `finally` restore, including `KeyboardInterrupt`/`SystemExit`. Residual edge: a module that replaces `sys.modules[__name__]` during exec has the replacement discarded and the original object returned. No supported pattern does this.
3. **Collision during retry:** the prior-entry save and restore makes nested or repeated calls under the same name safe. The only shared state is the in-process dict. Other threads in an MCP-hosted upgrade only see a transient private key.
4. **Strongest challenge (executed probe, non-blocking):** the fix covers import time only. A hook function runs after the helper has unregistered the module. If that function introspects its own dataclasses, it still fails. I probed this on a scratch copy, outside the repo, with a reimplementation of the proposed fix, on CPython 3.14 and 3.11 (`python3 -B -I`). With a field annotated `Path` under postponed annotations, the import succeeded and the module was absent afterwards. Inside `prepare(root)`, `typing.get_type_hints(Entry)` raised `NameError` and `pickle.dumps(Entry(...))` raised `PicklingError`. The Objective says "imports it", so the spec establishes it. The boundary should still be stated: a hook that resolves its own annotations or pickles its own classes at call time is still unsupported.
5. **Strongest alternative:** keep each private module registered while `_journal_incoming_imports` is active, then remove it in that context's `finally`. `pre_docs_gate` already holds that context across the load and the call. This would cover call-time introspection and still leave nothing registered after the gate. The cost: the preview path (`_load_journal_declaration(root, load_hook=False)`, line 2796) runs outside that context and would still need the per-call restore. I think the per-call fix is the right size for the reported defect. One line in the CHANGELOG or the docstring, saying the module is unregistered when the hook is called, would close the gap honestly.

## Item 2: `241l2` slot matching in `_refresh_guru_description`

Verified: `previous_guru_descriptions` (`render_agent_surfaces.py:567-633`) holds the hand-filled entries the spec describes. The `short_form` hardcodes `Implement wave` and `Close wave`. The current template is compared only through `value == current`, so a description rendered under another profile's shortcuts is kept. Repository callers are only the renderer (662) and `test_render_agent_surfaces.py`.

Attacks:

1. **Strongest overwrite of a deliberate customization (inferred from the Requirement 2 slot grammar, non-blocking):** a slot accepts any non-empty text without `,`, `(`, `)` or line breaks. So the matcher takes over more than renamed shortcut names. Example: an operator edits the routing boundary as `(Plan spec, Implement wave, Close wave, Prepare wave or security reviews, etc.)`, or `(Plan spec and Plan arc, ...)`. The value matches the current template, gets replaced, and the operator's added exclusion is lost. This changes which questions route to the subagent, so it is a semantic edit, not a rename. The spec's Risks row, "customized only the shortcut names", understates the class.
   - Does it matter? Little. The edit is in a git-tracked file, the stderr notice names the file, the operator accepted the broader take-over, and a customization written as a separate list item (with a comma) is kept. Suggested cheap fix before readiness: reword the Risks row to "customized only within the shortcut slots, including added text without a comma or parenthesis", and add that `or` case to AC-2 as a documented replaced case, or to AC-1. A tighter slot grammar, such as a capped word count, would risk missing distribution shortcuts and is not worth it.
2. **Inverse edge:** a profile whose shortcut contains `,` or `(` renders a description the matcher can never recognise. That description is kept on later renders, so the failure is safe. The Objective says "any vocabulary profile change", so it is only partially established for such profiles. No shipped profile has such a shortcut.
3. **Test-interface trap (non-blocking, for the implementer):** after Requirement 7, `previous_guru_descriptions()` returns forms with `{plan}` placeholders, not filled texts. Existing tests use its members as rendered descriptions: `test_each_previously_shipped_description_is_replaced`, `test_other_descriptions_and_headers_are_kept`'s `shipped = ...[0]`, and `test_control_without_the_known_set_leaves_a_stale_description`. Each would then feed literal `{plan}` text, which the slot also matches. They would pass while testing almost nothing. The AC-4 literal strings cover the real texts, but these tests should fill the forms or be pointed at the AC-4 literals. The control patch should still be a real control under the new matcher: patching the tuple to `()` must still leave the current template matched.
4. Slot matching across the `", "` separators is linear, because slots exclude the comma. I see no backtracking risk.

## Ownership and intent

- **Item 1:** the helper is upstream code, and the older runner loads it from the upstream pack. A distribution has no way to fix it, apart from avoiding dataclasses, which the Decision Log rightly rejects. Upstream is the correct owner.
- **Item 2:** the matcher is in the upstream renderer and exposes no distribution extension point for earlier texts. Upstream is the correct owner. This passes the "test ownership before planning upstream code" check that the Waveforge 3.2.0 declines applied.
- The operator's DO decisions are recorded in both Decision Logs.
- **Objective:** item 1 establishes the Objective. Item 2 establishes it, apart from the comma/parenthesis profile edge (partially, safe failure).

## Verdict

No blocking defect. Strongest challenge: item 2's slot grammar overwrites semantic boundary edits written without commas, which the Risks row understates. Strongest alternative: register the item 1 modules for the span of `_journal_incoming_imports`, so call-time introspection also works. Both are optional repairs that fit the plans' scope.
