# qa-reviewer focused r4 (wave 242yp, receipt review-policy-5e41c61d92b7b2d240a2)

Context: `242yp-qa-reviewer-focused-r4`, fresh and independent. I wrote neither the finding nor the repair. No repo edits. `run_tests.py` was not run.

Verdict: the repair of `242yq-qa-r3-per-bound-skip-oracle` holds. Readiness approval recorded for qa-reviewer across 242yq, 241l1 and 241l2. 241l1 and 241l2 are unchanged since `qa-reviewer-readiness.md` and `qa-reviewer-focused-r2.md`, which still stand for them.

## Known-bad A (unrouted flush row)

AC-2 now pins the exact 11 skips with labels and states that a missing, extra or relabelled skip fails, naming the `lifecycle flush/projection warm` row. Known-bad A now fails AC-2.

## Known-bad B (repeated label)

Requirement 4 requires a label unique within its test, refused at call time with or without a declaration (AC-3 point 3). AC-7 runs a routed census worker through `qualification_worker` and `worker_detail`, and its negative half (refusal removed, label repeated) must report `duplicate skipped-test identity`. Known-bad B now fails AC-3.3 and AC-7.

Probe (scratch copy, `python3 -B`, Python 3.14, real `qualification_worker.QualificationResult`): a model helper that refuses a repeated label per `tc.id()` and skips inside `subTest(timing_budget=<label>)`. It covered test 1's three labels, test 8's two, tests 4 and 5 sharing `100K-row drift detection` through one `_scale` helper, and a refused duplicate. It produced 8 skip ids, all 8 unique. Tests 4 and 5 differ by test id, and `qualification_report.validate` keys on `(worker name, id)`, so a label shared across tests is safe. The duplicate call raised as expected.

## AC-2 table against the tree

- test 1 (`test_server_context_efficiency.py` 3703): three `budget_checks` rows, labels `10-source warm`, `50-source warm`, `lifecycle flush/projection warm`, asserted in one loop (3799-3812). Matches.
- test 2 (1053-1060): one `assertLess(elapsed, 2.0)`. Matches.
- test 3 (`test_memory_eval.py` 406): `assert_operation_within_budget(self, "1000-record memory lexical evaluation", ...)`. Matches.
- tests 4 and 5 (`test_indexer.py` 4178-4191): both call `_scale`, one `assert_operation_within_budget(self, "100K-row drift detection", ...)`. Matches.
- test 6 (`test_graph_indexer.py` 2345): `"20000-def line scan"`. Matches.
- test 7 (`test_lexical_ranking_eval.py` 236): one `assertLess(elapsed, RUNNER_BUDGET_SECONDS)`. Matches.
- test 8 (`test_memory_records.py` 2208-2209): two `assertLess(..., 0.5)`. Matches.

No other wall-clock bound in these bodies. 11 bounds total.

## Excluded 9 are guards

Each excluded test bounds pathological or maximum-size input: many `**` segments, nested call parsing, backtracking ceiling, adjacent floating prefixes, long unrepresentable subject, `?*` pathological pattern, symlink cycle, scanner at the decoded-size cap, and free-text placeholder quantifiers on an over-long line. Their docstrings and comments name the super-linear or hang risk. None is ordinary-input throughput.

## Residual (non-blocking)

- Test 1's three bounds are evaluated in one loop after the contention factor; the implementer must give each loop iteration its own helper call with the row label, which Requirement 4 and AC-2 already force.
- The probe models the helper; the real helper does not exist yet, so AC-7 is the executed check at implementation.
