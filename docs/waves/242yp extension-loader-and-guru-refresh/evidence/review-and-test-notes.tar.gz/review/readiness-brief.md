# Readiness review brief (wave 242yp)

Wave `242yp extension-loader-and-guru-refresh` holds two small bug specs from Waveforge field feedback against v1.47.0:
- `241l1-bug journal-hook-dataclass-import`: `upgrade_extensions._exec_module_from_file` will register the module in `sys.modules` only while `exec_module` runs, then restore the prior state, so a distribution's journal hook module that uses `@dataclass` with `from __future__ import annotations` imports.
- `241l2-bug guru-description-refresh-misses-departing-profile`: `render_agent_surfaces._refresh_guru_description` will treat a description as managed when it matches the current template or a listed earlier form with any non-empty text in the shortcut slots.

Both specs are in `docs/waves/242yp extension-loader-and-guru-refresh/`. Ordinary review applies. The receipt is `review-policy-60a1a7f4b2f639800cf6`, and the required lanes are code-reviewer and qa-reviewer. The council seats are red-team (primer, standard depth) and docs-contract-reviewer (rotating).

The review depth matches the change size: these are two small bug fixes. Do not expand scope.

As a fresh, independent reviewer of your lane:
1. Load the MCP tools via ToolSearch first and use code_* retrieval MCP-first. Read both specs and the wave record. Verify the specs' load-bearing claims against the tree, not the specs' prose:
   - cited symbols resolve
   - the loader census is complete (`spec_from_file_location` sites, and which ones load distribution code)
   - the "why never registered" rationale is right
   - the tuple claims in `previous_guru_descriptions` hold
   - no fixture or digest pin changes
2. Run probes only on a throwaway copy with `python3 -B`. Make no repo edits.
3. For each blocking defect, record a typed readiness finding: `wf_review_event(wave_id='242yp', event='finding', run_kind='readiness', cycle=0, actor=<lane>, context_id='242yp-<lane>-readiness', ...)`. Dry-run first, then create. You may state `evidence.execution_status` honestly; use `inferred` for a finding you only read. If you found no blocking defect, record your readiness approval instead (`event='approval'`, `signoff_key=<lane>`, `approval_phase='readiness'`, `fresh_context=true`, `independent=true`) with your OWN honest `integrity_checks`. Council seats (red-team, docs-contract-reviewer) record no approval; they write notes only, plus a finding when one blocks.
4. Write notes to `.wavefoundry/work/242yp/review/<lane>-readiness.md`. No em-dashes.
5. Reply in under 100 words: verdict and what you recorded.
