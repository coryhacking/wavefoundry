# Docs-contract review, readiness round 3 (wave 242yp, spec 242yq)

Seat: docs-contract-reviewer (rotating). Context: `242yp-docs-contract-reviewer-readiness-r3`, fresh and independent. No approval recorded. No blocking docs-contract finding, so no finding is recorded from this seat. Specs 241l1 and 241l2 are unchanged since `docs-contract-reviewer-readiness.md`, and that note still stands.

## Distribution-facing docs for the new key

The two named targets exist and fit: `docs/architecture/testing-architecture.md` **Expected profile (change 1zima)** (line 372) and `docs/contributing/build-and-verification.md` **Packaging profile qualification** (line 177). AC-5 lists the facts a distribution maintainer needs: the key, the active-asset-only rule, the skip reason format, the census rule, no environment variable, and that upstream never declares the key. Non-blocking recommendations:

1. Name a third target. `testing-architecture.md` **Performance-Test Budget Policy (wave 1seax / 1t3zv)** (line 642) is where an author of a new budget looks. It says "budget assertions go through `assert_within_budget`", and after this change the shared helper, the census rule and the liveness exclusion belong there. The Risks row "a new timing budget added later without the helper is not skipped" relies on this documentation as its only mitigation, so the section a new-budget author reads must carry it. The `perf_budget_policy.py` module docstring (its "Policy for any NEW wall-clock budget" list) should gain the same item.
2. Make Scope and Affected Architecture Docs agree. Scope names "Expected profile"; Affected Architecture Docs names "the Expected profile and Default-profile-only entries". Pick one list, plus item 1.
3. State in the Expected profile entry that a non-active asset carrying the key makes the whole resolution fail. `expected_profile` loads every asset, so a stray asset stops the suite instead of being ignored, and a distribution maintainer needs that failure mode written down.
4. Record the qualification consequence in Packaging profile qualification: bypass skips appear in both reports and compare equal, and (after the red-team / code-reviewer repair) each bypass skip id is unique within its worker.

## CHANGELOG task

"Add the CHANGELOG `[Unreleased]` entry" is adequate as a task. `[Unreleased]` has only `### Changed` and `### Fixed` today, so this enhancement adds `### Added`. Recommend that the entry follow the existing style: say what a distribution can now do, name `skip_timing_budgets` and the active-asset-only rule, say that upstream runs and qualification are unchanged and that liveness bounds still run, and end with `Wave 242yp / 242yq.`. It shares `CHANGELOG.md` with 241l1 and 241l2, which the Serialization Points already record.

## Writing guide (`.wavefoundry/framework/docs/writing-guide.md`)

The spec follows the guide on the points that change a reader's action. Product Intent leads with the outcome. The Waveforge figures are attributed to the distribution, with "Upstream has not reproduced the failure". Requirements name the file, function, key, error type and limit (200 characters). The planner's executed checks are labeled `execution_status: executed`. Decision Log alternatives carry their weakness. No hedges weaken a **must**. Non-blocking edits:

1. Requirement 1 "one-line string" is a category adjective a requirement acts on, so it needs a definition, for example "contains no CR or LF character".
2. Requirement 4 cites only Python 3.14 for the subtest-skip behavior. The supported floor is 3.11; this review executed the same behavior on 3.11.17, and the spec can say so.
3. Requirement 6's census sentence (the parenthetical scan description) runs past 50 words. Split the scan method into its own sentence.
4. Product Intent "upstream profile assets cannot declare the bypass" is broader than AC-4, which covers `second.json` and `declared.json` and non-active assets only. Narrow it to "the framework's own profile assets", or close the gap the red-team note describes. The current sentence states a conclusion stronger than its evidence.

No em-dashes in this note.
