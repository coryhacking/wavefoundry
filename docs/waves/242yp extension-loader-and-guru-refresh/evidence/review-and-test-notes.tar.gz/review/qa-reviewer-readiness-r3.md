# qa-reviewer readiness r3 (wave 242yp, receipt review-policy-001af52936c870cdd5b0)

Context: `242yp-qa-reviewer-readiness-r3`, fresh and independent. Verdict: one blocking finding on 242yq, so no qa-reviewer approval was recorded. 241l1 and 241l2 are unchanged. The earlier qa notes (`qa-reviewer-readiness.md`, `qa-reviewer-focused-r2.md`) still stand for them.

## Blocking finding `242yq-qa-r3-per-bound-skip-oracle` (do_now, executed)

AC-2 asks only for "at least one skip" per census test. AC-1 forces the helper to fail, and a forced failure stops each test at its first routed bound. Seven census tests carry more than one bound:

- test 1 has three `budget_checks` rows, and the Waveforge flush row is the third
- `test_memory_records` has two `assertLess` bounds
- four techdocs tests (at_ceiling, subject, pathological, symlink) assert inside `subTest` loops
- `test_call_parsing_is_bounded` also asserts inside a `subTest` loop

Two known-bad implementations pass every AC:

- A: route test 1's two warm rows but not the flush row. The reported Waveforge failure stays.
- B: reuse one operation label for both bounds in one test. The probe (`qa-reviewer-readiness-r3-probe.py`, run with Python 3.14.8 under the real `qualification_worker.QualificationResult`) produced two identical skip ids. `qualification_report.worker_detail` then reports `duplicate skipped-test identity` (lines 133-142), and `validate` raises `invalid terminal worker`. Every distribution qualification would fail, which contradicts Requirement 8.

Repair (spec only):

- Requirement 4: every helper call carries a subtest identity that is unique within its test.
- AC-2: pin the exact set of bypass skips for each census test (one per bound and per subTest iteration). Add an oracle that the skip detail from a declared-bypass run passes `worker_detail` with no duplicate-identity issue.

## Verified (no defect)

- Subtest skip mechanism: `skipTest` inside `subTest` records a skip whose id carries the params, and the test keeps running. A later failing assertion still fails the test. Nested subTest params merge, so the ids stay distinct.
- Visibility: `run_tests.py` runs each file with `-v` (line 1397), so the output prints skip reasons. `qualification_worker` records `{id, reason}` for each skip, subtest skips included.
- Default run executes all 17 bounds: with no active asset, `expected_profile` uses the shipped defaults, and the AC-1 forced-failure oracle catches any leak in the default run. Upstream `second.json` and `declared.json` have no `active` key.
- `load_profile` and `_profile_errors` currently accept unknown top-level keys, so AC-4 point 1 fails under the current code as the spec states.
- `compare`: both runs in a distribution read the same active asset. None of the 17 census files uses `default_profile_only`, so the second profile does not drop a bypass subtest skip that the baseline holds.

## Non-blocking notes

- Requirement 2 calls the run-mode layer "never the active asset". Nothing refuses `WAVEFOUNDRY_TEST_PROFILE` naming the active asset (`run_mode_profile_name`, line 854). This is harmless only if the reader takes the base active asset alone. State that the reader ignores the run-mode layer.
- AC-1's "under current code ... fails none of them" is loose. Census tests 4 to 6 already call `assert_operation_within_budget`. The new helper does not exist yet, so the oracle still holds.
- I did not independently re-derive the 17/27 census. I spot-checked 12 of the 17 sites, and all match the rule.

Not run: `run_tests.py` and full qualification (forbidden in this tree).
