# Readiness review for the late-admitted spec (wave 242yp)

Wave `242yp extension-loader-and-guru-refresh` has admitted a third spec: `242yq-enh distribution-timing-budget-bypass`, in `docs/waves/242yp extension-loader-and-guru-refresh/`. The operator decided on 2026-11-22 to keep the timing-budget tests in core and let a distribution switch them off. Under the spec, a distribution declares `skip_timing_budgets` in its active test profile asset, and 17 timing-budget tests then skip at the assertion with a visible reason. Liveness bounds are excluded, and the default upstream run never skips.

The wave's other two specs (241l1, 241l2) are already readied and their code is implemented; the wave is paused while wave 241lr is open. Those two specs did NOT change. The current receipt is `review-policy-001af52936c870cdd5b0`, and the required lanes are code-reviewer, qa-reviewer and architecture-reviewer. The council seats are red-team (primer, standard depth) and docs-contract-reviewer (rotating).

The review depth matches the change size.

As a fresh, independent reviewer of your lane:
1. Load the MCP tools via ToolSearch first and use code_* retrieval MCP-first. Read the 242yq spec and the wave record. Verify its load-bearing claims against the tree:
   - `expected_profile` and `load_profile` behave as stated, and an inactive asset refuses the key
   - the 17-test census is complete, and the 27 excluded liveness sites are correctly excluded
   - the qualification comparison is unaffected upstream
   - the subtest-skip mechanism reports a visible skip
2. Run probes only on a throwaway copy with `python3 -B`. Make no repo edits. Do NOT run `run_tests.py`: wave 241lr is being implemented in this tree.
3. For each blocking defect, record a typed readiness finding: `wf_review_event(wave_id='242yp', event='finding', run_kind='readiness', cycle=0, actor=<lane>, context_id='242yp-<lane>-readiness-r3', ...)`. Dry-run first, then create. State `evidence.execution_status` honestly. Required lanes with no blocking defect record a readiness approval (`event='approval'`, `signoff_key=<lane>`, `approval_phase='readiness'`, `fresh_context=true`, `independent=true`) with your OWN honest `integrity_checks`. That approval covers all three specs: for 241l1 and 241l2, cite the unchanged specs and the earlier approvals and notes in this folder by reference. Council seats write notes only, plus a finding when one blocks.
4. Write notes to `.wavefoundry/work/242yp/review/<lane>-readiness-r3.md`. No em-dashes.
5. Reply in under 100 words.
