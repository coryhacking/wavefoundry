# code-reviewer readiness notes (wave 242yp)

Verdict: one blocking finding on 241l2, recorded as `242yp-cr-guru-slot-excludes-legal-shortcut-chars` (do_now, cycle 0). 241l1 has no blocking defect. No approval recorded.

## 241l1 journal hook dataclass import

- Reproduced the failure on the current `_exec_module_from_file` (upgrade_extensions.py:2407) from a scratch copy: `AttributeError 'NoneType' object has no attribute '__dict__'`.
- Probed the planned shape (save prior with a sentinel, register, `exec_module` in `try`, restore in `finally`) on CPython 3.14 and 3.11 with `python3 -B`:
  1. dataclass under postponed annotations loads; `sys.modules[__name__]` is the executing module; the name is absent afterwards;
  2. a prior sentinel is restored by identity after a module that raises `KeyboardInterrupt` (BaseException);
  3. a module that deletes its own entry does not break the restore, provided the absent case uses `sys.modules.pop(name, None)`, not `del`. Implementer note: use `pop`.
  4. nested same-name calls restore correctly by stack discipline (each frame saves and restores its own prior).
- Rationale is right: the older runner loads the incoming `upgrade_extensions` via `exec` (upgrade_wavefoundry.py:1356), so the fix ships with the pack; `JournalIncomingRunnerTests` already holds old `mcp_tool_extensions` in `sys.modules`, which is what the private names protect. `_journal_incoming_imports` only touches names that match a file in the scripts directory, so the private names are unaffected.
- No existing test asserts absence during execution; the tests that patch `_exec_module_from_file` count calls only.
- Census confirmed: 18 non-test files contain `spec_from_file_location` (graph_indexer.py has 3 textual hits, not 2; immaterial). Non-blocking: the census narrative omits `inference_provider._load_provider`, an `exec` loader of the distribution's `ADAPTER_MODULE`; it already registers before `exec` and pops on BaseException, so it is unaffected.
- Known limitation, not blocking: after the load the module is unregistered, so later `typing.get_type_hints` or pickling of the hook's classes cannot find the module. Same as before the change.
- Test placement is sound: AC-1 fits `JournalIncomingRunnerTests._pack` (add a dataclass to the hook body) and reaches the real older-runner dispatch; AC-3 unit cases fit the same file.

## 241l2 Guru description refresh

- AC-1 replay: the current template filled with `Plan wave`, `Implement set`, `Close set`, `Prepare set` fully matches a slot regex built with `re.escape` on the fixed parts and `[^,()\r\n]+` slots.
- Regex safety: slots are delimited by literal `, ` and cannot cross `,`, so matching is linear. 1e6-character adversarial inputs complete in under 5 ms. The implementer must use `fullmatch`; `match` accepts trailing text (AC-2 case 3 catches it).
- Blocking: `vocabulary_profile._shortcut_problem` forbids only backtick, `*`, `|`, `[`, `]`, so `Plan (spec)` or `Plan, then build` are legal shortcuts. Under such a profile, `previous_guru_descriptions` today returns texts the current code replaces; the specified slot rejects them, contradicting Requirement 4 and AC-4. Choose a rule in the spec: narrow Requirement 4 and AC-4, or let each slot also match the active profile's own shortcut literally.
- Non-blocking: the spec does not state the new signature or return of `previous_guru_descriptions` (forms with placeholders, `shortcut` dropped or kept). Existing tests in `GuruDescriptionRefreshTests` (`[0]`, `len >= 4`, `assertNotIn(CLAUDE_GURU_DESCRIPTION, known)`, the `return_value=()` control) depend on it; they are inside the stated scope, but state the interface.
- Non-blocking: a whitespace-only slot (`( , ...`) satisfies "non-empty". Acceptable.
- Test placement in `test_render_agent_surfaces.py` is right; no golden fixture or digest pin contains the description (the `PINNED_CURRENT_DESCRIPTION` pin covers the current template, which does not change).
