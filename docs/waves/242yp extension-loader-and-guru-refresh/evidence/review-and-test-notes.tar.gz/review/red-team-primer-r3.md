# Red-team primer, readiness round 3 (wave 242yp, spec 242yq)

Seat: red-team (primer, standard depth). Context: `242yp-red-team-readiness-r3`, fresh and independent. No approval recorded; council seats write notes only.

## Verdict

One blocking finding, recorded: `242yq-bypass-skip-identity-collision` (`execution_status: executed`). It duplicates the code-reviewer's concurrent `242yq-CR-R3-1-duplicate-subtest-skip-identity`; one repair settles both. Everything else below is non-blocking.

## Blocking: repeated bypass skip identities fail distribution qualification

Requirement 8 says a distribution's default and profile reports carry the same bypass skips and compare equal. That needs every bypass skip id to be unique within its worker, and the spec does not require it.

Probe (scratchpad copy, `python3 -B`): a test that skips `subTest(timing_budget='warm path latency')` twice, run through the real `qualification_worker.py` and passed to `qualification_report.worker_detail`. Result: returncode 0, `skipped=4`, `complete=False`, `issues=['duplicate skipped-test identity']`. The comparator then refuses the worker as `invalid terminal worker`, so the distribution's release gate fails on qualification instead of on the budget. A control with distinct labels in the same worker produced no issue. The exposed site today is `test_memory_records.py::test_warm_path_call_counts_and_latency_are_bounded` (two bounds); most other sites already sit inside distinct enclosing subtests.

Repair: Requirement 4 states that each bypass skip id is unique within its worker (a label distinct per call site and iteration), and an AC-2 or AC-4 oracle runs one routed census worker through `qualification_worker` under a declared bypass and asserts `worker_detail` is complete with no issues.

## Question 1: can a distribution or an upstream accident launder a skip into upstream qualification?

- A distribution cannot reach upstream qualification: the pack excludes `scripts/tests` (`build_pack.py` `EXCLUDED_REL_PATHS`), and upstream never merges a distribution's tree.
- Run mode and the framework assets are closed as stated: `expected_profile` loads every asset through `load_profile`, so the planned refusal of the key on a non-active asset fails every resolution rather than skipping, and `second.json`, `declared.json` and `prompt-names.json` are pinned never active (`test_framework_assets_are_never_marked_active`).
- The open vector is an upstream accident: a new file such as `tests/fixtures/profiles/local.json` with `"active": true`, one constant at its shipped value and the key. Nothing upstream fails. The default and both qualification runs read the same asset, so they skip the same 17 budgets and compare equal. The close-gate receipt would also record `ok`, even with the asset left untracked. The pin covers only the three named assets, not a new file. The Risks row discloses this and accepts it as "a reviewable commit", which is accurate, but Product Intent's "upstream profile assets cannot declare the bypass" holds only for the named assets.
- Cheap closure (recommended, non-blocking): use the existing upstream identity seam `testing.upstream_fixtures_required` in `docs/workflow-config.json`, which is `true` only in this repository and never reaches consumers. With that key `true`, the helper fails instead of skipping (or a `source_repository_fixture` test asserts that no asset declares the key). This needs no new configuration.

## Question 2: can an inactive or stray profile trigger the skip?

No, under the spec as written. A non-active asset carrying the key makes `load_profile` raise `ProfileInvalid`, and `expected_profile` raises on any invalid asset. Two active assets already raise. An asset under `qualification/` is not globbed. A stray `WAVEFOUNDRY_TEST_PROFILE` value cannot add the key, because run-mode assets are not active. Recommendation: Requirement 2 or the reader task should state that the reader propagates `ProfileInvalid` and never maps it to `None`. Either way the failure direction is safe (budgets enforced or the run fails), but stating it keeps an implementer from catching it.

## Question 3: does a skipped budget hide a real regression where it matters?

Yes, for a subset. This is the strongest challenge. The census rule is mechanical (code that completes by doing its work), but the Decision Log excludes liveness bounds because skipping them "could hide a hang". Several of the 17 are hang or denial-of-service guards on inputs an attacker or a hostile document can shape, not machine-variance budgets:

- `test_techdocs_audit_lib.py`: the pathological pattern ("52 bytes of it hung the tool indefinitely"; the docstring says it is "Timed rather than merely asserted, because a fix that makes it merely slower would still pass"), the backtracking ceiling, the symlink cycle ("the failure mode is non-termination and a boolean assertion cannot see it"), and adjacent floating prefixes;
- `test_navigation_glob.py::test_many_double_star_segments_stay_fast`, `test_extension_tool_modules.py::test_call_parsing_is_bounded`, `test_scanner_input_limits.py`, and `test_upgrade_wavefoundry.py::test_free_text_placeholders_use_bounded_quantifiers`.

Under the bypass, a regression to "slow but terminating" (seconds per input instead of a hang) passes silently on the distribution. A true hang still surfaces as a worker timeout. The exposure falls mostly on code that a distribution edits itself, since upstream still runs every budget. The coordinator explicitly fixed the set at 17, so I do not block on it.

## Strongest alternative

Split the 17 into throughput budgets (census 1 to 9: warm estimator, projection poll, lexical evaluation, the indexer scale tests, line scan, calibration pass, memory warm path) and complexity guards (census 10 to 17). Under a declared bypass, skip only the throughput class. For the complexity class, multiply the bound by a fixed factor (for example 10) instead of skipping it. Machine variance never reaches 10x, and an exponential or cubic regression exceeds any constant factor, so the guard keeps its value with no flake. If the operator wants "disable" literally, the cheaper fallback is to record the class in the skip reason, so a distribution sees which skipped bounds were DoS guards.

## Verified claims

- `expected_profile` and `load_profile` behave as the spec states (`record_layout_support.py` lines 276 to 311 and 921 to 960); an unknown top-level key is accepted today, so AC-4 point 1 fails under current code as stated.
- A subtest skip is visible and the test body continues: executed on Python 3.14.8 and 3.11.17 (a failure after the skipped subtest still fails the test).
- The qualification comparison is unchanged upstream: `compare` requires each baseline skip with the same reason in the candidate, and refuses extra non-marker skips as `unexpected second-profile skip` (`qualification_report.py` lines 278 to 291).
- Side note: `coverage.json` pins `tests/record_layout_support.py`, so this change makes that pin stale. `build-and-verification.md` already says that current pins are stale and that runs fall back to full, so this needs no action here.
