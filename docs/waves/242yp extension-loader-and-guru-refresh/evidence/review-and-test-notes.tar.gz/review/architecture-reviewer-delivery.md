# Architecture reviewer: delivery notes (wave 242yp)

Verdict: approve. No blocking findings.

## Scope checked

- `docs/architecture/testing-architecture.md`: the new "Throughput-budget bypass" bullet after "Expected profile", and the "Distribution bypass" paragraphs in "Performance-Test Budget Policy".
- `docs/contributing/build-and-verification.md`: the Packaging profile qualification paragraph.
- The seam in `tests/record_layout_support.py` and `tests/perf_budget_policy.py`.
- The layering of 241l1 (`upgrade_extensions._exec_module_from_file`) and 241l2 (`render_agent_surfaces._is_managed_guru_description`).

## Docs match the code

- Key `skip_timing_budgets` (`TIMING_BUDGET_BYPASS_KEY`). It is refused in `_profile_errors` unless the asset has `"active": true`. The value must be one line (`splitlines() == [value]`) of at most 200 characters.
- `timing_budget_bypass_reason` loads each asset through `load_profile`, which means it reads the base layer only. It never reads the environment, and it propagates `ProfileInvalid`.
- The reason string matches exactly: `timing-budget bypass: declared by tests/fixtures/profiles/<name>.json: <reason>`.
- `timing_budget` records `subTest(timing_budget=label)` plus `skipTest`. A repeated label raises `ValueError` before the bypass reader runs, so the refusal applies with or without a declaration.
- The threshold tests call `check_operation_within_budget`, the core that is never bypassed, as the doc states.
- The warning against routing guards and liveness bounds appears both in the doc and in the module docstring. The pin test enforces it for the 9 listed guards.
- `qualification_report.py` contains the "duplicate skipped-test identity" rule that the doc cites.

## Seam layering

- The change is confined to test support. `perf_budget_policy` imports `record_layout_support` lazily, with a fallback to the package path.
- No environment variable enables the bypass. A grep for the key outside the tests finds only `record_layout_support.py` and `perf_budget_policy.py`.
- `qualification_report.py`, `qualification_worker.py` and `run_tests.py` are not modified.

## 241l1 and 241l2

- 241l1: `sys.modules` registration lasts only while the file executes, and the prior entry is restored on every exit. The change stays inside `upgrade_extensions.py`, and `_UNSET` and `sys` already exist there. It adds no new dependency.
- 241l2: the slot matcher is private to `render_agent_surfaces.py`. `previous_guru_descriptions()` drops its parameter. Its only callers are the module itself and its tests. It adds no new dependency.

## Verification

- In the tree: `TimingBudgetBypassDeclarationTests` 6 ok; `test_perf_budget_policy` 16 ok.
- Scratch-copy mutations, each detected:
  1. Drop the active-only check: 4 failures.
  2. Reader swallows `ProfileInvalid`: 3 failures.
  3. Route `test_many_double_star_segments_stay_fast` through `timing_budget`: `test_no_guard_test_calls_the_helper` fails.
- Limitation: the census child-run tests fail in the scratch copy because it lacks the repository context. They passed in the tree. I did not run the AC-7 worker test or the full suite.

## Advisory (not a finding)

The spec named the Default-profile-only entry as an edit site, but the content was placed in a new sibling bullet after "Expected profile" instead. All the required content is present.
