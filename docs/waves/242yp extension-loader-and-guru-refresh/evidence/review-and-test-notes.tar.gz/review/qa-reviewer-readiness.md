# qa-reviewer readiness notes (wave 242yp)

Verdict: no blocking defect. Readiness approval recorded (context `242yp-qa-reviewer-readiness`).

All probes ran with `python3 -B -I` on a throwaway copy of `.wavefoundry/framework/scripts` in the session scratchpad. No repo edits.

## 241l1 journal hook dataclass import

- Reproduced through the real `_exec_module_from_file` on `/opt/homebrew/bin/python3.11` (3.11.17) and `python3` (3.14.8): both print `AttributeError 'NoneType' object has no attribute '__dict__'`. With the planned register-then-restore-in-finally patch applied to the copy, both print `OK Row(x=1)`, and the private name is absent from `sys.modules` afterwards.
- The AC-2 probe really uses only the standard library. `upgrade_extensions` imports only stdlib modules at module level (the `wave_lint_lib` import at line 245 is inside a subprocess script string), and no third-party module was loaded during the probe. Because the crash comes from `dataclasses._is_type` on the plain string annotation path, which runs whether or not `typing` is loaded, the mechanism is the same on 3.11 and 3.14. So the 3.14 suite tests plus the 3.11 probe give adequate, honest coverage of the floor.
- AC-1 fails under the current helper: `_load_journal_hook` wraps the error as "could not be imported (AttributeError)". AC-3's in-module self-check fails under the current helper. Its absent and sentinel-identity cases catch two known-bad patches: one that leaves the module registered, and one that pops the entry instead of restoring the prior object.
- Non-blocking: Requirement 2 names `BaseException`, but AC-3 only says "a load whose module raises". A known-bad `except Exception: restore; raise` with no `finally` would pass if the test module raises an ordinary Exception. Suggest that the raising case raise a `BaseException` subclass that is not an `Exception`, such as `SystemExit` or `KeyboardInterrupt`.
- Non-blocking: no test loads `mcp_tool_extensions.py` itself with a dataclass. The shared-helper tests cover it.

## 241l2 guru description refresh

- AC-1 fails under the current code: the current template, filled with `Plan wave` / `Implement set` / `Close set` / `Prepare set`, goes through `_refresh_guru_description` unchanged and prints no notice.
- AC-4 enumeration: `previous_guru_descriptions()` returns 7 texts under the default profile (plan = `Plan spec`). Under a table that renames all four keys (the existing `Plan task` / `Build batch` table), it returns 9, of which 4 appear only under the renamed table. The union is 11 texts and covers every branch of the function: long form x3 fills, investigation form x3 fills, short form x2. A candidate slot matcher (`[^,()\r\n]+`, everything else escaped) over the current template and the three earlier forms matches all 11, and also matches the current description and the AC-1 text. AC-4 therefore really does enumerate every text recognized today, provided the renamed table renames all four keys. Advisory: name that table in the test. A table that keeps the default implement, close or prepare names collapses some entries.
- Known-bad controls are meaningful. A slot that crosses `,` or `(` replaces the AC-2 case 2 text. An empty-accepting slot replaces the AC-3 text. A matcher without the equality check prints the notice for AC-5.
- Non-blocking: `test_known_set_is_non_empty_and_excludes_the_current_description` asserts `len(known) >= 4`. With only three forms left, that assertion must change too. This falls within the stated `GuruDescriptionRefreshTests` update.
- Non-blocking: a distribution shortcut name that contains `,`, `(` or `)` would not be recognized. No shipped default shortcut contains them.
- Census: a whole-tree search for the description's opening words finds only the renderer, its tests, seed 050 and the closed 237ei record (`.claude/agents/guru.md` is not indexed). No fixture or digest pin changes.
