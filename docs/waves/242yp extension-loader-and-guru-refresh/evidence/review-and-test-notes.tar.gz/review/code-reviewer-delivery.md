# Code reviewer delivery notes (wave 242yp)

Verdict: approve. No blocking or actionable findings.

## 241l1 `_exec_module_from_file`

- Saves the prior entry with an `_UNSET` sentinel, registers the module, runs `exec_module` in `try`, and restores in `finally`. The prior entry goes back by identity; when there was none, the name is popped with a default. A module that deletes its own entry does not break the restore.
- `finally` covers `BaseException` (SystemExit). The tests check both an ordinary exception and SystemExit, with and without a prior entry.
- The docstring and the module comment state the call-time limit for `get_type_hints` and pickling.

## 241l2 slot matcher

- `re.fullmatch` is used. Literal pieces and the active profile's own shortcut both go through `re.escape`.
- The slot class `[^,()\r\n]+` cannot consume the `, ` or `)` delimiters. Each slot therefore has one viable extent, and backtracking is linear. A probe with inputs of 100k to 200k characters returned in 3 ms or less.
- Observation (not a finding): a slot made only of whitespace, for example `( , Implement wave, ...)`, matches and would be replaced. AC-3 covers only the empty slot, which is kept.

## 242yq helper and declaration

- `timing_budget` refuses an empty label and a repeated label before it reads the declaration, so the refusal holds with or without a declaration. The labels are stored per TestCase instance.
- `load_profile` goes through `_profile_errors`, which refuses the key without `"active": true`. It also refuses a value that is not a one-line string of 1 to 200 characters, judged by `splitlines() == [value]`. Each error names `skip_timing_budgets`.
- The reader reads only active assets, propagates `ProfileInvalid`, and does not cache exceptions (`lru_cache` keys on the directory).
- The reason string is `timing-budget bypass: declared by tests/fixtures/profiles/<name>.json: <reason>`. It uses `/` on every platform.
- Observation (not a finding): if two assets are marked active, the reader returns the first one instead of refusing. `expected_profile` refuses that state on the same tree.

## Execution

- Focused run on the real tree passed: 386 tests, `python3 -B -m unittest` on ExecModuleFromFileTests, JournalIncomingRunnerTests, test_render_agent_surfaces, test_perf_budget_policy, test_profile_support and test_qualification_report.
- I applied 13 mutations to a scratch copy under the session scratchpad. Each mutation made its focused tests fail:
  - restore through `except Exception` instead of `finally`
  - the module never registered
  - the name always popped
  - `match` in place of `fullmatch`
  - no escape on the literal pieces
  - no escape on the own shortcut
  - a slot that allows commas
  - a slot that allows an empty value
  - no duplicate-label refusal
  - an inactive asset accepted
  - a multiline reason accepted
  - backslash separators in the reason
  - a reader that swallows `ProfileInvalid`
- The repository was not edited.
