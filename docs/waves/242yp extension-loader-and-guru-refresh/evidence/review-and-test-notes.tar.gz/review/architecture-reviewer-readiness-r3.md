# architecture-reviewer readiness r3 (wave 242yp)

Verdict: APPROVE readiness for all three specs on receipt `review-policy-001af52936c870cdd5b0`. No blocking defect. Two advisories for the implementer, both fit inside the readied ACs and need only a Progress Log note.

## 242yq: the seam

The active profile asset is a sound home for the bypass.

- It is the one committed, distribution-owned file the suite already reads. `expected_profile` in `tests/record_layout_support.py` (lines 921-958) takes the single `"active": true` asset as the base layer. It refuses more than one active asset, and it never falls back.
- Each qualification report's source hash binds its bytes (comment at lines 388-391). A distribution declares it in `qualification/distribution-assets.json`, so the bypass is reviewable and hash-bound with no new mechanism.
- `test_framework_assets_are_never_marked_active` (`test_profile_support.py:1337`) pins `second.json` and `declared.json` as inactive. Requirement 2's active-only refusal means neither a run-mode layer nor an upstream asset can carry the key.
- Layering cost: the asset's existing job is "the constants the loaded modules must equal". Adding a test-policy key mixes a second concern into it, and a distribution that edits no constants must still name one in `modules`. The spec's Risks table states this. It is accepted coupling, not a defect. The alternatives in the Decision Log (an env var, an upstream-file constant) are each worse on reviewability or merge cost.
- Qualification is unaffected upstream. `qualification_report.compare` (lines 278-291) requires every baseline skip in the candidate with the same reason, and refuses any extra skip that is not default-profile-only. A distribution's default run and its profile runs read the same committed active asset, so their bypass skips match. Upstream has no active asset, so it records no bypass skips.

## 242yq: exposure

The spec bounds the bypass: it is declared in the active asset only, needs a non-empty reason of at most 200 characters, uses no environment variable, and skips with a visible reason. It reaches only the sites routed through the helper. The remaining exposure is a later author routing a liveness bound through the helper. The Decision Log accepts this, with no guard test, under the documented census rule. I agree for now. The rule belongs in the budget-policy section (advisory 1), where authors look.

## 242yq: the docs

Advisory 1 (doc placement). The spec's "Affected Architecture Docs" names only the Expected profile and Default-profile-only entries of `docs/architecture/testing-architecture.md`. The section that owns the helper and the budget convention is "Performance-Test Budget Policy" (line 642). It says "Every wall-clock budget in the suite follows the policy" and "budget assertions go through `assert_within_budget`". After this change that section must state the shared skip-aware helper, the census rule with its liveness exclusion, and the bypass. Without that, it overstates (liveness bounds are not routed) and hides the convention from future budget authors. AC-5 already requires the census rule in this document, so the edit is in scope. Record the section choice in the Progress Log.

Advisory 2 (subtest skip identity, qualification seam). `qualification_report.worker_detail` (lines 141-142) adds the issue "duplicate skipped-test identity" when two skip rows share an id, and the report then counts as incomplete. Probe (`python3 -B -I`, Python 3.14.8, scratch copy only): two `subTest(timing_budget='warm')` + `skipTest` calls in one test produced two skips with the identical id `T.test_a (timing_budget='warm')`. The skips inside `subTest` behaved as Requirement 4 states: the test continued, and a later failing assertion still failed the test. The current loop sites (techdocs `at_ceiling`, `groups`, `topology`; the context-efficiency `budget_checks` labels) already sit inside parameterized subtests or carry distinct labels, so nested ids stay unique. But two bounds in one test with the same label would break a distribution's qualification report. `test_warm_path_call_counts_and_latency_are_bounded` has two bounds, for example. Give each helper call in a test a distinct label. Preferably also run the AC-4 point 3 pair through `worker_detail`, not only `compare`.

Probe file: `/private/tmp/claude-502/-Users-coryhacking-Developer-wavefoundry/c49d4915-53cc-460a-9250-80578e2c9abc/scratchpad/arch/probe.py`.

## 241l1 and 241l2 (scope rationale)

I hold no earlier approval for these; this lane was not required in the earlier rounds. The specs are unchanged since their readiness approvals (`code-reviewer-readiness.md`, `qa-reviewer-readiness.md`, `council-chair-readiness.md` and the focused-r2 notes in this folder). Their code is already implemented.

- 241l1: its "N/A" claim holds. The `upgrade_extensions.py` row in `docs/architecture/layering-rules.md` (line 40) says new matching modules are "removed on success/failure". Registering the module only while it executes and then restoring the prior state keeps that true.
- 241l2: one function's matching rule in the renderer, with no boundary or flow impact. No architecture doc applies.

There is no diff under `docs/architecture/` in the tree today.

## Integrity

I read the spec, the wave record, `record_layout_support.py` (profile validation, loading and expected-profile resolution), `qualification_report.py` (`worker_detail`, `compare`), `qualification_worker.py` (`addSkip` identity), `perf_budget_policy.py`, and the relevant `testing-architecture.md` and `layering-rules.md` sections. I spot-checked the census loop sites in `test_techdocs_audit_lib.py` and `test_server_context_efficiency.py`. I did not re-run the 17-site AST census or the 27 liveness exclusions. The code and QA lanes own those checks. I ran only the scratch probe above, made no repo edits and did not run `run_tests.py`.
