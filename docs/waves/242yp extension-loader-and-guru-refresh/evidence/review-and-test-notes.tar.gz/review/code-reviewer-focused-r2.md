# code-reviewer focused readiness r2 (wave 242yp)

Verdict: finding `242yp-cr-guru-slot-excludes-legal-shortcut-chars` is repaired. No new blocking defect. Readiness approval recorded on receipt `review-policy-f26383340bc2cb0907d2`.

## Reverification of the slot rule (241l2)

Probe: `python3 -B .wavefoundry/work/242yp/review/code-reviewer-focused-r2-probe.py` (copy of a scratch probe; no repo code edited). It builds the Requirement 2 matcher (per slot: `re.escape(active shortcut)` or `[^,()\r\n]+`, whole value under `fullmatch`) over the three earlier forms, with the short form's `Implement wave` and `Close wave` slotted, plus the current template. 52 checks, 0 failures:

1. Requirement 4: every text the current `previous_guru_descriptions(shortcut)` returns is matched, with that table active, for the default profile, a fully renamed table (`Plan task`, `Build batch`, `Close batch`, `Prepare batch`), a `Plan (spec)` table, and a table whose implement, close and prepare shortcuts contain `,`, `(` and `)`. The renamed-table texts also match under the default profile (AC-4 case 2).
2. AC-1: the departing `Plan wave` / `Implement set` / `Close set` / `Prepare set` text matches; `Prepare wave or security reviews` in the prepare slot matches.
3. Kept: a one-character edit in fixed prose, trailing text, a slot value containing `,` or `(` under the default profile, an empty slot, and a departing `Plan (spec)` text under the default profile (fails safe, as Scope and Risks state).
4. Known-bad: a generic-only matcher misses the `Plan (spec)` texts, so AC-4 case 3 detects it.

Notes for the implementer (non-blocking):

- The current description itself matches the template pattern, so the `value == current` check must stay ahead of the matcher (Requirement 5 already says so).
- Slot alternation stays linear: the generic class cannot cross the literal `, ` separators.

## 241l1 advisory edits

The three edits (import-time-only limit documented, restore via `pop(name, None)` or re-insert, AC-3 `SystemExit` case) match my round-1 probe of the planned shape and change no verdict. The helper at `upgrade_extensions.py` `_exec_module_from_file` is unchanged on the tree, as expected before implementation.
