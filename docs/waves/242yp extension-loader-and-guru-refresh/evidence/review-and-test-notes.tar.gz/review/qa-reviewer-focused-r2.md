# qa-reviewer focused readiness notes, round 2 (wave 242yp)

Verdict: no blocking defect. Readiness approval re-recorded on receipt `review-policy-f26383340bc2cb0907d2` (context `242yp-qa-reviewer-focused-r2`). I wrote neither the finding nor the repair.

The probe is a scratch copy of the planned matcher at `/private/tmp/claude-502/-Users-coryhacking-Developer-wavefoundry/c49d4915-53cc-460a-9250-80578e2c9abc/scratchpad/qa242/probe.py`. It ran with `python3 -B` and imports the real `render_agent_surfaces` and `vocabulary_profile` read-only. I made no repo edits.

## 241l2 slot rule (Requirement 2)

The probe uses the three earlier forms plus the current template, with each slot matching `(?:<escaped active shortcut>|[^,()\r\n]+)` under `fullmatch`.

- Every text that `previous_guru_descriptions` recognizes today matches under the same active profile, with 0 misses. The tables were: default (7 texts), the full rename `Plan task`/`Build batch`/`Close batch`/`Prepare batch` (9), the earlier-plan table (9), `Plan (spec)` (7) and `Plan, then build` (7).
- A generic-only matcher (the known-bad for AC-4 case 3) misses the `Plan (spec)` and `Plan, then build` texts, so AC-4 case 3 detects it.
- AC-1: the departing-profile text is managed, while the current code does not recognize it. The `Prepare wave or security reviews` in-slot case is managed, as documented.
- AC-2: a one-character prose edit, a slot containing `,` and a slot containing `(` are each kept. Trailing text is kept under `fullmatch`. A known-bad `re.match` accepts it.
- AC-3: an empty slot is kept. A known-bad `[^\r\n]*` slot accepts it. A known-bad slot that crosses `,` accepts AC-2 case 2.
- AC-5: the filled current template equals `CLAUDE_GURU_DESCRIPTION`. The equality check and its known-bad were confirmed in round 1 and are unchanged.
- The short form's `Plan feature` and `Plan change` texts, with `Implement wave` and `Close wave` now in slots, are still managed.

## Trap tests (241l2 task 2 and task 3)

- `test_each_previously_shipped_description_is_replaced`, `test_other_descriptions_and_headers_are_kept` and `test_control_without_the_known_set_leaves_a_stale_description` all index `previous_guru_descriptions()`. Under the new interface that function returns raw placeholder forms, and the probe shows a raw `{plan}` form matches the generic slot. A test fed raw forms would therefore pass without proving anything. Task 3 now forbids raw forms and requires filled forms or the AC-4 literals.
- The control still has teeth. A filled long-form text cannot match the current template, because the prose differs. With the forms patched out (`return_value=()`), the control text is kept and `_assert_replaced` raises as intended.
- `len >= 4` is replaced (task 2), and `test_placeholder_form_follows_a_non_default_vocabulary`'s kept-under-default assertion inverts.

Advisories (non-blocking):

1. The matcher should resolve `vocabulary_profile.shortcut` at call time, as today's `shortcut or vocabulary_profile.shortcut` does, not bind it at definition the way `_vp_shortcut` does. Otherwise the `_render(shortcut=...)` patch in `GuruDescriptionRefreshTests` will not reach it. AC-4 case 3 fails loudly if this is missed, so the error cannot go unnoticed.
2. `assertNotIn(CLAUDE_GURU_DESCRIPTION, known)` becomes trivially true once `known` holds placeholder forms. Consider asserting that no form, filled with the default shortcuts, equals the current description.

## 241l1 advisory edits

- AC-3 now raises both an ordinary `Exception` and `SystemExit`. A known-bad `except Exception: restore; raise` with no `finally` fails the `SystemExit` case, which closes my round-1 advisory. The sentinel-identity check detects pop-instead-of-restore, and the in-module assertion detects the current helper.
- Requirement 2 mandates `pop(name, None)`, and the import-time-only limit is stated in Requirement 4, Scope, Risks, the Tasks and the CHANGELOG task. These are documentation edits and need no test.
- Non-blocking: no AC case has a module delete its own `sys.modules` entry. A known-bad `del sys.modules[name]` in the absent branch is therefore caught only by Requirement 2 and review, not by a test.
