# Red-team focused reverification, round 4 (wave 242yp, spec 242yq)

Seat: red-team. Context: `242yp-red-team-focused-r4`, fresh and independent (I wrote neither the finding nor the repair). Finding owned: `242yq-bypass-skip-identity-collision`. This records a reverification only, no approval.

## Verdict

The repair holds. Requirement 4 now requires a label unique within its test and a call-time refusal of a repeated label, with or without a declaration. AC-2 names the exact 11 skip ids. AC-7 runs routed census workers through `qualification_worker` and `worker_detail`. Requirement 10 now ties the "compare equal" claim to that uniqueness rule. No new blocking defect.

## Probe through the real qualification path (`execution_status: executed`)

Throwaway copy of `.wavefoundry/framework/` in the scratchpad (scripts plus install, seeds, docs and the rest, so fixtures resolve). In the copy only, I added a minimal helper per Requirement 4 to `tests/perf_budget_policy.py` (per-test label set, refusal on repeat, `subTest(timing_budget=label)` plus `skipTest(<reason>)`), and routed the two `test_memory_records.py` warm-path bounds and the `test_indexer.py::_scale` bound through it. A driver ran the real `qualification_worker.py` as a subprocess with `python3 -B`, parsed counts the way `run_tests.py` does, and called the copy's `qualification_report.worker_detail`. No repository file was edited; `run_tests.py` was not run.

| Run | Result |
| --- | --- |
| `test_memory_records.py`, labels `first advisory call` and `warm advisory call` | rc 0, 235 tests, skipped 6, `complete=True`, `issues=[]`; two bypass skips with distinct ids |
| `test_indexer.py`, tests 4 and 5 share `100K-row drift detection` via `_scale` | ids differ by test id (`test_10k_rows_sub_second (...)` and `test_100k_rows_contention_safe_budget (...)`); see the worker result below |
| Control: label repeated, refusal ON | the test fails at call time (rc 1); `worker_detail` still complete, so the mistake surfaces as a test failure, not a qualification refusal |
| Control: label repeated, refusal OFF | rc 0, skipped 6, `complete=False`, `issues=['duplicate skipped-test identity']`: the original defect reproduces, so the oracle is non-vacuous |

Indexer worker: rc 1 (4 unrelated GPU-routing failures in the copy's environment), `complete=True`, `issues=[]`, with both `100K-row drift detection` skips present under distinct ids. `worker_detail` completeness does not depend on the return code.

## The three checks the brief asks for

1. Unique identities hold: shown above. A label shared across two tests (rows 4 and 5) is safe, because the skip id carries the test id.
2. AC-2 table matches the tree. Test 1 builds `budget_checks` with `10-source warm`, `50-source warm` and `lifecycle flush/projection warm` (`test_server_context_efficiency.py` 3735 to 3790). Test 2 has one `assertLess(elapsed, 2.0)` (1060). Test 3 uses `1000-record memory lexical evaluation` (`test_memory_eval.py` 406). Tests 4 and 5 go through `_scale` with `100K-row drift detection` (`test_indexer.py` 4189). Test 6 uses `20000-def line scan` (`test_graph_indexer.py` 2345). Test 7 has one `assertLess` against `RUNNER_BUDGET_SECONDS` (`test_lexical_ranking_eval.py` 236). Test 8 has two `assertLess(..., 0.5)` (`test_memory_records.py` 2208, 2209). The labels for tests 2, 7 and 8 are new names the spec assigns, which is fine. Total 11.
3. The 8 are throughput budgets over ordinary input; the 9 excluded tests are complexity or hang guards: 40 `**` segments, bounded parse attempts, the backtracking ceiling, floating-prefix collapse, cubic cost in subject length, the exponential `?*` pattern, symlink cycles, the decoded-size cap scanned with the full ruleset, and bounded quantifiers. All are pathological or maximum-size input, matching exclusion 2 of Requirement 6.

## Non-blocking notes

- The 4 `test_indexer.py` GPU-routing failures in the scratch copy come from the copy's environment (no models or accelerator setup) and do not touch the bypass path.
- Requirement 4's "unique within its test" assumes the helper is not called under an enclosing `subTest` that repeats with the same label. No census site does this today, and the enclosing subtest's params would enter the id anyway.
