# council-chair readiness verdict (wave 242yp)

Verdict: Prepare-phase Wave Council PASS. Recorded `council-readiness` (context `242yp-council-chair-readiness`) on receipt `review-policy-f26383340bc2cb0907d2`.

Checked before recording: `wf_review_wave(phase='prepare')` shows code-reviewer and qa-reviewer readiness approvals current, lint passed, and the only finding (`242yp-cr-guru-slot-excludes-legal-shortcut-chars`) terminal with no unresolved lanes.

Seats that ran: red-team (primer, standard depth), docs-contract-reviewer (rotating), code-reviewer, qa-reviewer.

Intent fit: partially. 241l1 establishes the Objective (the hook imports). 241l2 establishes it except for a departing profile whose shortcut contains `,`, `(` or `)`, which is kept rather than refreshed (fails safe, stated in Requirement 2 and Risks).

Strongest challenge (red-team): the slot grammar replaces in-slot routing exclusions written without a comma, such as `Prepare wave or security reviews`. Now a documented replaced case in AC-1 and Risks.

Strongest alternative (red-team): keep 241l1 modules registered for the span of `_journal_incoming_imports` so call-time introspection also works. Rejected in the Decision Log; the preview path still needs the per-call restore.

Advisories carried:
1. The 241l1 fix covers import time only; the hook's own `get_type_hints` or pickling at call time still fails. Documented in Requirement 4, Risks and the CHANGELOG task.
2. A departing profile whose shortcut contains `,`, `(` or `)` is kept rather than refreshed, which fails safe.
3. In-slot routing exclusions are replaced.
4. Implementer notes from lanes: use `sys.modules.pop(name, None)`; keep `value == current` ahead of the matcher; resolve `vocabulary_profile.shortcut` at call time; trap tests must use filled forms or AC-4 literals; docs-contract notes seed 050 is misnamed in 241l2 (seed 160 and the upgrade prompt hold the sentence), a Progress Log correction.

Integrity: the chair ran no probes of its own; it read every lane note and both specs and relied on the lanes' executed probes. `test_ran_without_unintended_skip` and the other checks are affirmed on that reading basis only.
