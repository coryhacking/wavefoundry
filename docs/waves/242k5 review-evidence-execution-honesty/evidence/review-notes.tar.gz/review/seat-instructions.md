# Phase 2 seat instructions (wave 242k5 readiness)

1. Read briefing.md and primer-red-team.md here, the wave record and the spec. Address the primer's strongest_challenge, the primer_questions in your remit and its efficacy_replay.
2. Review your remit against the tree. Decide whether the plan, implemented as written, establishes its Product Intent in your remit, and whether each AC can pass and can fail.
3. Write notes to .wavefoundry/work/242k5/review/<lane>-readiness.md.
4. Record (required lanes only; reality-checker records nothing):
   - A blocking defect is recorded as a typed finding BEFORE any approval, and you do NOT approve: wf_review_event(wave_id='242k5', event='finding', run_kind='readiness', cycle=0, actor=<lane>, context_id='242k5-<lane>-readiness-r1', finding_id='R1-242k4-<short-slug>', source_lanes=[<lane>], blocking_required_lanes=[<lane>], approval_recheck_lanes=[], fresh_context=true, independent=true, judgment={all core keys plus disposition and disposition_rationale}, evidence={proposition, failure_condition, public_path, command_or_fixture, expected, observed, artifact_or_test_id, known_bad_detection_method, limitations, safety_and_authorization, disposition_rationale}, integrity_checks={honest}). Dry-run, then create. wf_review_wave(wave_id='242k5', phase='prepare') shows the vocabularies.
   - Wording preferences go only in notes.
   - Otherwise record your readiness approval: event='approval', signoff_key=<lane>, approval_phase='readiness', the same context, evidence {observed, artifact_or_test_id: your notes path}, honest integrity_checks. Dry-run, then create.
5. Reply in under 150 words: verdict, finding ids, and the one thing the chair most needs to know.
