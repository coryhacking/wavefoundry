# qa-reviewer readiness notes: wave 242k5, change 242k4

- context: 242k5-qa-reviewer-readiness-r1, fresh_context=true, independent=true
- verdict: not approved. Three typed findings, all blocking qa-reviewer.

## What I ran and what I only read

- Executed: `planning/repro_handler.py`, copied to `review/scratch/qa-reviewer/repro_handler_copy.py` with its throwaway root moved under my scratch folder, run with `python3 -B` against the current tree. Executed: the red-team primer probe `scratch/red-team/probe_relabel.py` (in memory, writes nothing).
- Read only: the spec, the primer, seed 209's readiness finding bar, `build_compact_review_event` (finding branch, `evidence_phase`, terminal reverification, convergence auto-mint), `_finding_origin_phases`, `normalize_review_event_request` (line ~1462 `setdefault("execution_status", "executed")`), and `wf_review_event_response` (status guard, replay lookup order).
- I did not run the suite, `repro_builder.py` or the prototype.

## Reproduction (executed)

All three Rationale rows reproduce exactly on the current tree:

- A: no status, checks true, "read-only, no probe run" -> ok, stored `execution_status='executed'`.
- B: honest `false` checks -> refused with `executed finding event cannot carry integrity_checks.public_path_reached=false` (and the two siblings).
- C/D/E: `inferred`, `unverified`, `not_applicable`, blocking or not, dry_run or create -> refused with `dedup evidence must be executed`; blocking `unverified`/`not_applicable` also hit `blocking synthesis ... cannot rely on unverified/not_applicable evidence`.
- F: `bogus` is refused today by the validator (`unknown value 'bogus'`), without the allowed values, so AC-2.2 can fail today as claimed.
- G: the handler script prints the response keys, not the derived approval status; the silent-replacement claim rests on `repro_builder.py` case 4, which I did not rerun. Read of the approval branch (line ~4531 literal `"executed"`) agrees.

## AC pass/fail check

| AC | Can pass | Fails under a known-bad | Note |
| --- | --- | --- | --- |
| AC-1 | yes | yes: reproduced today | sound |
| AC-2 | yes | partly | 2.3 tests replay of a stated-status finding only; see finding 3 |
| AC-3 | yes | yes | sound |
| AC-4 | yes | yes | sound |
| AC-5 | yes | no, for the relabel route | see finding 1 |
| AC-6 | yes | yes | sound |
| AC-7 | yes | yes | sound; 7.1 is the right oracle |
| AC-8 | yes | yes | sound |
| AC-9 | yes | yes | sound |

Priority table: fine. AC-8 `important` is reasonable since `verbose=true` already exposes the field.

## Gate coverage by status

The requirement-5 table is covered cell by cell: introduce (AC-1, AC-6.2), blocking synthesis (AC-6.2), clear and terminal (AC-5.1, 5.2, 5.3, 5.5, AC-6.1), non-clearing reverification (AC-5.4). Two gaps remain, both raised by the primer:

### Finding R1-242k4-readiness-relabel-bypass (blocking)

Executed probe on the current tree: after an `initial_delivery` run exists, a new finding with `run_kind='readiness'` builds and validates, and its `repair_start`, `reverification` and auto-minted `lane_reassessment` all carry `phase: readiness`; `_finding_origin_phases` returns `readiness`. The handler's only run-kind status guard is `repair_start` on a closed record (read). Requirement 5 says "the tool derives the phase; the caller cannot set it", but the caller sets `run_kind`, which is the phase authority. After the change, a delivery reviewer can introduce a delivery defect as a readiness finding and clear it with `inferred` evidence. Every AC-5 case roots the finding in `initial_delivery`, so AC-5 passes under an implementation that keeps this route open. The Product Intent boundary ("read-only evidence does not satisfy a gate that requires execution") is therefore not established by any AC.

Repair: bind the lenient clear to ledger state in the builder (refuse an `inferred` clear or terminal reverification for a readiness-origin finding introduced after any delivery run exists, or refuse a new `run_kind='readiness'` finding once a delivery run exists), and add an AC-5 sub-point for the relabel case through the public tool. Builder-only, so requirement 6.3 holds.

### Finding R1-242k4-repair-start-status (blocking)

Requirement 2 requires a stated status on every caller-authored finding event, including `repair_start`. Requirement 1's meanings describe verifying a claim; at `repair_start` the implementer has verified nothing. The `repair_start` synthesis stays blocking, so `unverified` and `not_applicable` are refused (the unchanged blocking-synthesis rule), and `executed` needs five `true` checks. The only recordable honest-looking value is `inferred`, and the spec never says so. No AC records a `repair_start` with or without a status, so an implementation that exempts it, defaults it, or refuses the honest `unverified` passes every AC. This is the most-scripted call and the one most exposed after upgrade. It is an unresolved substantive decision on a required path.

Repair: decide the `repair_start` status (state `inferred` with its meaning in requirement 1, or derive it in the tool as the primer suggests), and add an AC sub-point that a `repair_start` recorded through the guided action succeeds with that rule and that omission is handled as decided. Also: `convergence_checkpoint` is listed in requirement 2 as caller-authored, but the builder auto-mints it on the final reverification; say so (wording, notes only).

## Upgrade transition

### Finding R1-242k4-old-ledger-replay (blocking)

Requirement 2.4 says an identical retry of an event already in the ledger replays whether or not its original request stated a status. Read: the handler looks up `existing_bundle` before calling the builder, and `normalize_review_event_request` already defaults the status to `executed`, so a builder-level refusal is replay-safe. A refusal placed in the handler before the transaction (beside the `evidence` merge) is not, and it would refuse the retry of every pre-change finding mid-cycle in an open wave. AC-2.3 only replays a finding recorded with a stated status, and AC-2.4 checks digest equality, not refusal order. Neither fails under the known-bad placement. My remit's upgrade-transition check (old ledger replay never refused) has no AC.

Repair: add an AC-2 sub-point: a finding bundle stored with the pre-change shape and digest (no status in the request) replays on an identical retry that omits the status, with no refusal and no append, through `wf_review_event_response`.

Other old-code window direction (notes only): new prompts against a not-yet-restarted server meet the old `dedup evidence must be executed` refusal, whose wording invites flipping values. The seed 160 guardrail should tell an upgrading operator to restart the server before recording a non-executed finding. Not blocking.

## Primer responses

- strongest_challenge 1: agreed, confirmed by execution; finding 1.
- strongest_challenge 2 / question 2: agreed; finding 2. The diagnostic alone does not let a stale agent recover in one retry at `repair_start`, because the listed values include two that the blocking synthesis refuses.
- strongest_challenge 3 (prose lanes at delivery): docs-contract remit; I would accept a seed 209 sentence and do not block on it.
- question 3: finding 3 for the replay order; restart guidance noted above.
- efficacy_replay: the reproduction supports "recording the finding: fixed" once requirement 6.1 lands.
