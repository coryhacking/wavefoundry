# security-reviewer delivery review: wave 242k5, change 242k4

- context: 242k5-security-reviewer-delivery, fresh_context=true, independent=true. I did not implement the change.
- verdict: APPROVE. No blocking defect. Non-executed evidence clears no required lane, completes no repair on a head with no blocking lanes, makes no head terminal, completes no caller-authored checkpoint and satisfies no approval.
- recorded: one non-blocking finding, `D-242k4-recheck-and-depth-release` (`dont_do_later`, no repair pending), and the `security-reviewer` delivery approval.

## What I ran

All with `python3 -B`. Probe roots were `TemporaryDirectory` roots made by the test class's own `setUp`. No real ledger was written by a probe and no repository file was edited. Scratch files are in `.wavefoundry/work/242k5/review/scratch/security-reviewer-delivery/`.

1. `probe_delivery.py` (output `probe_delivery.out`): the real `wf_review_event_response` handler on the implemented tree. 219 checks, 219 as expected, no unittest error.
2. The focused tests `test_review_evidence.ExecutionStatusHonestyTests` and `test_server_tools_lifecycle.ReviewEventExecutionStatusTests`: 47 tests, OK.
3. `mutants.py` (output `mutants.out`): six in-process replacements of `_non_executed_gate_outcomes` and `_contrary_execution_status_errors`, applied to the builder module and to the module the server reloads. A seventh mutant was a scratch copy of `review_evidence.py` with the validator relaxation widened; the copy is deleted.
4. The implementer's `impl/ledger_snapshot.py`, with the change and against `impl/baseline/review_evidence.py`. I confirmed the baseline is byte-equal to `HEAD`.

Not run: `run_tests.py`, the full suite, `--profile second`, any platform but macOS. I did not review the seeds, docs or rendered carriers.

## Round-1 relabel probes, rerun on the implemented code

| Probe | Result |
| --- | --- |
| `run_kind='readiness'` after `initial_delivery`, wave `planned`, `implementing` and `active` | Lane-clearing reverification refused for `inferred`, `unverified` and `not_applicable`, with honest checks and with all-true checks, in `dry_run` and `create`. Ledger and head unchanged. The executed control clears. |
| Readiness on an `implementing` wave with no delivery record, and on a `planned` wave | Same: refused, unchanged; executed control clears. |
| Caller-authored lane-less `convergence_checkpoint`, cycle 2, delivery and readiness origin, blocking and non-blocking, with and without `frozen_boundary` | Refused for all three statuses. Head stays `pending`. A cycle-1 checkpoint is refused too. A non-executed checkpoint on a new finding id appends nothing. |
| `security_unsettled` settled as not actionable on `inferred` evidence | Refused through `reverification`, through `repair_start` and through a checkpoint; also refused as `invalid` and as shown unreachable. The candidate stays listed and `operator-signoff` stays withheld. Same for `unverified` and `not_applicable`. The executed control settles it. |

## Approvals and the operator close

- A specialist delivery approval, a specialist readiness approval, `council-delivery`, `council-readiness` and `operator-signoff` each refuse a stated status of `inferred`, `unverified`, `not_applicable`, `''`, `'Executed'`, `' executed'`, `0`, `False`, a list and a dict, in `dry_run` and `create`. Nothing is appended.
- An approval with `false` integrity checks is refused whether it states `inferred` or omits the status.
- A forged approval record with `execution_status: inferred` fails `validate_review_evidence_records`, and the projection reads it as "no current executed approval".
- An operator close that states any of six contrary values is refused, and the head stays `pending`.

## Other routes I tried

- Status smuggling. A status placed in `judgment` is ignored and the event is treated as executed, so `false` checks are refused. An explicit `None` is the default. `'INFERRED'`, a list and `True` are refused with the allowed values.
- After an `inferred` reverification that keeps its lane (head `completed` with the lane, not terminal, closure still fails), a non-executed lane drop, a checkpoint and a cycle-2 `repair_start` are all refused.
- An `inferred` `repair_start` that reclassifies a blocking finding as non-blocking is refused by the existing validator rule.

## Finding, not blocking: `D-242k4-recheck-and-depth-release`

An `inferred` `repair_start`, or an `inferred` reverification that keeps its blocking lane, can narrow `approval_recheck_lanes` or drop a `review_boundaries_changed` trigger. In the probe the `security-reviewer` delivery row moved from "withheld: blocking findings F-1" to "approved", and `review_depth` moved from `full` to `focused`. The outcome rule tests lanes, `completed` and terminal only, so the code comment "it may not change what a gate reads" says more than the rule does.

Why it does not block: the same event with the status omitted is accepted in the same way, from the same non-independent repair actor, so the change adds no authority. The three outcomes that the spec, the docstring and AC-5 name all hold. The finding's own lane still needs executed, fresh, independent evidence before closure. A fourth condition would need a spec change after readiness. The comment can be narrowed at any later edit.

## Old ledgers

396 ledgers read in both passes, same set, 0 differing in validation errors, approval currency or finding facts, 0 exceptions. `git status` shows no tracked ledger changed. The replay tests for a stored finding and for a stored approval whose request stated `inferred` pass.

## Known-bad detection

| Mutant | Failing tests of 47 |
| --- | --- |
| No outcome gate (validator change only) | 35 |
| Lane-drop condition only | 20 |
| No `completed` condition | 1, the builder test `test_completed_condition_alone_refuses_a_checkpoint_on_a_terminal_head`; no handler test catches it |
| No newly-terminal condition | 4 |
| No lane-drop condition | 2 |
| Approvals and operator close accept a contrary status | 17 |
| Validator accepts any non-executed dedup evidence | 1 |

The replay-before-refusal order (AC-7.5) was checked by running its test only; I did not mutate `server_impl.py`.

## Unchanged from before

A caller who falsely states `executed`, or omits the status, is recorded as executed. That is outside this change.
