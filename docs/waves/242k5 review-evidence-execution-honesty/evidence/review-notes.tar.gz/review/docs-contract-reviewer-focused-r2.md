# docs-contract-reviewer focused r2: wave 242k5 / change 242k4

Evidence status: read plus grep. I read the repaired spec, round-1 notes, ledger history for both findings and the live seed 178, seed 160 and upgrade-prompt text, and ran grep over framework scripts. I ran no handler, test or render. The tool records these as executed; the honest status is inferred.

## R1-242k4-status-meaning-boundary: holds
- Req 1 now draws the line: executed = something ran that exercised the system or evaluated the claim (test, probe, handler/tool call, checker such as docs-lint or a render); inferred = reading, and a read-only retrieval such as grep or code_read is reading. The "ran nothing" contradiction is gone. Safe-boundary is stated as inferred with safe_boundary true (req 1.5), matching the validator.
- unverified/not_applicable now have homes (1.3, 1.4); open census maps to unverified (9.1).
- repair_start: req 2.4 says no run kind is forced to state a status; the default applies. Acceptable under the narrowing (field optional). The checkpoint is minted by the builder (2.5).
- Carrier block (9.5) takes the one-line meanings from req 1; seed 209 (9.1) takes the full boundary; AC-9.1 names the boundary. Seed 178 and the refresh-techdocs prompt (9.7, AC-9.7) are in the census (9.8); live lines 71 and 70 match what the spec quotes.
- Narrowing effect: meanings are guidance only, no gate keyed on them, so no new route.

## R1-242k4-upgrade-guardrail-not-rendered: holds
- Req 9.6, AC-9.6 and the task now say hand merge outside the managed region; the render claim is gone and the sync task lists only the executable-review-evidence regions. Confirmed in the tree: upgrade prompt review-policy-upgrade end marker at line 745, the sibling "Council signoff keys" paragraph at 747 outside it; no framework script carries that text; UPGRADE_POLICY_BLOCK stays unchanged. Restart-before-use note is in 9.6 and Risks.

## Non-blocking (implementation time)
- AC-9.5's contract test pins the status set only; the one-line meanings in the carrier and seed 209 can drift apart. Consider asserting each status word appears in both.
- Seed 178 line 71 also says "as executed evidence" for the delivery approval clause; that is correct for approvals and should stay, so reword only the finding clause.
- Req 4 text about an approval's executed attesting the review pass must avoid the three phrases pinned as forbidden in test_review_evidence.py.

Verdict: both repairs hold; approve readiness for the docs-contract lane.
