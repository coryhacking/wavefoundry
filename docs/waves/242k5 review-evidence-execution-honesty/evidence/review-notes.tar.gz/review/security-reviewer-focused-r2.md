# security-reviewer focused readiness verification, round 2: wave 242k5, change 242k4

- context: 242k5-security-reviewer-focused-r2, fresh_context=true, independent=true. I wrote neither the round-1 findings nor the repair.
- receipt: review-policy-7d6780545c30ef824209
- verdict: both repairs HOLD. `R1-242k4-relabel-open-wave` and `R1-242k4-checkpoint-completion` are reverified; the security-reviewer lane is cleared on both.
- one advisory for the planner (AC-5 pins two of the four routes that only the builder gate stops), and one dependency on the open code-reviewer finding `R1-242k4-outcome-rule-completed-trigger`.

## What I ran and what I only read

Executed, all with `python3 -B`, all under `.wavefoundry/work/242k5/review/scratch/security-reviewer-r2/`. No real ledger was written and no repository file was edited.

- `probe_outcome_rule.py` (output `probe_outcome_rule.out`). In memory. It loads `model/review_evidence.py`, a copy of the tree's `review_evidence.py` with ONLY the requirement 6.1 relaxation, and drives the real `build_compact_review_event` and `validate_review_evidence_records`. Each scenario runs three ways: V0 is the relaxation alone, V1 adds requirement 5.1 as written (lane drop, `completed`, newly terminal), V2 adds 5.1 without the literal `completed` test (lane drop or newly terminal only).
- The two round-1 handler probes, rerun unchanged on the current tree (`rerun_handler_relabel.out`, `rerun_handler_checkpoint.out`). Both outputs are identical to round 1.
- `probe_handler_current_tree_inferred.py`: the real `wf_review_event_response` handler on the current tree, throwaway root, with `evidence.execution_status: inferred` and three honest `false` checks.
- `compare_ledgers.py`: read-only, 396 ledgers under `docs/waves/`, tree validator against the model validator, default (non-closure) mode.
- `wf_review_wave(phase='prepare')` and `wf_review_event(event='list')`.

Read only: the spec (Requirements, AC-5 to AC-7, Decision Log, Risks, Progress Log), the round-1 notes, the code-reviewer round-2 notes, and in `review_evidence.py` the finding branch of `build_compact_review_event`, the lane-reassessment and downgrade rules in `_validate_relationships`, `_approval_rows`, `_finding_affects_signoff` and the approval-blocking loop. I did not run the framework suite. I did not reread seed 209 beyond the integrity field table, or seed 213.

The requirement 5.1 gate does not exist in the tree. V1 and V2 are my model of the requirement text, about 15 lines in the probe. What a real implementation does is for delivery review.

## Results

| Route | V0 relaxation only | V1 rule as written | V2 lane drop or newly terminal |
| --- | --- | --- | --- |
| S1 relabel after a delivery run exists, `inferred` clear | Refused by the unchanged validator: `lane reassessment evidence must be executed` | Refused | Refused |
| S1 with `unverified` and `not_applicable` | Refused, same rule | Refused | Refused |
| S2 relabel with no delivery record | Refused, same rule | Refused | Refused |
| S6 two blocking lanes, one `inferred` reverification drops its own | Refused, same rule | Refused | Refused |
| S9c reclassify to invalid and drop the lane | Refused, same rule | Refused | Refused |
| S9b reclassify a blocking lane-less finding to invalid | Refused by the unchanged downgrade rule | Refused | Refused |
| S4 lane-less delivery finding, `inferred` terminal reverification | APPENDED, head completed and terminal | Refused, head stays pending | Refused |
| S5 caller-authored `convergence_checkpoint`, cycle 2, `inferred` | APPENDED, head completed, checkpoint run recorded | Refused, head pending, no checkpoint run | Refused |
| S9 non-blocking lane-less `do_now` finding reclassified to invalid by an `inferred` reverification | APPENDED, head `not_issue`, `not_required`, terminal | Refused | Refused |
| S10 `security_unsettled` head settled as `dont_do_later` by an `inferred` reverification | APPENDED, head terminal | Refused | Refused |
| S4 and S5 with `unverified` and `not_applicable` | Refused by the existing blocking-synthesis rule | Refused | Refused |
| S11 caller-authored checkpoint on a new finding id (no head to supersede) | Refused by the validator: no preceding `repair_start` | Refused | Refused |
| S7 `inferred` reverification that keeps its lane | Appended | REFUSED (sets `completed`) | Appended |
| S8 control: `executed` reverification clears the lane | Appended, terminal | Appended | Appended |
| S12 control: blocking finding stated `unverified` | Refused, as today | Refused | Refused |

Current tree, real handler: an `inferred` lane-clearing reverification on a readiness-labelled finding on an `implementing` wave is refused with `lane reassessment evidence must be executed` and `dedup evidence must be executed`; an `inferred` caller-authored checkpoint is refused with `dedup evidence must be executed`. Requirement 6.1 removes only the second message for a run's own finding evidence.

Ledgers: 396 read, 0 unreadable, 0 with a different error list between the tree and model validators.

## R1-242k4-relabel-open-wave: repair holds

The round-1 route needed a rule that was easier for one phase, so that the caller could select it through `run_kind`. The narrowed spec has no such rule (requirement 5.5, and the superseded Decision Log row). The validator relaxations for readiness reassessment evidence that the planning prototype carried are gone: requirement 6 keeps one relaxation, and requirement 5.4 keeps lane reassessment evidence `executed` in both phases. So the relabel is refused twice: by the unchanged validator even with no builder gate (V0), and by the outcome rule. AC-5.2 pins the three relabel cases and AC-6.3 pins the validator rule in both phases. The false sentence "the caller cannot set it" is gone from requirement 5. Declining to refuse `run_kind='readiness'` on an open wave is sound once the label selects nothing.

## R1-242k4-checkpoint-completion: repair holds

Requirement 5.1 is now stated by outcome and names the caller-authored checkpoint; requirement 2.5 routes it through the same finding branch; AC-5.4 pins it and AC-5.5 extends it to the other two statuses. In the model the checkpoint is refused, the head stays `pending`, and no checkpoint run is recorded, so "completes no checkpoint" holds. A checkpoint on a new finding id is stopped by the existing validator.

## Dependency on R1-242k4-outcome-rule-completed-trigger (code-reviewer, open)

I found the same contradiction independently (S7): the builder stores `completed` on every reverification, so the rule as written refuses the lane-keeping `inferred` reverification that requirement 5.2 and AC-5.7 say is recorded. It fails closed, so it is not a route. Its repair is what matters to this lane. V2 shows that scoping the `completed` trigger to a head with no blocking lanes, which is the same as "newly terminal", still refuses every route above. Dropping the trigger without keeping the newly-terminal condition would reopen S4, S5, S9 and S10. A `completed` head that keeps lanes gates nothing: closure and approval currency both read the lanes, and S7 then needs an `executed` clear (the second `inferred` attempt in S7 is refused).

That spec edit rotates the receipt, so this approval will lapse and I expect to be asked again. The check for the next round is short: the reworded rule keeps "drops a lane" and "makes a non-terminal head terminal".

## Advisory, not blocking: AC-5 pins two of the four builder-only routes

V0 shows four routes that only the builder gate stops: S4, S5, S9 and S10. AC-5.3 and AC-5.4 pin S4 and S5, and both are phrased as "`repair_execution_state` stays `pending`". S9 and S10 reach a terminal head through `not_required`, never `completed`. An implementation that tests lanes and `completed` only would pass every AC and leave both open. S10 is the security one: an `inferred` reverification would settle an unsettled security candidate and release `operator-signoff`. The third condition of requirement 5.1 covers both by text, so I do not block. Suggested Progress Log note for the implementer: add two tests under AC-5.3, an `inferred` reverification that reclassifies a lane-less finding to `invalid`, and one that settles a `security_unsettled` head, each refused with the head unchanged. I will look for them at delivery review.

## New downgrade routes from the narrowing

None found.

- A caller who states `executed` falsely, or omits the field after a read, clears a lane exactly as today. The rerun handler probes show the same results as round 1. The narrowing neither adds nor removes this; the Risks table says no mechanism detects it.
- Stating `inferred` on a finding's own record buys nothing: it still blocks (`inferred` supports a blocking synthesis today), and it cannot clear or complete.
- `repair_start` cannot terminalize or drop a lane (round-1 controls R3 and R3b, rerun, unchanged).
- Shrinking `approval_recheck_lanes` or the full-council triggers on an `inferred` lane-keeping event (read, not run): a non-terminal blocking head withholds its affected approvals whatever their position, and the terminal head that later decides currency comes from an `executed` event with its own lane lists. Nothing durable is gained.
- Approvals: requirement 4 refuses a contrary stated status and `_approval_rows` still reads only `executed` (read).
- Old ledgers: the validator only accepts more (396 ledgers, 0 differences). The replay-before-refusal order rests on the code-reviewer's reading of `transact()`; I did not rerun it. AC-7.4 and AC-7.5 pin it.
- Hand-edited ledger for a lane-less finding: accepted in Risks, unchanged in kind from today.
