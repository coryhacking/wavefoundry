# Reality-checker readiness notes: wave 242k5, change 242k4

- seat: reality-checker (fixed), mode `assumption-audit`, context 242k5-reality-checker-readiness-r1, fresh_context=true, independent=true
- recorded: nothing in any ledger. No repository edits.
- what I ran (executed): `planning/scan_status_census.py` over every ledger; `planning/scan_ledgers.py` over the 23z46 and 23zbf ledgers (output `scratch/reality-checker/scan_out.txt`); `scratch/reality-checker/probe_receipt.py` against a throwaway copy of `.wavefoundry/framework/`, `docs/workflow-config.json` and the 241lp wave folder, before and after mutating the copy (output of the mutated run `scratch/reality-checker/probe_after_mutation.txt`; the copy was deleted afterwards); a count of files holding the `wave:executable-review-evidence` region; `git diff` of the shared files.
- what I only read: the spec, briefing, primer, `review_policy.py` (`policy_input_snapshot`, `validate_policy_receipt`, `_NORMALIZER_SIGNATURE`), `lifecycle_gate_support._prepare_policy_state`, `review_policy_upgrade.plan_review_policy_upgrade`, `review_policy_reconcile.plan_reconciliation`, and the `execution_status` rules in `review_evidence.py`. I did not run the suite, the handler or the prototype.

## Verdict

No blocking assumption. Every load-bearing number I could re-derive matched. One claim's citation is wrong and one premise is only partly supported by the tree; both are wording-level. The plan has no named re-census trigger for 241lp (question 6), which I recommend fixing with a Progress Log row, not a re-ready round.

## Assumptions

| # | Assumption | Status | Evidence |
| --- | --- | --- | --- |
| A1 | 3,884 `finding` rows stored `executed` across 396 ledgers; 2 `inferred`, both in 1skt1 | **verified (executed)** | Census rerun: `ledger files: 396`, `('finding','executed') 3884`, `('finding','inferred') 2`, both ids in `1skt1 executable-review-evidence`. Both are delivery-phase, `public_path_reached: false`, and their runs use separate `ev-dedup-*` evidence, so they are the AC-7.2 "hand-authored inferred finding with separate executed dedup" shape. Totals also show 5,801 approvals, 1,280 lane reassessments and 15 dedup rows, all `executed`. The census includes the open 241lp ledger. |
| A2 | "No approval in any open wave lapses" | **verified for the current tree (executed for receipt currency; inferred for the future code)** | Non-closed waves: only 241lp (`implementing`) and 242k5 (`planned`). On a copy, `_prepare_policy_state` for 241lp gives digest `9e235ca8...` equal to the stored receipt `review-policy-025ea1c030390f542873`, `append_required False`, no receipt diagnostics, before and after mutating the copy's seed 209, seed 160, `REVIEW_PROTOCOL_CARRIER_BLOCK` and `review_evidence.py`. Approval currency also depends on `validate_review_evidence_records` (called inside `_prepare_policy_state`) and on `current_synthesis_heads` (feeds `delivery_council_required`). The spec relaxes the first and does not touch the second, and no stored record changes, so the outcome holds by reading. The real implementation does not exist yet, so the AC-7.1 delivery comparison remains the executed proof. |
| A3 | Receipt non-rotation (spec marks `inferred`) | **verified (executed probe, bounded)** | Same probe. `policy_input_snapshot` hashes schema and evaluator versions, `wave_review`, project lanes, `review_policies`, change bodies, requested lanes, phase gates and referenced sensors; `review_context` hashes only `gardener_metadata.py` and `change_doc_checklist.py`. None is in scope. Citation fix: the spec says "read from `validate_policy_receipt`", which checks the receipt's shape; the hash is computed in `policy_input_snapshot`, called from `lifecycle_gate_support._prepare_policy_state`. Primer Q4 sub-points: (a) the carrier re-render cannot set the re-Prepare marker. `plan_review_policy_upgrade` marks waves only when the migrated config or `plan_reconciliation` changes, and the reconciler only rewrites `UPGRADE_POLICY_BLOCK` and legacy sections. It validates renderer-owned regions and never rewrites them. The seed 160 bullet sits in the Guardrails list (beside line 992), outside `UPGRADE_POLICY_BLOCK` (review_policy.py:261). (b) One trap: the reconciler fails preflight if a carrier contains a `RETIRED_LIFECYCLE_TOKENS` phrase (for example "reviewer loop"), so the new sentence must avoid them. (c) The framework *test* receipt (`test-cache.json`) does rotate on any framework edit; the spec covers this by sequencing after 241lp. |
| A4 | "Validator changes only accept more" | **verified by reading (inferred)** | The two rules are pure refusals: the shape rule `lane reassessment evidence must be executed` (review_evidence.py ~5549) and the `dedup evidence must be executed` branch of `_validate_relationships` (~6011), plus the `execution_status == "executed"` conjunct in the reassessment check (~6120). Relaxing a refusal condition removes errors and adds none, so the change is monotone. No other rule I read keys on these two outcomes. The other `executed` keys (required approval in delivery ~5500, closure ~5988, census must be `unverified` ~5611, blocking synthesis on unverified/not_applicable ~6038, frozen boundary ~6217) are unchanged by the plan. Caveat: "today" is a moving baseline. 241lp adds a new shape rule (small-change approval fields, ~5437 in its diff). That rule is approval-only and does not interact, but AC-7.1 must run against the post-241lp tree. |
| A5 | 15 readiness lane reassessment rows among the matched rows in 23z46 and 23zbf | **verified (executed)** | Lexical scan rerun: 23z46 33/112 matched, 23zbf 28/72 matched (both equal to the spec). Readiness `lane_reassessment` matches: 23z46 7 (architecture 2, code 1, docs-contract 1, qa 2, release 1), 23zbf 8 (qa 3, reality-checker 1, release 3, security 1), total 15. All ledger rows in both waves are `executed`. The three 23zbf qa-reviewer readiness findings say "Read-only; no probe executed" with `ppr=True kbd=True`, as stated. The one delivery reassessment match (23z46 release-reviewer) matched on "no Windows filesystem execution", a partial-execution note, not a read. |
| A6 | Rationale premise: "two lanes changed `public_path_reached` from false to true to get a record accepted" | **partly verified (read)** | The 23z46 `wave.md` line 135 Progress Log "Evidence correction" records that the architecture finding `R1-23zia-preflight-on-recovery` and its reverification, plus the release reverification of `R1-23zia-no-override-premise`, carried true integrity values that "overstate what those reviewers executed". It also records the `dedup evidence must be executed` refusal on an `inferred` readiness preview. It does not record a false-to-true change. The 23z46 work folder is gone. Consequence for the primer's efficacy question: the overstated records are findings and reverifications, not approvals, so this change does reach them. |
| A7 | 21 carrier files | **verified (executed)** | 21 files hold the region. The spec's description omits a few kinds: `docs/contributing/review-and-evals.md`, `create-wave`, `council-review` and `archetype-council` prompts, and both Guru wrappers. The count is right; the label is loose. |
| A8 | Cited anchors exist | **verified (read)** | `review_action_input_schema` :748, `_finding_origin_phases` :2410, `build_compact_review_event` :4357, `terminal_reverification` :4842, `_build_operator_close` :4929, `_validate_relationships` :5940, `validate_review_evidence_records` :6282, `_review_evidence_list_response` in server_impl.py :11737. The request normalizer defaults `execution_status` to `executed` (:1462), which supports requirement 2.4. |

## Primer question 6: what triggers the re-census after 241lp lands?

Nothing named. The plan has three partial hooks:

1. The first task, "confirm with the coordinator that 241lp is committed or settled". This is a state check with no recorded result.
2. The seed-pin census repeat, which covers pins only.
3. The handler-digest pin refresh.

None of them re-checks the line-level claims I verified above against the post-241lp tree. 241lp already changes `build_compact_review_event` (approval branch), `_validate_evidence_shape` and server_impl.py, and adds `test_small_change_lifecycle.py`, which authors a finding.

Recommendation: make the trigger 241lp reaching `closed` in `wf_list_waves`. Record one Progress Log row before the first edit, with the re-run results:

1. `git diff <241lp close commit>` over the seven shared files, checking the anchors in A8.
2. A re-run of `scan_status_census.py` and this seat's `probe_receipt.py` against any then-open wave.
3. The carrier-file count.
4. A census of finding-authoring fixtures, including 241lp's new test.
5. The seed-pin census.

This needs no re-ready round. Only the Progress Log changes.

## Risks I accept, not block

- Primer challenge 1 (the `run_kind='readiness'` relabel) is outside this seat's remit. I did not probe the handler, and I defer it to code and security.
- A2 is proven for the current tree only. It rests on the implementation not touching `current_synthesis_heads` or approval currency. AC-7.1 is the executed check, so it must run after 241lp is merged into the baseline.
