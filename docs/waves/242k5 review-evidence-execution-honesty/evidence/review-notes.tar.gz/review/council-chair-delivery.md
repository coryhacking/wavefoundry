# Council chair delivery verdict: wave 242k5, change 242k4

- context: 242k5-council-chair-delivery, fresh_context=true, independent=true.
- seats: code-reviewer, qa-reviewer, docs-contract-reviewer, security-reviewer (their delivery notes in this folder).
- state check (executed): `wf_review_wave(phase='implementation')` shows all four required lanes approved and current, no blocking finding, lint passed. Only council-delivery and operator-signoff remain.
- chair checks (executed): the 47 focused tests pass; an in-process mutant replacing `_non_executed_gate_outcomes` with a no-op fails 20 of them.

## Verdict

PASS. intent_fit: `partially`, unchanged from readiness. The change establishes its Product Intent: a read-only finding is recorded with its stated status and honest checks (AC-1, AC-3), and non-executed evidence clears, completes and satisfies nothing (AC-5, AC-6). The wave Objective says the ledger never says a check was executed when it was not. By operator decision, approvals and lane clears stay executed-only, and an omitted status still defaults to `executed`, so the Objective is met only in part.

## Strongest challenge

Security finding `D-242k4-recheck-and-depth-release` (`dont_do_later`, non-blocking): an `inferred` `repair_start`, or an `inferred` reverification that keeps its lane, can narrow `approval_recheck_lanes` or drop a `review_boundaries_changed` trigger. The code comment "it may not change what a gate reads" overstates the rule. It adds no authority: the status-omitted form is accepted the same way.

## Strongest alternative

A fourth outcome condition covering recheck narrowing and depth release. Deferred: spec change after readiness, more mechanism for no new authority. Narrow the comment at the next edit.

## Advisories

1. Duplicated terminal predicate; `EVIDENCE_STATUSES` vs `EXECUTION_STATUS_MEANINGS` keys; explicit `null` status digest differs from omitted (code).
2. The handler-level AC-5.4 test does not isolate the scoped `completed` condition; only the builder test does (qa, security).
3. AC-9.5 checks meanings anywhere in seed 209, not in the table row (qa).
4. Docstring lacks the old-server note; long seed 209 table cell (docs-contract).
5. Observe uptake of `inferred` over the next two prepare councils (Product Intent).

## Limitations

Synthesis plus the focused rerun and one mutant. No full suite, second profile or non-macOS run. No repository edits.
