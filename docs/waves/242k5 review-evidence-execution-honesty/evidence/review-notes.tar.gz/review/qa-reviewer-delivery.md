# qa-reviewer delivery notes, wave 242k5 / change 242k4

Verdict: approve. No blocking defect found.

## What ran

- Focused tests, from `.wavefoundry/framework/scripts/tests`: `test_review_evidence.ExecutionStatusHonestyTests` and `test_server_tools_lifecycle.ReviewEventExecutionStatusTests` (47 OK), the whole `test_review_evidence` module (OK), `test_render_agent_surfaces.ReviewProtocolCarrierRegistryTests`, `test_server_tools_retrieval.TestMcpWrapperParameterExposure` and `test_lifecycle_golden` (46 OK).
- 21 mutations on a scratch copy of `.wavefoundry/framework`. Every mutation made at least one named test fail:
  1. M1 to M3: each of the three outcome conditions removed (lane drop, scoped `completed`, terminal).
  2. M4: `completed` condition unscoped (fails AC-5.7, keep-lanes reverification).
  3. M5: a validator-only implementation with no outcome rule (35 failures, including AC-5.3, 5.4, 5.9 and 5.10).
  4. M6: the rule keyed on `run_kind == reverification` (fails the caller-authored checkpoint tests).
  5. M7, M8: the approval and operator-close contrary-status refusals removed (AC-4).
  6. M9, M10, M15: an unknown status silently defaulted, the remedy text removed, a stated status replaced by `executed` (AC-2, AC-3).
  7. M11, M12: the validator relaxation made too broad (AC-6.4) and reverted (AC-1).
  8. M13: the compact row without `execution_status` (AC-8).
  9. M14: the digest normalization without the `executed` default (AC-2.3).
  10. M16 to M18: a meaning drifted in the carrier block, in seed 209 and in `EXECUTION_STATUS_MEANINGS` (AC-9.5).
  11. M19: one status dropped from the docstring (AC-9.2).
  12. M20: replay disabled (AC-7.4 and AC-7.5 tests fail).
  13. M21: the approval refusal placed before the replay lookup in `transact()` (`test_stored_approval_replays_before_the_new_refusal` fails).
- AC-7.1: reran `impl/ledger_snapshot.py` read-only with the changed module and with `impl/baseline/review_evidence.py`, which equals `review_evidence.py` at HEAD `d8a4dcc6`. 396 ledgers, no validation errors or exceptions, 0 ledgers differ in errors or currency, 4,998 approval rows. I count 2,434 finding facts because I sum both phases; the implementer's 1,217 is one phase. The bytes are the same across both passes. Against the implementer's snapshot, only the 242k5 `events.jsonl` changed, from the delivery records added since then.
- AC-2.1: reran `impl/omitted_status_records.py` against HEAD and against the changed module. The output is byte-identical. It covers all four run kinds and four approvals.
- Golden fixture: `lifecycle-gate-golden.json` equals HEAD once the three `optional_fields` entries are removed. HEAD has none, and nothing else differs.
- AC-9.4: the handler-digest diff touches only the `wf_review_event` hash and adds one sentence to the description.
- AC-9.5 render: 21 real carriers hold the new sentence. The other 11 files that mention the region are wave history and `platform-mapping.md`.
- AC-9.6: the seed 160 bullet and the prompt line 749 are identical. Line 749 comes after the `review-policy-upgrade` end marker at line 745. The renderer diff leaves `UPGRADE_POLICY_BLOCK` untouched.
- AC-9.7: the phrase "executed `finding` record" no longer appears in seed 178 or in the prompt copy.

## Advisories (not defects)

- The handler-level checkpoint test, AC-5.4, does not isolate the scoped `completed` condition, because the terminal condition also refuses that event. The builder test `test_completed_condition_alone_refuses_a_checkpoint_on_a_terminal_head` isolates it (M2 is killed only there).
- The AC-9.5 comparison checks that each meaning appears somewhere in seed 209, not specifically in the field table row. I read the row (line 140), and it holds all four meanings.

## Limitations

I did not run `run_tests.py` or the full suite; I read the implementer's logs. I read code with grep and sed, not with the `code_*` tools.
