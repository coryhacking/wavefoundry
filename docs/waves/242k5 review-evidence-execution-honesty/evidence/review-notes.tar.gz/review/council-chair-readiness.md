# Council chair readiness verdict: wave 242k5, change 242k4

- context: 242k5-council-chair-r3, fresh_context=true, independent=true. Receipt `review-policy-e764ccac54fd187c865e`.
- primer depth: standard. Rotating seat: docs-contract-reviewer.
- seats that ran: red-team primer (council-adversarial-primer), reality-checker, code-reviewer, qa-reviewer, docs-contract-reviewer, security-reviewer. No architecture-reviewer note exists.
- state check (executed): `wf_review_wave(phase='prepare')` shows all four required lanes approved and current, lint passed, eight readiness findings, every one terminal with no unresolved lanes.

## Verdict

Approve readiness. intent_fit: `partially`. The change establishes its own Product Intent: a read-only finding is recorded honestly and the stored status is the stated one (AC-1, AC-3), with the gate boundary held by the outcome rule (AC-5, AC-6). The wave Objective says the ledger never says a check was executed when it was not. By operator decision, approvals stay `executed` and a lane clear still needs `executed` evidence, so the pressure to overstate remains at the lane clear. Product Intent states this openly. The worst verdict is therefore `partially`.

## Strongest challenge

The red-team primer: the honest status was bounded only by caller-chosen labels. A delivery finding relabelled `run_kind='readiness'` could be cleared by an `inferred` re-read (executed probe against the builder and validator). The operator's narrowing decision removed the lenient readiness clear. Requirement 5.1 now refuses by outcome (lane drop, `completed` on a lane-less head, newly terminal), with no phase or run kind rule. Round-3 probes by code, qa and security confirm the scoped rule refuses every clearing route and opens none.

## Strongest alternative

The primer's: keep a lenient readiness clear but bind it to ledger state, derive the `repair_start` status, and define `executed` for prose checks. Rejected in the Decision Log: more mechanism, and the ledger alone cannot see that a wave is open. The `executed` boundary was adopted (Decision Log, AC-9.1).

## Non-blocking advisories for implementation

1. AC-9.5 needs a defined comparison mechanism: a shared constant of per-status meanings, or carrier meaning sentences that appear verbatim in seed 209's row. Otherwise the test degrades to a status-word check (docs-contract, qa).
2. AC-5.10's `invalid` case must be tested on a non-blocking finding; on a blocking finding an existing validator rule refuses it anyway, so the known-bad is not separated (qa).
3. No AC pins the scoped `completed` condition alone. Add a test under AC-5.4: an `inferred` caller-authored checkpoint on an already-terminal lane-less head with shrunk `approval_recheck_lanes` is refused and the stale approval stays stale. Fixture: `scratch/security-reviewer-r3/probe_r3_t7.py` (security).
4. Requirement 5.2's sentence "sets `completed` on every reverification of an action-required finding" is slightly broad: a reverification from a `security_unsettled` head stays `pending`. Safe-side error (security).
5. Reality-checker: record a Progress Log re-census row after 241lp before the first edit; keep the new carrier sentence free of `RETIRED_LIFECYCLE_TOKENS`.

## Limitations

Synthesis only. I ran no probe or test; I relied on the seats' executed probes and read their notes, the spec's Product Intent, Requirement 5, AC-5, AC-9 and Decision Log. No repository edits.
