# security-reviewer focused readiness verification, round 3: wave 242k5, change 242k4

- context: 242k5-security-reviewer-focused-r3, fresh_context=true, independent=true. I wrote neither the finding `R1-242k4-outcome-rule-completed-trigger` nor its repair.
- receipt: review-policy-e764ccac54fd187c865e
- verdict: the repair HOLDS for this lane. Scoping the `completed` trigger to a head with no blocking lanes left opens no downgrade route. I own no open finding (both of mine are terminal from round 2), so I recorded only the readiness approval.
- two advisories for the implementer, neither blocking: one AC coverage gap on the scoped `completed` condition, one inexact sentence in requirement 5.2.

## What I ran and what I only read

Executed, all with `python3 -B`, all under `.wavefoundry/work/242k5/review/scratch/security-reviewer-r3/`. No real ledger was written and no repository file was edited.

- `probe_r3.py` (output `probe_r3.out`). In memory. `model/review_evidence.py` is a copy of the current tree's `review_evidence.py` (after 241lp, commit d8a4dcc6) with ONLY the requirement 6.1 relaxation; `diff` shows that one line. The probe drives the real `build_compact_review_event`, `validate_review_evidence_records`, `current_synthesis_heads`, `_repair_cycle_progress`, `security_candidate_state` and `review_authority_projection`. Each scenario runs under six gate models:
  - V0: relaxation only, no builder gate.
  - V1: the round-2 text (lane drop, any `completed`, newly terminal).
  - V3: the repaired text (lane drop, `completed` with no lanes left, newly terminal).
  - V4: lanes and `completed` with no lanes left only, no terminal test.
  - V5: V3 with the completion and terminal conditions applied only to delivery-origin findings.
  - V6: no `completed` condition, and the terminal test keyed on `run_kind == 'reverification'`.
- `probe_r3_t4.py`, `probe_r3_t6.py`, `probe_r3_t7.py` (outputs beside them): non-blocking lane-less findings with `unverified` and `not_applicable`, and caller-authored checkpoints on heads that are ALREADY terminal.
- The implementer's `planning/probe_reclassify.py`, rerun unchanged on the current tree. Its output matches what AC-5.10 states.
- `wf_review_wave(phase='prepare')` and `wf_review_event(event='list')`.

Read only: the spec (Requirements 5 and 6, AC-5, AC-6.1, AC-9, Progress Log, Decision Log, Risks), the round-2 notes, the focused diff between the two receipts, and in the current `review_evidence.py` the `repair_execution_state` expression and `terminal_reverification` in `build_compact_review_event`, the lane-clear and downgrade rule in `_validate_relationships`, `_repair_cycle_progress`, `_finding_affects_signoff` and the `terminal` derivation in `review_authority_projection`. I did not run the handler `wf_review_event_response` this round, I did not rerun the 396-ledger comparison, and I did not run the framework suite.

The requirement 5.1 gate does not exist in the tree. V1 to V6 are my models of the requirement text and of known-bad implementations. What a real implementation does is for delivery review.

## The three points I was asked to confirm

1. The lane-drop and newly-terminal conditions are kept. Requirement 5.1 still lists all three conditions, and the Decision Log row says the other two are unchanged. The focused diff shows the only change to the rule is the phrase "on a head that would have no blocking lanes left".
2. A lane-less checkpoint is still refused. Scenario B, both origins: V3 refuses the `inferred` caller-authored `convergence_checkpoint` on a lane-less pending finding ("completed, no lanes left, newly terminal"), the head stays `pending`, no checkpoint run is recorded and cycle 2 stays incomplete. V0 and V6 append it.
3. AC-5.10's `security_unsettled` behavior is safe.
   - Settle as not actionable on `inferred` evidence: REFUSED under V3 (newly terminal through `not_required`). The head stays `security_unsettled` and `pending`, `security_candidate_state` still lists it, and `operator-signoff` stays affected. V0 and V4 append it and release the candidate, so AC-5.10 detects both.
   - Settle as actionable: recorded. The builder keeps `pending` for a reverification whose prior head was `security_unsettled`, so the head is `do_now`, `pending`, not terminal, closure still fails, and `operator-signoff` is still affected. This is a move toward more work, not less.
   - Leave unsettled: recorded, nothing changes.
   - Two-step attempts after an `inferred` settle-as-actionable (H4 complete it, H5 reclassify to invalid): both refused under V3. A next-cycle `repair_start` is refused by the validator because cycle 1 is not complete (H6). Settling through `repair_start` is refused by the validator (H8). Settling through a caller-authored checkpoint is refused by the validator because a non-actionable row does not complete the cycle (H7).

## Does the scoped trigger open a route?

No. Results under V3, both origin phases unless noted:

| Route | Result under V3 |
| --- | --- |
| Lane-less finding, `inferred` terminal reverification (AC-5.3, AC-5.9) | Refused, head stays `pending` |
| Same with `unverified`, `not_applicable`, blocking finding | Refused by the existing blocking-synthesis rule |
| Same with `unverified`, `not_applicable`, non-blocking finding (AC-5.5) | Refused by the gate; V0 appends |
| Lane-less caller-authored checkpoint (AC-5.4) | Refused |
| `inferred` lane clear (AC-5.1, AC-5.2) | Refused by the unchanged validator rule in every variant |
| `inferred` reverification that keeps its lane (AC-5.7) | APPENDED: head is `completed` with the lane, not terminal, cycle not complete, closure still fails |
| After that `completed` + lane head: second `inferred` event drops the lane | Refused (lane reassessment must be executed) |
| After that head: `inferred` `repair_start` in cycle 2 | Refused by the validator (cycle 1 not complete) |
| After that head: `repair_start` that drops the lane | Refused by the builder (same fresh independent actor) |
| Reclassify to invalid, lane dropped | Refused by the validator |
| Non-blocking lane-less, reclassify to invalid | Refused by the gate (newly terminal); V0 and V4 append |
| Blocking lane-less, reclassify to invalid | Refused by the existing downgrade rule |
| `executed` reverification clears (AC-5.8) | Appended |

A `completed` head that keeps a lane gates nothing I could find. `_repair_cycle_progress` counts a finding terminal only with no required lanes, so no cycle completes and no checkpoint is minted. Closure reads the lanes. The projection's `terminal` needs no unresolved lanes. Approval currency for a non-terminal blocking head withholds the affected approvals.

## The scoped `completed` condition is load-bearing on its own

Round 2 said that scoping `completed` to a head with no lanes is "the same as newly terminal". That is not exact, and the difference matters. T7 (`probe_r3_t7.out`): an approval predates the repair of blocking finding F-C, whose `approval_recheck_lanes` names the approver. After the executed terminal reverification the approval reads "repaired findings require fresh approval: F-C". Once two repair cycles are complete, a caller-authored `convergence_checkpoint` on that ALREADY-terminal head, with the same judgment and `approval_recheck_lanes: []`, is appended when stated `executed`, and the approval reads current again without a re-record. Stated `inferred`, V3 refuses it by the second condition alone ("completed, no lanes left"). The third condition does not fire, because the head was already terminal, and no lane is dropped.

So the repair was right to scope the condition and not drop it. The Decision Log's alternative "Drop the `completed` condition" names the lane-less checkpoint; this route is a second reason.

The `executed` form of this route exists today and is outside this change. It is the same class as "a reviewer states `executed` for a read", which Risks accepts.

## Known-bad detection for AC-5.3, AC-5.4, AC-5.6 to AC-5.10

| AC | Passes under V3 | Fails under |
| --- | --- | --- |
| AC-5.3 | Yes | V0 (appended, head `completed`) |
| AC-5.4 | Yes | V0 and V6 |
| AC-5.6 | Yes | Not a builder-only variant: the unchanged validator refuses it in every variant. It fails under an implementation that relaxes the lane reassessment rule, which the round-1 planning prototype did. I did not rerun that prototype this round. |
| AC-5.7 | Yes | V1 (the round-2 text) |
| AC-5.8 | Yes | Any implementation that refuses all reverifications; a control |
| AC-5.9 | Yes | V0 and V5 |
| AC-5.10 | Yes | V0 and V4, on both refused cases |

## Advisory 1, not blocking: no AC pins the second condition by itself

Every AC-5 case that meets the second condition also meets the third. An implementation that tests "lane drop or newly terminal" passes AC-5.1 to AC-5.10 and leaves the T7 route open for `inferred` evidence. Requirement 5.1 covers it by text, so I do not block, and a spec edit would rotate the receipt again. Suggested Progress Log note for the implementer: add one test under AC-5.4, an `inferred` caller-authored checkpoint on an already-terminal `completed` lane-less head, with `approval_recheck_lanes` shrunk, is refused and the stale approval stays stale. I will look for it at delivery review. `probe_r3_t7.py` is a ready fixture.

## Advisory 2, not blocking: one sentence in requirement 5.2 is slightly too broad

"The builder sets `repair_execution_state` to `completed` on every reverification of an action-required finding." One exception: a reverification whose prior head is `security_unsettled` stays `pending` (the 22ubf branch). AC-5.10 states that case correctly, and the error is on the safe side, so nothing rests on it.

## Unchanged from round 2

A caller who states `executed` falsely, or omits the field after a read, clears a lane exactly as today. A hand-edited ledger can bypass a builder-only rule for a lane-less finding. Both are recorded as accepted in Risks.
