# code-reviewer readiness notes: wave 242k5, change 242k4

- context: 242k5-code-reviewer-readiness-r1, fresh_context=true, independent=true
- verdict: approval WITHHELD. The blocking defects in my remit are already typed by other lanes (see Recording); I add no duplicate finding.
- what I ran (executed): `code_keyword("execution_status", glob="**/*.py", limit=0)` (34 hits, not truncated); a shell grep of non-test scripts, dashboard JS and the docs surfaces for `execution_status`, `"executed"` and `EVIDENCE_STATUSES`; a grep census of files holding the `wave:executable-review-evidence begin` marker; and one handler probe, `.wavefoundry/work/242k5/review/scratch/code-reviewer/probe_relabel_handler.py`, run with `python3 -B` in a throwaway root that it deletes.
- what I only read (inferred): the builder finding, approval and operator-close branches; `normalize_review_event_request`; the `wf_review_event_response` replay order; `_validate_evidence_shape`; `_validate_relationships`; `review_action_input_schema`; `test_lifecycle_golden.py`; `policy_input_snapshot`; `review_policy_upgrade.plan_review_policy_upgrade`; `review_policy_reconcile.plan_reconciliation`; and the 241lp diff of the shared files.
- I made no repository edits and wrote nothing to a real ledger.

## 1. Census of `execution_status` readers

The census is closed. Every non-test reader is in `review_evidence.py`. `server_impl.py`, `lifecycle_gates.py`, `lifecycle_gate_support.py`, `dashboard_lib.py` and `dashboard.js` read none (`run_tests.py` and `qualification_report.py` match an unrelated `availability` value). The sites:

| Line (tree of 2026-11-22) | Symbol | Role | Plan |
| --- | --- | --- | --- |
| 524 | `_EVIDENCE_REQUIRED` | required field | unchanged |
| 1462 | `normalize_review_event_request` | digest default `executed` for findings | kept (req 2.4) |
| 1961 | `_approval_rows` | approvals must be executed | kept (req 5.3) |
| 4531 | approval branch | writes literal `executed` | refuse contrary statement (req 4.1) |
| 4605, 4608, 4755 | finding branch | reads caller value, default `executed` | require it (req 2) |
| 5046 | `_build_operator_close` | writes literal `executed` | refuse contrary statement (req 4.2) |
| 5422 | `_validate_evidence_shape` | enum check | unchanged |
| 5500 | shape | required approval must be executed in delivery | unchanged |
| 5534 | shape | executed implies all checks true | unchanged |
| 5549 | shape | lane reassessment must be executed | relax for readiness (req 6.2) |
| 5554, 5558, 5561 | shape | probe class and safe-boundary rules | unchanged (req 5.4) |
| 5611 | shape | open census must be `unverified` | unchanged |
| 5988 | `_validate_relationships` | closure needs an executed delivery approval | unchanged |
| 6011 | relationships | dedup evidence must be executed | relax sole-finding case (req 6.1) |
| 6038 | relationships | blocking synthesis cannot rely on unverified or not_applicable | unchanged |
| 6120 | relationships | reassessment must be executed | relax for readiness (req 6.2) |
| 6217, 6220 | relationships | frozen-boundary safe evidence | unchanged |

Line 5611 interacts with the change: a finding that carries an open census must now be stated `unverified`, and then it cannot block or clear. That follows from the existing rule. It is worth one sentence in seed 209.

## 2. Refusal order

- **Replay is safe if the refusals live in the builder.** `wf_review_event_response` computes `request_digest` before `transact()`. Inside `transact()`, `_identified_review_event_bundle` finds an existing bundle and returns the replay *before* `build_identified_review_event` runs. So a refusal in `build_compact_review_event` (missing status, bad value, approval contrary status, the reverification gate) never reaches a replay. An approval stored before the change from a request that stated `inferred` also replays, because its digest is unchanged.
- **No AC fails on a wrong placement.** If the missing-field check is put in the handler before `transact()`, every pre-change retry is refused, and AC-2.3 and AC-2.4 still pass. This is already typed as `R1-242k4-old-ledger-replay` (qa-reviewer), and I agree with it.
- **Operator close.** `_build_operator_close` is dispatched before the finding-branch validation, so a required-field check placed after the dispatch leaves the operator close as it is. Requirement 2 lists `reverification` among the run kinds that must state a status, though, and an operator close is a reverification. AC-4 tests only a *contrary* stated value on the close. Add an AC-4.2 sub-point: an operator close with the field omitted records as it does today. This is a wording item, so it goes in these notes and not in a finding.
- **The validator only accepts more.** Requirement 6's two relaxations (lines 6011 and 5549/6120) remove conditions and add none. A readiness-origin finding's reverification evidence always gets `phase: readiness` (the builder's `evidence_phase`), and `phase_is_valid` already accepts readiness or delivery reassessment for a readiness-origin finding. So 6.2 needs to change only the status condition.
- **The reverification gate (req 5.1) can be placed.** `cleared` and `terminal_reverification` are both computed before the builder returns, so the refusal can run there with nothing appended.
- **Relabel bypass (primer question 1), now EXECUTED at the handler.** My probe recorded `initial_delivery` finding F-1, then `readiness` finding F-2 on a planned wave, then set the scratch wave to `Status: implementing` and recorded `readiness` finding F-3. All three returned `ok` with no diagnostics, and `finding_origin_phase` returns `readiness` for F-2 and F-3. The only status guard on the finding path is `repair_start` on a closed record (`wf_review_event_response`, change 230k6). Once requirement 5 is implemented, a delivery-time defect recorded as `run_kind='readiness'` can be cleared by an `inferred` re-read, and the wave can close. Today the same relabel still needs an `executed` clear, so the change makes this worse. qa-reviewer has already typed this as `R1-242k4-readiness-relabel-bypass`, from a builder-only probe plus a handler reading. My probe moves the handler part from read to executed.
  - Suggested repair: a builder-only refusal. The `inferred` clear or terminal reverification is allowed only when the finding is readiness-origin **and** `prior` holds no `initial_delivery` review run. Add AC-5.6 for the relabel. I would not refuse new readiness findings outright: a re-Prepare after a late admission legitimately records readiness findings on an open wave. The gate-keyed form costs only that such findings need an executed clear, which is today's rule.

## 3. Digest pin and tool surface

- `register-surface-handler-digests.json` hashes the `@mcp.tool` wrapper source inside `register_mcp_surface`, including its docstring. It does not hash `wf_review_event_response`. A docstring edit therefore moves only the `wf_review_event` hash, and the builder, validator and list-row edits move none. The plan is correct as written.
- 241lp's diff changes only the `wf_add_change` hash in that file, so the two changes do not touch the same line. AC-9.4's baseline is "as it stood when implementation began", which is after 241lp, so the fixture comparison holds.
- The tool-surface golden files (`tool-surface-golden.json`, `declared.json`) store `inputSchema` after `strip_prose_descriptions`, and the input schema does not change. They should stay unchanged. 241lp's `small_change` hunk in those files belongs to another tool.
- **The plan misses this test.** `test_lifecycle_golden.py` pins `caller_input_schema` key by key. Its `strip()` helper accepts only the declared additions (`conditional_fields`, `scanner_completion`, `configured_gates`) and fails on any other new key. Adding `execution_status` under `evidence.finding` (AC-9.3, AC-9.6) will fail it until a declared addition is added. Placing the field inside `conditional_fields` would also fail it, because that dict is pinned by equality. `test_review_evidence.py` `test_schema_exposes_all_nested_evidence_and_integrity_requirements` also pins `required_fields == REVIEW_FINDING_REQUIRED_EVIDENCE_FIELDS`, so the field needs its own key, as the spec intends. Add `test_lifecycle_golden.py` to the touched tests. A failing test will surface this, so it is a notes item.
- Serialization Points list two test files, but about 17 test files author finding events: `server_tools_support.py`, `test_security_unsettled_disposition.py`, `test_readiness_convergence.py`, `test_review_event_promotion_trigger.py`, `test_memory_records.py`, `test_council_signoff_keys.py`, `test_intent_fit_approvals.py`, `test_review_operator_integration.py`, `test_phase_gates.py`, `test_lifecycle_gates.py`, `test_archive_root.py`, `test_upgrade_wavefoundry.py`, `test_vocabulary_writers.py`, `test_small_change_lifecycle.py`, and others (grep count only; I did not classify each as a finding or a run). The task "update every existing test fixture" covers them, and the work is one sequence, so this does not block. A shared helper in `server_tools_support.py` is the cheapest place to make the change.

## 4. Carrier block

- **21 carriers is correct.** The begin marker appears in 21 live surfaces: 13 `docs/agents` files, `docs/contributing/review-and-evals.md`, 5 prompts, `.claude/agents/guru.md` and `.codex/skills/wf-guru/SKILL.md`. It also appears in the renderer itself, in `test_markdown_layout.py` and, quoted, in one closed spec in 22yox. `_carrier_protocol_block` appends role-specific blocks to the shared block, so one sentence added to `REVIEW_PROTOCOL_CARRIER_BLOCK` reaches all 21.
- **Primer question 4: re-rendering the carriers triggers no re-Prepare (inferred, read).**
  1. `policy_input_snapshot` hashes the schema and evaluator versions, `wave_review`, the lanes, `review_policies`, each admitted spec's canonical body, the requested lanes and the phase gates and sensors. It hashes no carrier or prompt file. A re-render therefore moves no receipt.
  2. `review-policy-reprepare-required` is set only by `review_policy_upgrade` and by review escalation.
  3. The upgrade marks waves when the migrated config differs, when `plan_reconciliation` plans an edit to a `LIFECYCLE_RECONCILER_CARRIERS` file, or when the receipt's evaluator version is stale. The reconciler owns the `wavefoundry:review-lifecycle` regions and the `review-policy-upgrade` region, not `wave:executable-review-evidence`, and the plan bumps no `REVIEW_POLICY_EVALUATOR_VERSION`. So a downstream upgrade that carries this change marks no open wave.
  4. Caveat: the seed 160 guardrail must stay out of `UPGRADE_POLICY_BLOCK`. Putting it inside that block would make the reconciler plan an edit and mark every open downstream wave for re-Prepare.
- **The seed 160 render claim is false.** Requirement 9.6 and the task "Run `wf_sync_surfaces` to render ... the upgrade prompt" assume a renderer carries seed 160 guardrail prose into `docs/prompts/upgrade-wavefoundry.prompt.md`. None does. The sibling "Council signoff keys" text sits after the `review-policy-upgrade:end` marker, outside every managed region, and was reconciled by hand. docs-contract-reviewer has already typed this as `R1-242k4-upgrade-guardrail-not-rendered`, and I agree with it. The repair is a hand edit outside the managed region, kept out of `UPGRADE_POLICY_BLOCK` (see the caveat in the previous item).

## 5. Files shared with 241lp

Merge risk is low to moderate. Implementation also waits for 241lp to close, which removes it.

- `review_evidence.py`: 241lp edits the **approval branch** of `build_compact_review_event` (small-change refusals near 4423 and stored fields near 4510) and `_validate_evidence_shape` (near 5434). This change edits the same approval branch (req 4.1) and the same shape function (5549), a few dozen lines away. The edits conflict only in text. 241lp does not touch the finding branch, `_validate_relationships`, `normalize_review_event_request` or `REVIEW_POLICY_EVALUATOR_VERSION`. Line numbers in the spec and in these notes move after 241lp lands, so re-anchor on symbols.
- `server_impl.py`: 241lp adds small-change checks inside `transact()` before the replay branch, guarded by `existing_bundle is None`, and changes the `wf_add_change` wrapper. This change edits the `wf_review_event` docstring and `_review_evidence_list_response`. The hunks do not overlap, and 241lp's checks do not alter the replay order described in section 2.
- Rendered prompts: 241lp's hunks in `docs/prompts/review-wave.prompt.md` (lines 5, 9 and 38) and `docs/prompts/agents/review-wave.prompt.md` (5 and 43) are outside the carrier regions (71 to 93 and 59 to 81), so a re-render after 241lp does not collide.
- `register-surface-handler-digests.json`: different hash lines (see section 3). The `description` sentence is a likely text conflict if both changes append to it, and it is trivial to resolve.
- 241lp's new `test_small_change_lifecycle.py` authors one finding event and will need a stated status. The Risks table already names it.

## Primer efficacy replay (my remit)

Requirement 6.1 plus the builder change fixes recording the 23z46 finding through the handler, because the replay order is unaffected and the dedup relaxation is the only validator blocker. The delivery gate holds only once the relabel route is closed (section 2).

## Recording

The blocking items in my remit are already typed: `R1-242k4-readiness-relabel-bypass`, `R1-242k4-upgrade-guardrail-not-rendered` and `R1-242k4-old-ledger-replay`. I record no duplicate finding. I withhold the code-reviewer readiness approval until those three are repaired, and I will reverify the relabel repair against the builder.
