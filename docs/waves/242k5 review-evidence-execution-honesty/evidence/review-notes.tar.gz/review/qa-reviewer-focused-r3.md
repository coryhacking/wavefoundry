# qa-reviewer focused readiness verification, round 3: wave 242k5, change 242k4

- context: 242k5-qa-reviewer-focused-r3, fresh_context=true, independent=true. I wrote neither `R1-242k4-outcome-rule-completed-trigger` nor its repair. I own no finding.
- receipt: review-policy-e764ccac54fd187c865e
- verdict: the repair holds. qa-reviewer readiness approval recorded.

## AC-5.7 can now pass

Requirement 5.1 now applies the `completed` condition only when the head would have no blocking lanes left. Probe (`scratch/qa-reviewer-r3/probe_r3.py`, readiness and delivery origins, two lanes): a reverification that keeps both lanes gives `repair=completed`, lanes unchanged, `dropped=[]`, `terminal=False`. None of the three conditions fires, so the event is recorded. The round-2 unscoped rule refuses it, so AC-5.7 detects that known-bad. Requirement 5.2 now agrees with 5.1.

AC-5.6: dropping one of two lanes gives `completed`, one lane left, `dropped=['qa-reviewer']`, not terminal. Only the lane-drop condition fires, so a rule that checks only completion or terminal state fails AC-5.6.

## New ACs are testable and discriminating

- AC-5.9: a lane-less readiness reverification gives `completed`, no lanes, `terminal=True` (implementer probe, rerun). A rule that applies completion and terminal checks only to delivery findings records it, so it fails AC-5.9.
- AC-5.10: rerunning `planning/probe_reclassify.py` reproduces the stated outcomes. Settling `security_unsettled` as not actionable gives `dont_do_later`, `not_required`, `dropped=[]`, terminal. A rule that checks only lanes and `completed` records it, so it fails AC-5.10. Settling it as actionable, or leaving it unsettled, stays `pending` with no lane dropped, so it is recorded. That matches requirement 5.1.
- AC-9.5: the meaning comparison is a string check between `REVIEW_PROTOCOL_CARRIER_BLOCK` and the seed 209 `execution_status` row. It fails when either text drifts.

## No contradictions

Requirements 5.1 and 5.2 are consistent. The recorded cases in AC-5.10 do not trigger 5.1. AC-1.5 (an `inferred` `repair_start` that keeps its lanes) sets `pending`, drops no lane and makes nothing terminal. AC-1.1 and AC-6.1 open new findings and supersede no head, so 5.1 does not apply to them. AC-5.3 and AC-5.4 (`pending` is kept) follow from the refusal. A caller-authored lane-less checkpoint gets `completed` from the `repair_execution_state` expression (`run_kind in {reverification, convergence_checkpoint}`), so the scoped second condition catches it even though it is not `terminal_reverification`. I found no route by which non-executed evidence clears a lane, completes a lane-less repair or makes a head terminal.

## Advisory (not blocking)

- AC-5.10, the invalid case: for a blocking finding, the lane-drop condition or the existing validator rule ("cannot clear a required-lane block without lane reassessment evidence") refuses the reclassification anyway. A rule that checks only lanes and `completed` therefore also refuses it. The invalid case separates that known-bad only on a non-blocking finding. My probe: `maybe_later` reclassified to `invalid` gives `not_issue`, `not_required`, `dropped=[]`, terminal. The test should use that variant so the claim that the known-bad "fails the two refused cases" holds.
- AC-9.5 leaves the comparison form to the implementer, for example the exact one-line text present in both places.

## What I ran and what I only read

Executed with `python3 -B`, in memory, with no ledger written: `planning/probe_reclassify.py` and `scratch/qa-reviewer-r3/probe_r3.py` (output in `probe_r3.out`). Both run through `build_compact_review_event` and `validate_review_evidence_records` on the current tree. The status is `executed` because the current builder cannot store any other value. I applied the outcome oracle and the known-bad rules to those outcomes by hand. No 242k4 implementation exists, so no AC ran against one. I also ran `wf_review_wave(phase='prepare')`.

Read only: the spec's Requirements 5, AC-5 and AC-9, the newest Progress Log and Decision Log rows, and the round-2 notes. In `build_compact_review_event` I read the `repair_execution_state` expression and `terminal_reverification`. In `_validate_relationships` I read the lane-clear, completed-only-by-reverification and closure rules.
