# docs-contract-reviewer readiness notes: wave 242k5 / change 242k4

Evidence status of this review: **read plus grep/census commands**. I ran grep, sed and awk over seeds, docs/prompts, docs/agents, docs/specs, install prompts and the renderer/reconciler sources, and read the files. I ran no test, no handler and no prototype. The tool records my findings as `executed`; that is the defect under review and is stated in `limitations`.

## Census: "execution_status" (seeds, docs/prompts, docs/agents, docs/specs, docs/contributing, install/)

Only four hits: seed 209 line 112 (tenet vocabulary), seed 209 line 140 (field table, vocabulary only, no meanings), seed 170 line 65 and docs/prompts/plan-spec.prompt.md line 62 (plan claims marked `inferred`/`unverified`). The renderer, `docs/agents/*` and `docs/specs/mcp-tool-surface.md` do not name the field. So seed 209 line 140 is the only place meanings could live, and it has none today. Adjacent census: seed 178 line 71 and docs/prompts/refresh-techdocs.prompt.md line 70 say the coordinator records docs-contract facts "as executed evidence ... or as an executed `finding` record".

## Findings

### F1 (blocking): the status meanings do not decide the read/run boundary and contradict themselves (primer Q5)

- Req 1.1 defines `executed` as "ran a command, test, probe or tool against the named path". Req 1.2 defines `inferred` as "derived the claim by reading source, documents, a plan or earlier output". `grep`, `code_read`, `code_search`, docs-lint and a render diff are commands or tools that also read. The text sends each to either value. Two honest reviewers record the same act differently, and the AC-8 reader cannot use the column.
- Req 1.2 says "The actor ran nothing for this claim. A safe-boundary demonstration is also `inferred`". A safe-boundary demonstration runs the nearest faithful boundary (seed 209 table: `safe_boundary` is "true only for an inferred faithful-boundary demonstration"). "Ran nothing" is false for it.
- `unverified` vs `inferred` is not separated: a reviewer who read the code and is unsure has no stated home.
- Seed 178 / refresh-techdocs prompt instruct "executed evidence" for docs-contract facts with no condition. After the change that reads as a prescribed status for a prose check, the exact rounding-up the change targets. Req 9.7's "No other carrier changes" census missed it because it names a value, not a field.
- AC-9.1 only requires seed 209 to "state the four meanings", so a seed that repeats req 1.1/1.2 passes while the boundary stays open.
- `repair_start` (implementer, verifies nothing) and the auto-derived `convergence_checkpoint` (mcp-tool-surface: "callers do not author a separate lightweight checkpoint") have no stated value in the meanings, yet req 2 lists both as caller-authored.

Proposed repair (pre-approval, planner): add to Req 1 a boundary sentence, for example: `executed` means the actor ran something whose output decides the claim (a test, probe, public tool call, or a deterministic checker such as docs-lint, a render-and-diff, or a search whose predicate is the claim and whose output is recorded); opening or searching text to read what it says is `inferred`, even through a tool; `unverified` is no conclusion reached; a faithful-boundary demonstration runs the nearest boundary, not the claimed path, and is `inferred`. State the `repair_start` value (`inferred`: nothing re-verified yet) and that the auto-minted checkpoint is tool-derived. Make AC-9.1 name the boundary sentence and the repair_start rule. Put the one-line rule in the carrier sentence too (native agent wrappers read only the carrier). Qualify seed 178 and refresh-techdocs "executed" to "executed when the audit tool or a probe was run; otherwise inferred", and add them to the 9.7 census.

### F2 (blocking): the upgrade guardrail does not reach docs/prompts/upgrade-wavefoundry.prompt.md by surface render

- Req 9.6, AC-9.7 and the task "Run `wf_sync_surfaces` to render the carrier block and the upgrade prompt, and confirm that only the generated regions changed" claim the render carries the seed 160 bullet.
- Verified: the only renderer-owned region in that prompt is `review-policy-upgrade`, filled from `UPGRADE_POLICY_BLOCK` in review_policy.py through `_reconcile_upgrade_policy_region` (review_policy_reconcile.py). Nothing in scripts contains the seed 160 "Council signoff keys" bullet text (grep over scripts hits only an unrelated docstring in lifecycle_gate_support.py). In the rendered prompt that bullet sits after the `:end` marker, as agent-reconciled project text (seed 160 step 8 merge contract). `KNOWN_SECTION_REPLACEMENTS["docs/prompts/upgrade-wavefoundry.prompt.md"]` is `()`.
- So AC-9.7 cannot pass through the stated task, and "only generated regions changed" would be violated by the hand edit it requires. The downstream path still works for distributions, because the upgrading agent reads the freshly extracted seed 160 directly (seed 160 line 1011), but the plan must say so and the guardrail must tell the agent what to do: scan project-authored prompts, scripts and agent instructions for `wf_review_event` finding calls and add `evidence.execution_status`, and say a not-yet-restarted old server refuses the field (dedup refusal wording).
- Repair: either add the bullet to `UPGRADE_POLICY_BLOCK` (a code change with its pins) or edit docs/prompts/upgrade-wavefoundry.prompt.md by hand outside the managed region and drop the render claim from req 9.6, AC-9.7 and the task. Also correct the Risks row: the "Tool-schema compatibility" note in mcp-tool-surface covers cached client schemas that lack new top-level fields; the input schema here does not change, so it does not cover this refusal. Add a sentence there.

## Non-blocking notes (wording, notes only)

- Approvals: `executed` on an approval means "performed its review pass" (req 4), on a finding "ran something". The seed table row and docstring should say plainly that an approval's `executed` is not a claim that code ran, and that a read-only readiness approval states what was read in `limitations`. Existing seed text already bars approving when a check cannot be affirmed; do not add new prose that tempts a pin phrase ("may carry `false` integrity checks", "supplied with honest `false` values", "If any boolean cannot be honestly affirmed, do not approve" are forbidden by a test).
- The docstring sentence "An executed claim also requires the exact caller-supplied integrity_checks object" and the mcp-tool-surface line "a non-executed finding may honestly carry `false`" already agree with the plan; no contradiction found there. The docstring "evidence holds the OBSERVATION (...)" list must gain `execution_status`.
- Primer Q6 and 241lp: not in my remit; the docs files in the Serialization Points overlap 241lp's edits.

## Verdict

Not approved. Two typed blocking findings recorded (below). Both are plan-text repairs with no code consequence.
