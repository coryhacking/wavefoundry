# code-reviewer focused readiness verification, round 2: wave 242k5, change 242k4

- context: 242k5-code-reviewer-focused-r2, fresh_context=true, independent=true. I wrote neither a round-1 finding nor the repair.
- verdict: approval WITHHELD. The repair introduced one blocking contradiction in the builder outcome rule (requirement 5.1 against AC-5.7 and requirement 5.2). Recorded as `R1-242k4-outcome-rule-completed-trigger`.
- I own no round-1 finding, so I record no reverification.

## What I ran (executed)

- `scratch/code-reviewer/probe_r2.py` with `python3 -B`, in memory only. It loads the real `review_evidence.py` and a scratch copy (`scratch/code-reviewer/proto_r2/review_evidence.py`) with ONLY the requirement 6.1 relaxation applied (the sole-finding branch keeps its dedup/census requirement; the `executed` test now applies only when `claim_kind` is `dedup` or `census`). It drives `build_compact_review_event` plus `validate_review_evidence_records` through origin, repair_start and reverification chains, then validates every `events.jsonl` under `docs/waves/` with both modules. Output:
  1. readiness and initial_delivery: an `inferred` origin and an `inferred` repair_start with honest `false` checks both record. Head stays `pending`, lanes blocking.
  2. `inferred` reverification that keeps the lane: records, and the builder sets `repair_execution_state` from `pending` to `completed` with lanes still blocking.
  3. `inferred` reverification that clears the lane: refused by the unchanged validator (`lane reassessment evidence must be executed`), because the auto-minted reassessment copies the finding evidence's status. Defense in depth for requirement 5.1 holds.
  4. `executed` reverification that clears the lane: records, terminal.
  5. lane-less delivery finding, `inferred` terminal reverification: validator ACCEPTS (repair completed). Only the builder rule of 5.1 stops it, as the Risks table says.
  6. blocking `unverified` origin: refused by the existing synthesis rule.
  7. Old ledgers: 396 read, 0 differ in validation errors between the real and the relaxed validator.
- `wf_review_wave(phase='prepare')` for the current state and vocabularies.

## What I only read (inferred)

- `_validate_relationships` dedup loop and lane-reassessment check; the reassessment mint in the builder finding branch; the `repair_execution_state` expression and `terminal_reverification` in `build_compact_review_event`; `wf_review_event_response` / `transact()` replay order in `server_impl.py`; test-file greps.

## Remit results

### Validator relaxation (requirement 6.1): holds

Only accepts more (probe item 7, 396 ledgers, 0 differences). Lane clears stay gated by the unchanged reassessment rule (item 3). Separate dedup/census evidence keeps the `executed` rule.

### Refusal placement: holds

`transact()` calls `_identified_review_event_bundle` (including the legacy approval spellings) and returns the stored bundle on a digest match before `build_identified_review_event` runs, for dry_run and create. A builder refusal therefore never reaches a replay, so AC-7.4 and AC-7.5 can pass. Identity and digest are computed before `transact()` and raise only on type errors, so an out-of-vocabulary status reaches the builder as requirement 2.3 needs.

### BLOCKING: the outcome rule's `completed` trigger contradicts AC-5.7

Requirement 5.1 refuses a non-executed event whose synthesis would "set `repair_execution_state` to `completed`". The builder sets `completed` on EVERY reverification of an action-required, non-security-unsettled finding, whether or not lanes are cleared (the `repair_execution_state` expression: `"completed" if run_kind in {"reverification", "convergence_checkpoint"}`). Probe item 2 shows the transition `pending -> completed` on an `inferred` reverification that keeps its lanes. So, implemented as written, 5.1 refuses the exact event that requirement 5.2 and AC-5.7 say must record ("read the repair, still wrong"). The implementer must choose between failing AC-5.7 and dropping the trigger; dropping it reopens the caller-authored checkpoint route that AC-5.4 closes (a lane-less checkpoint is not `terminal_reverification`, so only the `completed` trigger catches it).

Suggested repair (spec wording only): scope the trigger, for example "set `repair_execution_state` to `completed` on a head that would have no blocking lanes", or equivalently refuse when the resulting head has no blocking lanes and is completed or terminal, plus any lane drop. That keeps AC-5.3, AC-5.4 and AC-5.6 refused and lets AC-5.7 record. A `completed` state with lanes still blocking gates nothing: closure also requires empty lanes, and the projection's `open_block` is true while lanes remain.

### Pins and Serialization Points: correct

- `test_lifecycle_golden.py` is now listed and requirement 9.3 declares the key there.
- Of the roughly 17 finding-authoring test files, only the five listed need edits. Grep evidence: the only test asserting the `cannot carry integrity_checks` message is in `test_review_evidence.py` (substring assert, survives the appended remedy); no test outside it asserts `dedup evidence must be executed`; non-executed `execution_status` literals appear only in `test_review_evidence.py`; other test files that set `execution_status` set `executed`; list-row tests are in `test_server_tools_lifecycle.py` and `test_server_tools_retrieval.py`; the docstring test in `test_intent_fit_approvals.py` uses `assertIn` and survives an addition; carrier tests elsewhere (`test_docs_lint.py`, `test_upgrade_wavefoundry.py`, `test_agent_surface_integrity.py`) call `_carrier_protocol_block` dynamically.
- Notes item: `test_render_agent_surfaces.py` pins "never treat a `run` event as evidence" in the same seed 178 paragraph as the sentence being reworded. The census statement (no pin on the sentence itself) is accurate; the reword must leave the next sentence intact.

### 241lp re-check trigger: complete enough, one notes item

The five results cover the shared-file diff, census rerun, receipt probe, carrier count, test-file census and seed pins. Notes item: the anchor list omits `normalize_review_event_request` and the `transact()` replay order (`_identified_review_event_bundle` before `build_identified_review_event`), which requirement 2.6 and AC-7.4/7.5 rest on, and 241lp adds checks inside `transact()`. AC-7.4/7.5 tests would catch a change, so this is not blocking; adding the two anchors is cheap.

## Narrowing check

No new route: no rule is keyed on phase or run kind, the validator only accepts more, and approvals stay executed-only. Old-ledger replay is safe (placement above, probe item 7). The one defect is the over-broad trigger above, which blocks an honest path rather than opening a bypass, but its naive fix would reopen a bypass.

## Recording

- Finding `R1-242k4-outcome-rule-completed-trigger`, readiness, cycle 0, blocking `code-reviewer`. No approval.
- No repository edits; no real ledger touched by the probe.
