# qa-reviewer focused readiness verification, round 2: wave 242k5, change 242k4

- context: 242k5-qa-reviewer-focused-r2, fresh_context=true, independent=true. I did not write the round-1 findings or the repair.
- receipt: review-policy-7d6780545c30ef824209
- verdict: all three of my findings' repairs hold, and their three reverifications are recorded. qa-reviewer readiness approval WITHHELD: AC-5.7 cannot pass under requirement 5.1 as written (see "Approval withheld").

## Approval withheld: AC-5.7 cannot pass

The confirmation "every repaired AC can pass" fails for AC-5.7. The builder sets `repair_execution_state: completed` on every `reverification`, including one that keeps its lanes blocking. Requirement 5.1 refuses any non-executed event whose synthesis sets `completed`, so it refuses the exact event AC-5.7 requires to be recorded (and contradicts 5.2). My probe confirms it independently (`probe_outcome_oracle.py`, last scenario): a lane-keeping reverification on a readiness finding and on a delivery finding each show `dropped=[] completed=True terminal=False`, so the 5.1 oracle refuses both. The two-lane case shows the same `completed=True` when one lane drops. The code-reviewer recorded this as `R1-242k4-outcome-rule-completed-trigger` (blocking code-reviewer only) during this round. It is also in my remit (AC passability), so I do not approve until it is repaired. Suggested repair, same as the code-reviewer's: scope the `completed` trigger in 5.1 to a head left with no blocking lanes, which keeps AC-5.4 (checkpoint) refused and lets AC-5.7 pass. I will re-approve on a fresh focused check after that repair; the coordinator may want qa-reviewer named on that finding's reverification.

My relabel reverification stands: the relabel route itself is closed by the outcome rule, and AC-5.2 still detects the phase-keyed known-bad after the suggested scoping (the relabeled clear drops a lane and makes the head terminal).

## What I ran and what I only read

Executed (python3 -B, current tree, nothing written to a real ledger):

- `scratch/qa-reviewer-r2/probe_outcome_oracle.py` (in memory): builds the relabel-after-delivery, readiness-with-no-delivery, two-lane, lane-less readiness terminal and caller-authored checkpoint routes through `build_compact_review_event` and `validate_review_evidence_records`, reads heads via `review_authority_projection`, then applies the spec's requirement 5.1 outcome oracle and two known-bad gates (phase-keyed, reverification-only). Output in `probe_outcome_oracle.out`.
- `scratch/qa-reviewer-r2/probe_relabel_handler_r2.py`: through `wf_review_event_response` in a throwaway root (removed at exit): late readiness finding after `initial_delivery`, omitted-status `repair_start`, `inferred` reverification clearing and keeping the lane, `inferred` `repair_start` with false checks, and an identical replay of the omitted-status `repair_start`. Output in `probe_relabel_handler_r2.out`.
- `scratch/qa-reviewer-r2/probe_replay_order.py`: through `wf_review_event_response` in a throwaway root: records a delivery approval stating `inferred` (current code accepts it and stores `executed`), then retries it identically with (a) a simulated refusal patched into the builder, which replays with `replayed: true` while a NEW such approval is refused, and (b) the same refusal placed in a wrapper before the handler, which refuses the retry. Ledger stayed at one record. Output in `probe_replay_order.out`. This is the AC-7.5 oracle against a simulated correct and a simulated known-bad placement, not against the real implementation.
- `wf_review_event(event='list')` and `wf_review_wave(phase='prepare')` on 242k5.

Read only: the spec (Requirements 2, 5, 6, AC-1, AC-2, AC-5, AC-7, the narrowing Decision Log row and the repair Progress Log row), the round-1 notes, the primer, and the replay order in `wf_review_event_response` (`_identified_review_event_bundle` lookup at server_impl.py ~12351 precedes the builder in the non-replay branch). I did not implement anything, so no AC was run against an implementation; the AC pass and known-bad claims below are derived from the oracle applied to current builder outcomes.

## R1-242k4-readiness-relabel-bypass: holds

Requirement 5.1 now states the refusal by outcome (lane dropped, repair completed, head made terminal), and 5.5 removes every phase-keyed rule, so the relabel selects no easier rule. Probe: the late `run_kind='readiness'` finding still gets origin `readiness`, and its lane-clearing reverification trips the outcome oracle (dropped qa-reviewer, completed, terminal). The phase-keyed known-bad lets it through; AC-5.2 (all three relabel cases: after `initial_delivery`, `implementing` with no delivery record, `planned`) fails under that known-bad. Through the handler today, the `inferred` clear is refused (minted lane reassessment carries the event's status), and the lane stays blocking.

AC-5 coverage confirmed: relabel probes (AC-5.2), caller-authored checkpoint with `frozen_boundary` in cycle 2 (AC-5.4; the reverification-only known-bad lets it through, so AC-5.4 fails under it), and the two-lane case (AC-5.6; dropping one lane trips the oracle). AC-5.7 and AC-5.8 pin the non-gate and executed paths, so an over-refusing implementation also fails.

## R1-242k4-repair-start-status: holds

Requirement 2.4 makes the status optional for every run kind, so `repair_start` needs none; 2.5 settles the checkpoint wording. AC-1.5 (an `inferred` `repair_start` with false checks that keeps lanes is recorded) fails today through the handler (`dedup evidence must be executed`, probe step 6) and under any implementation that refuses or forces a status on `repair_start`. AC-2.1 (omitted status equals current records for all four run kinds) fails under one that requires the field. The oracle does not fire on a normal `repair_start`, so AC-1.5 can pass.

## R1-242k4-old-ledger-replay: holds

Requirement 2.6 now orders the replay lookup before every new refusal and keeps digest normalization. AC-7.5 (an approval stored from a request stating `inferred`, which the current code accepts, replays) is the discriminating oracle: it fails if the new approval refusal runs before the lookup. For findings, no pre-change stored request can reach a new finding refusal: an omitted status normalizes to `executed`, and the old tool refused every stated non-executed or unknown status, so none is stored (census: zero tool-written non-executed findings). AC-7.4 therefore cannot discriminate placement for findings, and there is nothing for it to discriminate; AC-2.1 pins the stored records, including `request_digest`, to current-code output, which catches a normalization change. Probe step 7: an identical omitted-status retry replays with `replayed: true` and no append today.

## Narrowing effects in my remit

No new route: the narrowing only removes rules (no required input, no lenient readiness clear). The DECLINE rows on refusing late readiness findings and caller checkpoints are safe because no rule keys on phase or run kind. Old-ledger replay stays safe as above. Validator change only accepts more (6.2), and AC-7.1 and 7.2 check existing ledgers.

## Advisory (not blocking)

AC-5.3 and AC-5.4 state a delivery finding only. A lane-less readiness finding made terminal by an `inferred` reverification trips the oracle (probe scenario 4), and requirement 5.5 forbids a phase rule, but no AC tests it. A known-bad that applies the lane-drop refusal in every phase but the completion and terminal refusal only to delivery findings would pass every AC. Suggest the implementer add a readiness variant to the AC-5.3 test (in scope of requirement 5.5; no spec edit needed).
