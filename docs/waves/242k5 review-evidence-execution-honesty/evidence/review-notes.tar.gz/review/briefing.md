# Readiness briefing packet: wave 242k5

- wave_id: `242k5 review-evidence-execution-honesty`
- phase: readiness (Prepare wave)
- wave record: docs/waves/242k5 review-evidence-execution-honesty/wave.md
- admitted spec: docs/waves/242k5 review-evidence-execution-honesty/242k4-bug review-event-execution-status-honesty.md
- planning probes: .wavefoundry/work/242k5/planning/ (repro_handler.py reproduces the defect through the real handler)
- review-policy receipt: review-policy-bbd191083a500bfeaa49
- primer depth: standard
- review lanes (required by the receipt): code-reviewer, qa-reviewer, docs-contract-reviewer, security-reviewer
- council seats: red-team (Phase 1 primer), qa-reviewer, security-reviewer and reality-checker (fixed), docs-contract-reviewer (rotating). The architecture fixed seat is not run: the change stays inside review_evidence.py and its handler; the chair says so.
- primer output: .wavefoundry/work/242k5/review/primer-red-team.md
- operator decisions 2026-11-22: refuse a finding that omits its status; `inferred` may clear readiness lanes; approvals and operator records stay `executed`-only. No LATER.
- WARNING: another session has wave 241lp OPEN with uncommitted edits in review_evidence.py, server_impl.py and other shared files. Review against the tree; never touch those files. Implementation waits for 241lp to close.
- Integrity note: this wave is ABOUT honest execution status. When you record, state your own evidence status truthfully in your notes; the current tool records findings as `executed` regardless, which is the defect under review. Say in `limitations` exactly what you ran and what you only read.

## Rules for every seat
- Read seed 209 (seed_get): the readiness finding bar, Code-Grounded Verification, the integrity_checks field table and execution_status. Read your role doc in docs/agents/ or docs/agents/specialists/, and its seed (213 security, 216 reality-checker, 225 red-team).
- Verify plan claims against the tree; cite symbol anchors.
- Read-only: NO repository edits, no commits. Probes run in a throwaway copy under .wavefoundry/work/242k5/review/scratch/<your-lane>/ with python3 -B; never write to a real ledger.
- Load MCP tools via ToolSearch first; use code_* / docs_search / seed_get first.
- Context id: 242k5-<lane>-readiness-r1, fresh_context=true, independent=true.
- Write notes to .wavefoundry/work/242k5/review/<lane>-readiness.md before recording. No em-dashes.
