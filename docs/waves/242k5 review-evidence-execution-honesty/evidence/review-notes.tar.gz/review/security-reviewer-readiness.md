# security-reviewer readiness notes: wave 242k5, change 242k4

- context: 242k5-security-reviewer-readiness-r1, fresh_context=true, independent=true
- verdict: NOT approved. Two blocking findings: `R1-242k4-relabel-open-wave` and `R1-242k4-checkpoint-completion`.
- remit: the review ledger as a control. Question asked: can unexecuted evidence satisfy a gate that requires execution?

## What I ran and what I only read

Executed (python3 -B, throwaway roots under `.wavefoundry/work/242k5/review/scratch/security-reviewer/`, removed at exit; no real ledger written):

- `probe_handler_relabel.py` (output `probe_handler_relabel.out`): the real `wf_review_event_response` handler on the current tree, `mode=create`, wave Status `planned`, `implementing` and `active`.
- `probe_handler_checkpoint.py` (output `probe_handler_checkpoint.out`): same handler, caller-authored `convergence_checkpoint`.
- `probe_proto_inferred.py` (output `probe_proto_inferred.out`): in memory against the planning prototype `planning/proto/review_evidence.py`, which has the requirement 6 validator relaxations and no requirement 5.1 builder gate.
- `wf_review_wave(wave_id='242k5', phase='prepare')` to read vocabularies and the findings already recorded.

Read only: the spec, the wave record, the primer, the qa and docs-contract notes, seed 209 (integrity paragraph, readiness finding bar, repair re-verification), `review_evidence.py` (`build_compact_review_event` finding branch, `_finding_origin_phases`, `_validate_relationships` run and reassessment rules), `server_impl.py` (`wf_review_event_response`, `_review_event_recovery_phase`). I did not run the framework suite. I did not read `docs/agents/security-reviewer.md` or seed 213 in full; I worked from the briefing and seed 209.

The handler probes necessarily used `executed` status, because the current tree cannot record anything else through the handler (the defect under review). The `inferred` variants were run only against the prototype in memory. What a faithful implementation of requirement 5.1 would do is a reading of the requirement text.

## Results

| Route | Probe | Result |
| --- | --- | --- |
| R1 relabel after an `initial_delivery` run exists | handler, Status planned, implementing, active | Accepted in all three. `F-R` origin `readiness`; repair_start, reverification and lane reassessment all `phase: readiness`; head terminal and completed |
| R2 relabel with no delivery record in the ledger | handler, Status implementing | Accepted. Same phases. No delivery run, evidence or approval exists to key on |
| R4 genuine readiness finding repaired after delivery records exist | handler, Status implementing | Accepted, cleared with `phase: readiness` evidence |
| A (R1 with `inferred` and honest `false` checks) | prototype, in memory | Build ok, validate ok; reassessment stored `readiness inferred`; head completed |
| R5 caller-authored `convergence_checkpoint` with `evidence.frozen_boundary`, cycle 2, lane-less delivery finding | handler | Accepted. `F-C` goes `pending` to `completed`, terminal, with no reverification |
| B (R5 with `inferred` and honest `false` checks) | prototype, in memory | Build ok, validate ok; delivery finding `F-C` completed on `inferred` evidence |
| Control: checkpoint without `frozen_boundary` | handler | Refused (`requires duplicate-free frozen_boundary`) |
| Control: checkpoint in cycle 1 | handler | Refused (`requires two completed repair cycles`) |
| Control R3: repair_start reclassifies a delivery finding to invalid | handler | Refused by the validator; a repair_start cannot terminalize |
| Control R3b: repair_start drops a blocking lane | handler | Refused (`clearing a required lane requires the same fresh independent actor`) |

The handler has one status guard on the finding path: `repair_start` on a closed record. Nothing reads the wave status for `run_kind='readiness'`. `_review_event_recovery_phase` maps `run_kind == "readiness"` to prepare without reading the status.

## Finding R1-242k4-relabel-open-wave (blocking)

Requirement 5 says "The tool derives the phase; the caller cannot set it." That is false on the current tree: the phase is derived from the root run's `run_kind`, which the caller supplies, and the handler accepts `run_kind='readiness'` on an open wave. After this change a delivery reviewer records a code defect as a readiness finding and clears it with an `inferred` re-read. The close gate then sees a terminal finding. Today that route needs a false `executed`; afterwards the record looks honest.

This overlaps qa's `R1-242k4-readiness-relabel-bypass`. I record it separately because the repair proposed there and in the primer ("no delivery run exists in `prior`") does not close route R2. Delivery lanes record findings before approvals, so the first delivery finding usually has no delivery record before it. A ledger-only condition cannot see that the wave is open.

Repair (both refusals sit outside the validator, so requirement 6.3 holds):

1. The lenient outcome in requirement 5 (an `inferred` lane clear or terminal completion) applies only when the finding's origin is readiness, the wave Status is `planned`, and `prior` holds no delivery-phase record (no `initial_delivery` run, no evidence with `phase: delivery`). Otherwise `executed` is required. The handler already reads the wave text and already refuses `repair_start` on a closed record, so it can pass a tool-derived flag to the builder. That flag must join the protected fields that `evidence` may not override.
2. Correct the requirement 5 sentence to say what the phase is derived from.
3. AC-5 gains three sub-points, each through the handler: an `inferred` clear is refused for a readiness-labelled finding recorded after an `initial_delivery` run; refused for one recorded on an open wave with no delivery record; refused for a genuine readiness finding once delivery records exist, where an `executed` clear is accepted.
4. Seed 209 states the cost: a readiness finding still open after the wave opens, including a late-admission re-Prepare on an open wave, needs an executed clear. This fails closed.

Uncertainty: I inferred from the fixture vocabulary (`planned`, `active`, `implementing`, `paused`, `closed`) that a readied wave is still `planned`. The planner should confirm before choosing the status test.

## Finding R1-242k4-checkpoint-completion (blocking)

Requirement 5.1 gates `reverification` only, and defines "terminal" as the builder's `terminal_reverification`, which is `run_kind == "reverification"`. Requirement 2 lists `convergence_checkpoint` as a caller-authored finding event that states a status. The builder sets `repair_execution_state: completed` for `run_kind in {reverification, convergence_checkpoint}`, and the validator accepts completion by either kind. A caller-authored checkpoint with `evidence.frozen_boundary` completes a lane-less delivery finding today (executed, handler). With the requirement 6.1 relaxation it does so on `inferred` evidence (executed, prototype). AC-5.2 covers the reverification form of exactly this case and would pass while the checkpoint form stays open.

It cannot clear a lane: the minted reassessment would be `inferred` in the `delivery` phase, which requirement 6.2 still rejects. So the exposure is lane-less delivery findings.

Repair: state requirement 5.1 by outcome, not run kind. The builder refuses any finding event whose synthesis would clear a required lane or reach a terminal or completed repair state when the table says refused, whatever its `run_kind`. Add an AC-5 sub-point: an `inferred` caller-authored `convergence_checkpoint` on a lane-less delivery finding is refused and `repair_execution_state` stays `pending`. Whether a caller should be able to author a checkpoint at all is an existing behavior and out of scope.

## Does any downgrade route work?

Downgrading a delivery finding's own status to `inferred` buys nothing: it still blocks, and requirement 5.1 stops the clear. The routes that work are the two above, where the caller picks the label that selects the lenient rule (`run_kind='readiness'`) or the event kind the gate does not name (`convergence_checkpoint`). `repair_start` is not a route (controls R3, R3b). Approvals are not a route: requirement 4 keeps them `executed` and the approval gates are unchanged (read).

One gap for notes, not a finding: AC-5.1 tests a single-lane clear. With two blocking lanes, one lane's `inferred` reverification that drops only itself also "clears a required lane". The implementation should test `cleared` non-empty, and a two-lane case would pin it.

## Primer questions

1. No. Executed through the handler: nothing refuses a new `run_kind='readiness'` finding on an open wave or after a delivery run. Requirement 5 must key the `inferred` clear on state the caller cannot choose, and the ledger alone is not enough (route R2). AC-5 needs the relabel cases. See the first finding.
2. From the control side: the status on `repair_start` carries no gate weight, because a `repair_start` can neither clear a lane nor complete a repair (controls R3 and R3b, executed). Deriving it or requiring it is integrity-neutral; qa's `R1-242k4-repair-start-status` owns the usability question. `convergence_checkpoint` is not neutral: it is a completion path, which is the second finding.
3. Old-code window (read only). New prompts on a server that was not restarted: an honest `inferred` finding meets the old `dedup evidence must be executed` refusal, which fails closed but repeats the pressure this change removes. The seed 160 bullet's three statements do not say to restart the server before recording; one clause would cover it. Old context on the new server: the missing-field refusal fails closed and names the field. Requirement 2.4's replay-before-refusal order is tested only for a finding recorded with a stated status (AC-2.3); qa's `R1-242k4-old-ledger-replay` covers that. No security blocker here.
5. The status changes an outcome in one place, the delivery clear, so an undefined line between `executed` and `inferred` matters exactly there: a lane whose check is `grep`, `code_read` or docs-lint will choose the value that clears. I support docs-contract's `R1-242k4-status-meaning-boundary` repair (a deterministic check whose output decides the claim is `executed`; reading alone is `inferred`). On read-only readiness approvals: seed 209 already defines a readiness approval's checks as attesting the review pass over the plan or tree, so `executed` with `public_path_reached: true` is honest under that definition, and requirement 4 restates it. I see no second rounding-up point there, provided the seed text keeps that sentence next to the new status meanings.

## Efficacy replay

The motivating 23z46 case (a read-only reviewer flipping `public_path_reached`) is fixed for recording a finding and for a readiness clear. The boundary claimed by the Product Intent ("gates that require execution still require it") is not established until both findings are repaired: AC-5 as written can pass while two routes complete a delivery finding on a reading.
