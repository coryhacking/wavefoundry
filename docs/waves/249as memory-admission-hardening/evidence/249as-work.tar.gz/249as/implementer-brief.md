# Implementer brief: wave 249as (change `249aq-enh memory-admission-hardening`)

The wave is OPEN (implementing). Repo: /Users/coryhacking/Developer/wavefoundry.

## Read first
- The spec: `docs/waves/249as memory-admission-hardening/249aq-enh memory-admission-hardening.md` (Requirements, 12 ACs, Tasks, Decision Log, Progress Log, Platform Behavior).
- Carry-forwards: `.wavefoundry/work/249as/review/council-chair-readiness-r3.md`, section "Carry-forwards for the implementer". Do items 1 to 8 and 10; item 9 is for 249ar and is NOT yours.
- Lane notes in `.wavefoundry/work/249as/review/*-focused-r3.md` for detail.
- `AGENTS.md` Stage Gate and Framework Script Hygiene.

## Rules
- Load MCP tools via ToolSearch first; use code_* MCP-first for retrieval. Record a `Gapfill:` Progress Log row if you rely on shell search.
- Open `framework_edit_allowed` before framework edits and `seed_edit_allowed` before seed edits (wf_open_gate); close both when done (wf_close_gate).
- Imports in new or edited code: use `import wf_server.X as X` form (the retired-import census fails otherwise).
- Preserve line endings in any writer you touch.
- After readiness, edit ONLY the Progress Log of the spec (plus AC/task checkbox flips via `wf_mark_ac` / `wf_mark_task` with the FULL change id `249aq-enh memory-admission-hardening`). Never edit Requirements, ACs text, Decision Log, Serialization Points or other sections: that rotates the receipt. Record deviations and the carry-forward outcomes as Progress Log rows.
- No test may mutate real memory records under `docs/agents/memory/`. Tests build temporary repositories.
- Do not run `wf_memory_eval` while editing docs. Run the AC-11 evidence script (read-only replay) once before the first code edit and once after the last, per the watchpoint.
- Do not commit. Do not close the wave. Do not run `wf_close_wave` except dry-run.
- No em-dashes in prose.
- Keep implementer scripts and evidence under `.wavefoundry/work/249as/` (they get archived into the wave's `evidence/` before close).
- Windows/macOS/Linux behavior per the spec's Platform Behavior section.

## Verification
- While iterating: `python3 -B .wavefoundry/framework/scripts/run_tests.py --file <file>` for touched test files, under the default profile and `--profile second` (record-shaped tests need the second profile).
- At the end: the coordinator runs the full suite. Do not run the full suite yourself, and make no repo edits while any `run_tests` is running.
- Run `wf_validate_docs` at the end and fix failures.

## Reply
Under 150 words: what landed per AC, carry-forward outcomes, tests run and results, anything not done.
