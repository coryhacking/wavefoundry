"""Read-only admission replay and targeted-brief count for wave 249as.

Usage (repository root): python3 -B .wavefoundry/work/249as/evidence/admission_replay.py

Prints one JSON document to standard output. It reads memory record bodies and
the working tree, never writes a file, and disables the brief's telemetry
credit so no ledger row is written. The admission replay needs the
``resolve_memory_refs`` primitive and reports ``available: false`` before the
change lands. The frozen-set control is read separately through
``wf_memory_eval``.
"""
from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
SCRIPTS = ROOT / ".wavefoundry" / "framework" / "scripts"
sys.path.insert(0, str(SCRIPTS))

import memory_records as mem  # noqa: E402
import wf_server.memory_handlers as handlers  # noqa: E402


def replay() -> dict:
    if not hasattr(mem, "resolve_memory_refs"):
        return {"available": False, "reason": "resolve_memory_refs is not present"}
    records = mem.load_memory_records(ROOT, statuses=None)
    tree = mem.memory_ref_tree(ROOT)
    by_status: dict[str, Counter] = {}
    totals: Counter = Counter()
    for record in records:
        status = record.get("status") or "unknown"
        counts = by_status.setdefault(status, Counter())
        counts["records"] += 1
        result = mem.resolve_memory_refs(
            ROOT, evidence=record.get("evidence_refs") or (),
            targets=record.get("target_refs") or (), tree=tree)
        reasons = mem.forbidden_content_reasons({
            "title": [record.get("title") or ""],
            "summary": [record.get("summary") or ""],
            "evidence": list(record.get("evidence_refs") or []),
            "targets": list(record.get("target_refs") or []),
        })
        for entry in result["refs"]:
            key = f"{entry['role']}_{entry['state']}"
            counts[key] += 1
            totals[key] += 1
        if result["blocking"]:
            counts["records_blocked_by_refs"] += 1
            totals["records_blocked_by_refs"] += 1
        if result["untrusted"]:
            counts["records_with_untrusted_refs"] += 1
            totals["records_with_untrusted_refs"] += 1
        found = sorted({code for codes in reasons.values() for code in codes})
        for code in found:
            counts[f"content_{code}"] += 1
            totals[f"content_{code}"] += 1
        totals["records"] += 1
    return {
        "available": True,
        "totals": dict(sorted(totals.items())),
        "by_status": {s: dict(sorted(c.items())) for s, c in sorted(by_status.items())},
    }


def targeted_briefs() -> dict:
    handlers._credit_exploration_avoided_surface = lambda *a, **k: None
    active = mem.load_memory_records(ROOT, statuses=("active",))
    scripts_root = ROOT / ".wavefoundry" / "framework" / "scripts"
    files = sorted(
        p.relative_to(ROOT).as_posix()
        for p in scripts_root.rglob("*")
        if p.is_file() and "__pycache__" not in p.parts
    )
    unmatched = [f for f in files if not any(mem.match_targets(r, path=f) for r in active)]
    histogram: Counter = Counter()
    for rel in unmatched:
        response = handlers.memory_brief_response(ROOT, context="pre_implementation", targets=[rel])
        histogram[len(response["data"]["advisories"])] += 1
    return {
        "files_under_scripts": len(files),
        "files_no_active_record_targets": len(unmatched),
        "advisory_count_histogram": {str(k): v for k, v in sorted(histogram.items())},
        "files_with_nonzero_advisories": sum(v for k, v in histogram.items() if k),
    }


if __name__ == "__main__":
    print(json.dumps({"replay": replay(), "targeted_briefs": targeted_briefs()}, indent=2))
