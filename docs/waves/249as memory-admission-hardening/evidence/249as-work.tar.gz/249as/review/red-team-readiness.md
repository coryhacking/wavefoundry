# Red-team readiness notes: wave 249as (change 249aq)

Seat: red-team (fixed, primer, standard depth). Fresh, independent context. I made no repository edits and changed no memory record. The probes are scratch scripts under the session scratchpad `redteam-249/`.

## Verdict

One blocking finding is recorded: `249as-rt-path-form-unspecified` (do_now, a fix to the spec text). I record no approval.

## Claim attacked: after this wave, memory is properly written

### Blocking: the rule for what counts as a path ref is unspecified

Requirement 1.1 says how a path ref resolves. Requirement 1.4 says that slugs and test names are `unchecked`. Nothing says how to classify a ref, yet AC-1 needs `a.py` to be a path and `finding-slug-text` not to be one. A rule that makes `a.py` a path because of its extension also turns `Class.test_name` ids and `test_x.py::test_y` node ids into unresolved paths. A comma line list such as `mcp_tool_roster.py:34,52,150` fails the `:N`/`:N-M` suffix and also ends up unresolved.

Census of the active corpus: 34 evidence refs have a dotted first token that does not look like a path, and 1 uses a comma line list. Both candidate rules pass every AC-1 case. Fix: state the form rule in Requirement 1, and add AC-1 cases for a dotted test id, a pytest node id and a comma line list.

### Can a poisoned or wrong record still get in? Yes, by design

1. **Targets that resolve but are irrelevant.** Any existing file passes, for example `README.md`. The `symbol:` check only proves that a name occurs in that file. Relevance is still the agent's judgment, as the spec admits.
1. **Evidence that resolves to an unrelated file or wave.** It passes. Nothing ties an evidence ref to the lesson.
1. **Getting around the floor.** Free-form evidence is `unchecked` and never blocks, so an author can avoid every check by writing slugs. With 320 unchecked refs in the corpus, this is the common case and not an edge case.
1. **Credential patterns.** Executed probe (`rt_patterns.py`): the planned patterns miss Anthropic `sk-ant-` keys, OpenAI `sk-proj-` keys, Google `AIza` keys, GitLab `glpat-`, npm `npm_` and Stripe `sk_live_` tokens, `Authorization: Bearer`, `aws_secret_access_key <value>` (no word boundary before `secret`) and credentials embedded in a URL. The existing keyword pattern misses all of them too. The planned patterns catch PEM, `ghp_` and Llama 3 headers.
1. **Control tokens.** The planned patterns miss DeepSeek full-width `<｜...｜>` markers, `<s>`/`</s>`, `<function_calls>`/`<invoke>` tool markup, an indented `  Human:` line, lowercase `[inst]` and invisible Unicode tag characters (U+E0000 block). They also refuse a record that merely documents the pattern: `` `<|im_start|>` is refused `` is a hit, so this wave's own lesson could not be written as a memory. That cost is acceptable, but the spec should state it.
1. **Cheaper, broader alternative for credentials.** `wave_lint_lib.secrets_validators.load_merged_ruleset` loads the 474-rule set in process in 0.38 s, and scanning one summary takes about 1 ms. It caught GitLab, npm and Stripe tokens that the planned list misses. The Decision Log rejects running `scan_secrets` because it is file-based and runs a worker. Running the rules over a string needs neither.

### Does refusing suffix-only targets break Review memories? No, but it costs a rewrite on most proposals

`memory_supply.draft_candidates` takes targets from backticked Decision Log tokens, which are usually bare names: `test_decision_prose_keeps_the_governed_module` pins `["memory_supply.py"]`. `memory_propose(create)` writes through `create_memory_record` and not through the add path, so pending drafts are still written. Each one then needs `memory_validate(verdict="rewrite")` with the full path before it can be promoted. The flow survives, at one extra rewrite per bare-named draft. Suggested fix: at supply time, replace a uniquely resolving bare target with its `resolved_path`.

Requirement 6 is ambiguous about the anchor: does a `suffix_only` original target "resolve"? If it does not, the anchor rule is skipped for records whose only targets are bare names (34 active records), which is where rewrites will happen most. Compare by `resolved_path` for both `resolved` and `suffix_only`.

## Strongest alternative design

Use a content-anchored target: (repo-relative path, symbol or line range, blob hash at admission or check).

- **Admission** requires at least one anchor whose symbol resolves inside its file.
- **Maintenance (249ar)** sets `target_churn` when the blob hash differs from the hash at the last check. This needs no commit-time index and has no date granularity. A bare or renamed path is unresolved and cannot be quietly churn-blind.
- **A check** re-records the hash, so a check without looking at the file is visible as an unchanged note against a changed hash.
