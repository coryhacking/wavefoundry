# qa-reviewer delivery review, wave 249as (change 249aq)

Context: `249as-qa-reviewer-delivery`. Fresh, independent; no repo edits.

## Verdict

Approve. Every AC has a non-vacuous test; the repaired tests were fixed by creating the files the fixtures cite, not by weakening assertions; second profile is green; no test touches this repository's memory records.

## AC to test map

- AC-1: `MemoryRefResolutionTests` (`test_target_states` with index absent and embedder modules blocked, `test_evidence_states_and_order`, `test_spaced_and_annotated_paths`, `test_blocking_set_is_exact` with an exact sorted equality, `test_known_bad_suffix_target_no_longer_passes`, CRLF, backslash, long-ref bound, walk pruning).
- AC-2, AC-3, AC-6: `MemoryAdmissionEnforcementTests` (byte-identical file on refused promote, reject allowed, ambiguous rewrite, content-before-refs with no ref or token echo, suffix_only suggestion, no-Git new file, stored-secret promote, untrusted flag).
- AC-3 dry-run resolution and AC-5: `MemoryProposeReasonTests` (exact `rejected_by_reason`, withheld keys exactly `reasons` and `source_event`, create writes 1).
- AC-4: `MemoryContentReasonTests` (13 secrets and 14 control tokens built at run time, no echo, 9 negative controls write, lint names reason without the line).
- AC-7: `MemoryRewriteAnchorTests` (validate and supersede, all cases, byte-identical refusals, `Retarget reason:` line).
- AC-8: `MemoryTargetedBriefTests` plus the updated `test_brief_remains_queryless_and_exact_target_promoted`.
- AC-9: `MemoryAdmissionGuidanceTests` over all six carriers.
- AC-10: `test_batch_of_fifty_records_walks_once` counts the walk.

## Repaired-test audit

`git diff` of the three test files: 8 deleted lines in total. Assertion changes are only the spec-mandated brief expectation (`["mem-target"]`) and the propose test now reading `withheld` plus asserting `proposed == []` and `rejected_by_reason == {"secret": 1}` (stronger). Everything else adds fixture files, plan stems and wave folders inside the temporary root.

## Executed probes

Run in a scratch copy of the tree because another reviewer held `test-run.lock`.

- Default `--file`: `test_memory_records.py` 289 OK, `test_render_agent_surfaces.py` 242 OK, `test_lifecycle_mutation_lock.py` 69 OK.
- `--profile second` over those three plus `test_docs_lint.py`: 0 of 4 files failed (967 tests, 4 skipped, none in the new classes; the default run of `test_memory_records.py` skipped 0).
- Known-bad mutants on the scratch copy, each caught:
  1. suffix_only target made non-blocking: 3 failures (exact blocking set, add path, known-bad delegate).
  2. npm pattern removed: `test_reasons_and_no_echo` fails on the npm sample.
  3. anchor check always passes: both rewrite and supersede tests fail.
  4. `exempt_end` ignored: 10 failures including the decision-log lint exemption tests.
  5. targeted brief filter removed: both brief tests fail.
- `git status --porcelain docs/agents/memory` identical before and after.

## Advisories (non-blocking)

1. The single-line and content checks on `retarget_reason` in `memory_add` and `memory_validate` (handlers lines near 698 and 1611) have no handler-level test; only `render_memory_record`'s refusal is pinned elsewhere. AC-7 does not enumerate them.
2. The supersede `also_gone` case asserts the code but not that the message names `src/also-gone.py`; the validate case does.

Gapfill: shell `grep` and `sed` read test and handler text after MCP tools were loaded, because the review compared diff hunks and line ranges.
