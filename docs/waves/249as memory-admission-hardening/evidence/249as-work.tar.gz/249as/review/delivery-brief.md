# Delivery review brief (wave 249as, change `249aq-enh memory-admission-hardening`)

The wave is implementing and the code is in the working tree (uncommitted; `git diff` and `git status` show it). Spec: `docs/waves/249as memory-admission-hardening/249aq-enh memory-admission-hardening.md`. Read the Requirements, ACs, and the Progress Log, which records the carry-forward outcomes and deviations (worktree stopgap, AC-5 fixture token, lint test location, the `contained_files` bootstrap exclusion, digest and golden refreshes). Readiness notes and the carry-forward list are in `.wavefoundry/work/249as/review/` (`council-chair-readiness-r3.md`).

Coordinator evidence: full suite `run_tests.py --no-cache` passed, 13,471 tests across 258 files (`.wavefoundry/work/249as/full-suite-2.log`); `--profile second` 0 of 258 files failed (`second-profile-2.log`). The initial_delivery run is recorded.

## Your task, as a FRESH, independent reviewer of your lane

1. Load MCP tools via ToolSearch first; use code_* MCP-first, and record a `Gapfill:` note in your notes if you fall back to shell search.
2. Verify the delivered code against each AC and the carry-forwards, not against the Progress Log's claims. Run executed probes: `run_tests.py --file <f>` (default and `--profile second`), and throwaway-copy probes. A known-bad control (a mutant on a scratch copy that your check catches) is expected for an executed approval.
3. Make NO repo edits. Never run the full suite. Do not run `wf_memory_eval`. Do not mutate memory records under `docs/agents/memory/`.
4. Record with `wf_review_event(wave_id='249as', ...)`, dry-run first, then create:
   - A blocking defect: a finding with `run_kind='initial_delivery'`, `cycle=0`, `actor=<lane>`, `context_id='249as-<lane>-delivery'`, honest `execution_status`.
   - Otherwise: a delivery approval, `signoff_key=<lane>`, `approval_phase='delivery'`, `fresh_context=true`, `independent=true`, executed, your OWN honest `integrity_checks`.
   - red-team: notes only, plus a finding for a blocking defect.
5. Write notes to `.wavefoundry/work/249as/review/<lane>-delivery.md`. No em-dashes.
6. Reply in under 80 words.

## Lane focus
- code-reviewer: correctness of `resolve_memory_refs`, `memory_ref_tree`, `forbidden_content_reasons`, refusal order, longest-prefix cost caps, import form `import wf_server.X as X`, line endings preserved.
- qa-reviewer: every AC has a non-vacuous test; the broken-test list was repaired, not weakened; second-profile behavior; no test touches real memory records.
- architecture-reviewer: the primitive contract for 249ar (AC-10), the `contained_files` upgrade-bootstrap exclusion is sound (would an upgrade from an older install load a stale `contained_files`, and does any bootstrap path call ref resolution?), worktree stopgap scope.
- docs-contract-reviewer: seeds 240 and 190, the four prompt copies, `docs/specs/mcp-tool-surface.md`, `docs/architecture/cross-cutting-concerns.md`, CHANGELOG, tool goldens match the docs.
- red-team: secrets echo paths (refused refs, promote/retain, lint output), bypasses of the admission checks, pathological refs.
