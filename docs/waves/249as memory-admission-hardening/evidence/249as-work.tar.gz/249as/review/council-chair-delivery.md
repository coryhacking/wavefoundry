# Council chair delivery review: wave 249as, change 249aq

Moderator: council-chair, fresh context, independent, `execution_status: executed`.
Seats: red-team, docs-contract-reviewer (rotating seat: docs-contract-reviewer).
Verdict: PASS. No blocking finding; `council-delivery` recorded with `intent_fit: establishes`.

## State check

`wf_review_wave(wave_id='249as', phase='implementation')`: code-reviewer, qa-reviewer, architecture-reviewer and docs-contract-reviewer delivery approvals are current, none has an unresolved blocking finding, and lint passed. Only `council-delivery` and `operator-signoff` remain. All 25 AC and task checkboxes are `[x]`.

## Independent check of the unreviewed batch A, B and C

Method: I copied `.wavefoundry/framework/scripts/` to the session scratchpad twice (`cc/good`, `cc/bad`) and ran one probe file (`probe_chair.py`, subclassing `test_memory_records._AdmissionCase`, so each case runs in a temporary repository) against each copy with `python3 -B`. `cc/bad` carries three known-bad mutants. No repo edit; `docs/agents/memory/` untouched; `git status --short` unchanged before and after.

- **A, unbalanced backtick.** `src/a.py\``, five backticks around `src/a.py`, `` `1abcd` `x `` and `` `src/a.py``src/b.py `` are each refused on `memory_add` with `memory_ref_unresolved` and nothing is written; a rewrite target `` src/a.py` tail `` is refused the same way; the balanced control `` `src/a.py` `` with evidence `` `1abcd` note `` is admitted. Known-bad: `_unterminated_refs` returning `[]` admits the first case (diagnostics `[]`). Holds.
- **B, stored secret withheld.** A `ghp_` token stored in the title, the summary, an evidence ref or a target ref of a pending record: `reject` and `rewrite` both return `ok`, `withheld_reasons: ["secret"]`, and the token appears nowhere in the response; a second `reject` on the now-finalized record (the not-pending path) does not echo it either. Known-bad: `_withhold_view` returning the view unchanged echoes the token in `data.record.title`. Holds.
- **C, tool-call markup.** Unclosed `<invoke`, `<invoke` with a tab, `</invoke`, closed tags, `<function_calls>`, `<parameter` mid-line and `<invoke` followed by 400k characters of attributes all give `model_control_token`; `the invoke method`, `<invoker>`, `<invoked`, `<parameters>`, `a < invoke b` and `<tool_calls>` stay clean. 500k `<` plus 200k `</x:` ran in 0.216 s. The handler refuses a summary carrying `<invoke name="x">`. Known-bad: restoring a closing `[^>]*>` requirement misses the unclosed opening. Holds.
- `run_tests.py --file test_memory_records.py`: 295 tests OK, 0 skipped (19.0 s).

## Council synthesis

- Strongest challenge (red-team seat): the content floor is a named-pattern heuristic, so unlisted shapes (Stripe `sk_live_`, URL-embedded credentials, upper-case `<INVOKE`, invisible tag characters) still pass admission. Answered: the Risks table records them, the repository secret scan still covers written files, and the spec claims a floor, not a boundary.
- Strongest alternative (docs-contract seat): load the 474-rule secret ruleset in process instead of named groups. The Progress Log weighs it and declines it for reason codes and MCP write-path cost; I agree.
- Intent fit: `establishes`. Each Objective clause has executed evidence: refs resolve or block (AC-1, AC-2; replay 51 of 197 bodies would be refused), credentials and control tokens are refused by reason (AC-4 and probe C), untrusted evidence is flagged (`test_untrusted_evidence_is_flagged_without_blocking`), a rewrite keeps a resolving target or states `retarget_reason`, and a targeted brief for untargeted files is empty (452 of 452 files, 5 advisories to 0). The frozen-set control is unchanged, as the Objective requires. The worktree stopgap (nested checkouts pruned from the walk) is operator-directed and does not weaken the Objective.

## Residual advisories

1. DECLINE. `_memory_view` on reject and rewrite still returns stored `action_delta`, `validation_rationale` and `source_event`, and the memory id and path carry the title slug, without the content check. A pending candidate has no stored `action_delta` or rationale, `source_event` is single-line ledger text, and the id is the caller's own input, so no new disclosure follows; the record lint still flags the file.
2. DECLINE. Markup matching is case-sensitive, so `<INVOKE` passes. It was never caught, the change claims named lower-case harness tags, and widening it risks prose false positives without a field case.
