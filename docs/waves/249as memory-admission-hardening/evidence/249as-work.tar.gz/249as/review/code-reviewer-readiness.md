# Code-reviewer readiness notes, wave 249as (change 249aq)

Reviewer: code-reviewer, fresh and independent context. Receipt `review-policy-547603c8059b79d88081`.

## Verdict

Not ready. Two blocking findings, recorded in the ledger:

1. `cr-249as-rewrite-pending-refs-contradiction`: Requirement 2 and AC-7 contradict each other.
2. `cr-249as-evidence-path-form-undefined`: Requirement 1 never says which evidence refs are path refs.

## Anchors checked against the tree

| Spec claim | Result |
| --- | --- |
| Three copies of the forbidden scan near lines 584, 990 and 1446 of `wf_server/memory_handlers.py` | Holds: 584 (add), 990 (propose create only, so dry-run is not scanned today), 1446 (validate). |
| The lint reuses the tuple through `_memory_forbidden_match` | Holds: `wave_lint_lib/wave_validators.py:151` and `:2519`. `MEMORY_DISALLOWED_PATTERNS` is `JOURNAL_DISALLOWED_PATTERNS` plus one pattern (`constants.py:244`). |
| `_memory_file_target_exists` near line 1350 skips `symbol:`, uses `rglob` and a suffix match, and only `memory_validate` calls it | Holds (`:1350`, sole caller `:1511`). |
| `_memory_add_response_locked` is the shared write path for add, rewrite and consolidation | Holds (`:515`, `:1549`, `:2307`). `memory_propose(mode="create")` does not use it: it writes through `mem.create_memory_record` (`:1030`). Its candidates are caught later by `memory_validate`, so this is acceptable, but the spec should say so. |
| `memory_brief` pads with `matched + unmatched` | Holds (`:1955`). In a probe copy, dropping the padding broke only `test_brief_remains_queryless_and_exact_target_promoted`. |
| `no_memory_matches` names `memory_add` as its recovery tool | Holds (`:1893`). |
| `contained_files.judge_contained_file` | Exists (`contained_files.py:572`). It is a removal judge that raises `ContainedFileRefused`. It does not check case-exact spelling, so the component-spelling check is new code, as the Platform section implies. |

## Blocking 1: a rewrite is refused on the pending record's refs

Requirement 2 checks the pending record's targets and evidence for `promote`, `retain` and `rewrite`. AC-7 case 2 requires a rewrite of a candidate that targets `src/a.py` and `src/missing.py` to succeed. `src/missing.py` is unresolved, so Requirement 2 refuses that rewrite. Today's code refuses it too (`memory_target_not_current`, `:1509-1520`). AC-7 case 3 gives no outcome. Requirement 6's fallback ("none of the original targets resolves") can never be reached from `memory_validate`. The spec also does not say whether `memory_target_not_current` is kept or replaced.

Fix: for `rewrite`, check only `rewrite_targets` and `rewrite_evidence` plus the anchor rule. Give AC-7 case 3 an explicit expected result. State whether a `suffix_only` original target counts as resolving for the anchor rule.

## Blocking 2: evidence path form is undefined

Requirement 1.1 defines a path ref as the first whitespace-delimited token, but it never says when an evidence ref is a path rather than `unchecked`. Real active evidence refs that the rule must classify:

- `review_evidence.py:review_authority_projection`
- `test_events_only_residue_census.py::test_each_new_historical_semantic_route_is_detected_individually`
- `MemoryAgentValidationTests.test_close_diagnostics_...`
- `index_state_store.py begin_build_epoch disjuncts`

The consolidation path also writes evidence such as `consolidated from <id>` (`:2306`). Under a "first token is a path" reading, several of these become `unresolved` and block every rewrite that carries them forward. Under an "only refs with `/` or an extension" reading, AC-1's `a.py` passes but `review_evidence.py:review_authority_projection` still blocks, because its suffix is not numeric.

Census of the 608 evidence refs on active records:

| Form | Refs |
| --- | --- |
| Wave id | 149 |
| Change id or memory id | 74 |
| Contains `/` | 52 |
| Bare name with an extension | 8 |
| Other | 325 |

Fix: state the classification rule and add the non-numeric-suffix and `::` cases to AC-1.

## Callers that break (counted in a throwaway copy)

I ran the probe on a private copy at `scratchpad/cr249/probe`. It refused any target that is not an exact existing file, and made `_memory_file_target_exists` exact-only. I compared the results against an unpatched baseline over `test_memory_records`, `test_memory_backfill`, `test_lifecycle_mutation_lock` and `test_archive_memory_backfill`.

| Probe | New failures |
| --- | --- |
| Suffix-only and unresolved targets refused | 33 test cases: 29 in `test_memory_records.py` and 4 in `test_lifecycle_mutation_lock.py` |
| Also refusing wave-id and change-id evidence that is absent from the fixture | 41 test cases: 37 in `test_memory_records.py` and 4 in `test_lifecycle_mutation_lock.py` |
| `test_memory_backfill.py` and `test_archive_memory_backfill.py` | 0 |

The fixtures cite `src/chunker.py` and `` `1abcd-bug some-change` `` without creating them. `test_lifecycle_mutation_lock.py` is missing from Serialization Points, and the Tasks name only backfill fixtures. This overlaps the qa finding `qa-249as-unnamed-test-breakage`.

Production callers: suffix-only targets are refused only through `_memory_add_response_locked` (add, validate rewrite, consolidate) and through `_memory_file_target_exists` (validate). On this repository, 47 of the 174 active records hold a target that would block: 73 suffix-only targets, 4 ambiguous and 9 unresolved. Any rewrite or consolidation of those records is refused until the reviewer writes full paths, which the spec accepts in Risks.

## Non-blocking

- Hot path: once 249ar lands, `_memory_ranked` runs on hot read tools through `_memory_advisories_for_path`. On this repository a full `memory_ref_tree` walk is 26 ms (5,149 files). On a large target repository it costs more. Delivery review should measure it.
- The default-profile run of `run_tests.py --file test_memory_records.py` is green on the current tree: 263 tests, 0 skipped.
