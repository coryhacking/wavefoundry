# Readiness review brief (waves 249as and 249ar)

This review covers two waves of the arc `docs/arcs/244cm memory-quality/244cm-arc memory-quality.md`. The research is in `research/`. The baseline waves `245na` and `248lb` are closed.

## Wave 249as, track 3 (admission hardening)

- **Spec:** `249aq-enh memory-admission-hardening`, in `docs/waves/249as memory-admission-hardening/`.
- **Receipt:** `review-policy-547603c8059b79d88081`.
- **Lanes:** code-reviewer, qa-reviewer, architecture-reviewer and docs-contract-reviewer.
- **Seats:** red-team (fixed) and docs-contract-reviewer (rotating).

The planned design:
- A new `memory_records.resolve_memory_refs`, plus `memory_ref_tree` for batch callers, resolves refs against the working tree. An unresolved or ambiguous ref blocks validation and every add.
- New admissions may not use suffix-only file targets. The error suggests the full path.
- Named credential and model-control-token patterns are rejected and counted by reason. The rejected text is never echoed.
- Untrusted refs (URLs, dependency paths, scratch paths) are flagged, not blocked.
- The rule that a record must hold something the code does not already show is validation guidance.
- A rewrite keeps a resolving original target.
- Targeted briefs no longer pad: an empty brief is normal.
- The three copies of the disallowed-pattern scan in `wf_server/memory_handlers.py` should become one.
- The frozen-set metrics cannot move. They serve as a control, and the wave is measured by a read-only replay over all records.

## Wave 249ar, track 4 (maintenance)

- **Spec:** `246to-enh memory-revalidation-by-signal`, in `docs/waves/249ar memory-maintenance-by-signal/`.
- **Receipt:** `review-policy-853a27f7da7e8def650b`.
- **Lanes:** code-reviewer, qa-reviewer and docs-contract-reviewer.
- **Seats:** red-team (fixed) and docs-contract-reviewer (rotating).
- **Dependency:** this wave depends on `249as`, whose primitive it reuses. It is implemented after 249as.

The planned design:
- The flags `target_unresolved` and `target_churn` are derived, not persisted.
- Churn no longer lowers confidence for any kind.
- Age and churn are counted from `Updated:`.
- The audit order runs unresolved first, then churned, then the 244fh order.
- `memory_reconcile` gains `check_note`. A keep without a note is refused (`memory_check_required`), and so is a keep whose target is unresolved (`memory_target_unresolved`). The check writes `Check flags:`.
- One churn threshold applies to every kind.
- New: a model-free `maintenance_signals`, and `memory_eval.uncoverable_records`, which returns 32 records on this repo.
- Versioned `.vN` query sets live beside an untouched v1.
- The batch review and the re-freeze run after close.

## Operator authorization and decisions (2026-11-24)

The operator authorized prepare, review and implementation of both waves. The coordinator decisions are recorded in each spec's Decision Log. Writing, maintaining, indexing and evaluating memory all have to work.

## Your task, as a fresh, independent reviewer of your lane, for EACH wave your lane covers

1. **Read.** Load MCP tools via ToolSearch first, and use code_* MCP-first. Read each spec and its Decision Log.
2. **Verify against the code, not the spec's prose.** Every cited anchor must resolve, and every claim that existing code already does something must hold. The two waves must not contradict each other: 249ar must use 249as's primitive as 249as defines it.
3. **Make no repo edits.**
   - You may run `python3 -B .wavefoundry/framework/scripts/run_tests.py --file <f>` under the default profile and under `--profile second`, plus probes on a throwaway copy.
   - Never run the full suite. Do not run `wf_memory_eval`. Do not mutate memory records.
4. **Record per wave** in the typed ledger (`wf_review_event` with `wave_id` set to that wave). Dry-run first, then create.
   - For a blocking defect, record a finding: `run_kind='readiness'`, `cycle=0`, `actor=<lane>`, `context_id='<wave>-<lane>-readiness'`, with an honest `execution_status`.
   - If you find no blocker, record a readiness approval: `signoff_key=<lane>`, `approval_phase='readiness'`, `fresh_context=true`, `independent=true`, executed, with your OWN `integrity_checks`.
   - Council seats write notes, plus findings when something blocks.
5. **Write notes** to `.wavefoundry/work/<wave>/review/<lane>-readiness.md`.
6. **No em-dashes.** Reply in under 120 words covering both waves.
