# Architecture reviewer, focused readiness round 3, wave 249as

Reviewer: architecture-reviewer, fresh and independent context `249as-architecture-reviewer-focused-r3`, 2026-11-24.
Scope: repair 2 of `249aq-enh memory-admission-hardening` on receipt `review-policy-1c51f95cd62f929bce87`. No repo edits, no memory mutations, no test suite run. Probes ran in the scratchpad only.

## Verdict

`arch-249as-path-form-truncates-spaced-paths` is repaired. No new blocking defect. Readiness approval recorded.

## Reverification of the spaced-path finding (executed)

Probe: a scratch script that implements Requirement 1 as now written (URI check first, `symbol:`/`community:`, longest exact-file prefix with the whole `:`/`::` suffix chain stripped, digit-bearing wave id, first-token fallback, pruned `memory_ref_tree` walk, case-exact component check).

1. Real corpus, every active record under `docs/agents/memory/`: all 11 spaced refs now resolve `resolved` through a 2- or 3-token prefix (6 targets, 5 evidence). Examples: `docs/architecture/decisions/1yb8v-adr record-layout-config-over-resolver-protocol.md`, `docs/waves/241c3 writing-guide-sentence-structure/evidence/README.md`, `docs/waves/1tuoc review-policy-and-delivery-evaluator/1tsbu-enh review-policy-and-delivery-evaluator.md`. In round 2 the first-token rule failed every one. The 7 remaining blocking targets are bare or directory refs (`server_impl.py` ambiguous, `docs/waves/` unresolved, one deleted eval script), none spaced. They belong to track 4, which does not re-judge records through `blocking`.
2. Annotated real refs: `index_state_store.py begin_build_epoch disjuncts` falls back to the first token and is `suffix_only` to `.wavefoundry/framework/scripts/index_state_store.py`; `render_platform_surfaces.py:1324-1360 (corrected docstring)` is `suffix_only`; `.wavefoundry/framework/scripts/tests/test_memory_records.py::MemoryToolTests::test_x` is `resolved` to the file.
3. AC-1 fixture, built in a temp tree to the spec's layout: every listed state matched, including `docs/waves/1abcd fixture/wave.md` resolved, `...wave.md:1 first line` resolved with the spaced `resolved_path`, `...missing.md` unresolved, `src/a.py begin_alpha notes` resolved, `a.py begin_alpha notes` suffix_only, `src/a.py::AlphaTests::test_alpha` resolved, `https://example.com/src/a.py` unchecked, `tests`/`fixed` unchecked, `index.js` unresolved with `node_modules` pruned, `Src/A.py` unresolved on macOS APFS. Extra cases: `docs/waves/1abcd fixture/wave.md::Cls::t` resolves, and `src/a.py:2 (see docs/waves/1abcd fixture/wave.md)` resolves to `src/a.py`.

Known-bad control: the round-2 first-token rule, run by the same harness, would leave the spaced fixture target unresolved; the AC-1 spaced-path sub-item fails against it.

## Fit with 249ar

The five state names are unchanged. `246to` Requirement 1 reads each target's `state`, not `blocking`. With repair 2, the six spaced targets on active records read `resolved`, so 249ar no longer raises a false `target_unresolved` on them. 249ar needs no text change.

## Round-2 advisories

All closed: URI check ordered first (rule a); wave ids need a digit; walk prunes dependency and cache folders; `exempt_end` on `memory_line_reasons`; NFC/NFD limitation recorded.

## Advisory (non-blocking)

- The longest-prefix step reads the disk once per token prefix per ref. Cost is bounded by token count and is fine at corpus scale (about 960 refs), but the implementation should stop at the first exact hit, as written.
