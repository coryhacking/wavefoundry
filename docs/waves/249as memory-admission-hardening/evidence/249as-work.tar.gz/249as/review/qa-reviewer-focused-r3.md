# qa-reviewer focused readiness verification, round 3, wave 249as (change 249aq)

Fresh, independent context (`249as-qa-reviewer-focused-r3`). Receipt reviewed: `review-policy-1c51f95cd62f929bce87`. No repository edits. Every probe ran on a scratch copy (`scratchpad/qa249r3/tree`, identical to the repo framework tree at review time).

## Verdict

No new blocker. Readiness approval recorded. Two advisories below; the first corrects the broken-test list.

## Probe

`qa_r3_resolve.py` (scratch copy only) is a fresh approximation of Requirement 1 after repair 2: URI check first, longest exact-file whitespace prefix with the whole `:`/`::` suffix chain stripped, first-token fallback, case-exact components, line checks, digit-bearing `[0-9a-z]{5,6}` wave ids, change and memory stems, symbol targets, pruned walk (`node_modules`, venvs and the rest), `suffix_only` targets blocking. It was enforced after the content scan in `_memory_add_response_locked`, on the pending record's refs for promote and retain, on `rewrite_targets`/`rewrite_evidence` for rewrite, with the Requirement 6 anchor rule on rewrite and supersede.

## AC fixtures are testable

- AC-1: every listed state came out as specified on a temporary fixture, and `blocking` equals the spec's exact list (13 refs). Spaced (`docs/waves/1abcd fixture/wave.md:1 first line`), annotated (`src/a.py begin_alpha notes`, `a.py begin_alpha notes`), `path::Class::test`, `:1,3`/`:1,4`, `tests`/`fixed`, `https://example.com/src/a.py` and the pruned bare `index.js` all behave as stated.
- AC-4: all 13 secret fixtures match only `secret`, all 14 control-token fixtures match only `model_control_token`, the 9 negative controls match nothing (including today's `MEMORY_DISALLOWED_PATTERNS`), and `<|im_end|>` gives `model_control_token`. The fixtures are generated, so no literal credential is committed.
- AC-3: content-first ordering is implementable; the secret-in-evidence plus missing-target case refuses on content before any ref is named.
- Real corpus (read-only, scratch copy, 174 active records, one walk): 12 spaced refs under `<id> <slug>` folders now resolve; `index_state_store.py begin_build_epoch disjuncts` is `suffix_only` to `.wavefoundry/framework/scripts/index_state_store.py`; `render_platform_surfaces.py:1324-1360 (corrected docstring)` resolves.

## Advisory 1: the 42 named tests are not exactly the set that breaks

`run_tests.py --file test_memory_records.py --file test_lifecycle_mutation_lock.py` on the probe copy fails 42 test ids, but the set differs from Tasks by one in each direction:

- Fails, not named: `MemoryProposeTests.test_registered_manual_pending_candidate_blocks_close_without_source_event`. Its `mem-unrelated` add cites evidence `1aaaax`, a 6-character digit-bearing ref, so under Requirement 1's `[0-9a-z]{5,6}` wave-id rule it is an unresolved wave id and the add is refused. The round-2 probe used 5 characters only and missed it.
- Named, does not fail: `SecretScanCoverageTests.test_secret_in_title_or_targets_is_refused_without_side_effect`. Requirement 2 now runs the content check before resolution, so this test still refuses on content and passes.

The stated fixture approach (create the stems a fixture cites, here a `1aaaax` wave folder) repairs the missing test without changing what it pins, and AC-12 requires the suites to pass, so this does not block. The implementer should record the corrected list in the first Progress Log row.

Other caller files under the probe: `test_archive_memory_backfill`, `test_memory_backfill`, `test_record_layout_nested`, `test_review_policy`, `test_server_context_efficiency`, `test_server_tools`, `test_storage_upgrade_resume`, `test_upgrade_recovery_guidance`, `test_handler_modules` all pass (1040 tests across 10 files). The one failure, `test_extension_tool_modules` script census, is caused by the probe's own new flat script and does not apply to the planned change, which adds no script.

## Advisory 2: 249ar agreement

The five states and `resolved_path` are unchanged, and 249ar reads `state`, not `blocking`, so the specs still agree. Two small notes for 249ar, neither blocking here:

- 249ar AC-3 uses evidence `zzzzz` as a "missing evidence ref". With the digit rule it is now `unchecked`, not an unresolved wave id. The expected `[]` still holds, because track 4 flags no evidence, but the fixture no longer exercises a missing wave id.
- 249ar's Progress Log census (280 resolved, 9 unresolved file targets) used the first-token rule; under longest-prefix this probe gets 289 resolved and 3 unresolved, because spaced paths now resolve. It is a dated record, not an AC.

## Limitations

The resolver is an approximation, not the implementation. Case behaviour was checked on macOS only. No full suite, no `wf_memory_eval`, no memory record mutated.
