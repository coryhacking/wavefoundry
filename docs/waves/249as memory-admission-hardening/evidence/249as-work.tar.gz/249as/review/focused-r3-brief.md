# Focused readiness verification, round 3 (wave 249as only)

The operator authorized a second bounded docs-only repair of spec `249aq-enh memory-admission-hardening` (in `docs/waves/249as memory-admission-hardening/`). The repair context is `249as-planner-repair-2`, cycle 2. It addresses `arch-249as-path-form-truncates-spaced-paths` and the round-2 advisories. The Decision Log and Progress Log carry repair-2 rows.

Current receipt: `review-policy-1c51f95cd62f929bce87`. Every earlier readiness approval is stale.

What repair 2 changed, per the planner:
- Path refs: resolve the LONGEST whitespace-joined prefix that is an existing file; otherwise fall back to the first token. The URI/untrusted check runs first. The whole `:` / `::` suffix chain is stripped (so `path::Class::test` resolves the file).
- Wave ids must contain a digit, so words like `tests` are not wave ids.
- The `memory_ref_tree` walk skips dependency and cache folders (node_modules, venvs, .git and similar).
- `bearer` matches case-insensitively; namespaced tool-call tags are caught.
- The content (credential) scan runs before ref resolution, so no refused ref echoes a secret. `memory_line_reasons(line, exempt_end=None)` is specified.
- The macOS NFC/NFD limitation is recorded. The broken-test list is 42 (adds `MemoryAgentValidationTests.test_promote_retain_and_reject_persist_compact_judgment`).
- AC-1, AC-3 and AC-4 have new fixtures. Still 12 ACs. The five resolution states are unchanged, so 249ar (spec `246to`, readied) must still agree.

## Your task, as a FRESH, independent reviewer of your lane

1. Load MCP tools via ToolSearch first; use code_* MCP-first. Read the full spec, your lane's earlier notes in `.wavefoundry/work/249as/review/`, and the repair-2 Decision/Progress rows.
2. Verify against the code and the tree, not the spec's prose. Run an executed probe on a throwaway copy where the claim is testable (for example: real spaced-path evidence refs from `docs/agents/memory/` records, an annotated ref like `index_state_store.py begin_build_epoch disjuncts`, `path::Class::test`). Make NO repo edits. `run_tests.py --file <f>` only, never the full suite. Do not run `wf_memory_eval`. Do not mutate memory records. Check the spec still agrees with 249ar's use of the primitive.
3. Record in the typed ledger with `wf_review_event(wave_id='249as', ...)`. Dry-run first, then create. Use `wf_review_wave(wave_id='249as', phase='prepare')` for the cycle and state args.
   - architecture-reviewer only: first record the reverification of `arch-249as-path-form-truncates-spaced-paths` (`event='finding'`, `run_kind='reverification'`, cycle from wf_review_wave, `blocking_required_lanes=[]` only if the repair holds, executed evidence, `fresh_context=true`, `independent=true`, `actor='architecture-reviewer'`, `context_id='249as-architecture-reviewer-focused-r3'`).
   - Required lanes (code-reviewer, qa-reviewer, architecture-reviewer, docs-contract-reviewer): if no blocker, record a readiness approval on the current receipt: `signoff_key=<lane>`, `approval_phase='readiness'`, `fresh_context=true`, `independent=true`, executed, with your OWN honest `integrity_checks`, `context_id='249as-<lane>-focused-r3'`.
   - red-team: notes only, plus a finding if a NEW blocking defect exists.
   - A new blocking defect gets a finding (`run_kind='readiness'`) instead of an approval. Advisories go in notes only.
4. Write notes to `.wavefoundry/work/249as/review/<lane>-focused-r3.md`. No em-dashes.
5. Reply in under 80 words.
