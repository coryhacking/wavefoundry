# Red-team delivery-fixes re-check: wave 249as, change 249aq

Reviewer: red-team, fresh context, independent, `execution_status: executed`.
Verdict: fixes 1 to 5 and 8 hold. There is no blocking defect, so I recorded no finding. Two advisories follow.

## Method

- I loaded the MCP tools through ToolSearch. Gapfill: I read the uncommitted hunks with `git diff`, `sed` and `grep`, because the index cannot show them.
- My probes are throwaway scripts in the session scratchpad (`rt/probe_fix.py`, `rt/probe_rej.py`, `rt/probe_ctl.py`). They subclass `test_memory_records._AdmissionCase`, so every probe runs in a temporary repository. Mutants were patched in process. I made no repo edits.
- `run_tests.py --file test_memory_records.py` passed 294 tests. `git status --porcelain docs/agents/memory` was empty afterwards.

## Fix by fix

1. **Stored title and summary on promote and retain.** A `ghp_` token in the stored summary or the stored title is refused on promote and on retain (`secret`), and the token appears nowhere in the response. Known-bad control: with `record_title` and `record_summary` removed from the handler module's check, promote returns `ok` and echoes the token.
2. **Linear markup regex.** At 80k characters of repeated `<invoke `, the old `[^>]*>` pattern took 0.319 s and the full new `memory_line_reasons` took 0.011 s. Six adversarial shapes up to 320k characters stayed at or under 0.06 s. These were `<a:` chains, an unclosed `<aaa...`, `bearer` plus spaces, `<|aaa...` and `<invoke` plus spaces. All five positive markup forms still match.
3. **The 1,024-character cap.** Padded `src/missing.py`, `1zzzz` and `src/a.py` refs block in both roles. A ref of exactly 1,024 characters resolves and one of 1,025 characters is `unresolved`. Control: with the cap lifted, a padded `1zzzz` ref is `unchecked` and passes. Over-cap `symbol:`, `community:` and URI refs stay `unchecked`, as before. A `symbol:` evidence ref was never checked, so this opens no new bypass.
4. **Unterminated leading backtick.** `` `1zzzz ``, `` `src/a.py ``, `` `src/a.py `` with leading spaces, and a bare pair of backticks are each refused with `memory_ref_unresolved` and nothing is written. `` src/a.py` `` (trailing backtick only) and `` `src/a.py` and ` `` are admitted. Each of those still carries a readable closed span.
5. **Line separators.** `memory_single_line` refuses all 11 `str.splitlines` separators, both mid-string and trailing. It accepts a clean reason and the empty string. `render_memory_record` also refuses U+2029. Control: the old CR/LF-only rule accepts U+2028.
8. **Batch cache staleness.** The cached id sets are stale by design once a write follows. A change id for a plan created after the tree was built is `unresolved` with the old tree and `resolved` without it. No handler reuses a tree across a write. In propose, `dry_run` writes nothing. In the validate rewrite, resolution and the anchor check run before the add, and the add builds its own context. The docstring says to build a new tree after a write. Track 4's plan uses one tree per ranked read-only batch and reads only targets.

## Advisories (non-blocking)

1. **Reject and rewrite still echo a stored secret summary.** On a pending record whose summary holds a `ghp_` token, `reject` and `rewrite` both return `ok` with the token in `data.record.summary`. This predates the wave: the HEAD handler already returned `_memory_view(updated)`. Fix 1 was scoped to promote and retain, and it holds as stated. However, the promote refusal tells the agent to "reject the candidate", and that recovery path echoes the secret. The record lint flags the file. A cheap fix is to redact `summary` and `title` in that view whenever the stored content check returns reasons.
2. **The bounded markup pattern misses some long or nested tags.** `[^<>]{0,512}` no longer matches `<invoke name="` followed by 600 characters and `">`, or `<invoke name="a<b">`. The old pattern matched both. The pattern is already case-sensitive, so `<INVOKE` was never caught, and this detection is a heuristic, not a boundary. I accept the trade-off for linear cost. A follow-up could fall back to a cheap `<invoke\b` presence check.
