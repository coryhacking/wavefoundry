# Red-team delivery review: wave 249as, change 249aq

Reviewer: red-team, fresh context, independent, `execution_status: executed`.
Verdict: no blocking defect. I recorded no finding. The advisories below are non-blocking.

## Method

- I loaded the MCP tools through ToolSearch. I read the diffs of `memory_handlers.py`, `memory_records.py`, `wave_lint_lib/constants.py` and `wave_lint_lib/wave_validators.py` against Requirements 1 to 4 and 6 and the carry-forwards.
- Gapfill: I read the diffs with `git diff`, `sed` and `grep` in the shell, because the review targets uncommitted hunks, which the index cannot show.
- For the probes I wrote a throwaway script under the session scratchpad (`probe_rt.py`). It subclasses `test_memory_records._AdmissionCase`, so every probe runs in a temporary repository. There were no repo edits. `git status --porcelain docs/agents/memory` was empty afterwards.
- Known-bad control: I patched `forbidden_content_reasons` so that it drops the `targets` field and then called `memory_add` with target `src/missing.py ghp_<36 generated chars>`. The `memory_ref_unresolved` diagnostic echoed the token (`MUTANT echo detected: True`). On the delivered tree, the same call is refused by the content check and the token appears nowhere in the response (`ECHO4 error False`).
- `run_tests.py --file test_memory_records.py --profile second` reported 0 of 1 files failed. For the default-profile run, see the end of this file.

## Secret echo paths (checked, held)

- `memory_add` and every caller field of `memory_validate`, including `retarget_reason`, run the content check before ref resolution. A refusal names only fields and reason codes.
- On promote and retain, the pending record's stored evidence and targets are content-checked before resolution (carry-forward 2).
- On a rewrite, the stored target `src/gone_ghp_<token>.py` was not echoed (`memory_retarget_reason_required`, `echo: False`). `_anchor_refusal` echoes only the `resolved_path` of a still-resolving target, or a `symbol:` name that already appears in a repository file.
- The record lint prints `reason: <codes>` and does not print the line.
- `memory_propose` returns withheld drafts as `source_event` plus reasons only.

## Advisories (non-blocking)

1. **The stored summary echoes on promote.** A pending record whose summary contains a `ghp_` token is promoted with `status: ok`, and the response includes the token through `_memory_view`. The record also becomes active. This was already true before this wave, and carry-forward 2 scoped the stored check to refs. The record lint now flags such a record, which contains it at the next validation boundary. The planner's census found 0 credential matches in `docs/`. The cheap fix is to add the stored `title` and `summary` to the promote and retain content check.
2. **Overlong refs skip resolution.** An evidence ref over 1,024 characters is `unchecked`. So `src/missing.py <1,100 chars>` and `1zzzz <1,100 chars>` are admitted (`LONGEV ok True`). The bound is deliberate (AC-10 Progress Log row, carry-forward 5), but padding defeats the floor. The fix is to keep classifying the first token, or to refuse an evidence ref over the cap.
3. **"Single line" checks only CR and LF.** A `retarget_reason` that contains U+2028, U+0085, form feed or vertical tab is written. I found no structural injection. A trailing ``Status: `archived` `` still parses as `active`, because the parse regexes anchor on `\n`, and the lint stays clean. However, `str.splitlines()` treats each of these characters as a line break, so the record is not single-line by Python's own definition. Consider refusing any character for which `len(s.splitlines()) > 1`.
4. **The tool-markup pattern is quadratic.** On one line made of repeated `<invoke ` with no `>`, `memory_line_reasons` took 0.023 s at 20k characters and 0.334 s at 80k. The pattern `[^>]*>` rescans the rest of the line from every start position. Input size is bounded only by the request, and the lint runs the same pattern over record files. The fix is to bound the attribute run, for example `[^>]{0,256}>`.

## Bypasses and pathological refs (checked, held)

- Absolute paths, drive-prefixed paths, `..`, `.` and empty components are rejected before the disk is read.
- The case-exact check works on the case-insensitive macOS file system, so `Node_Modules/...` stays unresolved.
- Backslashes are normalized, which keeps Windows-form `node_modules\dep` untrusted.
- `.wavefoundry/work/` and `.wavefoundry/cache/` refs are flagged as untrusted.
- A `./.wavefoundry/work/...` ref is unresolved and blocks, so it cannot hide as trusted.
- URIs are classified before any path test.
- High-entropy strings that match no listed credential shape still echo in `memory_ref_unresolved`. This is expected from the spec's pattern-based design, and the full scanner is out of scope.

Default-profile `run_tests.py --file test_memory_records.py`: 289 tests OK (after waiting out a concurrent run lock).
