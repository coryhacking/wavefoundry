# qa-reviewer focused readiness verification, round 2, wave 249as (change 249aq)

Fresh, independent context (`249as-qa-reviewer-focused-r2`). No repository edits. Every probe ran on a scratch copy of the tree in the session scratchpad (`qa249/base`, its own git baseline). Receipt reviewed: `review-policy-38ca5d622848eb76df68`.

## Verdict

Both qa findings are repaired. Readiness approval recorded. There is one count correction and one ordering note; neither blocks.

## Probe

The probe is a scratch approximation of Requirement 1 (`probe_resolve.py`). It covers the path-form rule with suffix stripping and the extension list, case-exact component matching, and line checks. It also covers wave ids, change and memory stems, symbol targets, `suffix_only` target blocking, and `unchecked` for everything else.

It was enforced in three places:

- in `_memory_add_response_locked`, after the content scan;
- in `memory_validate`, on the pending record's targets and evidence for promote and retain only (rewrite is left to the add path);
- in `_memory_file_target_exists`, by delegation.

A second variant added the Requirement 6 anchor rule.

Baseline on the unchanged copy: `run_tests.py --file test_memory_records.py --file test_lifecycle_mutation_lock.py` gave 332 OK.

## qa-249as-rewrite-gone-target-unreachable: repaired

Requirement 2 now checks only `rewrite_targets` and `rewrite_evidence` on a rewrite. Requirement 6 counts `resolved` or `suffix_only` originals as still resolving, compared by resolved path. AC-7 states an outcome for every case.

The probe test (`test_zz_qa249_probe.py`, scratch copy only) gave these results.

Patched copy:

- the `src/gone.py` rewrite reaches the anchor rule, giving `memory_retarget_reason_required` without a reason, and passes it with a reason;
- `src/a.py` plus `src/missing.py` rewritten to `[src/a.py, pkg/one/util.py]` writes;
- dropping the anchor gives `memory_rewrite_anchor_dropped`;
- a suffix-only `a.py` rewritten to `src/a.py` writes;
- a promote of `src/gone.py` is refused.

Unpatched copy (the known bad): every gone or missing case gives `memory_target_not_current`.

Note: when a rewrite has no reason and also an unresolved replacement, the spec does not fix which diagnostic wins. AC-7 tests only the case with a reason, so this does not block.

## qa-249as-unnamed-test-breakage: repaired, count correction

The probe fails 41 test ids: 37 in `test_memory_records.py` and 4 in `test_lifecycle_mutation_lock.py`. 40 of them match the Tasks list.

- **Named but passing:** `SecretScanCoverageTests.test_secret_in_title_or_targets_is_refused_without_side_effect`. It passes because the content scan runs before ref resolution.
- **Failing but not named:** `MemoryAgentValidationTests.test_promote_retain_and_reject_persist_compact_judgment`, in its promote and retain subtests. Requirement 2 now checks the pending record's evidence on promote and retain, and the class's `_candidate` helper cites wave id `1aaaa`, which the fixture never creates.

So the true count is 42. The extra test is in a named file and class, and the stated fixture approach (create the stems the fixtures cite) repairs it. The implementer should add it in the first Progress Log row.

The anchor rule adds no failures. With every ref forced to resolve, the anchor rule alone broke nothing. The one failure in that variant came from disabling the missing-target check, not from the anchor rule.

All other files that call these paths pass under the probe:

| File | Result |
| --- | --- |
| `test_memory_backfill.py` | 52 OK |
| `test_archive_memory_backfill.py` | 9 OK |
| `test_memory_eval.py` | 48 OK |
| `test_handler_modules.py` | 13 OK |
| `test_render_agent_surfaces.py` | 241 OK |
| `test_storage_upgrade_resume.py` | 20 OK |

Ordering note: the content scan must run before ref resolution. Otherwise a `memory_ref_unresolved` diagnostic that names the ref would echo a secret-bearing target such as `config.py password: ...`. The secret test pins this ordering, and the spec should say so at implementation.

## Claim: 10 test_storage_upgrade_resume.py tests fail on the unchanged tree

The failures are an artifact of the runner, not a real defect.

- `python3 -B -m unittest discover -s tests -p test_storage_upgrade_resume.py` on the unchanged copy: 7 failures and 3 errors. Every one traces to `ModuleNotFoundError: No module named 'numpy'` in the setup child, surfacing as "Semantic index update exited 1". The plain `python3` is Homebrew 3.14, which lacks the tool dependencies.
- `run_tests.py --file test_storage_upgrade_resume.py` runs its workers with the tool venv interpreter (`_test_runner_python`). It gave 20 of 20 OK on the unchanged scratch copy, on the real tree and on the probe-patched copy.

The planner's conclusion (not attributable to this change) holds, but its evidence used the wrong runner. The Progress Log sentence should cite the `run_tests.py --file` result instead.

## Concurrence

The open architecture finding `arch-249as-path-form-truncates-spaced-paths` is a real qa concern too. This repository's wave paths contain spaces, and the AC-1 fixture itself uses `docs/waves/1abcd fixture/wave.md`. Its repair will rotate the receipt, which lapses this approval.

## Cross-spec agreement

Both specs use the same states: `resolved`, `suffix_only`, `ambiguous`, `unresolved` and `unchecked`, with `resolved_path` on `suffix_only`. Symbol targets have the states `resolved`, `unresolved` and `unchecked`. 249ar maps each state exhaustively and reads `state`, not `blocking`. The signature `resolve_memory_refs(root, *, evidence=(), targets=(), tree=None)` matches.
