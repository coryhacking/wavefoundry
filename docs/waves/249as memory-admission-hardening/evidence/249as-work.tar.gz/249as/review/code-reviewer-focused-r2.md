# Code-reviewer focused readiness round 2, wave 249as (change 249aq)

Reviewer: code-reviewer, fresh and independent context `249as-code-reviewer-focused-r2`. Receipt `review-policy-38ca5d622848eb76df68`.

## Verdict

Both owned findings are repaired and cleared. The code-reviewer readiness approval is withheld while `arch-249as-path-form-truncates-spaced-paths` is open: that defect is real and this lane reproduced it independently.

## cr-249as-rewrite-pending-refs-contradiction: repaired

- Requirement 2 now checks a rewrite only on `rewrite_targets` and `rewrite_evidence`. The handler requires both (`memory_handlers.py:1432-1435`), so the new record's refs are exactly those.
- `memory_target_not_current` is replaced by `memory_ref_unresolved`.
- Every AC-7 case has an outcome. AC-7.3 settles that a `suffix_only` original counts as resolving, compared by resolved path, which matches Requirement 6.
- Executed known bad: a hermetic `_MemoryCase` fixture (scratchpad `cr249r2/rewrite_probe.py`), candidate targeting `src/a.py` and `src/missing.py`, rewritten to `[src/a.py]` on the unchanged tree. Result: `error`, `memory_target_not_current`, `missing_targets: ['src/missing.py']`, as AC-7.6 states.

## cr-249as-evidence-path-form-undefined: repaired

Requirement 1.1 now defines which refs are paths, and AC-1.3 pins the `:name`, `::name`, comma-list and dotted-id cases. The round-1 examples classify as intended.

## Path-form probe on the live active corpus

Scratchpad `cr249r2/probe.py` reimplements Requirement 1.1 and 1.2. It ran read-only over the 174 active records. `git status --porcelain docs/agents/memory` was empty before and after.

| Evidence refs | Count |
| --- | --- |
| Total | 608 |
| Resolved as path refs | 60 |
| Path refs that pass: `resolved` 40, `suffix_only` 10 | 50 |
| Path refs that fail | 10 |

The 10 failures sit on 8 records:

- 4 cite a line past the end of the file. This is genuine drift in `server_impl.py` and `test_server_tools.py`.
- 1 is `ambiguous`: `server_impl.py:6962-6968 early return`.
- 5 are `unresolved`, but each names an existing file under a wave folder whose name contains a space. The first-whitespace-token rule truncates them, for example `docs/waves/241c3 writing-guide-sentence-structure/evidence/README.md`.

Targets hit the same truncation. 6 active targets name existing spaced paths: wave evidence files and ADRs under `docs/architecture/decisions/`. Under the spec rule there are 9 unresolved targets on 13 records. With whole-ref resolution there are 3 unresolved targets on 7 records.

This is `arch-249as-path-form-truncates-spaced-paths`, already recorded by architecture. I did not open a duplicate. A fix must still split annotated refs such as `index_state_store.py begin_build_epoch disjuncts`. One option: try the whole ref, after stripping the suffix, as an exact path first, then fall back to the first token.

## Non-blocking

- Requirement 1.1 classifies anything containing `/` as a path, but Requirement 1.5 and AC-1.2 call URLs `unchecked`. The implementation must test for a URI scheme before the `/` test. The corpus has 0 URL evidence refs today.
- "Strip at most one trailing suffix" and "`::Class::test` also strips" read as a conflict. The implementation should strip the whole `(::name)+` run.
