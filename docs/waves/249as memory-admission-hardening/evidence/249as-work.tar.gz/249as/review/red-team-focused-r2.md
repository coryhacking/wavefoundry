# Red-team focused reverification, round 2: wave 249as (change 249aq)

Seat: red-team, fresh and independent context `249as-red-team-focused-r2`. No repository edits, no memory-record changes. Probes live in the session scratchpad under `rt-r2/` (`pathform.py`, `patterns.py`, `spaces.py`). They reimplement the repaired spec text, since no code exists yet. I record no approval.

## Verdict

`249as-rt-path-form-unspecified`: the repair holds. Reverification recorded with `blocking_required_lanes=[]`.

## Path form (Requirement 1.1)

Executed against hand cases and the active corpus (174 records):

- Not path refs, so `unchecked`: `test_memory_records.MemoryToolTests.test_x`, `test_a.AlphaTests.test_alpha`, `qa-249as-some-finding`, `wave_lint_lib.constants`, `memory_records.resolve_memory_refs`. In the corpus, all 32 dotted test ids classify as `unchecked`.
- Suffixes strip as written: `mcp_tool_roster.py:34,52,150` becomes `mcp_tool_roster.py`, `src/a.py:1-2,4` becomes `src/a.py`, `test_x.py::test_y` becomes `test_x.py`, and `src/a.py:Cls.meth` becomes `src/a.py`. The one corpus comma list and the one corpus `::` node id both strip.
- The round-1 known bad is detected: a first-token rule that treats every name with an extension as a path turns the 32 dotted ids into unresolved paths.

Non-blocking notes for the implementer:

1. `::Class::test` strips only if the suffix pattern is `(::name)+`. The text also says "at most one trailing suffix". A single-strip implementation leaves `tests/test_x.py::Cls`, which is unresolved. The corpus has 0 such refs today and no AC-1 fixture covers it.
1. A URL contains `/`, so the path-form rule alone would make `https://example.com/x` a path. Requirement 1.4 and AC-1 make it `unchecked`. The precedence is pinned only by AC-1.
1. AC-6 evidence `node_modules/dep/index.js` is a path ref and blocks when it is missing. The AC-6 fixture must therefore create that file for the record to be written.

## Credential and control-token patterns (Requirement 3)

Executed with generated tokens:

- Every named shape matches: `sk-ant-` in its real `api03` form and in the AC shape, `sk-proj-` in its real form and in the AC shape, `AIza` plus 35 characters, `glpat-`, `npm_` plus 36 characters, and `Authorization: Bearer` with both an opaque token and a JWT.
- Tool markup matches: `<function_calls>`, `</function_calls>`, `<invoke name="x">`, `<invoke name='x'>`, `</invoke>`, `<tool_call>`, `<tool_use>`, and `Human:` on a second line.
- All 7 AC-4 negative controls match nothing. So do 4 extra negatives: `Bearer tokens are refused`, `AIzaSy is a Google prefix`, `sk-project-level settings`, and a long `npm_config_...` name.
- Across 226 memory files, the new patterns match 0 lines, so the record lint does not fail on existing records.

Residual gaps, which the Risks table should name next to the shapes it already lists: lowercase `authorization: bearer` and `BEARER`, namespaced tool markup such as `<ns:invoke ...>` and `<ns:function_calls>`, `<parameter ...>`, an indented `Human:` line, and a bare `<invoke>`.

## Independent confirmation of `arch-249as-path-form-truncates-spaced-paths` (owned by architecture)

`spaces.py` checked this defect. The first-whitespace-token rule cuts down a path that contains a space. On this repository, 3,608 of the 5,158 walked files have a space in their path: every wave folder, every plan, every ADR and every memory record. Effects:

- Six active records have a target that is an existing file but that the rule classifies as `unresolved`, for example `docs/architecture/decisions/1ye5y-adr flat-sibling-tool-registry.md`.
- So 6 of the 13 `target_unresolved` records predicted in 249ar AC-11 are false.
- The current `_memory_file_target_exists` returns True for both of the spaced targets I probed, so this is a regression.
- Under 249aq, a new admission or retarget that names any wave or plan document would be refused.

I did not record a second finding because the architecture lane already owns this one. The 249ar keep refusal and rank 0 inherit the defect through the primitive.
