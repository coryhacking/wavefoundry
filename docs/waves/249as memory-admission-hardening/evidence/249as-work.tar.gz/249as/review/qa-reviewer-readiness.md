# qa-reviewer readiness notes, wave 249as (change 249aq)

Fresh, independent context. No repository edits. Probes ran on a throwaway copy under the session scratchpad.

## Verdict

Not ready. There are two blocking findings, both cheap spec fixes.

## Verified against the code

- Three scan loops exist at `wf_server/memory_handlers.py` 584 (add), 990 (propose create) and 1446 (validate). `MEMORY_DISALLOWED_PATTERNS` is `JOURNAL_DISALLOWED_PATTERNS` plus one personal-fact pattern. The lint at `wave_validators._memory_forbidden_match` scans each line, so the line-start `Human:` rule works there.
- `_memory_file_target_exists` (1350) skips `symbol:`/`community:`, accepts `root/target` via `is_file()` and otherwise uses an rglob suffix match. memory_validate checks only `target_refs` (1509), never evidence or `rewrite_*`.
- `memory_brief_response` pads with `matched + unmatched` (1955). The pin `test_brief_remains_queryless_and_exact_target_promoted` (test_memory_records.py 4506) expects `["mem-target", "mem-unmatched"]`. The AC-8 known bad holds.
- `no_memory_matches` names `memory_add` as recovery (1893).

## Known-bad probe (AC-1.4)

I ran today's `_memory_file_target_exists` on the AC-1 fixture (macOS). `src/a.py:4` is False, `util.py` is True, `a.py` is True, `Src/A.py` is True, and `src` and `src/missing.py` are False. The claim that `src/a.py:4` passes is false. The known bad still fails the test through `util.py` and `a.py`, so this is a correction, not a blocker.

## Finding qa-249as-rewrite-gone-target-unreachable (blocking)

Requirement 2 runs the primitive on the pending record's own targets for every verdict, `rewrite` included. Requirement 6 says that when none of the original targets resolves, any resolving new target is accepted. Under Requirement 2, a pending candidate whose only target is `src/gone.py` is always refused with `memory_ref_unresolved`, so that branch of Requirement 6 can never run in memory_validate. Today's code also refuses this case (`memory_target_not_current`). AC-7 sentence 3 says only "reaches the ref check rather than the anchor check". That passes for either outcome and does not say whether the rewrite succeeds. The Risks row ("a rewrite that needs a new target because the old one is gone stays possible") assumes it succeeds.

Fix: decide whether the source record's targets are checked on `verdict="rewrite"`. Then make AC-7 sentence 3 state the outcome (written, or `memory_ref_unresolved` naming `src/gone.py`). Also say whether a `suffix_only` original target counts as "resolving" for the anchor rule, compared through `resolved_path`. Most existing bare-name records hit that case, and AC-7 does not test it.

Ledger note: this finding was recorded with the default `execution_status: executed`. The honest value is `inferred`, because the claim rests on reading the spec and code, not on a run. It cannot be amended in place. Reverification should treat it as inferred.

## Finding qa-249as-unnamed-test-breakage (blocking)

The spec names the brief pin and "any backfill fixture". I probed the target part of Requirement 2 alone: the add path refused any non-symbol target that is not an exact file. Under the default profile this failed 33 existing tests (24 failures and 4 errors, with subtests) in `test_memory_records.py` and `test_lifecycle_mutation_lock.py`. They include `test_add_search_brief_reconcile_flow`, `test_add_with_supersedes_marks_old_record`, the `MemoryAddDuplicateDiagnosticTests`, the `SeqlockCoherenceTests`, the `GenerationCacheTests`, the `TwoProcessCacheCoherenceTests` and the consolidation rollback tests. `_MemoryCase` creates no `src/a.py`, and many calls use targets such as `["t"]`. No backfill test failed. Evidence enforcement would add more failures, because `_add` writes the default evidence `` `1abcd-bug some-change` `` and no such plan exists. `test_lifecycle_mutation_lock.py` is not in Serialization Points or Tasks.

Fix: name both files in Tasks and Serialization Points, and say how fixtures change. Either `_MemoryCase` creates the target files and plan stems, or the tests use resolving refs.

## Measurement

- The replay is honest. It is read-only, covers every record in every status, and the `git status` check guards it.
- The targeted-brief after-count is 0 by construction. The informative number is the before-count. The file selection uses "no active record targets", but the brief also surfaces `candidate` records. The selection should use the brief's own statuses and `match_targets`, or the after-count can be nonzero for a candidate-targeted file.
- The frozen-set control is correctly a control.

## Size

The change is large: 12 ACs and six workstreams. They all sit on one admission path, and the first outcome is named, so the size is acceptable.

## Tests run (unchanged tree)

`run_tests.py --file test_memory_records.py --file test_memory_eval.py --file test_memory_backfill.py --file test_archive_memory_backfill.py`: 372 tests OK under the default profile. The same set under `--profile second`: 0 of 4 files failed.
