# code-reviewer: delivery-fixes re-check (wave 249as)

Verdict: APPROVE. All eight fixes are present and behave as claimed. No blocking defect.

Context: fresh, independent; I did not implement any fix. Probes ran in a throwaway copy of `.wavefoundry/framework` under the session scratchpad (`tests/test_zz_cr_probe.py`, 6 tests OK). No repo edits, no `wf_memory_eval`, no writes under `docs/agents/memory/`, no stray `__pycache__`.

Focused runs in the working tree:
- `run_tests.py --file test_memory_records.py`: 294 tests OK, 0 skipped.
- `run_tests.py --file test_lifecycle_mutation_lock.py`: 69 tests OK, 0 skipped.

| # | Fix | Probe result | Known-bad control |
| --- | --- | --- | --- |
| 1 | Stored title and summary content-checked on promote and retain | Pending record with a `ghp_` token in its title: promote and retain both return error, `rejected_reasons=['secret']`, token absent from the response, record bytes unchanged | Patched the handler's `forbidden_content_reasons` to ignore `record_*` fields: promote returned `ok` and the token appeared in the response |
| 2 | Tool-call markup regex bounded and linear | `"<invoke " * n` at n=2000/4000/8000: 0.2/0.4/0.8 ms (linear); a 200k namespace run 0.1 ms; positives still match | Same pattern with `[^>]*`: 13/51/202 ms (quadratic) |
| 3 | Refs over 1,024 characters are `unresolved` and block | 1,025-character ref starting with an existing path: `unresolved`, 1 blocking; `memory_add` refuses with `memory_ref_unresolved`, nothing written | 1,024-character ref of the same shape: `resolved`, 0 blocking |
| 4 | Unterminated leading backtick refused | `` `src/a.py ``, `` `1abcd ``, and a space-led form: `memory_ref_unresolved`, not written | `` `src/a.py` `` writes |
| 5 | `retarget_reason` refuses every Unicode line and paragraph separator | `memory_single_line` false for U+2028, U+2029, U+0085, VT, FF, U+001C-U+001E, CR, LF; `render_memory_record` raises; repo test covers both handlers | Plain `a b` passes |
| 6 | Supersede test asserts the ref name | `test_supersede_cases` asserts `src/also-gone.py` in the diagnostic | Read only |
| 7 | 22 `from wf_server import server_impl` sites converted | HEAD had 22; tree has 0 of the old form and 24 of the new (2 in new helpers) | Both handler test files pass |
| 8 | Supplied tree caches record ids | Results with a shared tree, repeated, and with no tree are identical; `tree.ids` populated; repo test shows one record load across 50 calls | Untreed result equals treed result |

Advisory (non-blocking, not introduced by these fixes): a backtick-led value with a closed span and an unterminated tail, such as `` `src/a.py` and `src/missing.py ``, is admitted. The dangling tail is not checked. The reader extracts the same closed spans, so the stored record matches what was checked, and the unchecked tail is annotation.

Limitations: macOS only; Windows path handling for these fixes was not executed. Timing figures are from one machine.
