# Code-reviewer focused readiness round 3, wave 249as (change 249aq)

Reviewer: code-reviewer, fresh and independent context `249as-code-reviewer-focused-r3`. Receipt `review-policy-1c51f95cd62f929bce87`.

## Verdict

Ready. No new blocking defect. Repair 2 closes the spaced-path truncation this lane reproduced in round 2. Approval recorded on the current receipt.

## Executed probe

Scratchpad `cr249r3/probe.py` reimplements Requirement 1 as repair 2 states it: URI check first, `symbol:`/`community:`, longest exact-file prefix with the whole `:`/`::` suffix chain stripped, digit-bearing wave id, first-token fallback, and the pruned `memory_ref_tree` walk. No repository edit. `git status --porcelain docs/agents/memory` was empty before and after.

### AC-1 fixture

I built the AC-1 fixture tree in the scratchpad and ran every AC-1 target and evidence case, except the change-id and `symbol:` rows, which need the record-stem and identifier checks. All 34 cases give the state and `resolved_path` that AC-1 states. Examples:

- `docs/waves/1abcd fixture/wave.md:1 first line` resolves to the spaced file.
- `src/a.py begin_alpha notes` resolves to `src/a.py`.
- `src/a.py::AlphaTests::test_alpha` resolves.
- `https://example.com/src/a.py` is `unchecked`.
- `tests` and `fixed` are `unchecked`.
- The bare target `index.js` is `unresolved` because `node_modules` is pruned.
- `src/a.py:1,4` is `unresolved`.

The `blocking` set implied by these states matches AC-1 item 6.

### Live corpus (174 active records)

| Role | State | Refs |
| --- | --- | --- |
| target | resolved, by exact prefix | 286 |
| target | suffix_only | 73 |
| target | ambiguous | 4 |
| target | unresolved | 3 |
| target | symbol, not checked by the probe | 3 |
| evidence | resolved path | 45 |
| evidence | suffix_only | 10 |
| evidence | path unresolved (line past end) | 4 |
| evidence | ambiguous | 1 |
| evidence | wave id resolved / unresolved | 148 / 1 (`240wz`) |
| evidence | change or memory id, not checked | 74 |
| evidence | unchecked | 325 |

Every spaced wave, evidence and ADR path that round 2 found truncated now resolves. The remaining failures are genuine:

- 4 evidence refs cite lines past the end of `server_impl.py` and `test_server_tools.py`.
- `server.py` and `server_impl.py` are ambiguous bare names.
- `docs/waves` and `docs/waves/` are directories.
- `tests/eval/run_memory_eval.py` is missing.

The whole run takes 0.13 s, including the walk of 4,791 files.

Known-bad control: the same probe with the longest-prefix step disabled (`probe_firsttoken.py`, which is the first-token rule) leaves 5 spaced evidence refs and 6 spaced targets unresolved. That reproduces the round-2 defect, and repair 2 removes it.

### Content patterns

I compiled the Requirement 3 patterns and ran them against the AC-4 positives and negative controls. Every positive matches, including the case-insensitive bearer and the namespaced tool-call forms. No negative matches, including `<invoker>` and `a bearer of bad news`. Across `docs/`, the only lines that match are in this wave's own spec and `events.jsonl`, which quote the tokens. A future proposal from those lines is withheld by reason, which is what the spec intends.

### Other checks

- `memory_line_reasons(line, exempt_end=None)` reproduces today's `_memory_forbidden_match` rule (`wave_validators.py:151`), which ignores only a match that ends at `exempt_end`.
- `MemoryAgentValidationTests.test_promote_retain_and_reject_persist_compact_judgment` exists (`test_memory_records.py:4891`). The Tasks list sums to 42.

## Agreement with 249ar (spec 246to)

The five states and `resolved_path` are unchanged. 249ar reads `state`, not `blocking`, and its AC-3 fixture is consistent with the repaired rules.

Advisory: 249ar AC-11 predicts 13 `target_unresolved` records, a figure derived under the first-token rule. Under repair 2 my probe gives 7 records: 3 unresolved and 4 ambiguous targets. AC-11 already says the implementer re-derives the figure and states any difference, so no text change is required.

## Non-blocking advisories

1. When a rewrite both drops its anchor and names a blocking ref, Requirements 2 and 6 do not say which refusal comes first. AC-2's `util.py` rewrite fixes the order implicitly as resolution first. The implementation should state the order: content check, then resolution, then the anchor check.
1. On `promote` and `retain`, `memory_ref_unresolved` names refs from the stored pending record, not from caller fields. The content check in Requirement 2 covers caller fields only. Only a target can echo text, because an evidence ref with no path shape is `unchecked` and never named. With the new lint patterns, a stored pending record that holds a credential also fails docs lint. The risk is negligible, but delivery should check that a pending target holding a secret is not echoed.
1. When no exact-file prefix exists, the target `docs/waves/1abcd fixture/missing.md` falls back to the first-token form. The ref is still reported `unresolved` under its full text, which is correct. The internal candidate path is truncated, so the suggestion and diagnostic text should use the full ref.
