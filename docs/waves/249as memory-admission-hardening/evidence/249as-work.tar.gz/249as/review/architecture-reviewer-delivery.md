# Architecture reviewer, delivery (wave 249as, change 249aq)

Context: `249as-architecture-reviewer-delivery`, fresh and independent. Verdict: approve, no blocking defect. Three advisories below.

Retrieval: MCP tools loaded through ToolSearch. Gapfill: shell `grep`/`sed` read the handler, upgrade-extension and memory_records ranges after the change sites were known, because the reads spanned several large contiguous blocks.

## AC-10, the primitive contract for 249ar

- `resolve_memory_refs(root, *, evidence=(), targets=(), tree=None)` and `memory_ref_tree(root) -> MemoryRefTree` are public in `memory_records.py` and match the Progress Log contract row: `refs` entries `{ref, role, form, state, resolved_path?}`, `blocking` (entries), `untrusted` (ref strings), five states in `MEMORY_REF_STATES`.
- 249ar's spec reads target `state` only and builds one tree per ranked batch, which this contract supports. Its Decision Log row still says "a ref in `blocking` sets `target_unresolved`", while Requirement 1 and the 249ar wave record say `state`; that is 249ar's own text to reconcile, not this change.
- Executed: a read-only probe over the 197 records of this repository with one tree. Targets only, the 249ar call shape: 0.09 s, 0 `load_memory_records` calls, states resolved 323, suffix_only 74, ambiguous 4, unresolved 3, matching the AC-11 replay figures. With evidence: 12.6 s and 170 `load_memory_records` calls.
- `MemoryRefResolutionTests.test_batch_of_fifty_records_walks_once` asserts one walk; passed in the focused run.

## `contained_files` upgrade-bootstrap exclusion

- `memory_records` imports `contained_files` lazily in `_RefContext.exact_file` and `_ref_entry_is_link` (Windows only), both reached only from `resolve_memory_refs`/`memory_ref_tree`. No function in `memory_records` that the bootstrap uses calls them: `memory_backfill` calls `load_memory_records` and `resolve_migrated_memory_id` only, and the only in-module caller of `memory_ref_tree` is `_RefContext.tree`.
- Executed probe on a scratch copy: an old runner's `contained_files` stub lacking `judge_contained_file` and `_is_link_metadata` was placed in `sys.modules`; `upgrade_extensions._installed_memory_backfill` reloaded the bootstrap set, `load_memory_records` and `resolve_migrated_memory_id` ran, the stub stayed untouched, and `resolve_memory_refs` alone raised `AttributeError` on the stub. So a stale copy can exist in an old runner, but no bootstrap path reaches it.
- Known-bad control: a scratch mutant whose `load_memory_records` calls `resolve_memory_refs` made the same probe fail with `AttributeError: module 'contained_files' has no attribute 'judge_contained_file'`.
- After the upgrade, the MCP server loads `contained_files` fresh, and `wf_reload_mcp` lists `contained_files` and `wave_lint_lib` in its reload set (`server_impl.py`), so the memory tools never run the resolver against an old copy. `contained_files.py` is unchanged by this wave.
- The census test `test_every_framework_import_of_the_bootstrap_modules_is_reloaded_or_excluded` passed.

## Worktree stopgap scope

- The walk skips a non-root directory holding a `.git` entry, file or directory, before reading its children; the `.wavefoundry/` rule applies at the root only.
- Executed on a scratch tree with `.claude/worktrees/w1/` holding a `.git` file: bare `b.py` stays `suffix_only` to `pkg/b.py`, and `only.py`, present only in the worktree, is `unresolved`. Known-bad: a scratch mutant without the `.git` check returned `ambiguous` and `suffix_only` to the worktree file.
- The scope is the bare-name tree only. An exact path into a nested checkout still resolves from disk, as Requirement 1 states.

## Advisories (not blocking)

1. Batch evidence cost. `_RefContext.ids()` is per call, so each evidence id lookup reloads every memory record and rediscovers the wave folders; `tree` amortizes only the walk. Admission is one record, and 249ar uses targets only, so no shipped path is quadratic. `memory_propose` dry run resolves up to 20 drafts with evidence, around 1.5 s at this repository's size. A later batch evidence caller would need an id cache in the tree or context.
2. `ids()` swallows every exception, so a broken record-root layout makes every wave, change and memory id `unresolved`. That fails closed for admission. A future evidence-reading signal should be aware of it.
3. The exclusion reason names only `resolve_memory_refs`; `memory_ref_tree` is a second public entry to the same lazy import. The reason is still true, since the bootstrap calls neither. Also, the census test keys on file stems, so a lazy `wave_lint_lib.constants` import (in `forbidden_content_reasons`) is not counted. The bootstrap does not reach that function either.

## Commands

- `run_tests.py --file test_upgrade_wavefoundry.py --file test_memory_records.py`, default profile and `--profile second`.
- Scratch probes under the session scratchpad: `batch_probe.py` (read-only, repo), `stale_probe.py` plus its mutant, `wt_probe.py` plus its mutant. `git status --porcelain docs/agents/memory` was empty.
