# Architecture reviewer, focused readiness round 2, wave 249as

Reviewer: architecture-reviewer, fresh and independent context `249as-architecture-reviewer-focused-r2`, 2026-11-23.
Scope: the changed sections of `249aq-enh memory-admission-hardening` on receipt `review-policy-38ca5d622848eb76df68`. No repo edits, no memory mutations. Probes ran in the scratchpad.

## Verdict

Approval withheld. One new blocking finding: `arch-249as-path-form-truncates-spaced-paths`. Everything else in the repair holds.

## New blocking finding: the path form cannot name a path with a space

Requirement 1.2 keeps only the first whitespace-delimited token of a ref and treats the rest as annotation. The framework names wave folders, change docs and ADRs `<id> <slug>`, so their paths contain spaces.

Executed probe (scratch script applying the Requirement 1.2 rule to every active record's refs):
- 12 refs on active records (6 targets, 6 evidence) name an existing file when the whole backticked ref is used.
- Under the first-token rule, all 12 fail exact resolution and have no unique suffix match. Examples: `docs/architecture/decisions/1yb8v-adr record-layout-config-over-resolver-protocol.md` and `docs/waves/241c3 writing-guide-sentence-structure/evidence/README.md`.
- Fixture `docs/architecture/decisions/1abcd-adr some-choice.md`: the first token `docs/architecture/decisions/1abcd-adr` is not an exact file and has no suffix match, but the whole ref is exact.

Effect:
- A new record or rewrite anchored to any ADR, change doc or wave evidence file is refused with `memory_ref_unresolved`, with no way to express the path.
- 249ar reads the same state, so it would flag such existing targets `target_unresolved` and refuse their keep.

A plain whole-ref rule is not the fix either, because annotated refs such as `render_platform_surfaces.py:1324-1360 (corrected docstring)` need the split.

Suggested repair (docs only):
- Take the longest whitespace-joined prefix of the ref that, after one suffix strip, is an exact contained file, and fall back to the first token.
- Add an AC-1 fixture with a spaced path, for example the existing `docs/waves/1abcd fixture/wave.md` as a target and `docs/waves/1abcd fixture/wave.md:1 note` as evidence.
- 249ar needs no text change.

## Repair items that hold

- **Fit with the primitive interface.** The states agree with 249ar: `resolved`, `suffix_only`, `ambiguous`, `unresolved` and `unchecked`. 249ar's 2026-11-24 Decision Log reads `state`, not `blocking`, which settles my round-1 cross-wave note. 249ar's older row saying "a ref in `blocking` sets `target_unresolved`" is superseded by its own later row. That row belongs to 249ar's lanes.
- **Rewrite retarget path.** Checking only the new record's refs, keeping an original target that still resolves, and otherwise requiring resolving replacements plus `retarget_reason` makes the gone-target branch reachable. Comparing targets by resolved path handles the `a.py` to `src/a.py` case. Consolidation through `_memory_add_response_locked` is covered by the Risks row.
- **Shared line checker.** `memory_line_reasons` in `wave_lint_lib/constants.py` keeps one reason vocabulary, and the lint stops printing the line. Advisory: today's `_memory_forbidden_match` exempts a match by its end offset (`match.end() != exempt_end`). A checker that returns only reason codes cannot apply that rule, so it needs an `exempt_end` argument or must return spans.
- **Portability.** The component spelling check is executed on macOS APFS: `Path.is_file('Src/A.py')` is True, while the component check gives False for `Src/A.py` and True for `src/a.py`. That covers Windows, macOS and WSL2 on `/mnt/`. Normalizing `\` and counting lines with universal newlines is right. The spaced-path defect applies on every platform.

## Advisories (non-blocking, from round 1, still open)

- URL ordering: `https://example.com/x` contains `/`, so the URI-scheme check must run before the path-form test. AC-1 pins the outcome.
- A five-letter word used as evidence, such as `tests`, is read as a wave id and blocks. The `lifecycle_id` grammar is `{5,6}`.
- The walk does not prune dependency trees. The NFC/NFD limitation on macOS is still unrecorded.
