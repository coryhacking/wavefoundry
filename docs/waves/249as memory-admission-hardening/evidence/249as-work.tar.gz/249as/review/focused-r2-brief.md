# Focused readiness verification, round 2 (waves 249as and 249ar)

Both specs were repaired once, in docs only. The repair contexts are `249as-planner-repair-1` and `249ar-planner-repair-1`, both cycle 1. Each repair applies coordinator decisions recorded in its spec's Decision Log.

Current receipts:
- 249as: `review-policy-38ca5d622848eb76df68`
- 249ar: `review-policy-4ed936f0857f3aed8580`

## 249as (`249aq`)

Findings:
- `249as-rt-path-form-unspecified` (red-team)
- `qa-249as-rewrite-gone-target-unreachable` (qa)
- `qa-249as-unnamed-test-breakage` (qa)
- `cr-249as-rewrite-pending-refs-contradiction` (code)
- `cr-249as-evidence-path-form-undefined` (code)

Decisions:
- **Path refs.** A ref is resolved as a file only when, after stripping `:line`, a line range, a comma list or a `:symbol` suffix, it contains `/` or ends in a known extension. For `file.py:symbol`, the file must exist. Test ids, finding ids and slugs pass.
- **Rewrite resolution.** Resolution is checked on the NEW record. A rewrite keeps a resolving original target, or else supplies a resolving replacement together with a `retarget_reason`.
- **Broken tests.** All 41 broken tests are named: 37 in `test_memory_records.py` and 4 in `test_lifecycle_mutation_lock.py`, which is now a Serialization Point. The brief-padding pin also changes.
- **Credential patterns.** The new patterns are `sk-ant-`, `sk-proj-`, `AIza`, `glpat-`, `npm_`, Bearer tokens and tool-call markup.
- **Residual risk.** Accepted: a ref that resolves but is irrelevant.

## 249ar (`246to`)

Findings:
- `blocking-contract-mismatch` (docs-contract)
- `249ar-rt-bare-target-churn-blind` (red-team)
- `qa-249ar-keep-note-breaks-candidate-paths` (qa)
- `qa-249ar-eval-ids-break-aggregate-only` (qa)
- `cr-249ar-blocking-semantics-contradiction` (code)

Decisions:
- **Flags come from each ref's resolution state.**
  - A missing target, or an ambiguous suffix, sets `target_unresolved`: the keep is refused and the record goes first in the audit.
  - A unique bare-name or suffix match sets `target_not_canonical`: the keep is allowed and the record is ranked after churned ones.
  - Counts on this repo: 13 unresolved and 36 not canonical, so 47 records have either flag.
- **Churn.**
  - It is computed on the resolved canonical path.
  - A check writes a full ISO timestamp, and churn counts only commits after it.
  - 97 of 174 records cross the threshold today, measured from the day-granular `Updated:` date.
- **`check_note`.** It is required only for a keep of an already-active record. A candidate promotion is admission, which belongs to 249as. Eight guidance places were updated.
- **`wf_memory_eval`.** It reports only the count of uncoverable records. The ids come from a maintenance helper.
- **Residual risk.** Accepted: a trivial `check_note`. The blob-hash-per-check alternative was declined.

## Your task, as a FRESH, independent reviewer of your lane on each wave you cover

1. **Read.**
   - Load MCP tools via ToolSearch first, and use code_* MCP-first.
   - Read your lane's round-1 notes in `.wavefoundry/work/<wave>/review/` and the changed spec sections.
2. **Verify the repair.**
   - Check it against the code with an executed probe on a throwaway copy.
   - Make NO repo edits.
   - Use `run_tests.py --file` only; never the full suite.
   - Do not mutate memory records.
   - Check that the two specs agree on the primitive's states.
3. **Record a reverification for each finding you own.**
   - `event='finding'`, `run_kind='reverification'`, with the cycle `wf_review_wave(phase='prepare')` recommends.
   - `blocking_required_lanes=[]` only if the repair holds.
   - `fresh_context=true`, `independent=true`, `actor=<lane or seat>`, `context_id='<wave>-<lane>-focused-r2'`.
   - Executed evidence.
   - Dry-run first, then create.
4. **Record approvals.**
   - Each required lane then records a readiness approval on its wave's current receipt, as executed, with its OWN honest `integrity_checks`.
   - The required lanes are code, qa and docs-contract on both waves, plus architecture on 249as only.
   - Red-team records only reverifications.
   - A new blocking defect gets a finding.
5. **Write notes** to `.wavefoundry/work/<wave>/review/<lane>-focused-r2.md`. No em-dashes.
6. **Reply** in under 100 words covering both waves.
