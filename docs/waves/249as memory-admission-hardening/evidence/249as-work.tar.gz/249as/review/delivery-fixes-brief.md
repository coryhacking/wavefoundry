# Focused delivery re-check (wave 249as)

All four required lanes approved delivery with no blocking finding (notes: `.wavefoundry/work/249as/review/*-delivery.md`). The coordinator then ruled DO on eight advisories, and the implementer fixed them after those approvals. The spec's Progress Log has one row per item; the declined item (symbol-only rewrite needs `retarget_reason`, per Requirements 1 and 6) also has a row.

The eight fixes:
1. Promote and retain content-check the stored title and summary, so a stored secret is never echoed.
2. The tool-call markup regex is bounded and linear.
3. Refs over 1,024 characters are `unresolved` and block.
4. An unterminated leading backtick is refused as `unresolved`.
5. `retarget_reason` refuses every Unicode line and paragraph separator, tested in both handlers.
6. The supersede test asserts the ref name.
7. 22 `from wf_server import server_impl` sites in `wf_server/memory_handlers.py` became `import wf_server.server_impl as server_impl`.
8. A supplied tree caches record ids, so a batch loads records once with identical results.

Coordinator evidence after the fixes: full suite `run_tests.py --no-cache` OK, 13,476 tests across 258 files (`.wavefoundry/work/249as/full-suite-3.log`); `--profile second` 0 of 258 files failed (`second-profile-3.log`).

## Your task, as a FRESH, independent reviewer
1. Load MCP tools via ToolSearch first; code_* MCP-first.
2. Verify each fix in the working tree with executed probes on a throwaway copy, and a known-bad control. `run_tests.py --file` only; never the full suite. No repo edits. No `wf_memory_eval`. Do not mutate `docs/agents/memory/`.
3. code-reviewer: record a delivery approval (`wf_review_event(wave_id='249as', event='approval', signoff_key='code-reviewer', approval_phase='delivery', actor='code-reviewer', context_id='249as-code-reviewer-delivery-fixes', fresh_context=true, independent=true)`, executed, OWN honest integrity_checks), dry-run then create. A blocking defect gets a finding (`run_kind='initial_delivery'`, cycle 0) instead.
   red-team: notes only, plus a finding for a blocking defect.
4. Notes to `.wavefoundry/work/249as/review/<lane>-delivery-fixes.md`. No em-dashes. Reply in under 70 words.
