# Architecture reviewer, readiness, wave 249as

Reviewer: architecture-reviewer, fresh and independent context, 2026-11-23.
Scope: `249aq-enh memory-admission-hardening` (receipt `review-policy-547603c8059b79d88081`), with 249ar's spec `246to-enh memory-revalidation-by-signal` read to check fit. I made no repo edits. The probes were read-only.

## Verdict

249as: approve at readiness. Nothing in 249as blocks. There is one cross-wave contradiction, and its fix belongs to 249ar (see section 1).

## Anchors verified against the code

- The three scan loops are at `wf_server/memory_handlers.py` lines 584, 990 and 1446, and all three import `MEMORY_DISALLOWED_PATTERNS` lazily. `_memory_file_target_exists` is at line 1350, uses `root.rglob(name)` plus `endswith(target)`, and skips `symbol:` and `community:` refs. Its only caller is at line 1511, which checks `target_refs` only.
- `memory_brief_response` pads with `matched + unmatched` (lines 1951-1955). `no_memory_matches` names `memory_add` as its recovery tool (line 1896). `test_brief_remains_queryless_and_exact_target_promoted` exists at `tests/test_memory_records.py:4506`.
- `contained_files.judge_contained_file` exists. `memory_supply.eligible_repository_targets` already uses it for draft anchors, so reusing it follows precedent.
- `memory_records` imports `record_paths`, `line_endings` and `vocabulary_profile`. `wave_lint_lib/constants.py` imports only `re` and `vocabulary_profile`, so the new import in `memory_records` cannot create a cycle. `memory_eval` and `apply_decay` (line 1667) sit in or import `memory_records`. The handlers reach the module through `_memory_mod()`, which calls `server_impl._load_script`.

## 1. Cross-wave fit (needs a fix in 249ar, not 249as)

249as Requirement 1 puts admission policy in `blocking`: refs in state `unresolved` or `ambiguous`, plus any target in state `suffix_only`. It says that callers judging existing records read each ref's `state`.

249ar disagrees in three places:
- Requirement 1 sets `target_unresolved` when a ref appears in `blocking`.
- Requirement 6 refuses a transition to active when `blocking` is non-empty.
- Its 2026-11-24 Progress Log and Decision Log describe `blocking` as holding only `unresolved` and `ambiguous`. That predates the 2026-11-24 rule that blocks `suffix_only` targets.

The effect, from a read-only probe of exact-path existence: about 47 of 175 active records carry a bare-name or partial target. Under 249ar as written, all of them would rank 0 as `target_unresolved`, and every keep would be refused, although the target exists. Also, `blocking` includes unresolved evidence refs, which 249ar names `target_unresolved`.

The cheapest fix is in 249ar: derive `target_unresolved` from the per-ref `state` (`unresolved` or `ambiguous`). It should also decide explicitly whether unresolved evidence counts. I am reporting this to the coordinator for 249ar's own lanes to record. Architecture is not a 249ar lane, so I wrote no 249ar ledger entry.

Optional hardening in 249as, which would make the trap hard to fall into: name the list `admission_blocking`, or also return a policy-free `unresolved` list. The 249as record stays approved either way.

## 2. Primitive placement and interface

- **Placement in `memory_records.py`: right.** It is model-free, needs no index or Git, avoids the three registrations a new flat script needs, and is already in reach of the handlers, `memory_eval` and `apply_decay`.
- **Wave and change id resolution should reuse `record_paths`** (`load_record_roots`, `walk_wave_candidates`). That way, nested layouts, configured roots and the archive root resolve the same way they do everywhere else. Do not add a new folder glob.
- **The wave-id form "exactly five lowercase alphanumerics" differs from `lifecycle_id._PREFIX_RE` (`{5,6}`).** A six-character id becomes `unchecked`, which is harmless. A five-letter word used as an evidence ref (for example `tests`) becomes an `unresolved` wave id and blocks. The census found none. Preferably, take the grammar from `lifecycle_id`.
- **Determinism with and without `tree`.** Exact-path resolution must read the disk, not the tree. The walk skips `.wavefoundry/` except `framework/`, so a `.wavefoundry/work/...` evidence path would resolve without `tree` and fail with it. AC-10 should assert that both forms give identical results.
- **Walk scope.** The walk has no ignore rules, so in target repos it enters `node_modules/`, `.venv/`, `dist/` and similar directories. That makes it slow, and 249ar runs it once per ranked `memory_search` batch. It also makes bare names `ambiguous` more often. Two options: prune the untrusted-component names Requirement 4 already lists, or reuse `indexer.walk_repo`'s ignore handling. At minimum, record the cost in the Progress Log for 249ar's hot-path check.
- **Line-suffix check.** Count lines through a capped contained read (`read_contained_bytes`), not an unbounded read.

## 3. Scan consolidation

- One field-level helper replacing the three handler loops is right. Each loop scans a different field set, which `forbidden_content_reasons(fields)` handles naturally.
- The lint keeps its own loop, `_memory_forbidden_match`, with the prohibition-line and decision-log exemptions. So two scan implementations remain. Put the per-line reason classifier beside the pattern groups in `wave_lint_lib/constants.py` (or `helpers.py`), and call it from both `memory_records.forbidden_content_reasons` and the lint. Then the reason codes agree everywhere.
- **Worsened by this wave (DO during implementation):** the lint failure message at `wave_validators.py` around line 2521 prints `raw_line.strip()[:80]`. Once the credential patterns join `MEMORY_DISALLOWED_PATTERNS`, the lint would print `AKIA...`, `ghp_...` and JWT values into terminal and CI output. That contradicts Requirement 3's never-echo rule. The lint should name the reason code instead, and AC-4's lint case should assert that the literal is absent. The secret is already on disk, so this is not a blocker, but it is cheap to fix.

## 4. Docs

- `docs/architecture/cross-cutting-concerns.md` has no "memory admission section". The nearest sections are "Memory Curation" (line 230) and "Selective wave memory capture" (line 257). The implementer should add a short "Memory admission" section next to them, or name the section the text goes in.
- `docs/architecture/data-and-control-flow.md` has the propose-to-validate flow (line 822) and the brief description (line 779). Both targets exist.
- ADR `1sk58` says records are lint-enforced against secrets before write. This change extends that without contradicting it, so no amendment is needed.
- A behavior change that is not mentioned: once padding goes, a targeted brief never shows community-scoped records, because `match_targets` skips `community:`. State this in the tool docstring and in `mcp-tool-surface.md`.

## 5. Portability

- Checking spelling component by component against directory listings covers Windows, macOS default APFS, and WSL2 on `/mnt/` drives. Normalizing `\` to `/` and counting lines with universal newlines are correct.
- The walk must not descend symlinked directories or Windows junctions. Use the `contained_files` link checks (`_is_link_metadata`, `_is_windows_link`), because `followlinks=False` alone is not a dependable guard for junctions across the supported Python versions.
- Residual edge: on macOS, a ref typed in NFC against a filename stored in NFD would compare unequal. This is rare. Record it as a limitation, or compare NFC-normalized strings.
- Suffix matching compares against walked spellings case-sensitively, so `A.py` against `a.py` is `unresolved` on every platform. That is consistent and correct.
