# Council chair, readiness round 3, wave 249as (change 249aq)

Moderator: council-chair, fresh and independent context `249as-council-chair-readiness-r3`, 2026-11-24.
Receipt: `review-policy-1c51f95cd62f929bce87`. Primer depth: standard. Seats: red-team (fixed), docs-contract-reviewer (rotating).

## Verdict

Prepare-phase Wave Council PASS. Council-readiness approval recorded. intent_fit: `establishes`.

## Gate state (executed)

`wf_review_wave(wave_id='249as', phase='prepare')`: lint passed; code-reviewer, qa-reviewer, architecture-reviewer and docs-contract-reviewer approvals are current on the receipt; all six readiness findings (`249as-rt-path-form-unspecified`, `qa-249as-rewrite-gone-target-unreachable`, `qa-249as-unnamed-test-breakage`, `cr-249as-rewrite-pending-refs-contradiction`, `cr-249as-evidence-path-form-undefined`, `arch-249as-path-form-truncates-spaced-paths`) are terminal with no unresolved lanes. The only pending action was this approval.

## Intent fit

The wave Objective has six clauses: refs and targets resolve in the current checkout; credentials and control tokens refused by reason; URL and dependency-tree evidence flagged; a rewrite keeps a resolving target; an empty targeted briefing is normal; existing records, the query set, ranking and indexing unchanged. Each maps to a testable AC (AC-1 to AC-3, AC-4 and AC-5, AC-6, AC-7, AC-8, and AC-11 with Scope). The change's Product Intent is the same set plus guidance (AC-9), which it honestly limits to delivered text, with efficacy observed after release. Five independent r3 probes reproduced the repaired resolution rules on the AC-1 fixture and the live corpus, with known-bad controls that fail under the round-2 rule. The plan establishes its intent.

Two gaps were weighed and judged not to lower the verdict:

- Nested checkouts (red-team advisory 1): settled by the operator's 2026-11-24 stopgap, below.
- "Never echoes a secret" on promote and retain covers caller fields only (red-team advisory 2, code-reviewer advisory 2). Pending records come from `memory_propose(mode="create")`, which already scans content, and record files fall under the extended lint, so the residual is narrow. A one-clause fix is carried forward.

## Strongest challenge

Red-team advisory 1: `memory_ref_tree` does not prune nested checkouts such as `.claude/worktrees/<name>/`. One simulated worktree turned all 73 `suffix_only` targets and 10 `suffix_only` evidence refs into `ambiguous`, which 249ar would read as `target_unresolved`. Operator decision 2026-11-24: full worktree handling is a separate future wave; as a stopgap, 249as's walk skips any non-root subfolder with its own `.git` entry (file or directory), recorded as a Progress Log deviation at implementation.

## Strongest alternative

Block `suffix_only` evidence as well as targets, or resolve against `git HEAD`. Both are rejected in the Decision Log: the first refuses legitimate bare-name evidence, the second refuses the wave's own uncommitted files and needs Git on Windows.

## Seat notes

- red-team: no new blocking defect; five advisories, carried forward below.
- docs-contract-reviewer: full docs validation clean; five states agree with 249ar spec `246to`; test list sums to 42; two tidy advisories, carried forward.

## Carry-forwards for the implementer

Record each as done or as a deviation in the Progress Log.

1. Operator stopgap: the `memory_ref_tree` walk skips any non-root directory holding a `.git` entry (file or directory), covering worktrees, submodules and nested clones. Apply the root-relative `.wavefoundry/` rule at the root only. Record it as a Progress Log deviation. (red-team 1)
1. On promote and retain, run `forbidden_content_reasons` over the pending record's own refs before resolution, or redact matching refs in `memory_ref_unresolved`, so no diagnostic echoes a stored secret. Add a test. (red-team 2, code-reviewer 2)
1. State the refusal order in code and docs: content check, then ref resolution, then the anchor check. (code-reviewer 1)
1. For a target with no exact-file prefix, report and suggest using the full ref text, not the truncated first-token candidate. (code-reviewer 3)
1. Stop the longest-prefix loop at the first exact hit. Cap the tokens tried (for example 32) or the ref length (for example 1,024 characters), and parse the suffix from the right end rather than with a backtracking `search`; a 40k-character `:a` chain took 6.1 s. Consider a basename index for the `endswith('/<ref>')` scan in track 4 batches. (red-team 3, architecture advisory)
1. Document in `docs/specs/mcp-tool-surface.md` that only `:N`, `:N-M` and `:N,M` forms check lines; `:L999`, `line 32` and a second line ref in one entry are not checked. (red-team 4)
1. Pin the change-id form: the slug is the second token and anything after it is annotation. Add a Windows case to AC-1 tests, for example `src/a.py.` as `unresolved`, so a `normcase` or `resolve()` shortcut cannot pass. (red-team 5)
1. Correct the broken-test list in the first Progress Log row: add `MemoryProposeTests.test_registered_manual_pending_candidate_blocks_close_without_source_event` (6-character `1aaaax` wave id; repair by creating the cited wave folder) and drop `SecretScanCoverageTests.test_secret_in_title_or_targets_is_refused_without_side_effect`, which still passes under content-first ordering. (qa 1)
1. 249ar notes, for its implementer, not this change: AC-11's predicted 13 `target_unresolved` records is about 7 under repair 2 (re-derive); AC-3's `zzzzz` is now `unchecked`, so the fixture no longer exercises a missing wave id; its Progress Log census used the first-token rule; tidy the superseded 2026-11-24 Decision Log row. (code-reviewer, qa 2, docs-contract 2)
1. Refresh the 244cm arc Progress row for 249as from "repair cycle 1 ... awaiting reverification" to the current state when the Tasks item runs. (docs-contract 1)

## Limitations

The chair ran the review-state check and read the spec and notes; it ran no product test, since no product code exists. Lane probe results are cited from the r3 notes, not re-executed.
