# Code reviewer, delivery, wave 249as (change 249aq)

Context: `249as-code-reviewer-delivery`, fresh and independent, 2026-11-24. No repo edits; probes ran on temporary fixtures and a scratch copy of the framework.

## Verdict

APPROVE. No blocking defect. Four advisories below.

## What I checked (executed)

1. `resolve_memory_refs` on the AC-1 fixture plus extra cases, by a scratch script against the live tree: every AC-1 state, `resolved_path` and the exact `blocking` set reproduce. Extra cases all fail closed: `src/a.py.`, `src/a.py:0`, `src/a.py:3-2`, `../x`, `/etc/passwd`, `src//a.py`, `./src/a.py`, `src/a.py::`, `C:/src/a.py` are `unresolved`; `src\a.py` resolves to `src/a.py`; `1abce-bug fixture-plan with notes` resolves (slug is the second token); a nested checkout (`wt/.git` file) is pruned, so bare `a.py` stays `suffix_only`. Results are identical with and without a supplied `memory_ref_tree`.
1. Cost caps: a 40k `:a` chain and a 900-token ref return in under 1 ms (the 1,024-character cap fires before probing); suffix parsing is right-to-left `rfind`; the prefix loop stops at the first exact hit and tries at most 32 tokens.
1. `forbidden_content_reasons` and `memory_line_reasons`: reason codes per field, no matched text; `Human:` only at line start; `<invoker>` and "the invoke method" clean; case-insensitive bearer caught. The lint keeps the decision-log `exempt_end` behavior and no longer prints the line.
1. Refusal order through the handlers (scratch `_AdmissionCase` subclass): content first (generated `ghp_` token with a missing target gives only `secret`, no ref named), then refs, then anchor. Promote and retain scan stored refs before resolving. A mixed backticked target with a missing span is refused.
1. Line endings: a CRLF pending record promoted in place keeps every line CRLF (31 of 31).
1. Known-bad controls on a scratch copy of the framework: dropping the `suffix_only` target rule from `blocking` fails `test_blocking_set_is_exact`, `test_known_bad_suffix_target_no_longer_passes` and `test_add_refuses_blocking_refs_and_writes_resolving_ones`; restoring brief padding fails `test_brief_remains_queryless_and_exact_target_promoted`.
1. `run_tests.py --file test_memory_records.py`: 289 tests OK; `--profile second`: 0 of 1 files failed. `test_lifecycle_mutation_lock.py`: 69 OK. `test_docs_lint.py`: 367 OK.

## Advisories (non-blocking)

1. Unterminated leading backtick bypasses resolution. `_persisted_refs` keeps only backticked spans of a value that starts with a backtick, so evidence `` `1zzzz `` or target `` `src/missing.py `` yields no ref, and `memory_add` writes the record. The written record does not parse (`parse_memory_record` returns None) and the record lint reported nothing on it. HEAD wrote the same file with no check at all, so this was not introduced by the wave, but the new floor does not cover it. Simple fix: when a backtick-led value has no closed span, resolve the raw text.
1. ReDoS-shaped tool-call pattern. `</?(?:ns:)?(?:invoke|...)\b[^>]*>` is quadratic on many `<invoke` with no `>`: 224 KB took 2.9 s, so about 1 MB takes about 60 s. The pattern is the one the spec fixed, and only a local caller or a planted record file reaches it. A `[^>]{0,512}` bound would fix it.
1. A candidate whose only targets are `symbol:` or `community:` is `unchecked`, so a rewrite that keeps `symbol:alpha` and adds `src/a.py` still needs `retarget_reason`. This matches Requirement 6 as written; the guidance could say so.
1. Import form. The two new helpers use `from wf_server import server_impl`, like the 22 existing sites in `memory_handlers.py`, not Requirement 9's `import wf_server.server_impl as server_impl`. It is safe because `server_impl` is never evicted by the reload purge, but it differs from the requirement's wording.

Also noted: consolidation goes through the anchor check against the first source's targets, and `memory_consolidate` has no `retarget_reason`, so a consolidation whose first source's targets are all gone is refused with `memory_retarget_reason_required`. The Risks table already says gone targets refuse consolidation.

## Limitations

I did not run the full suite or `wf_memory_eval`. I took Windows junction pruning and Windows case behavior from reading the code, not from running them. Gapfill: shell `grep`, `sed` and `git diff` read the diff because the change spans many files and I needed hunks, not symbols; `code_*` tools were loaded and available.
