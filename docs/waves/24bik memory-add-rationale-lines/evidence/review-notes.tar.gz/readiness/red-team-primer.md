# Red-team primer (wave 24bik, readiness, standard depth)

strongest_challenge: memory_consolidate_response writes active replacements via _memory_add_response_locked with no _action_delta/_validation_rationale, so Review memories still raises no_rationale through consolidation; and _has_rationale only checks presence, so the real fix rests on prompt compliance.
strongest_alternative: same inputs on memory_consolidate(mode="create") too; cheaper complement is a non-blocking advisory on supersedes writes with neither line.
primer_questions:
1. Does the efficacy claim hold without consolidate support?
2. Does routing the values through _memory_add_response_locked double-scan memory_validate values or change its refusal wording (Req 6)?
3. Should tests/fixtures/tool-surface-golden.json (memory_add.inputSchema, test_live_surface_matches_committed_golden) be in Tasks/Serialization Points?
4. How is AC-5 "byte-identical before the change" testable given date lines and day-based id minting?
5. Where does stripping happen, given render_memory_record writes action_delta as given?
efficacy_replay: memory_add(status=active, supersedes) -> memory_add_response -> _memory_add_response_locked._render -> render_memory_record writes Action delta when non-empty -> parse _ACTION_DELTA_RE -> _has_rationale True -> uncoverable_records drops no_rationale. Fixes the memory_add case when the agent supplies the value; not consolidation (before amendment).
Probes: memory_reconcile does regex edits and preserves lines; memory_validate rewrites lines; gardener only lists labels; memory_propose writes candidates. Checks run before lock/fence/write. validated_by/validation/source_event stay private; no consumer treats the lines as provenance.
Findings (all nonblocking): F1 consolidate gap; F2 golden fixture omitted; F3 AC-5 untestable; F4 stripping unstated.
Disposition: all four repaired in the spec before any readiness approval (see spec Progress Log and Decision Log).
