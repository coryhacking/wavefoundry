# code-reviewer readiness (round 1)
VERDICT: FINDINGS
CR-1 (blocking): single-line check inside _memory_add_response_locked on _action_delta/_validation_rationale would newly refuse memory_validate rewrites (validate checks only \r/\n; U+2028 passes today) -> breaks Req 6. Fix: validate/scan public values in memory_add_response and memory_consolidate_response(create) and pass stripped values as _action_delta/_validation_rationale; leave the private path unchecked; regression test that memory_validate rewrite is unchanged.
CR-2: name the route (public wrapper into private params avoids lock re-entry forwarding).
CR-3: consolidate already returns before supersede/archive on add failure; say values checked only for create; name diagnostic and keep field+reason, never echo.
CR-4: single-line check runs on the raw value before stripping.
CR-5: name AC-4 test file; consolidate tests also in test_server_tools.py, test_handler_modules.py.
CR-6: risk wording on cached schema imprecise.
Integrity: test_ran null->(plan review), others true; known_bad: U+2028 action_delta accepted by memory_validate today would be refused under Task 2 placement; caught.
