# qa-reviewer readiness (round 1)
VERDICT: FINDINGS
Q1 (blocking): third prompt copy install/lifecycle-prompts/memory-review.prompt.md omitted; render is missing-only (test_missing_only_baseline_materializes_and_preserves_existing_prompt), self-hosted copy is a hand merge; CARRIERS lists all three. Fix: add template; replace re-render with hand merge into both copies.
Q2: AC-4 vacuous today because assert_memory_review_contract already requires "action_delta=..." (memory_validate step). Anchor to call forms; known-bad controls in test_prompt_contract_and_known_bad_controls; list test_render_agent_surfaces.py.
Q3: Req 5 has no AC; AC-5 oracle weak. Supersede a source carrying both lines, call with neither, assert none inherited.
Q4: AC-1 must assert the raw line (parser strips).
Integrity: test_ran null, others true; known_bad: vacuous AC-4 and CARRIERS census caught.
