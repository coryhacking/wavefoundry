# Readiness review brief: wave 24bik, spec 24bij

You are an independent readiness reviewer. Review the PLAN, not an implementation (no code has been written).

- Spec: `docs/waves/24bik memory-add-rationale-lines/24bij-enh memory-add-carries-action-delta-and-rationale.md`
- Wave record: `docs/waves/24bik memory-add-rationale-lines/wave.md`
- Code under change: `.wavefoundry/framework/scripts/wf_server/server_impl.py` (the `memory_add` tool), `.wavefoundry/framework/scripts/wf_server/memory_handlers.py` (`memory_add_response`, `_memory_add_response_locked`, `memory_validate_response`), `.wavefoundry/framework/scripts/memory_records.py` (`render_memory_record`, `_ACTION_DELTA_RE`, `forbidden_content_reasons`, `memory_single_line`), `.wavefoundry/framework/scripts/memory_eval.py` (`no_rationale` rule near `uncoverable`), seed `.wavefoundry/framework/seeds/240-memory-review.prompt.md`, contract `docs/architecture/contracts/mcp-tool-surface.md` (`memory_add` entry).
- Review bar: `.wavefoundry/framework/seeds/209-*.prompt.md` (readiness finding bar). Verify load-bearing claims against the actual tree, executing where you can (read-only: do NOT edit any repository file, do NOT write memory records, do NOT run the full test suite; running single read-only Python probes or targeted existing tests is fine). Cite symbol anchors, not bare line numbers.
- Use the Wavefoundry MCP tools first: load them with ToolSearch (e.g. `select:mcp__wavefoundry__code_read,mcp__wavefoundry__code_keyword,mcp__wavefoundry__code_outline,mcp__wavefoundry__code_references`) and confirm they are callable before your first retrieval; fall back to Read/Grep only with a `Gapfill:` note naming why.
- Do not name any AI model in your output.

Return, in this exact shape:
1. VERDICT: APPROVE or FINDINGS
2. For each finding: id, severity (blocking / nonblocking), the plan claim or gap, the code evidence (symbol anchor), what would fix it in the plan, and whether you executed or inferred it.
3. What you checked (bulleted, concrete).
4. Integrity values for your own review, honestly affirmed for a readiness review of a plan: test_ran_without_unintended_skip, public_path_reached, boundary_values_realistic, assertions_non_vacuous, known_bad_detected (true/false, or null only if your lane is genuinely unaffected), and known_bad_detection_method (one sentence: the known-bad plan claim, omitted census site, or invalid input you tested your review against, and whether you caught it).
