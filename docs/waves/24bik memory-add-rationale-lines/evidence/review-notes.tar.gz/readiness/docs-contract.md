# docs-contract-reviewer readiness (round 1)
VERDICT: FINDINGS (nonblocking)
F1: step text lives in seed 240, install/lifecycle-prompts/memory-review.prompt.md (render source, per render_agent_surfaces lifecycle-prompts pairing) and docs/prompts copy; plan names only seed + render. Fix: add the template to Tasks/Serialization/gate, edit the two steps in seed and template, AC-4 asserts rendered + template.
F2: instruction wording underspecified; require call forms with action_delta, a one-line definition (condition when it applies + what next action does differently; not a restatement), write fresh not copied, consolidation line describes merged lesson, validation_rationale optional; AC-4 checks name inside each call plus the phrase.
F3: contract doc: both signature lines, memory_add scanned-fields bullet + invalid_memory_record single-line, consolidation pre-preflight refusal, memory_validate note that its action_delta stays separate and required.
F4 (minor): no other inconsistent seeds/prompts/skills.
Strongest alternative: write-time non-blocking advisory when supersedes set without either value.
Integrity: all true; known_bad: plan claim "rendered copy is a render of the seed" refuted by diff + render_agent_surfaces.
