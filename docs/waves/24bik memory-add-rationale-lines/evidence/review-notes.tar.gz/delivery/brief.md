# Delivery review brief: wave 24bik, spec 24bij (implemented, uncommitted)

You are an independent DELIVERY reviewer. Review the implemented change against the spec and the actual tree. You did not implement it.

- Spec: `docs/waves/24bik memory-add-rationale-lines/24bij-enh memory-add-carries-action-delta-and-rationale.md` (Requirements, ACs, Progress Log rows dated 2026-11-25 incl. the landing-mutant list and carried notes).
- Wave record: `docs/waves/24bik memory-add-rationale-lines/wave.md` (Objective; Review Checkpoints holds the coordinator's draft Intent outcome).
- See the diff with `git diff -- <path>` for: `.wavefoundry/framework/scripts/wf_server/memory_handlers.py` (`_rationale_inputs_refusal`, `memory_add_response`, `memory_consolidate_response`), `.wavefoundry/framework/scripts/wf_server/server_impl.py` (`memory_add`, `memory_consolidate` tools), `.wavefoundry/framework/scripts/tests/test_memory_records.py` (`RationaleInputTests`), `.wavefoundry/framework/scripts/tests/test_render_agent_surfaces.py` (`assert_memory_review_contract`, `test_prompt_contract_and_known_bad_controls`), the three fixtures under `.wavefoundry/framework/scripts/tests/fixtures/` (tool-surface-golden.json, tool-surface-golden/declared.json, register-surface-handler-digests.json), the three prompt copies (`.wavefoundry/framework/seeds/240-memory-review.prompt.md`, `.wavefoundry/framework/install/lifecycle-prompts/memory-review.prompt.md`, `docs/prompts/memory-review.prompt.md`), and `docs/architecture/contracts/mcp-tool-surface.md`.
- tree_fingerprint: `git hash-object` of each reviewed path is recorded in `.wavefoundry/work/24bik/delivery-fingerprint.txt`. Recompute at start and end; if any differs, report `tree_moved_under_review`.
- time_budget: about 20 minutes of work; report what you have at the budget and list what you did not run.
- sweep_rule: mutation testing ONLY in a scratch copy (e.g. `cp -R .wavefoundry/framework/scripts <your scratch dir>`), never in the repo tree. Run targeted tests per mutant (`cd <scratch>/scripts/tests && PYTHONDONTWRITEBYTECODE=1 python3 -m unittest test_memory_records.RationaleInputTests`), whole-file runs only for survivors. Include a mutation table (mutant, test(s) that failed or SURVIVED).
- Read-only on the repository: do NOT edit any repository file, do NOT write memory records, do NOT run the full suite. Focused existing tests are fine: `python3 .wavefoundry/framework/scripts/run_tests.py --file <test_file.py>` from the repo root (writes no receipt).
- Use the Wavefoundry MCP tools first: load with ToolSearch (e.g. `select:mcp__wavefoundry__code_read,mcp__wavefoundry__code_keyword,mcp__wavefoundry__code_references,mcp__wavefoundry__code_outline`) and confirm callable before your first retrieval; note `Gapfill:` for any fallback. Cite symbol anchors.
- Do not name any AI model in your output.

Return:
1. VERDICT: APPROVE or FINDINGS
2. Each finding: id, blocking/nonblocking, claim, evidence (symbol anchor), execution_status (executed/inferred), suggested fix.
3. Mutation table.
4. What you checked; what you did not run.
5. Integrity values (test_ran_without_unintended_skip, public_path_reached, boundary_values_realistic, assertions_non_vacuous, known_bad_detected as booleans; known_bad_detection_method one sentence).
6. Fingerprint check result (unchanged / tree_moved_under_review).
