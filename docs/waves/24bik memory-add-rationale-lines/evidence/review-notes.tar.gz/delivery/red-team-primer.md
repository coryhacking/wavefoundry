# Delivery red-team primer (standard depth) — VERDICT APPROVE
strongest_challenge: no_rationale is presence-only and the prompt now asks for action_delta on every rewrite/consolidation, so a lower no_rationale count after release is not evidence of useful lines.
strongest_alternative: option (d) non-blocking advisory when supersedes/consolidate create carries neither line.
primer_questions:
1 (code): _rationale_inputs_refusal runs before the locked validation, so a call with a bad kind and a bad action_delta reports only the action_delta problem. Acceptable or merge?
2 (qa): consolidate's new refusal returns {written, problems} without preview_data, unlike sibling consolidate errors. Any caller/test relying on groups in errors?
3 (docs-contract): does the consolidation sentence satisfy Req 6.3 (written fresh, not copied) and 6.4 (validation_rationale states the evidence checked) given it says "as for a rewrite"?
4 (architecture): memory_validate still writes a U+2028 action_delta (AC-8 preserves it); keep as deliberate exception or log follow-up?
efficacy_replay (executed, scratch temp root): rewrite and consolidation with action_delta not flagged no_rationale; control without it flagged. Handler level, not MCP wrapper.
Probes: no other callers (only the two MCP wrappers; server_impl re-exports); refusal shape matches existing invalid_memory_record; empty-value filter before content scan harmless; leading/trailing separators stripped, internal refused; prompt hunks identical across three copies.
Findings (nonblocking): RT-1 metric presence-only; RT-2 pre-check hides other validation problems in same call; RT-3 consolidate refusal omits preview_data.
Gapfill: shell/reads instead of MCP tools. Mutation: none run by this seat. Fingerprint: six paths unchanged.
