// AC-9 check: headless Chrome over the DevTools protocol.
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const out = process.argv[2];
const url = process.argv[3];
const chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const profile = path.join(out, "profile");
fs.mkdirSync(profile, { recursive: true });
const proc = spawn(chrome, ["--headless=new", "--disable-gpu", "--no-first-run", "--hide-scrollbars",
  `--user-data-dir=${profile}`, "--remote-debugging-port=9337", "about:blank"], { stdio: "ignore" });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let targets;
for (let i = 0; i < 50; i++) {
  try { targets = await (await fetch("http://127.0.0.1:9337/json")).json(); if (targets.length) break; } catch {}
  await sleep(200);
}
const page = targets.find(t => t.type === "page");
const ws = new WebSocket(page.webSocketDebuggerUrl);
await new Promise(r => ws.addEventListener("open", r));
let id = 0; const pending = new Map(); const requests = [];
ws.addEventListener("message", ev => {
  const msg = JSON.parse(ev.data);
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); }
  if (msg.method === "Network.requestWillBeSent") requests.push(msg.params.request.url);
});
const send = (method, params = {}) => new Promise(r => { const n = ++id; pending.set(n, r); ws.send(JSON.stringify({ id: n, method, params })); });
const evaluate = async expr => (await send("Runtime.evaluate", { expression: expr, returnByValue: true, awaitPromise: true })).result?.result?.value;
await send("Network.enable"); await send("Page.enable"); await send("Runtime.enable");
const results = [];
for (const width of [1280, 390]) {
  await send("Emulation.setDeviceMetricsOverride", { width, height: 900, deviceScaleFactor: 1, mobile: width < 500 });
  for (const theme of ["light", "dark"]) {
    for (const stage of ["prepare", "close"]) {
      await send("Page.navigate", { url });
      await sleep(2500);
      const metrics = await evaluate(`(async () => {
        document.documentElement.setAttribute("data-theme", ${JSON.stringify(theme)});
        const card = document.querySelector(".framework-flow-card--${stage}");
        if (!card) return {error: "no tile"};
        card.click();
        await new Promise(r => setTimeout(r, 600));
        document.documentElement.setAttribute("data-theme", ${JSON.stringify(theme)});
        await new Promise(r => setTimeout(r, 200));
        const dlg = document.querySelector(".framework-process-dialog");
        if (!dlg) return {error: "no dialog"};
        const rect = dlg.getBoundingClientRect();
        const clipped = [...dlg.querySelectorAll("p, li, strong, code, span, h2, h3")].filter(el => {
          const r = el.getBoundingClientRect();
          return r.width > 0 && (r.right > rect.right + 1 || r.left < rect.left - 1 || el.scrollWidth > el.clientWidth + 1 && getComputedStyle(el).overflowX !== "visible");
        }).map(el => el.textContent.slice(0, 40));
        const probe = document.createElement("div");
        probe.style.cssText = "color: var(--ink); background-color: var(--panel-bg)";
        dlg.appendChild(probe);
        const tokens = {ink: getComputedStyle(probe).color, panel: getComputedStyle(probe).backgroundColor};
        probe.remove();
        const para = dlg.querySelector("p");
        let bgEl = dlg, bg = getComputedStyle(dlg).backgroundColor;
        return {
          dataTheme: document.documentElement.getAttribute("data-theme"),
          dialogWidth: Math.round(rect.width), viewport: innerWidth,
          pageHorizontalScroll: document.documentElement.scrollWidth > innerWidth,
          dialogHorizontalScroll: dlg.scrollWidth > dlg.clientWidth + 1,
          dialogOffscreen: rect.left < 0 || rect.right > innerWidth,
          clipped,
          bodyColor: para ? getComputedStyle(para).color : null, inkToken: tokens.ink,
          dialogBackground: bg, panelToken: tokens.panel,
          paragraphs: dlg.querySelectorAll("p").length,
        };
      })()`);
      const shot = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: false });
      const file = path.join(out, `${stage}-${theme}-${width}.png`);
      fs.writeFileSync(file, Buffer.from(shot.result.data, "base64"));
      results.push({ stage, theme, width, file, ...metrics });
    }
  }
}
const origin = new URL(url).origin;
const foreign = [...new Set(requests)].filter(u => !u.startsWith(origin) && !u.startsWith("data:") && !u.startsWith("about:"));
fs.writeFileSync(path.join(out, "requests.json"), JSON.stringify([...new Set(requests)], null, 1));
console.log(JSON.stringify({ results, requestCount: requests.length, uniqueRequests: new Set(requests).size, foreign }, null, 1));
ws.close(); proc.kill("SIGKILL");
process.exit(0);
