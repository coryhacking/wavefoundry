# qa-reviewer delivery notes (wave 241lr, change 241lq)

Context: 241lr-qa-reviewer-delivery. Fresh, independent; I did not implement this change.

## AC-1
- The pointer paragraph is the same in all three implement carriers after whitespace normalization (398 characters each): `docs/prompts/implement-spec.prompt.md`, `docs/prompts/implement-wave.prompt.md` (item 6) and `.wavefoundry/framework/install/lifecycle-prompts/implement-wave.prompt.md` (item 7). Each one points at seed 180's new `Rationale for the next engineer:` section, which says it covers single-spec and wave implementation alike.
- Explain is the same in the install template and the self-hosted copy. It separates behavior an executed check verified, planned work and checks, and unknowns. It names each executed check with its result and labels a planned check as planned.
- Known-bad: my scratch equality script caught a one-word mutant (ordinary -> usual) as unequal.

## AC-2
- Seed 180 `**Retrospective on rationale records:**` sets a concrete trigger: five waves implemented under the guidance and closed after the project installed the introducing release. It covers a sample that includes routine fixes, the required report contents, a limited-evidence statement and a keep-or-adjust recommendation. It states that the analysis gates nothing: "does not gate adoption, delivery or closure".

## AC-3
- Seed 180 and all three pointers say: "A routine fix needs only its ordinary completion entry." Seed 180 adds: "This guidance adds no artifact, gate, approval or required walkthrough." Explain says a routine fix needs no walkthrough unless the operator asks. The existing review-offer sentence and the optional teach-back text are unchanged.

## Watchpoint
- The diff only adds lines. It adds no approval gate. It does not rename the review authority or the `## Decision Log` / `## Progress Log` headings.

## Tests
- Twelve pinned focused files run via `run_tests.py --file <basename>`, including test_render_agent_surfaces.py (227 OK). Results are in the ledger approval.

Verdict: no blocking findings; delivery approval recorded.
