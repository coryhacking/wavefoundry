# Delivery review (wave 241lr, change 241lq)

The change `241lq-doc capture-implementation-rationale-for-walkthroughs` is implemented. Its spec, in `docs/waves/241lr implementation-rationale-handoff/`, has three ACs, all marked.

Files changed:
- `.wavefoundry/framework/seeds/180-implement-spec.prompt.md`: a new `Rationale for the next engineer:` section and a `**Retrospective on rationale records:**` paragraph.
- `.wavefoundry/framework/install/lifecycle-prompts/implement-wave.prompt.md` and `explain.prompt.md`.
- The hand-merged copies `docs/prompts/implement-wave.prompt.md`, `docs/prompts/implement-spec.prompt.md` and `docs/prompts/explain.prompt.md`.
- One `### Changed` bullet in `CHANGELOG.md` ending "Wave 241lr / 241lq."

The implementer ran 15 focused test files, which pass. The full suite has not run yet; the coordinator runs it before close.

The tree also holds wave 242yp's uncommitted edits: `upgrade_extensions.py`, `render_agent_surfaces.py`, their tests, the 242yp spec docs, and two `### Fixed` CHANGELOG bullets. Ignore them.

As a FRESH independent reviewer of your lane:
1. Load the MCP tools via ToolSearch first, and use code_* and docs_search MCP-first. Read the spec and the wave Watchpoints. Read the `git diff` for the 241lr files.
2. Verify each AC in your remit against the delivered text, not the spec's prose. In particular, the Watchpoint must hold: no approval gate is added, and the existing review authority and record headings are kept. Focused tests: `python3 -B .wavefoundry/framework/scripts/run_tests.py --file <file>`, never the full suite. Make no repo edits.
3. Record in the typed ledger (`wf_review_event`, wave `241lr`). Dry-run first, then create:
   a. For each blocking defect, a delivery finding (`event='finding'`, `run_kind='initial_delivery'`, cycle 0, `actor=<lane>`, `context_id='241lr-<lane>-delivery'`). State `evidence.execution_status` honestly.
   b. If there is no blocker, your delivery approval: `event='approval'`, `signoff_key=<lane>`, `approval_phase='delivery'`, `fresh_context=true`, `independent=true`, with your OWN honest `integrity_checks`.
4. Write notes to `.wavefoundry/work/241lr/review/<lane>-delivery.md`. No em-dashes.
5. Reply in under 100 words.
