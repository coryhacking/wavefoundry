# Readiness code review: 24i2t first-install-guidance

Lane: code-reviewer, readiness, fresh context. Plan reviewed: `24fw1-enh` spec, `wave.md`, red-team primer. MCP tools loaded via ToolSearch; Bash used for reads and probes.

## Verdict

**Approve.** No blocking defect. The plan can be built as written with a simple design, and its code claims hold on the current tree.

## Claims verified

- **Advisory callers.** `runtime_advisory.python_runtime_advisory` has three callers: `wf_cli.main` (stderr), `server.py` `__main__` (stderr, skipped on `--dry-run`) and `setup_readiness.assess_setup` (structured `advisories`). None writes to stdout, so MCP stdout stays clean. No test pins the policy prose. The only pins are `test_runtime_advisory.py` (range and `"3.13"`), and the 3.11 test recipe already accepts the advisory line on stderr.
- **No re-exec before the strict check.** `.wavefoundry/bin/wf` runs `exec python3`, and `wf.cmd` runs `python3` after `where.exe`. `wf_cli.main` skips `activate_tool_venv` for setup. `setup_wavefoundry.main` calls `ensure_python_resolves(strict=True)` before `activate_tool_venv(allow_version_mismatch=True)`. The running interpreter is therefore the one the operator invoked, and the notice stays silent under the launchers.
- **Probe data is already there.** Executed probe: under 3.13, `_probe_interpreter('python3')` returned `state=ok, version=(3,14), executable=/opt/homebrew/bin/python3`. The notice only needs that result compared with `sys.version_info[:2]`. No new spawn is needed.
- **Primer F1 repair is correct.** `activate_tool_venv` exits 2 when the venv's major.minor differs from the running interpreter. Requirement 2 now states that the host and `wf` refuse the tool environment and that the remedy is to rerun setup.
- **Threshold drop is safe.** In `check_factor_surface`, the consolidated branch requires `not active_factors`. Whenever any lane is active, control goes to the per-factor `else` branch whatever the threshold. Changing `>= 2` to "non-empty" changes only the empty-lanes, single-factor case.
- **Census.** `git grep` finds the README, seeds 011 and 160, `mcp-tool-surface.md:2986`, `build-and-verification.md`, `native-windows-support.md`, `project-overview.md`, two rendered `docs/prompts/*` files, and the two code sites. Requirement 4 covers all of them.

## Primer engagement

- strongest_challenge (F1): repaired, as above.
- Q2 (single factor): Requirement 5 drops the threshold, which covers it.
- Q3 (pending carrier): `pending_lint.warnings` with its own note is the right carrier. `pending_lint` is built before the branches, and only the `lint_errors` branch returns `data.warnings`.
- Q4: the wording is settled in Requirement 1 ("supported, security fixes only", python.org qualifier). The machine code `python_runtime_deprecated` stays the same, and that is acceptable.

## Implementation notes (non-blocking)

1. **Warning identity.** Use a shared constant prefix. Place it in `wave_lint_lib/constants.py`, which `wf_server` already imports. It should run from `docs/workflow-config.json: ` far enough to be unique, since other warnings may share the path. `run_validate` keeps the `WARNING: ` prefix on each line, so strip it before matching, the way `classify_lint_errors` strips `ERROR:`. The reworded text must stay on one line.
2. **Test the plan does not list.** `tests/test_docs_lint.py::test_factor_surface_single_inactive_factor_stays_per_factor` asserts the old behaviour and must be inverted. `test_factor_surface_retired_lane_repo_profile_applicable_passes` asserts "marks 2 factors applicable" and "Upgrade Wavefoundry", so it must change too. The partial-lane tests (`..._assessment_only_factor_warns_not_errors`) must stay unchanged; they act as the regression guard.
3. **Pending check scope.** Test for a pending seed-050 row on the full `rows`, not `scope_rows`, so that `phase=` filtering cannot reveal the warning early. Use `row.source == "seed-050" and row.is_pending`. Only template row 2.5 matches.
4. **Rendered prompts.** Regenerate `docs/prompts/install-wavefoundry.prompt.md` and `upgrade-wavefoundry.prompt.md` from seeds 011 and 160; do not hand-edit them.
5. **Advisory range.** Use `(3,11) <= v[:2] < (3,14)` so that 3.10 still returns `None`.
6. **Mismatch notice.** Emit it only on the strict path, after `state == "ok"`. Compare major.minor only, which is the same rule as the venv guard. Write it to stderr. The non-strict render and upgrade callers stay silent.
7. **Wording promise.** After a factor is added to `applicable_factors`, docs-lint raises a blocking error until `seed-050` task 5 generates the factor doc (`_FACTOR_RECOVERY`). The reworded "the agent generates their reviewer docs" must not imply that this happens automatically.

## Platform

The probe and launcher behaviour are the same on all platforms. On Windows, `py -3.14 setup_wavefoundry.py` with a 3.12 `python3` triggers the notice correctly. Native-Windows execution is unverified, which the spec already states.
