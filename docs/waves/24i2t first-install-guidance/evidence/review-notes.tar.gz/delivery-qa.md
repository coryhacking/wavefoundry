# 24i2t delivery review: qa-reviewer

Verdict: approve. No blocking defect.

Packet: tree_fingerprint `8bc95b8c2e293372`, recomputed at the start over the 27 paths in `delivery-paths.txt`, matched. The tree did not move.

## AC evidence (code and tests over checkboxes)

| AC | Evidence | Verdict |
| --- | --- | --- |
| AC-1 | `runtime_advisory.py`: range `(3, 11) <= v < (3, 14)`, `recommended_minimum` "3.14", installer-limit message. The `test_runtime_advisory.py` loop asserts 3.11 to 3.13 get an advisory and 3.14 gets none. `test_setup_readiness.py` adds 14. Red-team M1 to M3 killed | met |
| AC-2 | `venv_bootstrap._report_interpreter_mismatch`, called on the strict ok path only, writes to stderr, compares major.minor, and leaves the result `"ok"`. Tests cover a mismatch, a match, a non-strict call and the Windows launcher | met |
| AC-3 | The failure text says 3.14 (`test_unresolved_guidance_recommends_python_314`). I reran the census: the four phrases outside `docs/waves/` and `CHANGELOG.md` hit only a negative assertion in `test_venv_bootstrap.py:666`. A Python-related "deprecat" grep finds only the machine code and the stated reason it keeps its name (README:136, contract:2986) | met |
| AC-4 | `upgrade_handlers.wf_audit_install_response` and the `test_factor_reviews_off_warning_is_pending_until_the_seed_050_row_runs` handler test. The test uses the real `check_factor_surface` text on the shipped defaults with 1 and 5 factors. It runs phases None, 1 and 2, with and without a blocking lint error. The pending state carries the warning under `pending_lint.warnings` with the row 2.5 note, and the warning is in neither the diagnostics nor `data.warnings`. The test then rewrites the log with 2.5 checked and gets a diagnostic again, so the pending-then-checked sequence is exercised | met |
| AC-5 | The `test_docs_lint.py` consolidated test asserts the factor numbers, "blocks nothing", both options, the N1 clauses (ask the agent; lint errors until the doc exists), the RT-DEL-1 "mark any you leave off `partial`" clause, and none of "lane", "assessment" or "Upgrade Wavefoundry". The single-factor test was inverted | met |
| AC-6 | `full-suite-3.log` reports 13654 tests across 261 files, OK. `test-cache.json` has `result` "ok", and no framework file is newer than the receipt. The Progress Log records the second profile on the touched test files | met |

Note: the AC-4 fixture checks row 2.2 (the profile artifact row in `_MINIMAL_LOG`), not a row numbered 2.3. The behaviour it tests is the same: the profile row is done and seed-050 is pending.

## Requirement 6 as amended (N1 and RT-DEL-1)

Option 1 tells the person to ask the agent to generate the reviewer docs. It says docs lint reports an error until each doc exists, and that each becomes a reviewer agent that wave reviews can call on. It never claims the docs appear on their own. RT-DEL-1 adds "mark any you leave off `partial`". Option 2 says to mark the factors `partial` to stop the notice. The text keeps the `docs/workflow-config.json: ` prefix, which comes from `FACTOR_REVIEWS_OFF_WARNING_PREFIX`, the constant shared with the handler. Met.

## Red-team primer

- strongest_challenge (RT-DEL-1): repaired and asserted. My mutant Q1 removes the clause and is killed.
- Q2 (Windows remedy): repaired, chosen by `os.name`, and asserted. Q2 is killed.
- Q3 (`--check` never shows the mismatch): this follows from N4 and is acceptable. `--check` returns before `ensure_python_resolves`.
- Q4 (docstring): repaired. The handler digest fixture was refreshed for that entry only.

## Mutation table (scratch copy, targeted tests; baselines green)

| # | Mutant | Test | Result |
| --- | --- | --- | --- |
| Q1 | drop "mark any you leave off `partial`" | docs_lint `-k factor_surface` | killed |
| Q2 | Windows remedy always POSIX | test_venv_bootstrap (file) | killed |
| Q3 | handler leaves the warning in `lint_result` | lifecycle `-k factor_reviews_off` | killed (12F) |
| Q4 | a checked seed-050 row still counts as pending | same | killed |
| Q5 | drop the "docs lint reports an error" clause (N1) | docs_lint `-k factor_surface` | killed |
| Q6 | drop "blocks nothing" | same | killed |
| Q7 | notice also prints when versions match | test_venv_bootstrap (file) | killed |

I also spot-checked the red-team's M1 to M15 table: Q3 and Q4 overlap M10 and M13 and agree with them. 7 of 7 mutants were killed and none survived.

## Independent intent check

I agree with the coordinator: partial. The repository delivers every in-repo mechanism the Product Intent names:

- the 3.14 recommendation and its reason;
- the mismatch notice;
- no factor warning between the profile row and row 2.5;
- an actionable plain-language notice.

The intent's observable outcome cannot be read from this tree. That outcome is that a first installer is not shown the warning, the downstream agent invents no decision, and the operator settles on one interpreter. The next Waveforge first-install report is the measure. Residual limits:

- setup sees its own `PATH`, not the host's;
- the notice was not run on a native Windows host;
- the per-factor wording for partial adoption is still jargon (scoped out).

None of these makes the verdict "does not achieve".

## Integrity

The targeted tests ran without unintended skips. They reach the public paths: `wf_audit_install_response`, `ensure_python_resolves(strict=True)` and the docs-lint CLI. Boundary values are realistic: 3.13 and 3.14, 1 and 5 factors, all phase values. The assertions are not vacuous. Every mutant was detected.
