# Readiness QA: 24i2t first-install-guidance (24fw1)

Verdict: **approve, no blocking defect.** Five non-blocking notes for the implementer.

## Prediction (written after reading only the spec)

I expected AC-4 to be the weakest AC. Its key ("a pending install-log row whose source is seed-050") might not be readable from the parsed log. I also expected the AC-3 census (a Progress Log command, not a test) and AC-5's "states both options" to be soft oracles.

Outcome: the first part was refuted. `install_log_lib.parse_row` exposes `Row.source` and `Row.is_pending`, and in `install-log.template.md` row 2.5 is the only `seed-050` row. The soft-oracle part holds but is not blocking (notes 1 and 2).

## Primer engagement

- **Q1 / F1 (false consequence):** answered. Requirement 2 now says the host and `wf` refuse the environment, and gives the rerun-setup remedy. AC-2 asserts that remedy. I confirmed the consequence is true. In `setup_wavefoundry.main` the strict check runs before `activate_tool_venv(allow_version_mismatch=True)`. Activation happens in the same process, and `setup_index._bootstrap_venv` rebuilds the venv for `sys.version_info`.
- **Q2 / F2 (single factor):** answered. Requirement 5 drops the `>= 2` threshold, and AC-4 covers one factor and several.
- **Q3 / F3 (carrier):** answered. The carrier is `pending_lint.warnings` with its own note, and AC-4 asserts the warning is absent from `data.warnings`. See note 2.
- **Q4 / F6 (wording):** answered. Requirement 1 adds the python.org qualifier and the package-manager caveat, and Requirement 4 replaces "deprecated" with "security-only". F4 and F5 are also folded in (census patterns, "the `python3` on this `PATH`").

## Per-AC assessment

| AC | Testable | Fails on today's code | Oracle | Priority |
| --- | --- | --- | --- | --- |
| AC-1 | yes | yes, executed: 3.13 returns None and 3.12 recommends "3.13" | unit test over versions; the current test pins `(3,11),(3,12)` and `"3.13"` | justified |
| AC-2 | yes | yes, executed: strict check with a 3.12 probe under 3.14 returns `ok` with empty stderr | patched `_probe_interpreter`, which already returns `version` and `executable` | justified |
| AC-3 | yes | yes: `venv_bootstrap.py:373` says "3.13+", and `git grep` finds 11 census files | test assertion plus the census command | justified; see note 1 |
| AC-4 | yes | yes: warnings reach `docs_lint_warning` diagnostics in every branch of `wf_audit_install_response`; executed: one factor yields the per-factor warning | handler test | justified; see notes 2 and 3 |
| AC-5 | yes | yes, executed: today's text contains "lane", "assessment" and "Upgrade Wavefoundry" | docs-lint test | justified |
| AC-6 | yes | n/a (verification AC) | change-local: own suites, own docs, attribution-based for failures elsewhere | justified |

Intent fit: meeting AC-1 to AC-5 delivers each Product Intent outcome. Python guidance is AC-1 to AC-3, the mismatch notice AC-2, quiet install audits AC-4, an actionable warning AC-5. The Product Intent itself defers the downstream agent's behaviour to the next field report.

## Non-blocking notes

1. **Census miss.** `.wavefoundry/framework/README.md:136` ("deprecation alone does not require setup") matches none of the Requirement 4 patterns, but Requirement 4 says prose must not call 3.11 to 3.13 deprecated. Add `deprecat` near the Python-runtime prose to the census, or fix that line explicitly.
2. **One AC-4 assertion can pass vacuously.** `data.warnings` exists only in the `lint_errors` branch. A fixture in the `next_step` branch therefore passes the "no `data.warnings` entry" assertion without testing anything. Add one case that has a blocking lint error.
3. **Key the pending check on the whole log.** Use all parsed `rows`, not the phase-filtered `scope_rows`, so that `wf_audit_install(phase=1)` behaves the same.
4. **The notice also fires on `wf setup --check`.** There the strict check runs but nothing is built, so "the tool environment this run builds" overstates what happens. Consider wording or a test that covers this.
5. **Invert one existing test, don't delete it.** `test_docs_lint.py::test_factor_surface_single_inactive_factor_stays_per_factor` pins the old threshold, and `test_factor_surface_retired_lane_repo_profile_applicable_passes` asserts "Upgrade Wavefoundry". Rewrite both to the new behaviour rather than removing them.

## Evidence

- Executed probes on a scratch fixture with `sys.version_info` and `_probe_interpreter` patched.
- Reads of `runtime_advisory.py`, `venv_bootstrap.ensure_python_resolves` and `_probe_interpreter`, `setup_wavefoundry.py:360-363`, `setup_index._bootstrap_venv`, `upgrade_handlers.wf_audit_install_response`, `install_log_lib`, `wave_validators.check_factor_surface`, and the tests.
- `git grep` census.
