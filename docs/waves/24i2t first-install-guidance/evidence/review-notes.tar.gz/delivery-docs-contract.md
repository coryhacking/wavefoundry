# Delivery review, docs-contract-reviewer: 24i2t first-install-guidance

Verdict: APPROVE. No blocking defect. Fingerprint 8bc95b8c2e293372 matched (27 paths), no tree movement.

1. Census. `git grep -E "3\.13 or newer|3\.13+|3\.11/3\.12|3\.11 and 3\.12"` outside docs/waves and CHANGELOG.md: one hit, test_venv_bootstrap.py:666 (`assertNotIn("3.13+", ...)`, a negative assertion, correct). The "deprecat" grep near Python: README.md:136 and the contract line explain that the code name `python_runtime_deprecated` is kept for compatibility; runtime_advisory.py docstring says the same; test/pycache hits are unrelated DeprecationWarning. No prose calls 3.11 to 3.13 deprecated. All ten census files from my readiness report now say "3.14 recommended; 3.11 to 3.13 supported, security-only". Code agrees: `(3, 11) <= v < (3, 14)`, recommended_minimum "3.14", message and venv_bootstrap hint say 3.14. C1 satisfied (both greps run).

2. Seed vs rendered. The Python paragraph in seeds 011 and 160 is byte-identical to docs/prompts/install-wavefoundry (line 45) and upgrade-wavefoundry (lines 426, 812). Seed 012 adds one clause (pending_lint.warnings may carry the factor warning until row 2.5; do not ask the operator to choose factors) consistent with the code. Seed 012 has no rendered prompt copy. The two install-log-format.md copies are identical (diff clean) and name `warnings` and `warnings_note`. C3/C4 met.

3. wf_audit_install contract. Contract lines (diagnostic exemption while a seed-050 row is pending anywhere; return as a diagnostic once checked; `pending_lint` = {count, errors, truncated, note, warnings, warnings_note}; warnings always present, usually empty; warnings_note empty when none; never blocking) match `wf_audit_install_response` (searches all rows, not the phase-filtered scope; strips `WARNING:` prefix before matching; removes the warning from lint_result so diagnostics lose it; emits `warnings: []` and "" otherwise). The tool docstring matches. Minor: the contract says the warning is absent from `lint_errors.warnings` as well; the code removes it from the shared lint_result, so that holds.

4. Factor warning text. It does not promise automatic generation: it says "ask your agent to generate their reviewer docs", states that docs lint reports an error for each until its doc exists (matches check_factor_surface failure (a)), says it blocks nothing, and gives the keep-none option (mark `partial`; correct, warning (d) keys on `applicable`). Singular/plural noun handled. The claim "each becomes a reviewer agent that wave reviews can call on" is true in the sense the Factor Review Model describes (factor-<nn> reviewer subagents evaluating a wave); review-lane selection in scripts does not read `applicable_factors`, so factor lanes are available reviewers, not automatically required lanes. The wording says "can call on", which is accurate. Non-blocking observation: the last two sentences overlap slightly ("mark ... partial" appears twice); acceptable.

5. CHANGELOG [Unreleased]. Two Changed and two Fixed entries, accurate to the code (advisory range, python.org clause, mismatch notice on setup stderr only, pending_lint.warnings). Style matches 1.54.0 (plain sentences, "Wave X / change." suffix, no build numbers, no em-dashes). Nit: entries use a blank-line-free list, consistent with the file.

6. wf_validate_docs: passed, 0 errors, 0 warnings (scope full).

Not covered: test suite (not run per instructions); the Windows/macOS/Linux behavior of the mismatch notice (code uses os.name for the example only).

## Delta recheck (fingerprint 2d07c3fb2f87aaad, was 8bc95b8c2e293372)

Verdict: APPROVE. Recomputed fingerprint matches the coordinator's.

- Accuracy: `venv_bootstrap.tool_venv_base()` returns `WAVEFOUNDRY_TOOL_VENV` or `~/.wavefoundry/venv`, so all projects share one environment unless the override is set. `setup_index._bootstrap_venv` deletes and recreates that directory when it was built for a different major.minor than the running setup, and setup installs the running project's dependencies, so "rebuilds it for every project with this project's release" is true. "An older-release project may fail until upgraded" is hedged ("may") and consistent with `activate_tool_venv` refusing mismatches and with the field report; I did not reproduce it.
- README step 2, the advisory guidance string and the CHANGELOG sentence agree with each other. The guidance string omits the variable name (as the guard test requires), points to the README section by name, and the README section exists. CHANGELOG naming the variable is allowed (not a code literal).
- Other docs: seeds 011/160, rendered prompts, project-overview, native-windows-support and build-and-verification say "stop shared-environment consumers or propagate an isolated override" and defer to the README section. None contradicts the new point; none states the workstation-wide consequence. Non-blocking suggestion: a clause such as "this affects every project on the machine" could be added, but the README link covers it.
- Writing guide: plain declarative sentences, answer first, no banned wording; step 2 is long but the new text leads it. No em-dashes.
- `wf_validate_docs`: passed, 0 errors, 0 warnings.
