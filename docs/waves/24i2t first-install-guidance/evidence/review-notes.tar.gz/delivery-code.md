# Delivery code review: 24i2t first-install-guidance

Lane: code-reviewer, delivery, fresh context. Packet `tree_fingerprint` `8bc95b8c2e293372` (27 paths) recomputed at the start and the end, and it matched both times, so the tree did not move during review. Probes ran in a scratch copy only.

## Verdict

**Approve.** No blocking defect.

## Checks

- **`runtime_advisory.python_runtime_advisory`.** The range is `(3, 11) <= v[:2] < (3, 14)`, so 3.10 and 3.14 or later return `None`. The code and field names are unchanged, and `recommended_minimum` is `"3.14"`. The message matches Requirement 1. The docstring explains why the `deprecated` code keeps its name (N2).
- **`venv_bootstrap._report_interpreter_mismatch`.** The notice is called only on the `strict` + `state == "ok"` path, which is `setup_wavefoundry.main`'s only strict call. That call is skipped for `--check-gpu`, and `--check` returns before it. The two non-strict callers (`render_platform_surfaces`, `upgrade_wavefoundry`) stay silent. The comparison is major.minor only, the output goes to stderr, and the return value is unchanged. The `ok` state guarantees a 2-tuple `version`. The `len != 2` guard is defensive and harmless. The text does not claim that this run builds an environment (N4). On Windows it uses `os.name == "nt"` and the raw string `.\.wavefoundry\bin\wf.cmd setup`, which is correct (RT-DEL-2 repaired). The strict-path failure text recommends 3.14.
- **`check_factor_surface`.** The consolidated branch now runs on `not active_factors and inactive_applicable`. The singular and plural nouns are correct. The message is a single line and starts with `FACTOR_REVIEWS_OFF_WARNING_PREFIX`. It contains no "lane", "assessment" or "Upgrade Wavefoundry". The N1 clauses are present, and the switch-on option tells the person to mark factors they leave off `partial` (RT-DEL-1). I checked the claim that "row 2.5 resolves it" against seed 050 task 5, which fills `applicable_factors` from the profile.
- **`wf_audit_install_response`.** The pending row is searched in all `rows` (`source == "seed-050" and is_pending`), not in `scope_rows`. Repeated `WARNING:` prefixes are stripped before the prefix match. `lint_result` is rebound to a new dict, so nothing is mutated in place. After the rebinding it feeds only `_docs_lint_warning_diagnostics` and the `lint_errors` branch's `data.warnings`; `output` and `errors` are not read afterwards. Every branch is consistent: `lint_errors`, `checked_but_missing`, `phase_complete`/`complete` and `next_step` all carry `pending_lint` with the warning, and the diagnostics omit it. `complete` cannot occur while the row is pending. With no seed-050 row, or with the row checked, `pending_warnings` is `[]`, `warnings_note` is `""` and the warning stays a diagnostic. The `wf_validate_docs` path does not change. One cosmetic point: `pending_lint.warnings` and `warnings_note` are always present (empty when inactive). The contract and install-log-format describe them as additional fields, which is acceptable.
- **Stdout.** Every new output goes to stderr. The advisory callers are unchanged.
- **Docstring and digest.** The `wf_audit_install` docstring names `pending_lint.warnings` (RT-DEL-4). The fixture diff changes exactly one entry (`wf_audit_install`), and `run_tests.py --file test_mcp_tool_registry.py` passed on the real tree (27 tests OK).
- **Readiness notes 1 to 7.** All were honoured: the constant is in `constants.py` with the strip; the single-factor and retired-lane tests were inverted and updated, and the partial-lane tests are unchanged; the row search uses all rows; the rendered prompts match their seeds (red-team census); the range is as specified; the notice is strict-only, stderr and major.minor; and the wording does not promise automatic doc generation.
- **Missed callers.** I found none. `git grep` for the old warning phrases outside `docs/waves` finds nothing, and the prefix has one producer and one consumer.

## Primer engagement

- strongest_challenge (partial adoption leads to the jargon): repaired in the switch-on option text.
- Q2: repaired (the remedy example is chosen by `os.name`). Q3: intended. N4 only requires the text to stay true, and `--check` is a readiness probe. Q4: repaired.

## Mutation table (scratch copy, `run_tests.py --file <one module>` per mutant; baselines green)

| # | Mutant | Module | Result |
| --- | --- | --- | --- |
| A | remedy example always POSIX | test_venv_bootstrap | killed |
| B | `warnings_note` set whenever the row is pending, even with no warning | test_server_tools_lifecycle | **survived** |
| C | singular noun dropped | test_docs_lint | killed |
| D | no `lint_result` rebinding (warning stays a diagnostic) | test_server_tools_lifecycle | killed |
| E | mismatch compares the major version only | test_venv_bootstrap | killed |
| F | advisory lower bound 3.12 | test_runtime_advisory | killed |

The red-team rows M4 and M9 cover the same mechanisms as E and C, and my results agree with theirs.

## Non-blocking

- **CODE-DEL-1 (test gap, survivor B).** No test asserts `warnings_note == ""` when no factor warning is carried. The cases with the row pending and no matching warning, and with the row checked, assert only `warnings == []`. Repair (optional): add `self.assertEqual("", result["data"]["pending_lint"]["warnings_note"])` to the checked-row assertion in `test_factor_reviews_off_warning_is_pending_until_the_seed_050_row_runs`. The production code is correct as written.

## Platform

The logic is the same on every platform. Windows behaviour is covered by the patched `os.name` test. I did not execute it on a native Windows host.

## Delta recheck (context 24i2t-delivery-code-2)

The fingerprint moved from `8bc95b8c2e293372` to `2d07c3fb2f87aaad` (27 paths). I recomputed it at the start and the end of this recheck, and it matched both times. I reviewed only the delta.

- **Shared-environment guidance (`runtime_advisory.python_runtime_advisory`).** I checked the claim "setup under a different Python rebuilds it for all of them with this project's release" against the code, and it holds:
  - `venv_bootstrap.tool_venv_base()` is `WAVEFOUNDRY_TOOL_VENV` or `~/.wavefoundry/venv`, so every project shares one environment unless it sets the override.
  - `setup_index._bootstrap_venv` removes and recreates that environment when the recorded major.minor differs from `sys.version_info[:2]`.
  - The `_install_deps` calls that follow install the running framework's pinned requirements.
  - The text avoids the variable's literal name, which keeps the single-reader test intact (`full-suite-6.log`: 13654 OK). The README step 2 claim and the CHANGELOG clause match the same code.
- **Advisory tests.** The new `test_runtime_advisory.py` assertions are non-vacuous. Mutant G (drop the new guidance sentence) was killed by `--file test_runtime_advisory.py`. The baseline was 6 tests OK.
- **CODE-DEL-1 repair.** The added assertion is correct, but it does not kill mutant B. Re-run in a scratch copy, B **still survives** (`test_server_tools_lifecycle.py`, 743 tests OK). The checked-row case has no pending row, so the mutant also yields `""` there. My earlier suggested repair was wrong. B differs from the real code only when the seed-050 row is pending and no factor warning is present. A test that would kill it: with row 2.5 pending, audit using lint warnings `[other]` only, then assert `pending_lint.warnings == []` and `warnings_note == ""`. This is still non-blocking, because the production code is correct, and the gap stays recorded as CODE-DEL-1.

Verdict: approve; no blocking defect in the delta.
