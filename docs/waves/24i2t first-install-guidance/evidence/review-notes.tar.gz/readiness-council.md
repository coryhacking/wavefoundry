# Prepare-phase Wave Council synthesis: 24i2t first-install-guidance

Moderator: council-chair. Primer depth: standard. Seats: red-team (fixed primer), docs-contract-reviewer (rotating; also a required lane). Lane inputs: code-reviewer, qa-reviewer. Verdict: **PASS**. intent_fit: **establishes**.

## Seat outcomes

- **red-team primer:** F1 blocking (mismatch notice claimed the next `wf` call rebuilds the venv), F2 to F6 non-blocking. All six were repaired into the spec before any lane approval.
- **docs-contract-reviewer:** approve, with C1 to C4 (deprecat census grep; Requirement 6 option 1 promised automatic doc generation; contract and seed-012 `pending_lint` wording; serialization paths).
- **code-reviewer:** approve, with seven implementation notes.
- **qa-reviewer:** approve, with five notes; the spec-only prediction about AC-4's key was refuted.
- Agreement: unanimous approve after the F1 repair. Correlated signal: docs-contract C2 and code note 7 found the same Requirement 6 wording gap, so they count as one finding, not two confirmations.

## Chair spot-checks (code_read / grep on the current tree)

- `venv_bootstrap.activate_tool_venv` lines 238-250: a version mismatch prints "built for Python X.Y ... run wf setup" and exits 2. Nothing rebuilds the venv except setup, which defers activation. F1's premise holds.
- `check_factor_surface` line 1065: `not active_factors and len(inactive_applicable) >= 2`. Dropping the threshold changes only the empty-lanes, single-factor case. Today's text contains "lane", "assessment" and "Upgrade Wavefoundry".
- `wf_audit_install_response` lines 281-298: `pending_lint` holds only errors, and its note says they "become blocking". `data.warnings` appears only in the `lint_errors` branch. That confirms F3 and QA note 2.
- `runtime_advisory.py`: the range is `((3,11),(3,12))` and the recommendation is "3.13". AC-1 fails on today's code.

## Is F1 repaired?

Yes. The Rationale now describes the exit-2 refusal. Requirement 2 says the host and `wf` will refuse the environment and gives the remedy: rerun setup with `python3`. AC-2 asserts the remedy. Residual: AC-2 does not assert the refusal clause. The delivery reviewer should check it.

## Progress Log notes N1 to N5

These are acceptable as binding implementation notes. None adds scope or changes what is delivered.

- **N1** corrects Requirement 6's literal text: "after which the agent generates their reviewer docs" implies the docs appear on their own, and they do not (they appear only through seed-050 task 5 or the seed-160 backfill). The note keeps Requirement 6's structure: factor numbers, fine to start with, two options with their consequence, the banned words dropped. It makes the consequence true and strengthens AC-5. That is a fidelity fix to message content that serves the Product Intent's "act on it from the message alone". It does not change any requirement. **Delivery reviewers must judge Requirement 6 as amended by N1, not by its literal sentence.**
- **N4** likewise narrows Requirement 2's "this run builds" so the notice stays true under `wf setup --check`. AC-2 is unaffected.
- **N2, N3 and N5** cover census coverage, contract and seed-012 doc sync, and test design. N3 adds `mcp-tool-surface.md` and seed 012 as edit targets the spec already implies (Affected Architecture Docs names that contract).

## Strongest challenge

F1, the false consequence in the mismatch notice. It is resolved, and my reading of the code confirms it.

## Strongest alternative

The red-team's alternative: report the venv-versus-`python3` mismatch through `setup_readiness`, so that `index_health` and `wf setup --check` show it persistently. The Decision Log weighed it and rejected it for now. That is acceptable: the host's refusal already names the remedy, and the stderr notice catches the mismatch at the moment it is created. The alternative is stronger only for hosts whose PATH differs from the setup shell (F5). It is a reasonable follow-up, not a readiness blocker. The rotating seat gave no alternative of its own, which is a process gap. This synthesis supplies the weighing.

## Finding dispositions

| Finding | Disposition | Rationale |
| --- | --- | --- |
| F1 | repaired in spec | Requirement 2, Rationale, AC-2 |
| F2 to F6 | repaired in spec | Requirements 1, 4 and 5, AC-3 and AC-4 |
| C1 to C4 / N1 to N5 | binding implementation notes | wording and coverage only |

No typed findings are open. The ledger shows 0.

## intent_fit: establishes

Each Product Intent outcome maps to an AC: Python choice to AC-1 and AC-3, the interpreter notice to AC-2, the quiet install audit to AC-4, the actionable warning to AC-5 with N1. The wave Objective matches that mapping. Bounded limitation: setup can see only its own PATH (F5), and the notice says so honestly. **Reading success after release:** the next Waveforge first-install report should show no factor warning between rows 2.3 and 2.5, no agent-invented three-option decision, and an operator who used one interpreter from the notice alone.

### Falsification check

Working verdict: PASS. The strongest counterargument is that N1 rewrites what Requirement 6's message promises, so it needs a re-Prepare. That does not hold: it corrects a false clause toward the mechanism that already exists, adds no scope, and the operator's standing rule favours Progress Log notes over re-ready rounds.
