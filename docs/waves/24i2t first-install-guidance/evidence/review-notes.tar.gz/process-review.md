# 24i2t process review: making reviews cheaper without weakening them

Read-only review. Nothing in the repository was edited and no review events were recorded.

## The direct answer: what should a corrected plan claim cost?

**It should never cost a suite run, and in this wave it did not.** The test receipt hashes only `.wavefoundry/framework/` (`run_tests._hash_inputs`, checked by `lifecycle_gates._framework_test_receipt_status`), and the spec lives under `docs/waves/`. Fixing F1 republished the review-policy receipt and ran no tests, which was the right cost.

**After readiness, it should cost a re-review of the changed text, not a fresh review.** Editing the spec rotates the policy receipt. Only these spec edits are exempt (`gardener_metadata.canonical_review_policy_body`): the Progress Log, Session Handoff, status metadata, the date line, and checkbox or `*Status:*` markers. Seed 215's `focused_rereview` already limits the work: the lane that found the problem replays its finding, and the other lanes check only the effect of the change. Every required lane must still record a new approval. I would not let the machine label a correction as "narrowing" and skip that step. Deciding that a claim got narrower is the judgment the review exists to make. Instead, keep each re-review small: give each lane only the diff and a lighter model.

**None of the six extra suite runs came from correcting a plan claim.** They all came from edits under the framework tree: code, tests, a docstring and README wording. The fixes below target that.

## Ranked improvements

**1. Run the guard tests before the full suite (practice now; framework change later).**
- **Problem:** run 2 failed in `test_mcp_tool_registry.py`, which takes 5.8 s, and run 5 failed in `test_venv_bootstrap.py`, which takes 3.3 s. Each failure was reported only after a 13–15 min run.
- **Mechanism today:** `--file` runs are already supported (`run_tests._main`, focused branch) and never touch the receipt. The scheduler starts the slowest files first (`_schedule_order`), so short guard files finish late: `test_venv_bootstrap` was file 238 of 261.
- **Change now:** before each full run, use `--file` to run the test files for the touched modules, `test_mcp_tool_registry`, the census tests (`test_*census*`, about 85 s in total, 72 s of it `test_line_ending_census`) and any single-reader scan tests.
- **Framework change:** add a `--guards` set, or start guard files first, so they finish within seconds even in a full run.
- **Time saved:** about 28 min in this wave.
- **Integrity risk:** none. Close still requires the full receipt.

**2. Batch delivery repairs and run the full suite once at the end (practice now).**
- **Problem:** runs 2 through 7 each followed a separate small repair: the red-team items, the digest refresh, the mutant, the wording, and the test edit.
- **Mechanism today:** close only checks that a green receipt exists for the current tree. Nothing requires a full run between repairs.
- **Change:** collect findings from the primer, the lanes and the operator. Repair them together, check each repair with `--file`, then run the full suite once just before close.
- **Time saved:** 3–4 runs, about 45–55 min.
- **Uncertainty:** a lane that cites the receipt in its approval needs the final run. Lanes should cite the focused runs while reviewing and the final receipt at close. Check this against seed 209's evidence rules before adopting it.

**3. Let test-only edits update the receipt without a full run (framework wave).**
- **Problem:** runs 4 and 7 rechecked about 13,650 tests after a change to a single test.
- **Mechanism today:** the receipt is one SHA-256 of the whole tree (`_hash_inputs`), with no per-file manifest.
- **Change:** store a per-file manifest with the green receipt. When the only changes since then are to `tests/test_*.py` files, run the changed files plus every census or scan guard, then update the receipt and record which files were rerun.
- **Do not exclude prose from the hash.** Tests read README and seed files (`test_docs_lint`, `test_build_pack`, `test_distribution_seams`, and 61 test files reference seeds). A hash that ignores prose would hide real failures.
- **Time saved:** about 13 min for each test-only edit.
- **Integrity risk:** a test file imported by another test file, which the manifest must detect.

**4. Stop the boilerplate platform statement from requiring the delivery Council (framework wave).**
- **Problem:** `review_policy.FULL_COUNCIL_TRIGGER_TOKENS` treats any spec containing `windows`, `macos` or `linux` as a cross-platform change. Every spec states its behaviour on each platform, so every wave sets `delivery_council_required`. Running `extract_full_council_triggers` on this spec returned only `('cross_platform_changed',)`.
- **Change:** require an explicit `cross_platform_changed: true` declaration, or skip the required platform section when matching.
- **Candid:** this wave really does change cross-platform behaviour (which interpreter is used), so its Council was justified. Smaller waves would avoid one Council synthesis and the rotating seat.

**5. Record the primer depth honestly (framework wave, small).**
- **Problem:** `lifecycle_gate_support._prepare_policy_state` writes `"primer_depth": "standard"` as a fixed value. The tiers in seed 225 and prepare-wave step 5 are applied only by the chair's judgment in prose, so the receipt cannot show `lightweight`.
- **Change:** derive the tier from the paths in scope and the boundaries touched, or record the chair's declared tier.
- **Candid:** seed edits made `standard` correct here.

**6. Review the delivery diff, not the whole delivery (practice now).**
- **Problem:** the delivery primer took about 6 min and ran 10 mutants. That was valuable, but readiness had already covered the design.
- **Change:** brief the delivery primer with the diff and the readiness conditions carried in the Progress Log, and ask it for mutation and efficacy checks rather than reconsidering the design. Brief lane rechecks with only the repair diff (review-wave step 8 already repairs editorial findings inline without another cycle).
- **Integrity risk:** low, provided the source lane replays its own finding.

## What today's design gets right

- **The small-change lane correctly refused this wave.** It has five or more paths, and seeds and `docs/` are protected (`small_change_lane._path_reason`). It also has a requested `qa-reviewer` and allows only 1 to 3 paths (`assess`).
- **Edits to the tree do not invalidate delivery approvals.** Only a repair recorded after an approval does, so lane rechecks were optional.
- **Fixing F1 before any approval was recorded cost nothing extra.** Carrying lane conditions in the Progress Log avoided a second readiness round.
- **Wall-clock time is spent in the suite, not in review.** Review took about 25 min; the full suite ran seven times at about 14 min each, roughly 95 min. Changes 1–3 would reduce that to one or two full runs.
