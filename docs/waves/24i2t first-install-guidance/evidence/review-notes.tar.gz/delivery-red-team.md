# 24i2t delivery red-team primer (standard depth)

Packet: tree_fingerprint `e27a8f1f871fb4a8` recomputed and matched at start and end; the tree did not move during review. No review event recorded.

## strongest_challenge

The factor notice's "switch some on" option leads to the old jargon. If a person adds only some numbers to `applicable_factors`, `active_factors` is no longer empty, so `check_factor_surface` takes the `else` branch and emits one per-factor warning for each relevant factor left off, worded with "assessment", "review lane" and "reconcile". The new text does not say that factors left off need `partial`. Requirement 6 scoped out the per-factor warnings, so this is not a requirement miss. It is still the next message the person sees after following the advice.

## best_alternative

Report the interpreter mismatch as a `setup_readiness` reason, so `index_health` and `wf setup --check` keep it after setup's stderr has scrolled away. The Decision Log declined this, and the decision holds: the host's refusal already names `wf setup`, and a rerun through `wf` rebuilds the tool environment for `python3`.

## primer_questions

1. Should the switch-on option add "mark any you leave off `partial`", so that partial adoption does not lead to N jargon warnings?
2. On native Windows the remedy example `.wavefoundry/bin/wf setup` is in POSIX form. Should the notice choose `.wavefoundry\bin\wf.cmd setup` by `os.name`?
3. `wf setup --check` returns before `ensure_python_resolves`, so it never shows the mismatch. Is that intended (N4 only required the text to stay true)?
4. Should the `wf_audit_install` tool docstring (`server_impl.wf_audit_install`) name `pending_lint.warnings`, as the contract and seed 012 now do?

## efficacy_replay

- **Python (field case):** the operator runs setup with 3.14 while PATH `python3` is 3.12. `ensure_python_resolves(strict=True)` probes `python3` and gets `(3, 12)`, state `ok`. `_report_interpreter_mismatch` then prints one stderr line naming 3.14 with `sys.executable`, 3.12 with the probe's `executable`, and the refusal and remedy. The result stays `"ok"`. The text is true: setup's `_bootstrap_venv` builds for `sys.version_info`, the host and `bin/wf` / `wf.cmd` launch `python3`, and `activate_tool_venv` refuses a different major.minor. The notice never fires on non-strict render or upgrade calls, on `--check-gpu`, or on `--check`. Covered by a test with a patched probe (executed); not run on a real two-interpreter host or on Windows.
- **Factor (field case):** the shipped template's row 2.5 parses to source `seed-050`, pending (executed: `parse_row` on template line 45). While that row is pending in any phase, the warning moves to `pending_lint.warnings` and leaves both the diagnostics and `lint_errors.warnings`. Once the row is checked, it is a diagnostic again. The prefix match strips repeated `WARNING:` prefixes, and the only producer of that prefix is the consolidated branch. No other code consumes the old text (`git grep` for the old phrases outside waves found none).

## Mutation table

Run in a scratch copy, one targeted test module or `-k` selection per mutant. Baselines were green.

| # | Mutant | Tests | Result |
| --- | --- | --- | --- |
| M1 | advisory range back to 3.11/3.12 | runtime_advisory, setup_readiness | killed (9F, 2E) |
| M2 | upper bound `< (3, 15)` | same | killed (11F) |
| M3 | `recommended_minimum` "3.13" | runtime_advisory | killed (6F) |
| M4 | drop the mismatch call | EnsurePythonResolvesTests | killed |
| M5 | notice on non-strict path | same | killed |
| M6 | notice to stdout | same | killed |
| M7 | compare major.minor.micro | same | killed |
| M8 | failure text "3.13+" | same | killed |
| M9 | restore the `>= 2` threshold | test_docs_lint | killed (single-factor test) |
| M10 | never find a pending row | lifecycle `-k factor_reviews_off` | killed (12F) |
| M11 | no `WARNING:` strip | same | killed (12F) |
| M12 | phase-filtered row search | same | killed (4F) |
| M13 | any pending row qualifies | same | killed (7F) |
| M14 | "lane" back in the text | docs_lint `-k factor_surface` | killed |
| M15 | prefix constant drifts from the text | lifecycle + docs_lint `-k factor` | killed |

There were 15 mutants, all killed and none survived.

## Candidate findings

| ID | Claim | Evidence | execution_status | Blocking | Repair |
| --- | --- | --- | --- | --- | --- |
| RT-DEL-1 | After the person switches some factors on, each relevant factor left off still gets the old wording ("assessment", "review lane") | `wave_validators.check_factor_surface`, the `else` branch after `if not active_factors and inactive_applicable` | inferred (code read) | non-blocking | Add "mark any you leave off `partial`" to the switch-on option; leave per-factor rewording to a later wave |
| RT-DEL-2 | The remedy example is POSIX-only; the native Windows launcher is `.wavefoundry\bin\wf.cmd setup` | `venv_bootstrap._report_interpreter_mismatch`; `bin/wf.cmd` line 29 | inferred | non-blocking | Choose the example by `os.name`, or name both forms |
| RT-DEL-3 | `test_ok_when_python3_already_ge_311` fakes a 3.11 probe without patching `sys.version_info`, so on a 3.14 host the real notice leaks to the runner's stderr; the output depends on the host | baseline run of `EnsurePythonResolvesTests`: one "setup is running on Python 3.14" line | executed | non-blocking | Patch `vb.sys.version_info` to (3, 11) in that test, or capture stderr |
| RT-DEL-4 | The `wf_audit_install` tool docstring omits `pending_lint.warnings`; the contract (mcp-tool-surface.md lines 2734 and 2736), install-log-format and seed 012 include it | `server_impl.wf_audit_install` docstring | executed (read) | non-blocking | Add one sentence; the file is outside this delivery's paths |

There are no blocking findings. Census: both install-log-format copies are identical; the seed 011 and 160 hunks match their rendered prompts byte for byte; seed 012 has no rendered copy. The only remaining census hit is a negative assertion in a test.
