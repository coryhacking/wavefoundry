# Readiness review, docs-contract-reviewer: 24i2t first-install-guidance

Verdict: APPROVE, with four binding implementation conditions (C1-C4). No blocking defect.

## 1. Requirement 4 census (run with git grep, outside docs/waves and CHANGELOG.md)

Patterns "3.13 or newer", "3.13+", "3.11/3.12", "3.11 and 3.12", plus "deprecated" near Python. Files that state the recommendation and must change:

- `.wavefoundry/framework/README.md` lines 132, 134 (3.11/3.12), 136 (`python_runtime_deprecated` / "deprecation alone")
- `.wavefoundry/framework/seeds/011-install-wavefoundry-phase-1.prompt.md:54`
- `.wavefoundry/framework/seeds/160-upgrade-wavefoundry.prompt.md:1078`
- `docs/architecture/contracts/mcp-tool-surface.md:2986` ("3.11/3.12", `recommended minimum 3.13`, "3.13+ has no deprecation entry")
- `docs/references/project-overview.md:169`, `docs/references/native-windows-support.md:144`
- `docs/contributing/build-and-verification.md:752`
- `docs/prompts/install-wavefoundry.prompt.md:45`, `docs/prompts/upgrade-wavefoundry.prompt.md:426` and `:812`
- Code (not prose): `runtime_advisory.py:16,19,20,24`; `venv_bootstrap.py:373`; `tests/test_runtime_advisory.py` (the `deprecated` assertion at 57 and the range pin).

Judged keep: `README.md:145` (historical test statement), `docs/repo-index.md` (repo's own interpreter fact), `pyproject.toml` classifiers (out of scope; note 3.14 is absent), `test_server_tools_lifecycle.py:16616` (comment; touch only if desired), the indexer/path comments.

The four-phrase rule does catch every recommendation statement today. Gap: it has no "deprecated" pattern, so a variant like "3.11 or 3.12" would escape. All ten files above happen to match, but AC-3's claim "no deprecation wording for 3.11 to 3.13" is only proved if the command also runs the `deprecated` grep. See C1.

Rendered files: `docs/prompts/install-wavefoundry.prompt.md` (from seed 011) and `docs/prompts/upgrade-wavefoundry.prompt.md` (from seed 160) are seed-derived. Do not hand-edit them without the seed edit; update the seed under `seed_edit_allowed`, then bring the prompts in line through the render/upgrade path, and confirm no seed-vs-prompt drift remains. `build-and-verification.md:752`, `project-overview.md` and `native-windows-support.md` are hand-maintained copies of the same paragraph and are edited directly (`docs/` edits, edit gate not needed).

## 2. Requirement 6 wording accuracy

`check_factor_surface` error (a): a factor in `applicable_factors` with no canonical `docs/agents/factor-<nn>-<name>.md` is an ERROR that blocks the gate. Seed 050 task 5 generates docs only during install; seed 160's factor-surface backfill regenerates them during an upgrade. Nothing generates docs when someone edits `applicable_factors` by hand. So "add their numbers, after which the agent generates their reviewer docs" promises an automatic step that does not exist, and omits that docs lint reports an error until the docs exist. The old "re-run ... via Upgrade Wavefoundry" was the real mechanism (the backfill); dropping it without a replacement removes the only path.

C2: option 1 must say: add the numbers to `applicable_factors` and ask your agent to generate `docs/agents/factor-<nn>-<name>.md` for each; until those files exist docs lint reports an error for them. No "Upgrade Wavefoundry" wording is needed. AC-5 should assert the "generate ... docs" and "error until" clauses, not only the absence of banned words. Option 2 ("mark `partial`") is accurate: warning (d) keys on status `applicable` only. Also state in the message that nothing is required while the set is empty (accurate per the docstring).

## 3. Seed 050 and the pending_lint contract

- Seed 050 line 88 says an empty lane set "emits a factor-review reconciliation warning on every audit". After this change that holds only after row 2.5 is checked. Optional tightening, but not contradicting; no edit required.
- Contract `mcp-tool-surface.md` wf_audit_install (lines 2733, 2734, 2736): line 2736 pins `pending_lint` to `{count, errors, truncated, note}`; line 2734 says `WARNING:` lines ride every envelope as `docs_lint_warning` diagnostics. Requirement 5 adds `pending_lint.warnings` and an exception to 2734. C3: update 2733/2734/2736 to name the new key, whether it is always present or only when non-empty, its own note, and the exemption from `docs_lint_warning` and `data.warnings`. Add this file to the Affected Architecture Docs section (it currently names only the advisory range).
- `seeds/012-install-wavefoundry-phase-2.prompt.md:34` describes `pending_lint` as "expected absences"; add "and the pending seed-050 factor warning" in one clause (seed edit, and its rendered phase-2 prompt follows the seed). Same note as 2736: the old `note` ("become blocking at the final install gate") must not be reused for warnings.
- C4: the Serialization Points list does not name seed 012, `mcp-tool-surface.md`, or the three hand-maintained docs; add them (bare paths).

## 4. Primer questions

F4 (census gap): repaired; residual is the missing `deprecated` grep (C1: record both greps in the Progress Log). F6 (3.13 wording, "deprecated" vs "supported"): Requirement 1 and 4 settle it as "supported, security-only"; keep the machine code `python_runtime_deprecated` but the prose and the advisory `message` must not use "deprecated" (the field name stays; say so once in README 136 and the contract so the name does not contradict the prose). Qualify the installer clause with "from python.org" as the spec does.

## Verdict

Approve. Conditions C1-C4 bind implementation; record them in the Progress Log (no re-ready round needed, per standing operator rule).
