# Readiness red-team primer: 24i2t first-install-guidance

Red-team, standard depth, read-only. MCP tools loaded via ToolSearch; Bash used for the executed probes.

## strongest_challenge

Requirement 2 tells the operator something false. When the tool venv's `pyvenv.cfg` names one minor version and `python3` is another, no ordinary `wf` subcommand or MCP start rebuilds it. `venv_bootstrap.activate_tool_venv()` prints "built for Python X but this is Y, run wf setup" and exits 2. That is the path taken by `server.py:280` and by `wf_cli.main` for every subcommand except setup. Only setup (`setup_index._bootstrap_venv`, lines 156-160) recreates the venv. I ran a probe with a fake venv at version 3.99 and got exit 2 with exactly that message. In the motivating case, the operator's MCP host therefore fails to start; nothing rebuilds the venv on next use. The Rationale's "next wf call through python3 rebuilds it" models the wrong mechanism. AC-2 checks only that the notice names both versions, so a notice carrying the wrong consequence would pass.

## best_alternative

Keep the notice, but make it state the real consequence and remedy: "the agent host and `wf` launch `python3` (3.12). They will refuse this tool environment until you rerun setup with that interpreter (`.wavefoundry/bin/wf setup`)." AC-2 should assert that remedy text. A stronger option is to have `setup_readiness` report a mismatch between the venv's build version and `python3`. `index_health` and `wf setup --check` would then surface it persistently.

## primer_questions

1. Does the notice describe what `activate_tool_venv` actually does (exit 2), and does AC-2 assert the remedy?
2. With exactly one applicable factor, the per-factor warnings fire instead of the consolidated one (`check_factor_surface` requires `len(inactive_applicable) >= 2`). Is that install path in scope?
3. Which response field carries "pending context"? The `pending_lint.note` says entries "become blocking at the final install gate", which is wrong for a warning.
4. Should the 3.13 advisory, which also fires on Homebrew and distro builds that still get patches, say "if installed from python.org"? And is the label "deprecated" (`python_runtime_deprecated`, plus the README prose) still accurate next to "supported"?

## efficacy_replay

- **Operator with 3.12 first on PATH runs setup with 3.14.** The strict check probes `python3`, gets 3.12, which is at least 3.11, so it passes. The new notice fires. Setup builds a 3.14 venv. The MCP host then launches `python3` (3.12), and `activate_tool_venv` exits 2. The notice, as written, says the environment will be rebuilt, which misdirects. Result: partial fix. It becomes a full fix once F1 is repaired. Confirmed safe: under `wf setup`, `.wavefoundry/bin/wf` runs `exec python3` and `wf.cmd` runs `where.exe python3` then `python3 ...`, so the running and probed interpreters are the same and the notice stays silent.
- **Fresh install, audit between rows 2.3 and 2.5.** The template parses so that row 2.5 is the only row with `source == "seed-050"` (executed). With at least 2 applicable factors, the consolidated warning moves to pending, and seed-050 task 5 then fills `applicable_factors`. Result: fixed. With exactly 1 applicable factor it is not fixed (F2).

## Candidate findings

**F1. Mismatch notice states a false consequence**
- Evidence: `venv_bootstrap.activate_tool_venv` (version guard, `sys.exit(2)`), its callers `server.py:280` and `wf_cli.main:215`, and `setup_index._bootstrap_venv:156`.
- execution_status: executed (fake-venv probe, exit 2).
- Severity: blocking.
- Repair: reword Requirement 2 and the Rationale to say the host refuses the venv and to rerun `wf setup` with `python3`. Have AC-2 assert that text.

**F2. The single-applicable-factor install path is not covered**
- Evidence: the `check_factor_surface` consolidated branch fires only when `len(inactive_applicable) >= 2`. Otherwise the per-factor warnings, written in lane/assessment vocabulary, fire on every audit between rows 2.3 and 2.5.
- execution_status: inferred (read).
- Severity: non-blocking.
- Repair: key the pending treatment on "lane set empty plus seed-050 row pending" rather than on the consolidated text, or drop the threshold.

**F3. The pending carrier is unspecified**
- Evidence: in `wf_audit_install_response`, `pending_lint` holds errors and its note claims they will become blocking. The `lint_errors` branch also returns the raw `warnings` list in `data`.
- execution_status: inferred.
- Severity: non-blocking.
- Repair: name the field (for example `pending_lint.warnings` with its own note). Have AC-4 also assert that the warning is absent from `data.warnings` in the `lint_errors` branch.

**F4. The census pattern misses range-only prose**
- Evidence: `.wavefoundry/framework/README.md:134` ("advisory ... on Python 3.11/3.12") does not match either census pattern.
- execution_status: executed (`git grep`).
- Severity: non-blocking.
- Repair: add `3.11/3.12` and `3.11 and 3.12` to the census.

**F5. The probe sees the setup shell's PATH and working directory, not the host's**
- Evidence: `_probe_interpreter` uses `shutil.which("python3")`. macOS GUI hosts and pyenv/asdf shims can resolve a different interpreter.
- execution_status: inferred.
- Severity: non-blocking.
- Repair: word the notice as "the `python3` on this PATH".

**F6. 3.13 advisory wording**
- Evidence: `runtime_advisory.python_runtime_advisory` cannot tell how Python was installed, and its message currently says "deprecated".
- execution_status: inferred.
- Severity: non-blocking.
- Repair: qualify the installer clause with "from python.org". Decide "deprecated" versus "security-only" consistently across the README, the contract doc and the message.

## Checks that hold

- **AC-1 to AC-5 fail on today's code.** AC-1: the advisory range is `((3, 11), (3, 12))`. AC-2: the ok path prints nothing. AC-3: `venv_bootstrap.py:373` says "3.13+". AC-4: the warning reaches the diagnostics in every branch. AC-5: the text contains "lane" and "Upgrade Wavefoundry".
- **`wf_audit_install` surfaces warnings on every non-error path.** It does so through `lint_warning_diagnostics` in the `next_step`, `complete` and `checked_but_missing` branches, so the AC-4 oracle works.
- **Pins on the version range.** The only pins are in `tests/test_runtime_advisory.py` (the `(3,11),(3,12)` range and `"3.13"`) and the contract doc `mcp-tool-surface.md:2986`, which the census covers. Other tests patch the advisory to `None` or derive it at runtime.
- **The pending treatment hides nothing real.** It applies only while row 2.5 is pending, and `wf_validate_docs` output is unchanged.
