# Operator spot-check, wave 245na query set (draft, not frozen)

The 10 cases with the lowest `sha256(id)` (authoring rule 8). For each, check that the
query reads as an agent's situation before it knows the lesson, and that it does not
copy or paraphrase the target record's summary (leakage). Reply keep, fix (with wording)
or drop for each id.

## 1. `a-0286` (answerable, heldout)

- Query: add retrieval tests in test_server_tools_retrieval.py for index content correctness
- grep_terms: `test_server_tools_retrieval`, `retrieval`
- Relevant `1wxu2-mem repaired-defect-code-rv1-2`: Repaired defect CODE-RV1-2
  - Summary: Real defect fixed in wave 1wpif: The named file is exhaustively repaired and independently verified; the residual site outside it is CODE-RV2-2, repaired in cycle 3.

## 2. `a-0019` (answerable, heldout)

- Query: Full index rebuild prints SyntaxWarning invalid escape sequence with only <unknown>:293 as location
- grep_terms: `syntaxwarning`, `invalid escape`, `unknown`
- Relevant `1swco-mem give-target-code-parser-failures-their-real-filename`: Give target-code parser failures their real filename
  - Summary: When parsing target Python during indexing or chunking, pass the repository-relative filename into ast.parse and fix warning-producing source at its origin; pair the fix with a sweep guard so invalid escapes or parse diagnostics cannot regress into pathless build noise.

## 3. `a-0050` (answerable, heldout)

- Query: After renaming MCP tools, clients still call the old wave_ names and get tool not found
- grep_terms: `tool not found`, `wave_`, `wf_`
- Relevant `1t38p-mem reload-survivor-mcp-tool-changes-are-a-process-restart-bound`: Reload-survivor MCP tool changes are a process-restart boundary
  - Summary: Hot reload (wf_reload_mcp) re-imports server_impl but deliberately cannot replace the in-memory server.py runner, so tools in _RELOAD_SURVIVOR_TOOLS keep their old definition and name until the host process restarts. Renaming or removing a survivor therefore requires one host reconnect, and the old in-memory name can trip guards written against the new contract (observed: the prefix-contract check refused re-registration during the wave_ to wf_ rename). Verify such changes with a fresh-process MCP tools/list probe, never against the degraded live session.

## 4. `a-0034` (answerable, dev)

- Query: A one-shot memory close in the MCP server silently does nothing and reports no error
- grep_terms: `memory`, `close`, `silent`
- Relevant `1syzx-mem close-requires-explicit-disposition-for-evidence-derived-mem`: Close requires explicit disposition for evidence-derived memory
  - Summary: Before closing a wave, run memory proposal and give every drafted candidate an explicit promote, retain, reject, or rewrite disposition. Treat zero-memory as valid only when drafting itself finds no material source; never interpret a failed or skipped proposal pass as an empty successful result.

## 5. `a-0154` (answerable, heldout)

- Query: reconcile_scan flags a non-allow hit under the wrong provenance channel
- grep_terms: `reconcile_scan`, `provenance`, `allow`
- Relevant `1u43m-mem reconcile-scan-py-fragility-is-channel-boundaries-four-repai`: reconcile_scan.py fragility is channel boundaries: four repairs across two waves
  - Summary: Every reconcile_scan.py repair in waves 1tz6l and 1u2b0 is a channel-boundary defect: a scan hit routed to the wrong channel. Misrouting toward the self-healing channel is the dangerous direction, because that channel tells the operator "no edit needed" for a stale reference the renderer will never rewrite, producing a permanently unfixed reference nobody is looking at. 1tz6l: a rollback-bridge backup leaked into the live scan (scope boundary), and host-permission files were not partitioned to their own channel. 1u2b0: _is_renderer_provenance_hit gated only on rel == '.claude/settings.json' plus a rule match, so a retired tool name inside a HOOKS COMMAND in that file was classified as renderer provenance; and after that repair, _json_array_spans still keyed on ANY array named allow at any nesting depth, so a foreign somePlugin.config.allow hit misrouted the same way. The delivery review named the control gap explicitly: the existing near-miss tests varied the RULE and the FILE but never the LOCATION within the file, which is how the boundary went vacuous in a new dimension even though the fragile-file protocol was followed. Current code pins the two renderer-governed regions to exact document positions (the top-level provenance array, and the allow array that is a direct member of the TOP-LEVEL permissions object), with a position-tracking scan that consumes string literals whole and degrades every unrecognized or malformed shape to "not governed", i.e. the operator channel, which is the safe direction. This record subsumes the single-wave view in 1u0yp-mem.

## 6. `a-0380` (answerable, heldout)

- Query: server_tools_support.py, record_layout_support.py and _tag_utils.py import order in test_record_layout_cold_sites.py
- grep_terms: `server_tools_support`, `_tag_utils`
- Relevant `1z6oc-mem load-server-shares-server-impl-test-order-leaks-need-a-pairw`: load_server shares server_impl; test-order leaks need a pairwise single-process sweep
  - Summary: server_tools_support.load_server re-executes only server.py, so server_impl and its _script_cache persist across calls; only the FIRST server_impl import evicts record_paths from sys.modules, leaving spec-loaded modules (e.g. a test's docs_gardener) holding an older copy that patch_layout misses unless passed via modules=. Modules that capture layout at import freeze whatever layout the first importer patched (wave 1z8tz removed the _tag_utils and retrieval_eval captures; review_policy.SCAFFOLD_DOCS remains, pinned by the census test). run_tests.py isolates files per process, so these leaks only show under single-process unittest; verify an isolation fix by running every layout-patching or load_server file before the fixed module in one interpreter, not just the reported pair.

## 7. `n-018` (null, dev)

- Query: wf.cmd fails with 'python3 is not recognized as an internal or external command' on a fresh machine.
- grep_terms: `wf.cmd`, `python3`

## 8. `a-0320` (answerable, dev)

- Query: reap state surface returns malformed table entries that break the health output
- grep_terms: `ReapStateSurfaceTests`, `malformed`
- Relevant `1x729-mem a-store-meta-reader-that-validates-only-the-outer-shape-serv`: A store meta reader that validates only the outer shape serves malformed entries
  - Summary: Wave 1x6ti (1x551): reap_state_for_index in index_state_store.py served hand-edited or future-schema per-table entries verbatim when it checked only that the deferred and preserved maps were dicts, and a second pass that coerced with int() still accepted bools, truncated floats and defaulted a missing key under a surviving mutant. The shipped reader accepts a count only when it is an int, not a bool and non-negative (_is_count), drops any other entry, and reads a record with no well-formed entry as none, so the two tools that share it (index_build_status, index_health) never show a malformed block. Reuse the posture for any new meta record: validate per entry, no coercion, no default; the display-only generation and timestamp fields are still coerced (QA-RV2-2, accepted).

## 9. `a-0201` (answerable, heldout)

- Query: editing test_events_only_residue_census.py to pin a prose claim across several living docs
- grep_terms: `residue_census`, `events_only`
- Relevant `1ug1d-mem repo-tree-census-pins-home-in-the-census-module-key-on-the-c`: Repo-tree census pins: home in the census module, key on the claim
  - Summary: A durable pin that a false doc claim has not reappeared belongs in test_events_only_residue_census.py, whose _census_files() already builds the shipped-surface scope and excludes docs/waves and docs/plans by construction, so wave archives cannot defeat it. Do not home it in a module that only reads constants; that acquires a whole-repo filesystem dependency and has no scope scaffolding. Key the pin on the false CLAIM shape (for example `delivery_mode=universal`), never on a bare token that is also a live legal value: `universal` has 64 legitimate occurrences across 28 in-scope files as an enum member and as ordinary English, so a token sweep is red on contact, then loosened, then rotted. Add no allowance table when the expected count is zero in every in-scope file: a zero-count allowance exempts nothing, and a sibling test asserting the corpus total is zero is strictly stronger and makes any exempting entry fail immediately. Extend the scope only where a real carrier lives (docs/references/ had to be added) and keep docs/architecture/decisions/ excluded when an ADR deliberately preserves the original claim under an amendment note.

## 10. `a-0004` (answerable, heldout)

- Query: Code index build via MCP fails downloading the embedding model with CERTIFICATE_VERIFY_FAILED behind a corporate TLS-intercepting proxy even though wf setup succeeded
- grep_terms: `certificate_verify_failed`, `ca bundle`, `httpx`
- Relevant `1sv1q-mem census-model-download-paths-by-behavior-not-constructor-spel`: Census model-download paths by behavior, not constructor spelling
  - Summary: When changing model-download or TLS handling, census construction paths by behavior and call graph rather than only literal constructor tokens, apply the CA environment at every raw download path, and keep certificate diagnostics visible through graceful-degradation catches.
