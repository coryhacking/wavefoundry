import difflib, random, hashlib
s="When changing renderers, write fully generated surfaces with explicit byte-stable line endings, but preserve the existing file's newline behavior when patching operator-authored content in place."
qs={"light paraphrase":"When changing a renderer, write generated surfaces with explicit byte-stable line endings but keep the existing file's newline behavior when patching operator content in place.",
"close paraphrase":"I'm changing the renderer; fully generated files get stable line endings, but in-place patches of operator files must keep their existing newlines.",
"situation":"A Windows user reports AGENTS.md flipped from CRLF to LF after an upgrade rewrote its marker block."}
for k,q in qs.items(): print("seqratio",k,round(difflib.SequenceMatcher(None,q.lower(),s.lower()).ratio(),3))
# split by case id vs record: fraction of records with queries in both splits
def split(i): return "heldout" if int(hashlib.sha256(i.encode()).hexdigest()[:8],16)%10>=3 else "dev"
recs=175; both=0
for r in range(recs):
    ss={split(f"r{r:03d}-q{j}") for j in range(3)}
    both+= len(ss)==2
print("records with queries in both dev and heldout (3 q each):",both,"/",recs)
# null cases held out
print("heldout nulls of 40:",sum(split(f"n-{i:03d}")=="heldout" for i in range(1,41)), " stale of 23:",sum(split(f"s-{i:03d}")=="heldout" for i in range(1,24)))
# bootstrap width false_show on 28 nulls
rng=random.Random(0)
for p in (0.1,0.25):
    xs=[1]*round(28*p)+[0]*(28-round(28*p))
    bs=sorted(sum(rng.choice(xs) for _ in xs)/28 for _ in range(1000))
    print("false_show p",p,"CI",bs[25],bs[974])
# gate tautology: production shows 1 relevant record on 3% of 350 answerable cases, nothing elsewhere, nothing on nulls
n=350; prod=[(1,1) if i<10 else (0,0) for i in range(n)]  # (relevant shown, shown)
full=[(1,175)]*n
bm=[(1,5) if i<200 else (0,5) for i in range(n)]
def pooled(rows): s=sum(b for a,b in rows); return None if s==0 else sum(a for a,b in rows)/s
def paired(a,b):
    d=[];idx=list(range(n))
    for _ in range(1000):
        smp=[rng.choice(idx) for _ in idx]
        pa=pooled([a[i] for i in smp]); pb=pooled([b[i] for i in smp])
        d.append(None if pa is None or pb is None else pa-pb)
    nn=sum(x is None for x in d); v=sorted(x for x in d if x is not None)
    return nn, v[int(0.025*len(v))]
print("prod recall@5", 10/n, "precision", pooled(prod))
print("vs full_context (none-resamples, p2.5 diff):",paired(prod,full))
print("vs bm25 recall 0.57 (none-resamples, p2.5 diff):",paired(prod,bm))
