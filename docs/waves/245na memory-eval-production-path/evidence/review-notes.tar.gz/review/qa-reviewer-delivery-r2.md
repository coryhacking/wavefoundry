# QA delivery reverification, wave 245na (change 245sp), round 2

Lane: qa-reviewer. Context: `245na-qa-reviewer-delivery-r2`. Fresh and independent: I wrote neither the findings nor the repair. No repo edits; all mutation ran in the session scratchpad.

## Verdict

The repair holds. Both cycle-2 findings are reverified as completed, the convergence checkpoint was derived, and the qa-reviewer delivery approval is recorded.

## Method

- A full suite (`run_tests.py --no-cache`, implementer's `full-suite-3.log`) was running, so I did not use `run_tests.py`.
- I copied `.wavefoundry/framework` (without `__pycache__`) to the scratchpad and ran `python3 -B -m unittest tests.test_memory_eval` from `scripts/`.
- I applied each mutant alone to a `memory_eval.py` restored byte-identical (`cmp`) from the repo file.

## Results

| Run | Result |
| --- | --- |
| Real code | Ran 48, OK |
| M14: `_bootstrap` divides by `len(draw)` instead of the pooled case count | FAILED (1): `test_bootstrap_pools_cases_across_unequal_clusters` |
| M8: `bounded=True` dropped at the `_sanity_floor` call | FAILED (1): `test_curated_pass_wires_the_bounded_experimental_rows` |
| Real code after restore | Ran 48, OK |

A first attempt ran M8 on top of M14 because the backup path was wrong. I discarded that run and reran M8 alone.

## Test review

- The pooling test computes values by hand: 2/3 for draw `[0, 1]` over clusters `(2.0, 2)` and `(0.0, 1)`, and 4/4 for `[0, 0]`. It also checks `score_arms` end to end over unequal held-out clusters. It rejects an unweighted mean of cluster means (0.5) by inspection, but I did not run that mutant.
- The wiring test spies `_candidate_and_controls` under `run_curated`. It asserts that at least one call happened and that every call passed `bounded=True`. The ranking effect of the bound stays pinned by the AC-9 helper test.
- I read the new `dense_only`, hybrid lexical cap, incomplete-coverage and stale-row tests, and they run green. I did not mutation-probe them one by one.

## Carried notes

- The first-round findings and the sample notes in `qa-reviewer-delivery.md` stand.
- Minor: the Progress Log records intervals only for recall@5.
