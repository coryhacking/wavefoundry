# Council chair readiness, wave 245na (spec 245sp)

Context `245na-council-chair-readiness`, fresh and independent. Receipt `review-policy-3b5b233080d44f483481`.

**Verdict: approve readiness. intent_fit: establishes.**

## State checked

- `wf_review_wave(phase='prepare')`: code-reviewer, qa-reviewer, architecture-reviewer and docs-contract-reviewer approvals are current. Lint passed.
- `wf_review_event(event='list')`: all 7 findings have terminal heads at cycle 1, repair completed, no unresolved lanes.

## Seats

- red-team (fixed): `red-team-readiness.md`, `red-team-focused-r2.md`, `red-team-probe-r2.py`. Both red-team findings were reverified as repaired.
- docs-contract-reviewer (rotating): `docs-contract-reviewer-readiness.md`, `docs-contract-reviewer-focused-r2.md`. All four round-1 advisories were applied, and full `wf_validate_docs` is clean.

## Strongest challenge

The red-team asked whether these numbers can look good while memory quality is bad. Some paths remain:

- Queries authored by the same model family, plus a labeling pool built from BM25 and dense results, both tilt the scores toward dense and production.
- Path-style queries come close to a target lookup.
- `full_context` recall@5 is ranked by id.
- The retrievability count is close to a tautology.

None of this blocks readiness. The report gives no verdict, leads with recall and flags `recall_below_bm25`, and the eval reference must state these limits. The operator decides whether the pause lifts.

## Strongest alternative

The red-team proposed mining real situations from later changes that touched each record's targets. The design uses a temporal split, takes null cases from those changes and adds grep to the labeling pool. It removes authoring bias and handles corpus drift. It is a candidate supplement for a later track, not a readiness blocker.

## Chair executed check

The check ran in a scratch copy with `python3 -I`:

- The re-run of `red-team-probe-r2.py` showed 0 of 215 records straddling the split under the `source_id` key, against 112 of 215 under the case-id key. The AC-11 values and flag reproduce, and the run is deterministic.
- An independent recomputation of AC-1 matched the spec:
  - Scored arm: 0.75, 0.5, 0.4286, 0.5 and 1.0.
  - `full_context`: 1.0, 0.5625, 0.1667, 1.0 and 1.0, with `mean_shown` 6.0.
  - `no_memory`: 0, 0, null, 0 and 0.
- The AC-1 and AC-5 split hashes matched the spec.
- Known-bad controls are detected:
  - A per-case precision mean gives 0.375 against the pooled 0.4286.
  - The case-id split key leaves 112 records straddling.

## Implementation carry-forwards

1. Report `full_context` as recall over all records, not recall@5, because it is ranked by memory id.
1. Dense arms on a stale or incomplete index report not measured.
1. Dense ties reuse production's `(-score, memory_id)` sort.
1. State that `target_retrievable.retrievable` is near-tautological. `crowded_past_search_cap` carries the signal.
1. Cover the two literals left only in Requirements: Req 3 (a case-level `split` field is ignored) and Req 6 (`cosine_threshold: 0.95`).
1. The coverage helper joins `vectors_docs`, so a chunk without a vector does not count as covered.

No repository edits beyond this note. The full suite was not run.
