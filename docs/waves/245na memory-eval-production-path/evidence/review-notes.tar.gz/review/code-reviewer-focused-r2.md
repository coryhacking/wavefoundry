# code-reviewer focused readiness r2, wave 245na

Context `245na-code-reviewer-focused-r2`, fresh and independent (wrote neither the findings nor the repair). MCP review tools loaded through ToolSearch; code reads used `sed` and `grep` on the cited sites plus `python3 -c` probes against the live tree. No repo edits.

Verdict: both findings hold as repaired. Readiness approval recorded.

## 245na-cr-grep-null-gate: repair holds

1. Req 2.2 requires 1 to 3 `grep_terms` on every case, and the loader refuses a set without them (`query_set_invalid`). AC-4 tests the refusal.
2. AC-1 adds a null case `q-004` with `grep_terms: ["lockfile"]`. On it, grep ranks `[r1, r3]` and `false_show_rate` is 1.0, so an empty grep result fails the test.
3. Req 10 removes the gate, and AC-11 checks that no `beats`, `pause` or new `gate` key exists.
4. Probe: `r1`, `r2`, `r4`, `q-004` and `q-005` hash to heldout. `r3` and `n-001` hash to dev. `q-001`, `q-002` and `n-005` hash to heldout. This matches AC-1 and AC-5.
5. The AC-1 values recompute by hand:
   1. Scored arm: 0.75, 0.5, 0.4286, 0.5 and 1.0.
   2. `full_context`: 1.0, 0.5625, 0.1667 and `mean_shown` 6.0.

## 245na-cr-arm-corpus-and-signals: repair holds

1. **Corpus.** Req 7 matches `memory_search_response` (memory_handlers.py:1772-1777), which ranks `DEFAULT_SURFACED_STATUSES` records plus the archive register entries. Live tree: 174 surfaced records and 23 register entries.
2. **Dense stream.** `_memory_query_records` (1673-1689) calls `_memory_candidate_scores` and fuses with `reciprocal_rank_fusion([semantic, lexical[:MEMORY_SEARCH_CAP]])[:MEMORY_QUERY_CHECK_CAP]`. Req 7.5 states the same expression in the same stream order, so `hybrid_no_rerank` is production before the reranker screen.
3. **Coverage.** The Req 17.1 three-way partition (covered, stale, missing) is total and reads only `chunks_docs` and `layer_path_state`, the tables `dense_path_scores` already reads. AC-10 tests it with an embedder that raises on any call.
4. **Target deviation: accepted.**
   1. `memory_search_response` clamps `limit` to `MEMORY_SEARCH_CAP` (20) at line 1739.
   2. Live probe: 28 records target `server_impl.py`. 4 records have every file target shared by more than 20 corpus items, counting register entries, so a capped check would misreport them.
   3. The uncapped `match_targets` check plus `crowded_past_search_cap` reports both views honestly. AC-10's 21-on-one-target fixture gives `crowded_past_search_cap` 1 by construction.

## Advisories (not blocking; coordinator decides DO or DECLINE)

1. `target_retrievable.retrievable` is nearly a tautology. Live probe: 174 of 174 records match their own file targets, because `match_targets` compares the ref with the path as passed. It catches only malformed refs, such as a ref with a backslash. `crowded_past_search_cap` carries the signal. Suggest that the eval reference say so. File existence is track 4.
2. The spec does not say what `dense_only` and `hybrid_no_rerank` report when `_memory_candidate_scores` returns `source_current: false` or `complete: false`. In that state the dense stream is empty or partial, and the arm would score as a measured result. AC-13 is safe, because zero production fallbacks imply a current and complete dense state. Other runs are not. Suggest omitting or flagging those arms in that state, as the production arm is.
3. Req 7.4 says "the order of `_memory_candidate_scores`". Production re-sorts by `(-score, memory_id)`, while `dense_path_scores` sorts ties by path. Suggest reusing production's sort, so the AC-8 equality also holds on ties.

## Limitations

This is a spec-level readiness review, because the implementation does not exist yet. A focused `run_tests.py --file test_memory_eval.py` run was refused because another run held `test-run.lock`. Round 1 recorded 26 OK on the same file.
