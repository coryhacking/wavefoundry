import sys, sqlite3, struct, tempfile, json, builtins
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, sys.argv[1])
import sqlite_vector_store as store
H = lambda c: c*64
P = [f"docs/agents/memory/m{i}.md" for i in range(4)]
def build(db, stale=None, missing=None):
    c = sqlite3.connect(db)
    c.executescript("CREATE TABLE chunks_docs(id INTEGER PRIMARY KEY,path TEXT);"
        "CREATE TABLE vectors_docs(chunk_id INTEGER PRIMARY KEY,embedding BLOB);"
        "CREATE TABLE layer_path_state(layer TEXT,path TEXT,hash TEXT);")
    for i,p in enumerate(P):
        if p != missing:
            c.execute("INSERT INTO chunks_docs VALUES(?,?)",(i,p)); c.execute("INSERT INTO vectors_docs VALUES(?,?)",(i,struct.pack('<f',0.1*i)))
        c.execute("INSERT INTO layer_path_state VALUES('docs',?,?)",(p, H('b') if p==stale else H('a')))
    c.commit(); c.close()
def coverage(db, expected):  # spec Requirement 16 definition, model-free SQL
    c = sqlite3.connect(db); out={"requested_paths":len(expected),"covered_paths":0,"stale_paths":0,"missing_paths":0}
    for p,h in expected.items():
        n = c.execute("SELECT count(*) FROM chunks_docs WHERE path=?",(p,)).fetchone()[0]
        s = c.execute("SELECT hash FROM layer_path_state WHERE layer='docs' AND path=?",(p,)).fetchone()
        if not n: out["missing_paths"]+=1
        elif s and s[0]==h: out["covered_paths"]+=1
        else: out["stale_paths"]+=1
    c.close(); return out
exp = {p:H('a') for p in P}
for label,kw in [("fresh",{}),("one_stale",{"stale":P[1]}),("one_missing",{"missing":P[2]})]:
    with tempfile.TemporaryDirectory() as t:
        db = Path(t)/"x.sqlite"; build(db, **kw)
        def ro(_):
            d = sqlite3.connect(db); d.create_function("vec_distance_cosine",2,lambda b,q: struct.unpack('<f',b)[0]); return d
        with patch.object(store,"_open",side_effect=ro):
            dp = store.dense_path_scores(Path(t),"docs",[1.0]*store.DIMENSIONS,P,expected_hashes=exp)
        print(label, "dense_path_scores:", {k:dp.get(k) for k in ("covered_paths","complete","source_current")}, "spec_helper:", coverage(db, exp))
