# Architecture review, focused round 2, wave 245na

Reviewer: architecture-reviewer, fresh and independent context `245na-architecture-reviewer-focused-r2`. Receipt `review-policy-3b5b233080d44f483481`.

Verdict: **approved**. `245na-arch-dense-stream-unspecified` is resolved; its cycle-1 reverification is recorded and the head is terminal.

Retrieval: `code_keyword` returned `index_runtime_stale`, so I used grep and direct reads.

## Evidence run

- `python3 -B .wavefoundry/framework/scripts/run_tests.py --file test_memory_eval.py`: 26 tests, OK.
- Probe `.wavefoundry/work/245na/review/architecture-reviewer-focused-r2-probe.py`, a 4-path sqlite fixture (`chunks_docs`, `vectors_docs`, `layer_path_state`), no embedder loaded:
  - Real `dense_path_scores`: fresh 4 covered; one stale **0 covered**, `source_current` false (known-bad); one missing 3 covered.
  - Spec Requirement 16 definition on the same tables: `{4,4,0,0}`, `{4,3,1,0}`, `{4,3,0,1}`, exactly AC-10.

## The three checks

1. **Both dense arms use `_memory_candidate_scores`.** Requirement 7 names `WaveIndex._memory_candidate_scores(query, body_paths, expected_hashes=...)` with the paths and hashes `_memory_query_records` builds (memory_handlers.py:1657-1675), and forbids `search_docs` and `_semantic_order`. `hybrid_no_rerank` is `reciprocal_rank_fusion([semantic, lexical[:MEMORY_SEARCH_CAP]])[:MEMORY_QUERY_CHECK_CAP]`, the same list order as memory_handlers.py:1688-1689. AC-8 enforces it with a `search_docs` spy and a paths-and-hashes assertion. Holds.
2. **Coverage helper is model-free and reusable.** `memory_vector_coverage(index_dir, layer, expected_hashes)` reads only `chunks_docs` and `layer_path_state`, sits beside `dense_path_scores`, and takes no query or embedder, so `index_health` can call it for track 2. AC-10 uses a raising embedder stub and covers stale and missing separately. Holds.
3. **Placement.** `docs/evals/` already holds the repo's eval fixtures, and the docs layer indexes only `.md`/`.markdown` (indexer.py), so the JSON set and lock never enter retrieval. `docs/architecture/search-architecture.md:611-613` is in Scope, Serialization Points and Affected Architecture Docs, with the right replacement statement. Holds.

## Advisories (non-blocking)

- Production orders the semantic stream by `(-score, memory_id)` (memory_handlers.py:1687); `dense_path_scores` orders ties by path. For "equals production's candidate order" to hold exactly, the implementer should reuse production's sort key.
- When sources are stale or coverage is incomplete, `_memory_candidate_scores` returns no scores, so `dense_only` and `hybrid_no_rerank` would score near zero without a label. Production is omitted in that case (Requirement 11). The dense arms should follow the same not-measured rule, or the report should say so. AC-13 requires a current index, so the live run is unaffected.
- The helper's "chunks exist" test should join `vectors_docs`, as `dense_path_scores` does, so a chunk without a vector does not count as covered.

## Platforms

Pure sqlite and hashlib, with no model and no network. Behavior is the same on Windows, macOS, Linux and WSL2.
