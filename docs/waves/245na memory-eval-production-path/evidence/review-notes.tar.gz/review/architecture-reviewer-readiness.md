# Architecture review, readiness, wave 245na

Reviewer: architecture-reviewer (fresh, independent context). Receipt `review-policy-fa410d29b8588e678ce7`.

Verdict: **withheld**. One blocking finding recorded, `245na-arch-dense-stream-unspecified`. It overlaps part (b) of the code reviewer's `245na-cr-arm-corpus-and-signals`, and one repair clears both.

Retrieval: `index_health` returned `index_runtime_stale`, so I did not use the code_* tools. I read the files directly and grepped them.

## Evidence run

- `python3 -B .wavefoundry/framework/scripts/run_tests.py --file test_memory_eval.py`: 26 tests, OK.
- Scratch probe (`scratchpad/245na-arch/probe.py`), run with real `sqlite_vector_store.dense_path_scores` on a 4-path fixture:
  - All sources fresh: `covered_paths` 4, `complete` true, `source_current` true.
  - One source hash changed: `covered_paths` **0**, `complete` false, `source_current` false. A single stale file reads as zero coverage.
  - `limit=2`: `covered_paths` is still 4, so coverage counting does not depend on the score limit.

## Focus 1: where the eval lives and how it is layered

- Module and tool surface: this is sound. The engine stays in `memory_eval.py` and the handler stays in `memory_handlers.wf_memory_eval_response`. `server_impl.wf_memory_eval` (server_impl.py:25802) changes only to pass `get_handler().index`, which matches the `memory_search` handler. This respects the `domain-map.md` rule that "`memory_eval.py` retains its shared server handle". The input schema does not change.
- Production arm: calling `memory_search_response` with the shared index is the right seam. It goes through the real production code instead of a copy of it.
- **Blocking (recorded):** Requirement 7 does not say which dense stream `dense_only` and `hybrid_no_rerank` use. The existing curated helper `_semantic_order` (memory_eval.py:857) calls `index.search_docs`. That is a docs-wide hybrid search with reranking (server_impl.py:2961), and other docs crowd the memory hits out of its top 20. Production instead uses `_memory_candidate_scores` (server_impl.py:2155), which calls `dense_path_scores` over the eligible memory body paths. If an implementer reuses `_semantic_order`, the arms are mislabeled again, and `hybrid_no_rerank` no longer isolates the reranker. Repair: name `_memory_candidate_scores` with production's paths and hashes, use RRF order `[semantic, lexical[:MEMORY_SEARCH_CAP]]`, and add a spy AC check that `search_docs` is never called.
- Query-set location (advisory): the repository already keeps project eval fixtures under `docs/evals/` (`retrieval-quality-golden.json` and others). `retrieval_eval._CARRIER_PATH_RULES` classifies that path as `fixture_source`. The Decision Log did not consider `docs/evals/`. I recommend `docs/evals/memory-query-set.json` plus its lock, which keeps one convention. `docs/references/` is otherwise prose. Neither path is embedded, because the docs layer indexes only `.md` files (indexer.py:670), so neither choice leaks into retrieval. This is not blocking.
- Privacy boundary: aggregate-only output is consistent with the existing curated pass. The query set itself contains memory ids and query text. That is acceptable, because it is a repo-visible, reviewable file and is never echoed to MCP output. The exception-to-reason mapping in AC-17 matches the existing pattern at memory_eval.py:960-964.

## Focus 2: index signals, in index_health or in the eval

- Measuring memory coverage in the eval for track 1 is the right call: the arc needs the number now. Track 2 says it will surface memory coverage in `index_health`. To avoid building the signal twice, compute coverage and freshness with one helper that does not need a model, and that `index_health` can later call. That helper is a count over `chunks_docs` joined to `layer_path_state` for the active body paths. Requirement 16 currently takes both from a `dense_path_scores` call. That call needs a query embedding just to count rows, and it returns early when sources are stale.
- The probe confirms the early return: one stale record reports `covered_paths` 0. Track 2's own success measure reads `memory_vector_coverage` after an edit made outside the tools. As specified, that case reports an empty index instead of "N-1 covered, 1 stale". The code reviewer's finding (d) covers this, so I did not record a duplicate. Repair: report `covered_paths`, plus `stale_paths` or `source_current`, independently, and add a one-stale case to AC-14.
- `target_retrievable`: `match_targets` always matches a record to its own target (memory_records.py:1739). The signal therefore measures cap crowding only, with no index involved. The passive surface agents actually receive is `_memory_advisories_for_path`, capped at `MEMORY_ADVISORY_CAP = 3` (memory_handlers.py:348). The `memory_search` default limit of 10 is not that surface. The code reviewer's finding (c) covers the unstated limit. Architecturally, I recommend labeling this signal as crowding and scoring it at the advisory cap. Track 4 owns target resolution, and this signal neither pre-empts nor duplicates it.

## Focus 3: the embedded-text decision

- Measure-only is the right scope, and it agrees with the arc's pause on retrieval investment. The `embedded_text` descriptor matches the code: lexical `_record_text` uses summary, title, evidence, targets and keywords (memory_eval.py:235). The screen uses summary or title (memory_handlers.py:1694). Dense embeds record markdown chunks.
- Advisory: the spec has no decision rule. State that the ablations are informational and do not feed `retrieval_stack_gate`. State also that a later indexer spec decides on held-out paired evidence against `dense_only`, with the same cap. Note that the ablations use one vector per record, while production uses the minimum distance over chunks. That difference confounds "text choice" with "chunking", and the report should say so. Document-side embedding is reachable through `WaveIndex._get_embedder(DOCS_MODEL)`, and it runs locally on all four platforms.

## Focus 4: fit with arc tracks 2 to 4

- Nothing here blocks tracks 2 to 4. The production path, the indexer and `memory_policy_sort_key` are unchanged. The only pre-emption risk is the coverage primitive described above. If it is built model-free and shared, track 2 reuses it. If it is built on `dense_path_scores`, track 2 either reimplements it or inherits the misreport when sources are stale.

## Affected architecture docs

- **Omitted:** `docs/architecture/search-architecture.md:611-613` says "The memory evaluator's sampled self-summary output remains nonqualifying; detailed independent qualification is an explicit local run." After this change, the evaluator scores an independent frozen set through MCP, and the self-summary probe is only a floor, so that sentence goes stale. Add this doc to Affected Architecture Docs and to Serialization Points. This is small and can go in with the repair.
- `domain-map.md:37` remains accurate.
- The `testing-architecture.md` row is correctly listed.

## Sizing

The spec has 20 ACs. These can merge without losing a falsifiable check:
- AC-4 and AC-5, and AC-12 and AC-13. Make each known-bad control a clause of its parent AC.
- AC-9 and AC-11, the shared-index plumbing.
- AC-19 into AC-20, as a named suite assertion.
- AC-16's label list could become an authoring rule, keeping only the check that `memory_rrf_summary5` is absent.

That leaves about 15 ACs. The real size driver is query-set authoring, about 400 cases with independent labeling, and that work is already a single task.

## Platforms

All planned measurements run locally with no network, using the stdlib `difflib`, `random` and `hashlib`, sqlite, and the local docs model. The parsed-JSON hash avoids CRLF drift. The production expected hashes read the record bytes on the same machine that built the index, so CRLF checkouts stay consistent. Windows, macOS, Linux and WSL2 behave the same, except for the provider choice, which the spec already handles by falling back.
