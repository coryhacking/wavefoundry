# Delivery review (wave 245na, change 245sp)

The change `245sp-enh memory-eval-situation-queries-and-baselines` is implemented. Its spec is in `docs/waves/245na memory-eval-production-path/`. It is track 1 of the arc `docs/arcs/244cm memory-quality/244cm-arc memory-quality.md`.

## Delivered

`wf_memory_eval` now scores a frozen situation-language query set, and the old self-summary probe remains only as a labeled `sanity_floor`.

**Query set:**
- `docs/evals/memory-query-set.json` and its lock hold 606 cases: 517 answerable, 70 null and 19 stale.
- Dev and held-out are split by record.
- Authoring ran in a separate context with independent labelers, the similarity filter and a leakage rescan.
- The operator spot-checked 10 cases on 2026-11-23.

**Arms:** no_memory, grep, bm25_only, dense_only (`_memory_candidate_scores`), hybrid_no_rerank, production (`memory_search_response` with the real `WaveIndex` and reranker), full_context (`recall_all`), plus two ablations of the embedded text.

**Metrics and signals:**
- Recall@5 and MRR come first, then precision, false-show and stale-shown, each with intervals from a cluster bootstrap over records.
- Index signals report memory vector coverage (stale versus missing) and target retrievability, including `crowded_past_search_cap`.
- There is no automatic gate. The operator reads the report.

**Files changed:** `memory_eval.py`, `sqlite_vector_store.py`, `wf_server/memory_handlers.py`, `wf_server/server_impl.py`, `tests/test_memory_eval.py`, the handler digest fixture, the line-ending census fixture, `docs/specs/mcp-tool-surface.md`, `docs/references/memory-retrieval-eval.md`, two architecture docs, the CHANGELOG and the query-set files.

## Results

Held out, as recall@5 / precision / false-show:

| Arm | Recall@5 | Precision | False-show |
| --- | --- | --- | --- |
| hybrid_no_rerank | .857 | .238 | 1.0 |
| production | .673 | .394 | .389 |
| bm25_only | .782 | .213 | 1.0 |
| grep | .519 | .502 | .074 |

**Status of the acceptance criteria:**
- **AC-13 is `[~]`** with the operator's reasoning. 4 records have fewer than 2 answerable cases, and the work on them goes to track 4. The production measurement comes from the CLI run (0 of 606 fallbacks). Two runs of `wf_memory_eval` through MCP lost 7 and 15 probes to a transient lexical fallback during docs index publishes, which is recorded as track 2 evidence.
- **AC-14:** the full suite passed (13,421 OK) and the second profile passed (0 of 258 failed).

The logs are `.wavefoundry/work/245na/impl/full-suite-2.log` and `second-2.log`. `initial_delivery` is recorded.

## Your task, as a FRESH independent reviewer of your lane

1. **Read.** Load MCP tools via ToolSearch first and use code_* MCP-first. Read the spec, its Progress Log and Decision Log, and `git diff` for your remit.
2. **Verify each AC in your remit** with EXECUTED checks: mutants on a scratch copy, probes, and focused tests run with `run_tests.py --file`. Run each of those focused tests under BOTH the default profile and `--profile second`. Never run the full suite.
   - Do not run `wf_memory_eval` on this repo. It takes 14 minutes and is already measured.
   - Use small fixtures.
   - Make NO repo edits and do NOT mutate memory records.
3. **Record in the typed ledger** (`wf_review_event`, wave `245na`). Dry-run first, then create.
   - For a defect, record a delivery finding: `run_kind='initial_delivery'`, cycle 0, `actor=<lane>`, `context_id='245na-<lane>-delivery'`.
   - Otherwise record a delivery approval: `signoff_key=<lane>`, `approval_phase='delivery'`, `fresh_context=true`, `independent=true`, executed, with your OWN honest `integrity_checks`.
4. **Write notes** to `.wavefoundry/work/245na/review/<lane>-delivery.md`. No em-dashes.
5. **Reply** in under 100 words.
