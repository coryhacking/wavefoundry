# Red-team focused reverification, round 2 (wave 245na, spec 245sp)

Seat: red-team, context `245na-red-team-focused-r2`. Fresh and independent: this context wrote neither the round-1 findings nor the repair. Reverifications only, no approval.

Retrieval: read the round-1 notes and probe, the repaired spec (Requirements 3 and 7 to 10, ACs 2, 5 and 11, authoring rules, Decision Log) and the arc's retrieval-stack pause paragraph. No code tools were needed: no implementation exists yet, and the round-2 question is about the spec's rules. No repository edits.

Probe: `.wavefoundry/work/245na/review/red-team-probe-r2.py`, written and run in a scratch directory with `python3 -I`, then copied here. It reimplements the repaired split, the pinned cluster bootstrap, `arm_order` and the `recall_below_bm25` flag. It reads no repository state.

## Probe output (executed)

```
records straddling (repaired, source_id key): 0 / 215
records straddling (old, case-id key): 112 / 215
heldout clusters: 149 heldout nulls: 26 heldout stale: 18
prod recall@5 0.0286 [0.0057, 0.0571] precision 1.0 [1.0, 1.0] undefined_prec 5
bm25 recall@5 0.5714 [0.4971, 0.6457] precision 0.1143 [0.0994, 0.1291] undefined_prec 0
arm_order: ['bm25', 'prod']
prod flagged recall_below_bm25: True
AC11 prod recall 0.1 [0.0, 0.3] precision 1.0 ([1.0, 1.0], 352)
AC11 bm25 recall 0.6 [0.3, 0.9] precision 0.12 ([0.06, 0.18], 0)
AC11 flag: True
correlated recall CI cluster [0.4417, 0.625] case-level [0.4806, 0.5861]
determinism: True
```

## 245na-rt-gate-rewards-abstention: repair holds

The automatic gate is gone. Arms are ordered by recall@5, then MRR. The round-1 abstaining arm, which beat BM25 under the precision gate, now sits below BM25 and carries `recall_below_bm25`. The AC-11 fixture numbers and its flag reproduce under the pinned percentile rule. AC-11 forbids `beats`, `pause` and new `gate` keys. The arc leaves lifting the pause to the operator.

Residual, non-blocking:
- `full_context` ranks by memory id. On about 175 records its recall@5 is about 5/175, so it lands at the bottom and gets flagged, even though it shows every record. The arc's "if grep or full context matches production on recall and precision, accept the simpler design" stays unreachable for full context. It is now an operator reading, not a gate. Recommend the eval reference state that full_context recall@5 reflects id order, and that its effective recall is 1.0 at a mean_shown of about 175.
- The flag rule does not cover a null interval (fewer than 100 defined resamples). For recall at the planned held-out size this cannot happen.

## 245na-rt-split-and-resample-unit-is-case: repair holds

The split key is `source_id`. Nulls key on their own id, and stale cases key on the successor. Probe: 0 of 215 clusters straddle, against 112 under the old case-id key. The bootstrap resamples clusters and counts a cluster drawn twice twice. It pins `Random(0)`, 1000 resamples, the percentile indexes and the undefined handling. With record-correlated difficulty, the cluster interval (width 0.18) is wider than the case-level one (width 0.11), which is the intended correction. AC-5 has a case-id known-bad, and AC-2 has a `[point, point]` known-bad.

Residual, non-blocking:
- A record can still appear in `relevant_ids` of a case in the other split, through the labeler's additions. Tuning is global, not per record, so this leak is small.
- Held-out still holds about 26 nulls and 18 stale cases, so those intervals stay wide. The spec now reports them with no verdict, which is the right handling.
