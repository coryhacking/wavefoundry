# code-reviewer readiness notes, wave 245na

Verdict: approval withheld. Two blocking findings were recorded (context `245na-code-reviewer-readiness`):

1. `245na-cr-grep-null-gate`: Req 7.2 gives grep an empty result for a case without `grep_terms`. Authoring rules 3 and 5 give `grep_terms` only to answerable cases, so grep's `false_show_rate` is 0.0 by construction. Req 13 then needs production at 0 false shows on every null case to beat grep, so the verdict is decided by an authoring gap. AC-15 has no null case and cannot catch this. Fix: require `grep_terms` on every case and add a null-case sub-check to AC-15. This likely overlaps red-team `245na-rt-gate-rewards-abstention`.
2. `245na-cr-arm-corpus-and-signals`:
   1. Corpus. `memory_search_response` scores the surfaced records (active and candidate) plus 23 archive register entries. Req 7 names no corpus for bm25, dense or hybrid, and grep and full_context use active records only. Production alone can show stale register entries, which biases precision against it.
   2. Dense stream. The spec should name `WaveIndex._memory_candidate_scores` as the dense stream. It is already capped at 20 by `dense_path_scores`. With that stream, `hybrid_no_rerank` equals production before the rerank and isolates the reranker.
   3. Target retrievability. Req 16 uses the default `limit` of 10. A live probe found 5 of 174 records whose every file target is shared by more than 10 surfaced records (4 by more than 20). Truncation at the cap would read as "not retrievable".
   4. Coverage when stale. `dense_path_scores` returns `covered_paths` 0 when `source_current` is false, and it needs a real query vector. Use one `_memory_candidate_scores` call and report coverage as null when the source is stale.

Verified claims:
1. All cited sites resolve. `memory_search_response` accepts `index=` and `limit=` and returns `data.retrieval.qualification` and `fallback_reason`, so the Req 10 screening is computable. The `memory_search` handler passes `handler.index`. `wf_memory_eval` currently calls `wf_memory_eval_response(get_handler().root)` with no index, which matches the planned change. Top-level `server_impl` is a `sys.modules` alias of `wf_server.server_impl`, so `WaveIndex` is the same class on both import paths. `_get_memory_reranker` lives on the index, so a shared index reuses the reranker.
2. The AC-1 and AC-2 arithmetic checks out. The AC-8 split hashes match: q-001 to q-006 are heldout, n-001, n-002 and s-001 are dev.
3. Every baseline is locally computable without network access: BM25 is pure Python, the dense path uses the sqlite vector store, and the ablations and freeze cosine use `_get_embedder` and `_embed_query`. A missing model raises `SemanticModelUnavailableOfflineError`, which gives the exit-2 path. difflib, hashlib and JSON behave the same on all four platforms.
4. Baseline: `run_tests.py --file test_memory_eval.py` ran 26 tests, all OK.

Minor points that are not blocking:
1. Req 6 does not say whether cosine-rejected cases are removed from the file or skipped at run time using the lock.
2. The Progress Log says 175 active records and 1 candidate. The tree now has 174 active and 0 candidate.

Sizing: 20 ACs is heavy for one measurement change. These merges keep every check falsifiable:
1. AC-3 into AC-1.
2. AC-5 into AC-4 and AC-13 into AC-12, as known-bad sub-points.
3. AC-9 with AC-11, since both cover index plumbing.
4. AC-16 into AC-17, since both check the report shape.

That gives about 15.
