# Focused readiness verification, round 2 (wave 245na)

Round 1 recorded seven blocking findings against 245sp:

| Finding | Reviewer |
| --- | --- |
| `245na-rt-gate-rewards-abstention` | red-team |
| `245na-rt-split-and-resample-unit-is-case` | red-team |
| `245na-cr-grep-null-gate` | code-reviewer |
| `245na-cr-arm-corpus-and-signals` | code-reviewer |
| `245na-qa-ac18-vacuous-live-check` | qa-reviewer |
| `245na-qa-bootstrap-untested` | qa-reviewer |
| `245na-arch-dense-stream-unspecified` | architecture-reviewer |

The planner, context `245na-planner-repair-1`, recorded a cycle-1 repair_start for each and repaired the spec, the arc record and the withdrawn 243hz plan. All of the coordinator decisions below are reversible and recorded in the Decision Log.

**Gate removed.** The wave measures only.
- The report leads with recall@5 and MRR. Lifting the retrieval pause is the operator's decision, made from the report.
- Null queries carry `grep_terms`.
- An AC stops a near-zero-recall arm from being reported as better.

**Split and bootstrap.**
- The dev/held-out split is by record.
- The bootstrap is a cluster bootstrap that resamples records. It pins the percentile method, a seed, the resample count and the handling of an undefined metric.
- A known-bad check: a fake `[point, point]` bootstrap must fail.

**Arms.**
- Every arm uses production's corpus, including archive register entries.
- The dense arms use `_memory_candidate_scores`.
- Coverage distinguishes stale from missing, through a model-free helper that track 2 can reuse.

**Target-search limit (deviation, accepted by the coordinator).** `memory_search_response` caps results at 20, and 28 records target `server_impl.py`. Retrievability is therefore checked with the uncapped `match_targets` predicate. The capped shortfall is reported as `crowded_past_search_cap`.

**Live check.** A production fallback is reported as not measured, with its reason, and the AC fails. The operator spot-check of about 10 queries is now in the authoring rules, the Tasks and the AC.

**Advisories applied.**
- The 243hz header, the CHANGELOG `### Changed` line and the tool-reference field-list plan.
- `docs/architecture/search-architecture.md` was added.
- The query set moved to `docs/evals/memory-query-set.json`, with `docs/evals/memory-query-set.lock.json` beside it.
- An embedded-text decision rule was added: highest held-out recall@5, with ties going to the shortest text.
- The ACs went from 20 to 14.

Get the current receipt from `wf_review_wave(wave_id='245na', phase='prepare')`.

## Your task, as a FRESH, independent reviewer who wrote neither the finding nor the repair

1. **Read.** Load MCP tools via ToolSearch first and use code_* MCP-first. Fall back to grep and read if a tool reports `index_runtime_stale`, and say so. Read your lane's round-1 notes in this folder and the changed spec sections.
2. **Verify against the code.** Make NO repo edits. You may run probes on a throwaway copy, for example re-running `red-team-probe.py` against the repaired rules. You may run `run_tests.py --file`, but never the full suite.
3. **Record the reverification for each finding you own:**
   - `event='finding'`, `run_kind='reverification'`, with the cycle that `wf_review_wave` recommends.
   - `blocking_required_lanes=[]` only if the repair holds.
   - `fresh_context=true`, `independent=true`, `actor=<lane or seat>`, `context_id='245na-<lane>-focused-r2'`.
   - Executed evidence.
   - Dry-run first, then create.
4. **Record the approval.** Every required lane (code-reviewer, qa-reviewer, architecture-reviewer and docs-contract-reviewer) then records a readiness approval on the current receipt, as executed, with its OWN honest `integrity_checks`. Red-team records only its reverifications. A new blocking defect gets a finding.
5. **Write notes** to `.wavefoundry/work/245na/review/<lane>-focused-r2.md`. No em-dashes.
6. **Reply** in under 80 words.
