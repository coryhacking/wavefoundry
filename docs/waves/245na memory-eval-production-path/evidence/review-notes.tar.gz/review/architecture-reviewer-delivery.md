# Architecture reviewer, delivery (wave 245na, change 245sp)

Verdict: approve. Context `245na-architecture-reviewer-delivery`, fresh and independent.

## Layering

- `memory_vector_coverage` in `sqlite_vector_store.py` belongs there. It sits beside `dense_path_scores`, reuses the read-only `_open` (snapshot-aware) connection, and runs the same `chunks_docs JOIN vectors_docs` and `layer_path_state` queries in one read transaction. It embeds and writes nothing.
- `memory_eval.py` reaches production only through `memory_search_response` and `WaveIndex._memory_candidate_scores`, and reads its caps from `memory_handlers`. The handler passes `handler.index` into `run_curated` (AC-6). The tool keeps `_READONLY_TOOL`.

## Privacy

- Every `unavailable_reason` is a fixed string or an exception type name. `fallback_reasons` keys come from production's controlled vocabulary. The sanity floor emits only a hash fingerprint.
- Mutants on a scratch copy: case ids added to the report fail AC-12; exception text in the production `unavailable_reason` fails AC-12; query text in `fallback_reasons` fails AC-7.

## Track 2 reuse

- The helper is model-free: the AC-10 test uses a raising embedder, and dropping the vectors JOIN fails AC-10.
- Advisory: `memory_body_paths` in `memory_eval.py` copies the body-path and hash loop of `memory_handlers._memory_query_records`, without its duplicate-path refusal. If track 2 calls the helper from `index_health`, that builder should move to a shared module first, so the eval script does not become a dependency of health checks.
- Advisory: a mutant that counts a path with vectors but no `layer_path_state` row as covered survives. The docstring says such a path is stale, and no test pins it.

## Docs

- The two architecture rows, `memory-retrieval-eval.md`, `mcp-tool-surface.md` and the arc's track 2 and track 4 additions match the code and the Progress Log. Track 4's 39 target-only records are 10 named plus 29, and the 4 short records match AC-13.
- Advisory: the tool docstring and `mcp-tool-surface.md` say an unavailable query set returns `available: false`. An absent set (Requirement 1) runs only the sanity floor and can return `available: true`.
- Advisory: `mcp-tool-surface.md` does not list `index_signals.coverage_unavailable_reason` or `target_retrievable_note`.

## Cross-platform

- `.gitattributes` pins `docs/**/*.json*` to `eol=lf`. The hash covers parsed JSON. The lock is written with `line_endings.encode`, and `freeze_query_set` is registered in the line-ending census as generated. Paths are repo-relative POSIX strings, built the same way as in production. The claims hold for Windows, macOS, Linux and WSL2.
- Small wording point: the lock write is `write_bytes` of encoded bytes, not an atomic generated-file writer. This is harmless for a CLI artifact the operator runs.

## Executed

- `run_tests.py --file test_memory_eval.py`: 43 OK under the default profile and under `--profile second`.
- `test_mcp_tool_registry.py`: 27 OK under both profiles.
- The mutants ran in a scratch copy under the session scratchpad. No repo edits were made, `wf_memory_eval` was not run, and the full suite was not run.
