# Council chair, delivery (wave 245na, change 245sp)

Verdict: approve, intent_fit `partially`. Context `245na-council-chair-delivery`, fresh and independent. No repo edits besides this note; `wf_memory_eval` and the full suite were not run.

## Ledger

- 9 findings, all terminal: 7 readiness findings completed in cycle 1, and 2 delivery findings (`245na-qa-bootstrap-pooling-untested`, `245na-qa-curated-bound-wiring-untested`) completed in cycle 2.
- Delivery approvals current: code-reviewer, qa-reviewer, architecture-reviewer, docs-contract-reviewer.
- AC-1 to AC-12 and AC-14 are `[x]`. AC-13 is `[~]` with an operator-decision note.

## Executed

- `run_tests.py --file test_memory_eval.py`: 48 OK.
- `full-suite-3.log`: 13,426 OK. `second-3.log`: 0 of 258 failed.
- `test-cache.json`: `result: ok`, written 23:13Z. No framework file is newer except `test-run.lock`.

## Seats

- **red-team:** the abstention-gate and case-level split findings are closed. The report makes no automatic verdict, splits and resamples by record, and pins the bootstrap. Two biases remain and are stated in the Risks table: query authors come from the same model family, and a BM25-plus-dense labeling pool may bias against grep.
- **docs-contract-reviewer:** the tool reference matches a real response. Advisories remain:
  - three emitted keys are undocumented;
  - the wording for an absent query set is imprecise;
  - the arc's Progress table still says "Planned, not readied" and "Nothing in this arc is delivered yet". Update it before or at close.

## Strongest challenge

Over MCP, both `wf_memory_eval` runs returned `production_measured: false`, with 15 and 7 of 606 probes falling back during docs index publishes. On this repo, while the server writes, the shipped tool cannot yet produce a measured production number. AC-13 accepts the CLI run instead (0 of 606 fallbacks, same code path).

## Strongest alternative

Hold the wave until index-publish stability (track 2) lands. Declined: it would merge track 2 into track 1. The report already refuses to score a production arm that fell back.

## Intent fit: partially

**Established:** memory quality is measurable with held-out, interval-bearing numbers against honest baselines. The report flags that production recall@5 (.673) is below BM25 (.782) rather than hiding it.

**Left open by the `[~]`:**
- the measured production number comes only from the CLI path;
- 4 records (1t78a, 1vo1a, 1ydvk, 21rnt) have fewer than 2 answerable cases;
- the declined leakage in a-0084 and a-0345 is left to track 4's versioned re-freeze. The arc's track 4 row names the 4 records but not these two cases.

## Recorded

- `council-delivery` approval created (`ev-approval-council-delivery`). The tool appended the AC-13 criterion status line.

## Close dry-run blockers (not resolved by the chair)

1. `missing_operator_signoff`: operator-signoff is withheld until the operator approves after the repaired findings.
2. `open_changes_remaining`: the `245sp` Change Status still reads `planned`.
3. `memory_validation_check_failed`: `index_runtime_stale` for `sqlite_vector_store`. Fix it by reloading or restarting the MCP host.

The dry-run reported these as green: lint, garden, the framework test receipt (proven, 13,426) and the scanner. It also raised three advisories: `retrieval_posture_gap` (no `Gapfill:` entry), the AC-13 deferral, and the arc Progress table, which is stale.
