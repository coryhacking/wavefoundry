# docs-contract-reviewer delivery notes (wave 245na, change 245sp)

Verdict: approve. No blocking defect.

## Checked

- Tool reference: ran the SituationQueryEvalTests fixture through `wf_memory_eval_response` from a scratch script and compared the real top-level and nested keys with the field list in `docs/specs/mcp-tool-surface.md`. Every documented key exists, including `query_set` case-type counts, per-arm `intervals`, `undefined_resamples`, `flags`, `split_counts`, `recall_key`, `arm_order` and `full_context` `recall_all`.
- CHANGELOG: `production_variant` `memory_rrf_summary5` to `memory_search_hybrid_rrf` and `experimental_variant` `policy_ordered_rrf` to `policy_ordered_rrf_shortlist5` match HEAD versus the working tree. The `sanity_floor` move is correct.
- Retrieval-eval doc: thresholds 0.9, 0.95, 1000 resamples, minimum 100 defined, percentile indexes and the split rule match `memory_eval.py` constants.
- Spec record: 606 cases (517 answerable, 70 null, 19 stale) match the query set. 4 records below 2 answerable cases match (two have 1, two have 0). Suite 13,421 OK and second profile 0 of 258 failed match the logs. No em-dashes in the added prose.

## Minor observations (non-blocking)

1. The tool reference omits three emitted keys: `index_signals.target_retrievable_note`, `index_signals.coverage_unavailable_reason` and `sanity_floor.dense_measured`.
2. `Last verified` stamps are old on `docs/references/memory-retrieval-eval.md` (2026-10-14) and `docs/specs/mcp-tool-surface.md` (2026-11-22); garden before close.
3. An earlier Progress Log row says "AC-13 stays open"; the later operator-decision row resolves it. Historical, accurate in sequence.
4. CHANGELOG does not mention the `--freeze-query-set` CLI flag.
