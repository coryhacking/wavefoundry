# Readiness review brief (wave 245na)

Wave `245na memory-eval-production-path` holds one spec, `245sp-enh memory-eval-situation-queries-and-baselines`, in `docs/waves/245na memory-eval-production-path/`. It is the first wave of the arc `docs/arcs/244cm memory-quality/244cm-arc memory-quality.md`. The arc's research report is in `docs/arcs/244cm memory-quality/research/`. The spec supersedes the withdrawn `243hz` (now in `docs/plans/`).

**Goal.** The operator wants memory quality covered end to end: memories must be properly written, maintained, indexed and evaluated. This wave builds the evaluation, including the index coverage and freshness signals, so the later waves can be measured.

The current `wf_memory_eval` queries 12 records with their own summaries, which is trivially easy, and never runs the production path. Its `candidate` row admits every record that shares a token with the query, then sorts by policy before relevance, which produced recall 0.25.

**Operator decisions, 2026-11-23** (in the spec's Decision Log):
- Query authors may come from the same model family, with three mitigations: a separate context that never sees the record text, the similarity filter, and an operator spot-check of about 10 queries.
- Full context is scored only as "every record shown", with no LLM-judged arm.
- Candidate records are excluded from the query set.

**Sizing concern.** The spec has 20 ACs. Judge whether the spec is sized to the change, and name ACs that could be merged or turned into authoring rules without losing a falsifiable check. The operator values plans sized to the change.

**Review setup.** The receipt is `review-policy-fa410d29b8588e678ce7`. The required lanes are code-reviewer, qa-reviewer, architecture-reviewer and docs-contract-reviewer. The council seats are red-team (fixed, primer, standard depth) and docs-contract-reviewer (rotating).

## Your task, as a fresh, independent reviewer of your lane

1. **Read the plan.** Load the MCP tools through ToolSearch first and use code_* retrieval MCP-first. If a tool reports `index_runtime_stale`, fall back to grep or read and say so. Read the spec, its Decision Log and the arc record.
2. **Verify against the code.** Check the load-bearing claims against the code, not the spec's prose. That covers `memory_eval.py` (`run_curated`, `_candidate_and_controls`, `_policy_order`, `lexical_bm25_order`), `wf_server/memory_handlers.py` (`memory_search_response`, `_memory_query_records`, `wf_memory_eval_response`), `memory_records.memory_policy_sort_key`, `index_health` and the indexer's memory coverage. Confirm that every cited site resolves and that each "already does" claim holds. Check that the planned measurements are feasible locally, with no network, on Windows, macOS, Linux and WSL2.
3. **Make no repo edits.** You may run `python3 -B .wavefoundry/framework/scripts/run_tests.py --file <f>` and probes on a throwaway copy, but never the full suite. Do not mutate memory records.
4. **Record your result** in the typed ledger, `wf_review_event`, wave `245na`. Dry-run first, then create.
   - For each blocking defect, record a finding: `event='finding'`, `run_kind='readiness'`, `cycle=0`, `actor=<lane>`, `context_id='245na-<lane>-readiness'`, with an honest `execution_status`.
   - A required lane with no blocker records a readiness approval: `event='approval'`, `signoff_key=<lane>`, `approval_phase='readiness'`, `fresh_context=true`, `independent=true`, executed, with your OWN honest `integrity_checks`. Approvals need executed evidence, so run a probe.
   - Council seats write notes only, plus a finding when something blocks.
5. **Write notes** to `.wavefoundry/work/245na/review/<lane>-readiness.md`. No em-dashes.
6. **Reply** in under 100 words.
