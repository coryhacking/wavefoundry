# qa-reviewer readiness notes, wave 245na

Spec: `245sp-enh memory-eval-situation-queries-and-baselines`. Receipt `review-policy-fa410d29b8588e678ce7`.

**Verdict: approval withheld.** Two blocking findings were recorded, and the lane concurs with `245na-cr-grep-null-gate`.

## Method

- `index_health` reports `index_runtime_stale`. I read code with `code_outline` and plain reads, and wrote grep counts. I made no semantic retrieval.
- Read `memory_eval.py` (`run_curated`, `_candidate_and_controls`, `_policy_order`, `_semantic_order`), `memory_handlers.py` (`_memory_query_records`, `memory_search_response`, `wf_memory_eval_response`), `sqlite_vector_store.dense_path_scores`, `server_impl._memory_candidate_scores` and `memory_records.load_archive_register_entries`.
- Probe: `/private/tmp/claude-502/.../scratchpad/probe245.py`, a scratch reimplementation of the planned metrics and bootstrap.
- Corpus count with `memory_records`: 174 active records, all with a file target and a summary. The register has 23 entries, all with a successor. `server_impl.py` is a target of 28 records.

## Confirmed claims

- AC-1 numbers check out: 0.75, 0.5, 0.4286, 0.5, 1.0.
- AC-2 numbers check out: full_context 1.0, 0.5625, 0.2, 1.0, 0.0. no_memory 0, 0, null, 0, 0.
- AC-8 split check: `int(sha256(id)[:8],16)%10` gives 3, 6, 4, 4, 7 and 8 for q-001 to q-006, which are held out. It gives 1 for n-001, n-002 and s-001, which are dev.
- AC-12 and AC-13 fail against current code. `_candidate_and_controls` passes the unbounded `lexical` list to `_policy_order`.
- AC-16 fails against current code. `memory_rrf_summary5` and `policy_ordered_rrf` are in `run_curated`.
- AC-9 and AC-11 fail against current code. `run_curated` takes no `index`, and `wf_memory_eval_response` passes none.
- Every AC except AC-19 and AC-20 would fail today, which is expected because the feature is new.

## Blocking findings

- **Q1 `245na-qa-ac18-vacuous-live-check`.** AC-18 passes with the production arm omitted. Any stale memory body hash or incomplete vector coverage makes every probe fall back, and the gate then defaults to pause. The operator-decided spot-check of about 10 queries appears only in the Decision Log, not in the authoring rules, Tasks or AC-18.
  - Fix: AC-18 requires `fallback_probes: 0` after `index_health` reports current.
  - Fix: add authoring rule 8, an operator spot-check before freeze whose outcome goes in the Progress Log.
- **Q2 `245na-qa-bootstrap-untested`.** A stub that returns `[point, point]` passes AC-3, and AC-15 too. On the AC-1 fixture the real probe gives the mrr interval `[0.1667, 0.875]`, and the stub gives `[0.5, 0.5]`.
  - Fix: pin the percentile index and the rule for a resample in which a metric is null.
  - Fix: assert a literal interval, or low < point < high, for the AC-1 fixture.
  - Fix: add an AC-15 case in which production wins on point precision but the paired interval crosses 0, so `beats` is false.
- **Concur with `245na-cr-grep-null-gate`.** Null cases carry no `grep_terms`, so grep's false_show_rate is 0 by construction (probe confirmed). There is a second problem: cases without grep_terms drop out of grep's pooled precision, so the "paired" comparison runs over different case sets. Require grep_terms on every case.

## Leakage controls

- **Separate context.** This is the real control, and it is process-only. The author sees the title and Rationale of the source change, and those often state the lesson. Withhold the source-change title too, or have the labeler flag paraphrase.
- **Similarity filters.** A sequence ratio of 0.9 or higher and a cosine of 0.95 or higher catch only near-copies. AC-7's rationale ("catches paraphrased copies") overstates the cosine filter, since paraphrases with the docs model usually land around 0.85 to 0.93. Record each case's maximum cosine in the lock, or calibrate the threshold on the dev split.
- **Split.** The split hashes the case id, which the author chooses. Each record's 2 or 3 queries also land in both splits, so dev tuning leaks into held-out. Red-team `245na-rt-split-and-resample-unit-is-case` covers this; split by record.
- **Freeze.** Sound. Hashing the parsed JSON handles CRLF. Re-freeze is only a process rule with a Progress Log reason, which is acceptable.

## Statistics

- **Dataset size.** About 350 to 520 answerable cases, about 70% held out, is enough for pooled precision. 40 null cases give only about 28 held out, so a false_show_rate point comparison flips on one case. Use 60 or more null cases, or a paired interval as red-team proposes. 23 stale cases give about 16 held out, so stale_shown_rate is informational only.
- **Bootstrap unit.** Resampling cases ignores clustering by record, so the intervals are understated. Covered by red-team.

## Non-blocking gaps

- No AC covers `dense_only`, `hybrid_no_rerank`, the two ablation arms (Req 12) or the `embedded_text` label.
- The record universe for each arm is unspecified. Production includes archive register entries (`memory_search_response` extends records with them for queries). grep and full_context use active records only, so stale_shown_rate is 0 for those arms by construction. Overlaps `245na-cr-arm-corpus-and-signals`.
- `target_retrievable` calls `memory_search_response(target=...)` with the default limit of 10. `server_impl.py` is a target of 28 records, so 3 records whose every target is shared that widely can count as unretrievable because of the cap, not retrieval. State the limit or the intent.
- When `source_current` is false, `dense_path_scores` returns early with `covered_paths` 0. Report coverage as unmeasured instead, and add an AC-14 case.
- AC-4's second query (shares only target-path words) has no literal string.

## Sizing judgment

20 ACs is heavier than the change needs. About 13 would keep every falsifiable check:

- Merge AC-5 into AC-4 and AC-13 into AC-12, each as a "with the guard removed, this test fails" clause.
- Merge AC-3 into AC-1, with the pinned interval.
- Merge AC-9, AC-10 and AC-11 into two ACs: the production spy with the fallback rule, and the shared-index plumbing.
- AC-16 (labels) can become a single assertion inside AC-17's envelope test or AC-1's report test.
- AC-20 is boilerplate.
- Cut scope: defer the ablation arms (Req 12) to the later spec that would act on them. They have no AC and do not feed the gate.
- AC-8 could become an authoring rule plus one assertion inside AC-1.
