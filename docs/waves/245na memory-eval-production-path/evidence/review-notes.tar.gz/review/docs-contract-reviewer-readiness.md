# docs-contract-reviewer readiness notes (wave 245na)

Verdict: approve. No blocker. Probe: `wf_validate_docs` full run, passed with no errors or warnings.

## Verified
- AC-1 and AC-2 arithmetic re-derived by hand: recall 0.75, mrr 0.5, precision 3/7 = 0.4286, full_context mrr 0.5625 and precision 0.2. All correct.
- Relative links in the spec, the arc and the 243hz banner resolve. Cited assessment sections exist ("Evaluation: the current design measures the index, not the memory", "The verdict", "Do not do", four tiers).
- Research copy: assessment body matches the work-folder source (only the H1 moved into the title line). All four notes carry Owner, Status, Last verified and the copy statement. No broken links, no references to the work folder as a live path.
- 243hz: Change Status `withdrawn`, supersession banner, Progress Log row, diagnosis kept. Arc and wave.md agree with it.
- Requirement numbers cited elsewhere (10 in Platforms, 15 in AC-16) match the rendered list order.
- No em-dashes in the spec, arc or 243hz.

## Non-blocking points
1. 243hz header still says `Status: planned` and `Wave: 245na` although it was removed from the wave. Lint passes; set Status to withdrawn when convenient.
2. CHANGELOG: the draft is accurate but sits only under Added. The change also renames labels (`experimental_variant` becomes `policy_ordered_rrf_shortlist5`, `memory_rrf_summary5` goes) and moves the self-summary fields under `sanity_floor`. Add a `### Changed` line for the response-shape move.
3. `docs/specs/mcp-tool-surface.md` section `wf_memory_eval` currently lists `sample_size`/`sample_cap`, metrics and the three variant names as the response `data`. The docs task should rewrite that list (query_set, arms, index_signals, retrieval_stack_gate, sanity_floor) and drop "sampled self-summary" from its first sentence. Also the Tool Index line says "diagnostics"; keep it.
4. Sizing: 20 ACs is heavy. Candidates to merge without losing a falsifiable check: AC-2 into AC-1 (same fixture), AC-3 into AC-1, AC-5 into AC-4 and AC-13 into AC-12 (make "record the known-bad run" an authoring rule), AC-16 into AC-8, AC-19 into AC-20. That leaves about 14.
