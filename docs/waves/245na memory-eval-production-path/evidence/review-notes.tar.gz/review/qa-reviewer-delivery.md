# QA delivery review, wave 245na (change 245sp)

Lane: qa-reviewer. Context: `245na-qa-reviewer-delivery`. Fresh and independent. No repo edits, no memory mutation, `wf_memory_eval` not run.

## Verdict

Two delivery findings, both `do_now`, no approval recorded:

1. `245na-qa-bootstrap-pooling-untested` (required_ac, derived blocking). A `_bootstrap` mutant that divides each resample by the number of drawn clusters instead of the pooled case denominator passes all 43 tests. Requirement 9.2 is not pinned. The fix is a fixture with clusters of unequal size and one interval or resample value computed by hand.
2. `245na-qa-curated-bound-wiring-untested` (important_ac, non-blocking). Removing `bounded=True` from the only curated call site (`_sanity_floor`) passes all 43 tests. The AC-9 test calls the helper directly. The fix is a spy or a `run_curated` assertion.

The shipped code is correct on both points. Both findings are gaps in test strength.

## Focused tests (both profiles)

- `run_tests.py --file test_memory_eval.py`: 43 OK. `--profile second`: 0 of 1 files failed.
- `test_mcp_tool_registry.py` and `test_line_ending_census.py`: 43 OK under the default profile, and 0 of 2 failed under `--profile second`.
- Full-suite logs as claimed: `full-suite-2.log` 13421 OK, `second-2.log` 0 of 258 failed.

## Mutants (scratch copy, whole test file)

Killed (12):
- fake bootstrap `[point, point]` (AC-2)
- `recall_below_bm25` flag dropped (AC-11)
- `arm_order` by precision (AC-11)
- `production_measured` forced true (AC-7)
- fallen-back production arm kept (AC-7)
- bound removed inside `_candidate_and_controls` (AC-9)
- hash check skipped (AC-4)
- byte hash instead of parsed (AC-4)
- `cosine_rejected` ignored at run (AC-4)
- split keyed by case id (AC-5)
- sequence filter removed (AC-3)
- unseeded Random (AC-2)

Survived (3):
- M8: `bounded=True` dropped at the call site. This is finding 2.
- M14: the bootstrap divides by cluster count. This is finding 1.
- M6: only `qualification == "unavailable"` counts as a fallback. This is not a finding: `memory_search_response` emits only `model_relevance`, `unavailable` and `not_requested` (the last only when there is no query), so the mutant is equivalent today.

## Freeze and lock

- The real set loads with `available: true`, and its sha256 `34afd084...` matches the lock and the live-eval report.
- The lock records both thresholds, the docs model and empty reject lists.
- On a copy, I edited one case's `relevant_ids`, and separately added one trailing space to a query. Both gave `query_set_hash_mismatch`.
- Reindenting the copy and converting it to CRLF still matched the lock.
- Counts are 517 answerable, 70 null and 19 stale.
- All 606 cases name existing ids.
- The 19 stale cases cover all 19 register entries that name a successor. The other 4 entries say `Successor: none`. The planning note "all 23 name a successor" was imprecise, but the delivery is correct.

## Query sample (15: 9 answerable, 4 null, 2 stale, `random.Random(245)`)

- Most cases are plausible situation language, and their labels fit.
- Mild leakage of targets and terms in `a-0084` ("server_impl.py envelope building for stale journal watchpoints" echoes the summary terms) and `a-0345` (a target filename plus the wave topic). Both are below the rescan threshold. I am noting them, not recording findings.
- `n-024` (document the `wf_stats` fields in the tool-surface spec) is borderline: `1vlnj` and `1vpm4` concern tool-surface carriers, but only when behavior changes. The null label is defensible. Ambiguous null cases like this can inflate false-show for every arm equally.
- The stale cases `s-019` and `s-022` are shaped correctly.

## AC-13 `[~]`

The note is honest and matches the evidence:
- The 4 short records (1t78a 1, 1vo1a 0, 1ydvk 0, 21rnt 1) are re-derived exactly.
- The CLI run shows 606 of 606 probes screened.
- The MCP runs that fell back (15 and 7 probes) are recorded in the Progress Log.
- The arc's track 2 and track 4 rows carry both deferrals.

One gap in completeness: the Progress Log records intervals only for recall@5. The AC asks for "intervals" in general, and the others exist only in `live-eval.json`. This is minor.
