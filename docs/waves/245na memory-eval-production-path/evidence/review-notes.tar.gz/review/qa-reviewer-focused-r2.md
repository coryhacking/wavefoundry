# qa-reviewer focused readiness verification, round 2 (wave 245na)

Context `245na-qa-reviewer-focused-r2`, fresh and independent. Receipt `review-policy-3b5b233080d44f483481`.

**Verdict: both qa findings are repaired. Readiness approval recorded.**

## Method

- `code_keyword` reported `index_runtime_stale`, so I read code with plain file reads. No conclusion depends on semantic retrieval.
- Probe: `/private/tmp/claude-502/-Users-coryhacking-Developer-wavefoundry/c49d4915-53cc-460a-9250-80578e2c9abc/scratchpad/r2/probe.py`. It is a scratch reimplementation of Req 3, Req 8 and Req 9.
- Handler call: `memory_handlers.memory_search_response(root, query=..., index=None, limit=5)` with bytecode writing disabled.
- To map the ACs, I decoded the round-1 spec body from receipt `review-policy-fa410d29b8588e678ce7` and compared its 20 ACs with the current 14.

## `245na-qa-bootstrap-untested`: repaired

- Req 9 now pins every free parameter:
  - the cluster key, `source_id`
  - one `random.Random(0)` per split and metric
  - 1000 resamples
  - undefined resamples are skipped and counted
  - the interval is `[v[floor(0.025n)], v[ceil(0.975n)-1]]`
  - the interval is null when `n` is below 100
- Results on the AC-1 fixture:
  - The point mrr is 0.5 and the real interval is `[0.0, 1.0]`, with 12 undefined resamples. `low < 0.5 < high` holds.
  - The fake `[point, point]` gives `[0.5, 0.5]`, which fails AC-2.
  - The result is the same under 5 case-order shuffles.
- The all-RR-1.0 fixture gives `[1.0, 1.0]`.
- The fixture with one answerable and one null cluster gives 244 undefined resamples for recall.

## `245na-qa-ac18-vacuous-live-check`: repaired

- When a query is given, production returns one of two qualifications:
  - `unavailable`: the default, every early return and every exception
  - `model_relevance`: the probe was screened
- I forced a fallback with a real call, `index=None`. It returned `qualification: unavailable` with `fallback_reason: semantic_index_unavailable`.
- Req 11 counts such a probe as a fallback. The production arm is then omitted and `production_measured` is false.
- AC-7 tests this with 1 fallback in 4 probes.
- AC-13 requires `production_measured: true` and `fallback_probes` 0 while `index_health` reports current. It states that a run with `production_measured: false` does not satisfy it.
- The operator spot-check now appears in authoring rule 8, in a Task and in AC-13.

## Other checks re-derived

- The AC-1 values all match.
  - Scorer: 0.75, 0.5, 0.4286, 0.5 and 1.0.
  - `full_context`: 1.0, 0.5625, 0.1667, 1.0 and 1.0, with `mean_shown` 6.0.
  - The `full_context` precision changed from 0.2 to 0.1667 and the stale rate from 0.0 to 1.0. Both follow from `r9` now being in the corpus.
- The split hashes match. `r1`, `r2`, `r4`, `q-004`, `q-005` and `n-005` are held out. `r3` and `n-001` are dev.
- AC-11 checks out.
  - Production: recall 0.1, interval upper bound 0.3, which is below bm25's 0.6.
  - Precision: 1.0 for production against 0.12 for bm25.
- `MEMORY_SEARCH_CAP` is 20, so the AC-10 count of 21 records sharing a file target gives `crowded_past_search_cap` 1.

## AC mapping, 20 to 14

Every falsifiable check survives or was changed on purpose by a coordinator decision: the gate, the split key, the corpus and the coverage shape. Two minor literals dropped out of the ACs. Requirements still state both, so neither blocks:

- The lock's `cosine_threshold: 0.95`, which old AC-7 asserted. Req 6 still requires it.
- "whatever their `split` field says", from old AC-8. Req 3 still says a case-level `split` field is ignored.

## Non-blocking advisories

- AC-13 could also require `model_screened_probes` to equal the number of scored cases. The AC-6 spy already covers the call count in tests.
- The AC-2 mrr interval of `[0.0, 1.0]` is wide. The AC proves the interval is not degenerate, not that it is accurate, which is enough for a known-bad control.
