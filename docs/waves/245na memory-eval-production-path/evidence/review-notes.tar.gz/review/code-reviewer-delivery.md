# code-reviewer delivery review (wave 245na, change 245sp)

Verdict: APPROVE. Recorded as `ev-approval-code-reviewer-2` (delivery, context `245na-code-reviewer-delivery`).

## Executed checks

- `run_tests.py --file test_memory_eval.py`: 43 OK.
- `run_tests.py --profile second --file test_memory_eval.py`: 0 of 1 files failed.
- 10 mutants, applied one at a time to a scratch copy of `.wavefoundry/framework`. The real tree was not edited.

| Mutant | Result |
| --- | --- |
| dense_stream ties broken by path instead of memory_id | killed (test_dense_ties_use_production_sort_order) |
| dense arms kept when the index is stale | killed (test_dense_arms_on_a_stale_index_are_not_measured) |
| coverage `JOIN vectors_docs` changed to `LEFT JOIN` | killed (test_ac10) |
| production arm passes `index=None` | killed (test_ac6) |
| production arm passes `limit=search_cap` | killed (test_ac6) |
| MCP handler drops `handler.index` | killed (test_ac6) |
| coverage treats a missing state row as covered | survived |
| hybrid lexical stream not capped at 20 | survived |
| incomplete-coverage check removed in dense_stream | survived |
| dense_only arm scored from the BM25 list | survived |

I probed the 4 survivors against the unmutated code. Their behavior is correct:

- When a vector-backed path has no docs `layer_path_state` row, it counts as stale. A row for the code layer is ignored, and a path with several chunks counts once.
- An incomplete dense result returns `memory_vector_coverage_incomplete`.
- The dense_only and hybrid_no_rerank metrics follow the dense order through `run_curated`. With r1 at rank 2, MRR is 0.5 and mean shown is 2.
- Hybrid caps its lexical stream at `MEMORY_SEARCH_CAP`, the same cap production uses.

## Code reading

- The production arm calls the real `memory_search_response` with the shared index and `MEMORY_QUERY_CHECK_CAP`. A run with any fallback probe drops the arm.
- `dense_stream` makes the same `_memory_candidate_scores` call as production and sorts the same way, by `(-score, memory_id)`.
- The `vectors_docs` join on `v.chunk_id=c.id` matches the schema's integer foreign key.

## Non-blocking notes

- Test gaps: no test covers the missing-state-row stale case, the incomplete-coverage reason, the dense_only metric values, or the hybrid cap with more than 20 records.
- The `memory_vector_coverage` docstring says "one read transaction". Outside `read_snapshot`, the function actually runs two autocommit SELECTs. The existing `dense_path_scores` has the same pattern. Only an advisory signal is affected.
