import hashlib, random, math
def split_of(key): return "heldout" if int(hashlib.sha256(key.encode()).hexdigest()[:8],16)%10>=3 else "dev"
# 1. split straddle under repaired rule (cluster key = source_id)
cases=[]
for r in range(175):
    for j in range(3): cases.append(dict(id=f"r{r:03d}-q{j}",source_id=f"r{r:03d}",type="answerable"))
for i in range(1,41): cases.append(dict(id=f"n-{i:03d}",source_id=f"n-{i:03d}",type="null"))
for i in range(23): cases.append(dict(id=f"s-{i:03d}",source_id=f"r{i:03d}",type="stale"))  # stale: source=successor
by={}
for c in cases: by.setdefault(c["source_id"],set()).add(split_of(c["source_id"]))
print("records straddling (repaired, source_id key):",sum(len(v)>1 for v in by.values()),"/",len(by))
byc={}
for c in cases: byc.setdefault(c["source_id"],set()).add(split_of(c["id"]))
print("records straddling (old, case-id key):",sum(len(v)>1 for v in byc.values()),"/",len(byc))
held=[c for c in cases if split_of(c["source_id"])=="heldout"]
print("heldout clusters:",len({c['source_id'] for c in held}),"heldout nulls:",sum(c['type']=='null' for c in held),"heldout stale:",sum(c['type']=='stale' for c in held))
# 2. pinned cluster bootstrap
def interval(clusters, metric, seed=0, B=1000):
    rng=random.Random(seed); keys=sorted(clusters); v=[]; und=0
    for _ in range(B):
        drawn=[clusters[rng.choice(keys)] for _ in keys]
        m=metric([c for cl in drawn for c in cl])
        if m is None: und+=1
        else: v.append(m)
    v.sort(); n=len(v)
    if n<100: return None, und
    return [round(v[math.floor(0.025*n)],4), round(v[math.ceil(0.975*n)-1],4)], und
def recall(cs):
    e=[c for c in cs if c["type"]!="null"]
    return None if not e else sum(c["hit5"] for c in e)/len(e)
def precision(cs):
    e=[c for c in cs if c["type"]!="null"]; s=sum(c["shown"] for c in e)
    return None if s==0 else sum(c["relshown"] for c in e)/s
# abstaining arm vs bm25 on 350 answerable cases (175 clusters x 2)
def mk(arm):
    cl={}
    for r in range(175):
        rows=[]
        for j in range(2):
            i=r*2+j
            if arm=="prod": rows.append(dict(type="answerable",hit5=1 if i<10 else 0,shown=1 if i<10 else 0,relshown=1 if i<10 else 0))
            else: rows.append(dict(type="answerable",hit5=1 if i<200 else 0,shown=5,relshown=1 if i<200 else 0))
        cl[f"r{r}"]=rows
    return cl
res={}
for arm in ("prod","bm25"):
    cl=mk(arm); pt=recall([c for v in cl.values() for c in v]); ci,_=interval(cl,recall)
    pp=precision([c for v in cl.values() for c in v]); pci,pu=interval(cl,precision)
    res[arm]=(pt,ci); print(arm,"recall@5",round(pt,4),ci,"precision",round(pp,4),pci,"undefined_prec",pu)
order=sorted(res,key=lambda a:-res[a][0]); print("arm_order:",order)
print("prod flagged recall_below_bm25:",res["prod"][1][1]<res["bm25"][0])
# AC-11 fixture
cl_p={f"c{i}":[dict(type="answerable",hit5=1 if i==0 else 0,shown=1 if i==0 else 0,relshown=1 if i==0 else 0)] for i in range(10)}
cl_b={f"c{i}":[dict(type="answerable",hit5=1 if i<6 else 0,shown=5,relshown=1 if i<6 else 0)] for i in range(10)}
for nm,cl in (("AC11 prod",cl_p),("AC11 bm25",cl_b)):
    allc=[c for v in cl.values() for c in v]
    print(nm,"recall",recall(allc),interval(cl,recall)[0],"precision",round(precision(allc),4),interval(cl,precision))
print("AC11 flag:",interval(cl_p,recall)[0][1]<0.6)
# 3. cluster vs case bootstrap width with correlated queries (record-level difficulty)
rng=random.Random(1); cl={}
for r in range(120):
    hard=rng.random()<0.5
    cl[f"r{r}"]=[dict(type="answerable",hit5=0 if hard else 1,shown=5,relshown=0 if hard else 1) for _ in range(3)]
ci_cl,_=interval(cl,recall); ci_case,_=interval({f"k{i}":[c] for i,c in enumerate(c for v in cl.values() for c in v)},recall)
print("correlated recall CI cluster",ci_cl,"case-level",ci_case)
# 4. a fake [point,point] bootstrap vs the pinned one on a small mixed fixture
print("determinism:",interval(cl_b,recall)==interval(cl_b,recall))
