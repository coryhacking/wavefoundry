# Red-team readiness notes, wave 245na (spec 245sp)

Seat: red-team (fixed, primer, standard depth). Fresh, independent context. Notes and findings only, no approval.

Retrieval: MCP `code_outline` on `memory_eval.py`, then targeted `sed`/`grep` reads of `memory_eval.py`, `wf_server/memory_handlers.py`, `memory_records.py`, `review_evidence.py`. Probe: `.wavefoundry/work/245na/review/red-team-probe.py` (copied from a scratch dir; run with `python3 -I`). It reads no repository state. No repository edits, and no memory records changed.

## Verdict

The plan is a large improvement over the self-summary probe, and the code claims hold. But its core claim (that the gate tells us whether memory helps) fails in two places, recorded as blocking findings:

1. `245na-rt-gate-rewards-abstention`. The gate reads only pooled `precision_shown` and point `false_show_rate`. Production applies a reranker cut (`MEMORY_QUERY_MIN_LOGIT = -4.0`), so it tends to show few records. Probe: a production arm with recall@5 0.029 and precision 1.0 beats BM25 (recall 0.57) and full context. Paired 2.5th percentile differences are 0.876 and 0.994, so `pause_retrieval_investment` is false. Full context can never win: its precision is about 1/175 and its false-show rate is 1.0 by construction. That makes the arc's rule "if full context matches production, accept the simpler design" unreachable. The spec also leaves the paired difference undefined when a resample shows nothing (precision `null`).
2. `245na-rt-split-and-resample-unit-is-case`. The split hashes the case id and the bootstrap resamples cases. Under the spec's own rule, 109 of 175 records would put queries in both dev and heldout, so dev-only tuning leaks into heldout. Case-level resampling ignores the correlation between a record's 2 or 3 queries, so the intervals come out too narrow. Heldout holds about 26 null cases. The false-show interval at p=0.1 is [0.0, 0.21], yet the gate compares false-show rates as point values.

## Attack surfaces (non-blocking unless noted)

- **Leakage that survives the filters.** The probe shows that a light paraphrase of a real summary scores a sequence ratio of 0.927 (caught). A close paraphrase scores 0.556, and a situation query scores 0.19. The 0.9 ratio and the 0.95 cosine thresholds catch only near-verbatim copies. Both filters compare the query with the summary alone. The author sees target paths, evidence refs, and the source change's title and Rationale, which is often the text the lesson was distilled from. Target paths and evidence refs are in BM25's `_record_text` and in the dense-embedded markdown. Rule 3 makes one query in three a "touched path", and AC-4 explicitly keeps path-word overlap. So a third of the set is closer to a target lookup than a situation lookup. Recommend: report metrics by query type (task, symptom, path), so a path-driven win is visible, and add a filter on the change Rationale if feasible.
- **Same-family authors.** The bias is not shared across arms. Model-written queries match model-written records better in embedding space, which favors dense, hybrid and production over grep and BM25. Paired comparison does not cancel it. Partial counterpoint: the agent that queries memory in production is the same family, so some of this is realism. The operator's third mitigation, a spot-check of about 10 queries before freeze, appears only in the Decision Log. It is absent from the authoring rules, Tasks and AC-18. It should be an authoring rule with a Progress Log record (docs-contract gap). Ten of roughly 400 queries is a sanity check, not a measurement.
- **Labeling pool bias.** The labeler sees only the target record plus the top 10 BM25 and top 10 dense results (rules 4 and 5). Production fuses exactly those two streams, so applicable records that only grep finds are labeled irrelevant. Null cases are defined as "nothing in the BM25 or dense top 10 applies". That biases the comparison against grep and toward production. The Risks table claim that "paired comparison cancels a shared labeling miss" is wrong, because the miss is correlated with the pooled retrievers. Recommend: pool grep hits as well.
- **grep arm comparability.** `grep_terms` is optional and authored per case ("may carry"). Null cases are not said to carry them, so grep shows nothing on nulls and gets a false-show rate of 0 for free. Answerable cases without terms show nothing, and they drop out of grep's pooled precision. grep's result therefore depends on which cases an author chose to give terms. Recommend: require `grep_terms` on every case, nulls included.
- **Arm corpora differ.** In query mode, `memory_search_response` loads `DEFAULT_SURFACED_STATUSES`, which is active plus candidate. It also adds archive register entries, whose `memory_id` is the archived id. `full_context` ("every surfaced active record") and `grep` ("active record files") cannot show a stale id, so their `stale_shown_rate` is 0 by construction. The spec does not say which record list `bm25_only`, `dense_only` and `hybrid_no_rerank` use. The candidate record can appear in production and counts as irrelevant. The spec should name one corpus per arm.
- **Too few cases for the arc's later uses.** Tracks 3 and 4 measure false-show and precision before and after a change on this frozen set. About 26 heldout nulls and 16 stale cases can detect only large effects. Track 3 changes which records exist: new records have no queries and count as irrelevant whenever shown, and archived records break `relevant_ids`. The spec has no rule for corpus drift against a frozen set.
- **Full-context arm.** It is not comparable as specified. It bounds recall and measures cost, which is useful, but only when reported as such (recall 1.0 at a shown count of about 175). It should not be one of the gate's "beats" terms. The actual full-context question is whether an agent does as well with everything loaded, and that is tier four, which was declined.

## Strongest alternative design

Mine real situations instead of authoring them. For each active record, the later changes and waves in this repository that touched its target paths after the record's creation date provide task statements written before anyone knew the lesson: spec titles, Rationale paragraphs and wave objectives. Use a temporal split: records created before date T, and queries drawn from changes after T. Changes that touch no record's targets form natural null cases. This removes the same-family authoring problem and the paraphrase leak, gives the real situation distribution, and produces new cases as the repository grows, which addresses corpus drift. Combine it with three things: splitting and resampling by record, pooling all arms (grep included) for labeling, and a gate that compares arms at an equal shown budget per case, meaning recall and precision with every arm truncated to production's shown count. Then an arm cannot win by abstaining. The authored set can remain as a supplement for symptom and error queries.

## Sizing

The 20 ACs are dense but mostly falsifiable. AC-5 and AC-13 (the known-bad runs) could fold into AC-4 and AC-12 as a "with the guard removed this test fails" clause. AC-16 and AC-17 are a compact pair. My priority is not fewer ACs. It is adding one AC for the gate's known-bad abstaining arm and one for a record-level split.

## Probe outputs (executed)

```
seqratio light paraphrase 0.927
seqratio close paraphrase 0.556
seqratio situation 0.19
records with queries in both dev and heldout (3 q each): 109 / 175
heldout nulls of 40: 26  stale of 23: 16
false_show p 0.1 CI 0.0 0.214
false_show p 0.25 CI 0.107 0.393
prod recall@5 0.0286 precision 1.0
vs full_context (none-resamples, p2.5 diff): (0, 0.994)
vs bm25 recall 0.57 (none-resamples, p2.5 diff): (0, 0.876)
```
