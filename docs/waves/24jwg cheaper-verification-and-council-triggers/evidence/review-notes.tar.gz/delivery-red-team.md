# 24jwg delivery red-team primer (depth: standard)

Packet: tree_fingerprint `bc51944e623c803a` (recomputed, matches; 19 paths). Read-only; mutants ran in a scratch copy of `.wavefoundry/framework`. Only 24jwg hunks reviewed in shared files.

## strongest_challenge

`cross_platform_changed: false` is a self-attested suppressor of a safety trigger. It fails unsafe in two ways that need no deliberate declaration. (1) `_explicit_field_value` is unanchored, so any prose mention counts, including a negation or a quote of the rule. (2) The small lane joins spec and `intended_diff` into one text (`small_change_lane.assess`, `effect = normalized_review_text(spec) + "\n" + intended_diff`), so a spec's `false` also silences OS names in the diff sentence, and the one-sentence diff can carry its own `false`. The explicit `true` shares the regex but fails safe; `false` does not.

## best_alternative

Match `false` only as a standalone declaration line, and evaluate it only in spec bodies. The small lane would pass `[normalized_spec, intended_diff]` as two texts. The existing tests already write the declaration on its own line, so they keep passing.

## primer_questions

1. Should a mention of `cross_platform_changed: false` inside a sentence (negated, quoted or explained) count as a declaration?
2. Should the `intended_diff` sentence be able to suppress its own OS-name trigger, or inherit the spec's suppression?
3. AC-6 says "schedule-control orders are unchanged". Which test fails if guard-first leaks into `--schedule-control`?
4. Is the `_main` missing-guard branch meant to give a different message from the `--file` selector error? If it is, pin that message.

## efficacy_replay (executed)

- `run_tests.py --guards` on the real tree: 136 tests, 9 files, 5.53 s reported, 8.85 s wall. Both files that failed in 24i2t (`test_venv_bootstrap.py`, `test_mcp_tool_registry.py`) are in `GUARD_TEST_FILES`.
- Golden fixture diff, classified: 9 entries x {`evaluator_version` 8->9, `policy_input_digest` x2, `receipt_id`}. No other field changed.
- Probes on `extract_full_council_triggers` (live tree):
  - A: spec declares `false`, `intended_diff` "strip Windows drive letters", passed as one text: `()`. The same two strings passed as separate texts: `('cross_platform_changed',)`.
  - B: `intended_diff` ends "; cross_platform_changed: false" (the format allows it): `()`.
  - C: "Fix Windows paths. Do not declare cross_platform_changed: false here.": `()`.
  - D: a Windows-only bug spec that quotes the seed 170 rule: `()`.
- Prepare's call site passes one text per change (`lifecycle_gate_support`, `canonical_change_texts`), so the per-text rule does hold for Prepare.

## Mutation table (targeted tests per mutant)

| # | Mutant | Tests | Result |
| --- | --- | --- | --- |
| M1 | corpus-level override (`for text in [corpus]`) | CrossPlatformDeclarationTests | KILLED (sibling test) |
| M2 | `false` suppresses the phrases too | same | KILLED |
| M3 | `false` beats `true` | same | KILLED |
| M4 | override applied to every field | same | KILLED (trust-boundary test) |
| M5 | evaluator version back to 8 | tripwire + phase_gates pin | KILLED (2) |
| M6 | drop `--guards` dedupe | GuardArgs/GuardRun | KILLED (2) |
| M7 | dedupe user `--file` duplicates instead of refusing | GuardArgsTests | KILLED |
| M8 | guards appended after `--file` | GuardArgs/GuardRun | KILLED |
| M9 | drop the `_main` missing-guard check | GuardRunTests | **SURVIVED** (equivalent; see F4) |
| M10 | `_guard_first` applied to the schedule-control order | all of test_run_tests_cache (114) | **SURVIVED** |
| M11 | drop `_guard_first` at the production site | ScheduleControlTests | KILLED |
| M12 | reorder the non-guard remainder | ScheduleControlTests | KILLED (2) |

## Candidate findings

**F1: small lane joins spec and diff, so declarations cross the boundary.** Medium, non-blocking; recommend fix now.
- Evidence: `small_change_lane.assess` builds `effect` as one text and passes `extract_full_council_triggers([effect])`. Probes A and B were executed.
- This conflicts with the per-text principle from the readiness repair (QA-RDY-1/CODE-RDY-1), even though Requirement 2 calls inheriting the rule "intended". The independent code reviewer at both phases mitigates the risk but does not close it.
- Repair: `extract_full_council_triggers([normalized_review_text(spec), selection["intended_diff"]])`. Add a test: spec declares `false` and the diff names Windows, so the change is not eligible.

**F2: unanchored `false` matches prose mentions.** Medium, non-blocking.
- Evidence: `review_policy._explicit_field_value` regex `\bcross_platform_changed\b\s*[:=]\s*false\b` under `(?mi)` with no line anchor. Probes C and D were executed. The 24jwf spec itself has an inline `false`; its inline `true` overrides it.
- Repair: for `false` only, require a line holding nothing but the declaration, e.g. `(?mi)^\s*(?:[-*]\s+)?`?cross_platform_changed`?\s*[:=]\s*`?false`?\s*$`. Add a test for a negated mention. This changes no golden output because no evaluator inputs carry the declaration.

**F3: no test pins the schedule-control order with guard files present.** Low, non-blocking.
- Evidence: M10 survived all 114 runner tests. The `ScheduleControlTests` fixtures contain no guard-named file, so AC-6's negative half has no oracle.
- Repair: add a guard-named fixture file to one `--schedule-control alphabetical` case and assert its alphabetical position.

**F4: the `_main` missing-guard branch is redundant.** Low, non-blocking.
- Evidence: M9 survived. `_validate_focus_selectors` already rejects the absent name with exit 2 and names it, which satisfies `test_missing_guard_name_is_a_usage_error_for_guard_runs`.
- Repair: assert the distinct "GUARD_TEST_FILES names no discovered test file" text, or delete the branch (simpler).

**F5: nits.** Non-blocking.
- `--guards --no-cache` reports "--file and --no-cache are mutually exclusive", which names a flag the user did not type (executed).
- The tripwire `test_evaluator_version_eight_is_the_shipped_transition_boundary` now asserts 9 under the "eight" name.
- Seed 170 "(not only in the Progress Log ...)" reads as if a Progress Log copy also counts. "not in the Progress Log" is accurate.

The 24jwe docs (`build-and-verification.md`, `testing-architecture.md`), the docstring and the seed 180/209 neutrality check were confirmed accurate.
