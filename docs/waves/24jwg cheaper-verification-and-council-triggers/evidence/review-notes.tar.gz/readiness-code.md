# 24jwg readiness: code-reviewer

Verdict: **not approved. There are two blocking defects, and each has a narrow spec repair.** No approval event was recorded.

## Blocking

**B1 (24jwf): one spec's `false` can suppress another spec's Windows change.** `review_policy.extract_full_council_triggers` (lines 1358-1369) joins every text into one corpus before matching. Prepare passes it every admitted spec at once (`lifecycle_gate_support.py:1399`, `canonical_change_texts`). The legacy fallback passes it the whole wave.md (line 214). If the override is added to the existing corpus regex, which is the natural way to build it, a `cross_platform_changed: false` in spec A suppresses `windows` in spec B, even where B really changes Windows behaviour. The probe ran on today's code (executed): `[B]` and `[A,B]` both give `('cross_platform_changed',)` because the texts are joined, so after the change, `[A,B]` would give `()`. That contradicts AC-2's goal that no trigger weakens, and the AC-1 oracle tests only one spec, so it would not catch the problem.
Repair: Requirement 1 must say the override is evaluated per element of `texts`, and the result is the union across texts. AC-1 must add a two-text case: `[A(false + OS names), B(OS names)]` still gives the trigger.

**B2 (24jwe): the out-of-scope list contradicts Requirement 3 and AC-6.** Out of scope still lists "Reordering the full run or streaming results early", but Requirement 3 and AC-6 (required) now reorder it. Repair: delete "Reordering the full run". Also reword the Risks row "A slow file matches the name rule", because the name rule was rejected. Both edits are cheap now. After readiness, only the Progress Log may change.

## Implementation notes (non-blocking; carry these into the implementer brief)

1. **Guard-first ordering belongs at the production call site only** (`run_tests.py:2549`). Do not change the `alphabetical` branch of `_schedule_order`: the 1tm6d schedule-control candidates use it (line 1710), and `test_alphabetical_candidate_submits_name_order_via_actual_executor` pins it. Add a separate mode or wrapper. Rename `test_production_full_run_order_stays_alphabetical_despite_cached_timings` (test_run_tests_cache.py:1290) and add a guard case to it. Its fixture files are not guards, so the asserted order should not change. Update the `# Production order: alphabetical` comment, and update `docs/architecture/testing-architecture.md`:171-176, which records alphabetical as the measured schedule. That makes it an Affected Architecture Doc, not N/A.
2. **Scope of the AC-2 existence check.** Make the missing-name usage error apply to `--guards` runs. A full run should use the intersection of the guard set with the discovered files. Otherwise every `main()` test in a fixture tests directory (test_run_tests_cache.py) breaks, and a renamed guard file blocks the run that writes the receipt. To stop the list rotting, add a static test that every `GUARD_TEST_FILES` name exists in the real tests directory.
3. **How the union composes.** Expand `--guards` into names in `_main` before calling `_validate_focus_selectors` or `_run_profile`, and dedupe before `_selector_format_error`, which rejects duplicates. `_run_profile` (line 2003) checks the format only, before copying, and passes names to the child process as `--file` (line 1978). The guard set must therefore reach it as names, and the existence check must run against `_SCRIPT_DIR/tests`. Following the `--file` rules: allowed with `--profile`, refused with `--no-cache`, `--schedule-control` and `--qualify-profile`. Update `_USAGE` and correct the docstring's "buffered" note (lines 25-26).
4. **The evaluator bump (24jwf).** Change 8 to 9, and add a comment line describing the 8-to-9 change at review_policy.py:175. Two pinned tests must move with the constant: the tripwire `test_evaluator_version_eight_is_the_shipped_transition_boundary` (test_review_policy.py:673-699; extend its docstring and do not delete it) and test_phase_gates.py:763. Staleness detection already works: `evaluator_version` is part of the `policy_input_snapshot` digest (line 1271), and `review_policy_upgrade.py:166` compares the receipt's version.
5. **Matching literals in prose.** The existing `\bfield\s*[:=]\s*true\b` regex already matches a quoted mention such as "never set `cross_platform_changed: true`" (probe, executed). Today that can only add a trigger, so it is harmless. A quoted `false` will now remove one. Readiness reviewers check that claim, and B1's per-text scoping keeps the effect inside one spec. The Progress Log and comments are excluded by the canonical body, so a declaration there has no effect. `small_change_lane` (line 355) uses `normalized_review_text`, not the canonical body, so for that lane a Progress Log declaration does count. Pin that difference, or state it in the spec.

## Red-team primer

- Q1: answered. The Decision Log was corrected, and Requirement 3 adds guard-first ordering.
- Q2: answered on paper by Requirement 2 and AC-1. Note 3 covers how to build it.
- Q3: answered, "once per wave".
- Q4: answered, Requirement 5 keeps the duties.
- Q5: moot, because the section strip was dropped.
- Strongest challenge: answered by switching to the explicit-false override, and the Product Intent states the adoption-limited effect honestly. B1 is a new problem that this design introduces.

## Platforms

Both changes are pure Python string matching and ordering with no path or OS calls, so they behave the same on Windows, macOS, Linux and WSL2. Selectors stay as basenames, which fits the existing `\\`/`/` rejection.

## Focused reverification (context 24jwg-readiness-code-2, receipt review-policy-14e0261b782c1d39230f)

Verdict: **both repairs are correct. The code-reviewer readiness approval is recorded.** I did not perform the repairs.

- **CODE-RDY-1 (B1) is repaired.** 24jwf Requirement 1 now evaluates the override for each admitted text and takes the union of the results. AC-1 adds the two-text case and states that this case fails against a corpus-level override. Requirement 2 states that the small lane sees the Progress Log and Prepare does not, and a test pins that difference.
  - I reran the original two-spec probe (executed). Today's extractor returns the trigger for [A,B].
  - A scratch model that applies the override to the joined corpus returns no trigger for [A,B], which reproduces the leak.
  - A per-text union model returns: [A,B] trigger, [A] no trigger, [B] trigger.
  - The code-reviewer lane is cleared. qa-reviewer has since cleared its lane too, so this finding is terminal.
- **CODE-RDY-2 (B2) is repaired.** The out-of-scope list now reads "Streaming failure detail early". The Risks row now refers to the curated list. Requirement 3 keeps guard-first ordering at the production call site only, and AC-6 now tests the default full-run path.
  - I ran an assertion script (executed). It returns True on the repaired spec and False on a known-bad copy with the old bullet restored.
  - The finding is terminal.
- **My readiness implementation notes all landed:**
  - The AC-2 missing-name error applies only to `--guards`, and a static test checks that every guard file name exists.
  - Repeated `--file` selectors are still refused; only overlap with the guard set is deduplicated.
  - Schedule-control modes are unchanged.
  - The task list includes the docstring correction and the test rename.
  - `testing-architecture.md` is listed under Affected Architecture Docs.
  - The evaluator 8-to-9 bump notes are in the 24jwf Progress Log, including the two pinned tests.
- **One point remains for the implementer:** the per-text extraction must still apply `comment_visible_text` and lowercasing to each element.
