# 24jwg readiness: architecture-reviewer

Verdict: **approve, no blocking defect.** Execution status: inferred (read-only reads and greps of code and docs; no tests or probes run). Context `24jwg-readiness-arch-1`, fresh and independent.

## 24jwe: guard-first production schedule

- **The 1tmtx decision is a recorded measurement, not an ADR.** `docs/architecture/testing-architecture.md` lines 169-178 say alphabetical is "the MEASURED schedule". It was selected over longest-first by total wall time (130.5 s vs 136.8 s A-T-T-A). There is no ADR under `docs/architecture/decisions/`. Guard-first optimises a different objective, time to the first guard failure, so it does not contradict the measurement. The spec already names this doc as affected. No decision-log entry or ADR is needed. The Decision Log row in the spec is the right record.
- **Implementation notes (non-blocking):**
  1. Rewrite the testing-architecture paragraph so that the 1tmtx comparison stays as history. It should state that production now submits `GUARD_TEST_FILES` first and then alphabetical order, that the change was chosen for early failure signal, and that its wall-time effect was not measured. The guard prefix front-loads `test_line_ending_census` (about 67 s), which is partly what the slower longest-first candidate did.
  2. State that the `--schedule-control alphabetical` candidate no longer reproduces production order exactly. It stays a benchmark-only mode and never touches the receipt. Requirement 3 already keeps `_schedule_order` unchanged.
  3. Update the comment at `run_tests.py:2547` ("alphabetical until the measured schedule winner...").
- **Layering:** `--guards` reuses discovery, the worker path and the focused-run no-receipt rule. The close gate (`lifecycle_gates._framework_test_receipt_status`) and receipt scope are untouched. The boundary is sound.

## 24jwf: per-text override, evaluator 8 to 9

- **Consumers of `extract_full_council_triggers`:**
  - `lifecycle_gate_support.py:1399` (Prepare, per admitted canonical text).
  - `lifecycle_gate_support.py:214`, the legacy no-receipt fallback. It passes wave.md as one text, so there the declaration is wave-scoped. That fallback is compatibility-only, so this is acceptable. A test is optional.
  - `small_change_lane.py:356`, which passes one text. The Progress Log difference is stated and pinned by Requirement 2.
  - `wf_server/server_impl.py:600` imports it only.

  `cross_platform_changed` appears nowhere else. `FULL_COUNCIL_TRIGGER_FIELDS` as repair-depth booleans (`review_boundaries_changed`, seed 209) is a separate mechanism, and the spec says so. For the other fields, per-text union equals the joined-corpus result, so behaviour there is unchanged.
- **Receipt and version flow:**
  - `evaluator_version` is in the `policy_input_snapshot` digest (`review_policy.py:1271`) and in the receipt (`lifecycle_gate_support.py:1434`).
  - `review_policy_upgrade.py:164-167` marks any non-closed declared wave whose receipt version differs for re-Prepare.
  - The bump is therefore detected without new code, and AC-3 covers it.
- **Downstream distributions:** `review_policy`, `review_policy_upgrade` and `lifecycle_gate_support` are in the reserved-module list (`mcp_tool_extensions.py:277`), so Waveforge cannot shadow the evaluator through an extension seam. It gets the change only through upgrade. On upgrade, any readied or open declared wave in a target gets one automatic re-Prepare marker.
  - **Note (non-blocking):** Requirement 3 states the effect only for this repository. The CHANGELOG entry should also say that targets with readied or open declared waves need one re-Prepare after upgrade, and that the new `false` declaration can drop `delivery_council_required` for their specs.
- **Docs completeness:** The list is complete: `mcp-tool-surface.md:2188` (version line, test-enforced; add the v8-to-v9 re-Prepare sentence), `data-and-control-flow.md` around line 920 (one per-text sentence), `review-and-evals.md`, seed 007 and seed 170. ADR 1tsbu does not pin a version number and needs no edit.

## Summary

Both plans keep their boundaries: the runner change stays in production scheduling, and the evaluator change is confined to one trigger field with per-text scope. The three notes above belong in the implementer brief. None blocks readiness.
