# 24jwg delivery QA review (qa-reviewer)

Verdict: approve, no blocking defect. Packet tree_fingerprint `4c9612c34274a219` recomputed over the 20 listed paths (sha256 of `git hash-object` lines) and it matches. Only 24jwg hunks were reviewed.

## Executed

- `run_tests.py --guards --file test_run_tests_cache.py --file test_review_policy.py --file test_small_change_scope.py --file test_phase_gates.py --file test_lifecycle_golden.py`: 446 tests, 14 files, 29.8 s, OK.
- Own mutants, run in a scratch copy of `scripts/`:
  - Q1: un-anchor `_declares_field_false` (F2 reverted). `CrossPlatformDeclarationTests` fails twice. KILLED.
  - Q2: small lane passes the joined `[effect]` (F1 reverted). `test_spec_and_intended_diff_declarations_do_not_cross` fails. KILLED.
  - M10 recheck: `_guard_first` at the schedule-control call site (line 1756). `test_alphabetical_candidate_submits_name_order_via_actual_executor` fails, because the guard fixture sorts last but would be submitted first. KILLED.
  - M11 recheck: drop `_guard_first` at the production site. `test_production_full_run_order_is_guard_first_then_alphabetical` fails. KILLED.
- M9: the `_main` missing-guard branch is gone (there is no "names no discovered" text). AC-2's usage-error test passes through `_validate_focus_selectors`.
- The two seed-text tests error in the scratch copy only, because it has no `seeds/`. They pass on the real tree.

## AC backing

24jwe:
- AC-1 (required): GuardArgs/GuardRun tests. M6, M7 and M8 were killed (red-team).
- AC-2 (important): the missing-name usage-error test and the real-directory existence test.
- AC-3 (required): seed 180 and seed 209 text tests, including the absent-name checks.
- AC-6 (required): production-path order test (default and `--no-cache`) and the schedule-control guard fixture. M10, M11 and M12 are killed.
- AC-4 (important): docs. The red-team confirmed accuracy.

24jwf:
- AC-1 (required): `CrossPlatformDeclarationTests` covers the per-text, phrase, explicit-`true` and prose-mention cases, plus two small-lane tests. M1, M2 and M3 are killed, as are Q1 and Q2.
- AC-2 (required): the trust-boundary test. M4 is killed.
- AC-3 (required): the version pins in the tripwire and `test_phase_gates`. The lifecycle golden asserts that `receipt_id` and `policy_input_digest` change across the version, so an old receipt cannot match. No test feeds a v8 receipt to the currency check directly; it is covered indirectly. This is non-blocking.
- AC-4 (important): seed 170 text (line rule, no Progress Log).

The AC Priority tables match the AC lists in both specs. Requirement 2's disproved premise was handled correctly: the test pins the actual consistent behaviour, and the Progress Log records the disproof. Non-blocking: every AC box is still `[ ]`. Mark AC-1 to AC-4 and AC-6 when the coordinator records evidence.

## AC-5 (required, both specs): open

The full suite has deliberately not run. From that single final run I need:

1. `result == "ok"` in `test-cache.json`, with `inputs_hash` matching the final tree and no edit after it.
2. Zero skips beyond baseline.
3. The guard files appear first in the progress lines, which is live evidence of AC-6.
4. `wf_validate_docs` clean.

The second profile per touched test file is already reported in the Progress Log. I did not re-run it.

## Intent check (independent): agree, "partially"

24jwe's mechanism is delivered and was demonstrated in-wave: the guard run caught a real defect in about 5 s. Its downstream outcome (fewer full runs per wave) can only be measured in later waves. 24jwf's mechanism is delivered, but its saving depends on adoption. F2's own-line rule narrows adoption further than the intent paragraph says, although seed 170 states the rule. "Partial" is honest until AC-5 is green and adoption is observed.
