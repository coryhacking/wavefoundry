# 24jwg prepare-phase Wave Council synthesis

Moderator: council-chair. Primer depth: standard (no trust boundary; runner scheduling and one trigger field). Seats: red-team (fixed, primer), docs-contract-reviewer (rotating). Lanes: code, qa, architecture, docs-contract all approved on receipt `review-policy-14e0261b782c1d39230f` (confirmed with `wf_review_wave(phase='prepare')`; lint passed, no unresolved required lanes).

Verdict: **PASS.** seat_agreement: unanimous after one repair cycle; max_severity: medium (the cross-spec leak, now repaired).

## Seat outcomes

- Red-team primer: overturned two premises before any lane ran. Guard-first ordering was wrongly rejected as "buffered" output, and a heading strip would have fixed 2 of 41 triggering waves. Both specs were repaired: guard-first full runs, and an explicit-`false` override. The primer was confirmed by all lanes and extended by code and QA.
- Docs-contract (rotating): best alternative weighed. Point seeds 180 and 209 at the existing fast-checks guidance rather than restating it. Its doc census was adopted into both specs. No blocker.
- Code and QA, sharing one correlated signal: the corpus join in `extract_full_council_triggers` let one spec's `false` suppress a sibling's Windows change. This was repaired as per-text evaluation plus a two-text AC-1 case; known-bad probes separate the naive and repaired models. Code also raised CODE-RDY-2, an out-of-scope line that contradicted Requirement 3, which was repaired. All three findings are terminal.
- Architecture: no blocker. Guard-first optimises time to first failure, not wall time, so the 1tmtx measurement stands as history. The evaluator bump is detected by existing digest and upgrade code.

## Chair spot-checks (inferred, code read)

- `review_policy.py:1361` joins all texts into one corpus. Prepare passes every admitted canonical text in one call (`lifecycle_gate_support.py:1399`). The leak finding was real, and the per-text repair is the right shape.
- `run_tests.py:1617-1621` flushes each file's ok/FAIL line from `as_completed`, and the docstring at lines 24-26 is stale. `_schedule_order` has two call sites: schedule-control at line 1710 and production at line 2549. Requirement 3's production-only change is feasible without touching the benchmark.
- `small_change_lane.py:355-356` passes one text: normalized spec plus `intended_diff`.

## Progress Log notes

All are placement, wording, test-rename and CHANGELOG-content notes inside listed scope and surfaces. None changes a Requirement, AC or trigger, so no re-Prepare is needed. The planned 8-to-9 evaluator bump will force a self re-Prepare before delivery, as the watchpoint states.

## intent_fit

- 24jwe: **establishes**. AC-1, AC-2 and AC-6 deliver the maintainer outcome mechanically, including early FAIL lines without `--guards`. AC-3 delivers the project-neutral guidance. Downstream agent behaviour is honestly deferred. Measure after release: the number of full runs per wave in work logs.
- 24jwf: **establishes** the stated capability. The saving depends on authors adopting the declaration, which the Product Intent states, backed by a corpus replay. Measure after release: the share of new waves declaring `false`, and how often `delivery_council_required` drops for them.
- Objective: **establishes**, with the close gate, receipt scope and other triggers unchanged.

## Strongest challenge / alternative

- Challenge: the 24jwf value is adoption-limited. It is accepted because the declaration covers every placement and seed 170 prompts authors to use it.
- Alternative: a module-level `GUARD_TEST = True` marker per file instead of a curated tuple. It is not stronger, because the curated tuple with a static existence test is simpler and equally visible.

## Improvements recommended (non-blocking)

- Small lane: a spec's `false` also suppresses OS names in its own `intended_diff`, which shares the same text. Add one small-lane test that pins this.
- Re-Prepare immediately after the evaluator bump lands, not at delivery.

## Falsification check

The strongest argument against PASS is that a `false` declaration is a self-attested claim that can hide a real platform change. It does not change the verdict: the claim is scoped per spec, "cross-platform" and an explicit `true` still trigger, and readiness reviewers judge it.
