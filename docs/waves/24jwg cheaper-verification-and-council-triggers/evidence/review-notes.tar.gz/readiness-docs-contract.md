# 24jwg readiness: docs-contract-reviewer

Verdict: approve, no blocking defect. Execution status: inferred (read-only code and doc reads, greps); no tests run.

## 1. Seeds 180 and 209
- Seed 180: put the cost-ordering section directly after `## Choose evidence for the claim` (line 180), before `## Host-neutral orchestration`. Related, not duplicate: that section is about test boundary, not order or cadence.
- Seed 209: add the brief-scoping and once-per-wave sentences inside `### Repair re-verification` (line 262). The existing "Repairs are batched once per round" sentence stays; word the new cadence as "full verification once per wave, after the last repair" so it does not read as contradicting per-round repair batching. Line 79 (Continuation And Qualification Discipline: "run the fast contract checks ... before the full suite") already states half of the ordering; 180's new section should point at it, not restate it. "Focused readiness re-review" (line 67) is about readiness receipts; leave untouched.
- Delivery to targets: `docs/prompts/implement-spec.prompt.md` is a thin pointer to seed 180 (cites only "Host-neutral orchestration"), so the new text reaches targets from the seed as written; no rendered copy to sync. Neutrality oracle (AC-3) must forbid `run_tests.py`, `--guards`, `GUARD_TEST_FILES` and test file names, as planned.

## 2. Seed 170
- Put the `cross_platform_changed: false` guidance under `### Plan shape and readiness repairs` (line 126), as one bullet. Seed 170 and `docs/prompts/plan-spec.prompt.md` currently carry no full-Council trigger or platform-behaviour text, so there is no duplicate. The plan-spec prompt is a rendered summary that cites seed 170 by section; no sync needed unless the implementer adds a pointer.
- Caution: seed 209 line 322 and 334 name five full-council booleans for repair depth. `cross_platform_changed` is a different, spec-text delivery-Council trigger (review_policy.py line 232). Do not edit those lines; say so in the CHANGELOG to prevent confusion.

## 3. Docs that must change (add to Affected Architecture Docs and Serialization Points)
24jwf:
- `docs/architecture/contracts/mcp-tool-surface.md` line 2188: "evaluator version `8`" becomes the new version, with a v8-to-v9 re-Prepare sentence. Spec says "if it lists the trigger tokens"; it does list the version, so this is required.
- `docs/architecture/data-and-control-flow.md` ~lines 920 and 934: describes trigger extraction and `REVIEW_POLICY_EVALUATOR_VERSION`; add one sentence on the explicit-false override (no number there, so low-risk).
- `docs/contributing/review-and-evals.md` line 137: lists cross-platform work as a delivery-Council trigger; add the declaration.
- `.wavefoundry/framework/seeds/007-review-system-overview.md` line 23: same trigger list; one clause.
- CHANGELOG (already planned). Code: `review_policy.py` line 176 plus `lifecycle_gate_support.py` as listed.
24jwe:
- `docs/contributing/build-and-verification.md` (planned; "Focused Diagnostic Runs" at ~line 66 is the anchor, add `--guards` there and the order).
- `docs/architecture/testing-architecture.md` line 69 Test Tiers row lists the runner: add `--guards` mention or declare N/A explicitly.
- `docs/contributing/discovery-delivery-workflow.md` line 31 and `docs/prompts/close-wave.prompt.md` line 99 and `AGENTS.md` line 186: mention only the plain full run; unchanged, but the spec should say so (no edit needed).
- The docstring text sits in `run_tests.py`, not a doc; no `run_tests` usage text lives in the framework README.
- Add all of these to Serialization Points; the spec's "testing-architecture if it describes modes" hedge should become a named decision.

## 4. Docstring
`run_tests.py` lines 25-26 ("Output is buffered and printed file-by-file after all workers finish") is wrong for the per-file ok/FAIL line (flushed from the `as_completed` loop). 24jwe Task covers it; the corrected note should say only the failure detail is held and printed after the completed set.

## Non-blocking cautions
- Both specs edit `docs/contributing/*` and seeds under separate gates; open `seed_edit_allowed` and `framework_edit_allowed` once each.
- The mcp-tool-surface version line is a test-enforced contract text; check its contract test when bumping.

## Focused recheck (context 24jwg-readiness-docs-2)
Read the changed Requirements, ACs, Scope, Affected Architecture Docs and Serialization Points of both specs (inferred, no tests run). My docs list is complete in both: 24jwe names testing-architecture.md (runner row and measured schedule record) and build-and-verification.md; 24jwf names mcp-tool-surface.md, data-and-control-flow.md, review-and-evals.md and seed 007, and states seed 209's repair-depth booleans are a separate mechanism. Placement notes are in the Progress Logs. No new docs contract is touched by the repairs (per-text override, small-lane Progress Log difference, --guards-only stale-name error all stay inside already listed surfaces). No blocker; approval re-recorded.
