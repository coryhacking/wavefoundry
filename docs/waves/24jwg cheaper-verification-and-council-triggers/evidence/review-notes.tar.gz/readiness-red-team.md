# 24jwg readiness red-team primer (standard)

thinking_stances_applied: premise check (is the stated mechanism true), efficacy replay over real records, evasion and hiding, boundary interactions.

## strongest_challenge

24jwf mostly misses the habit it targets. A replay of `extract_full_council_triggers` over the specs of the last 60 waves found 41 with `cross_platform_changed`. A heading-scoped strip of `## Platform Behaviour/Behavior` removes the trigger from only **2** of them (22sft, 242ys). Recent specs state platform behaviour inline ("Platform behavior: ...", "**Platform behaviour:**", "Platforms: ..."; see 24a50, 24bij, 244fh, 23zib) and repeat OS names in Decision Log and Risk rows, which `canonical_review_policy_body` keeps. So the evaluator bump, and the re-Prepare it forces, buys roughly a 5% reduction until authors change habits through seed 170. The spec claims that "a docs-only spec with only a platform statement loses it", but that case is rare in the corpus.

## best_alternative

24jwf: honour an explicit `cross_platform_changed: false` as an override of the bare OS-name tokens (`windows|macos|linux`), while still matching "cross-platform" and an explicit `true` anywhere. This covers inline statements, Decision Log rows and headings alike, and needs no section parser. The evasion risk is the same as with the heading. 24jwe: keep `--guards`, and also run the guard set first in the full run's `_schedule_order`, because per-file FAIL progress lines are already flushed as each file completes.

## primer_questions

1. The 24jwe Decision Log rejects guard-first scheduling because "output is buffered until all workers finish". `_execute_files` prints `[n/N] name — ... FAIL` with `flush=True` from `as_completed`; only the failure detail is buffered. Is the rejection reworded, or the alternative reconsidered?
2. "Union" with `--file`: `_selector_format_error` rejects duplicate selectors. Does `--guards --file test_venv_bootstrap.py` dedupe, or does it fail as a duplicate? Is `--guards` with `--profile` allowed? The spec only mirrors the `--file` refusals, and `--file` is allowed with `--profile`.
3. Requirement 3 says the full run happens "once, after the final repair"; Requirement 4 says "after the round's final repair". Is the full run once per wave or once per round?
4. Does the slimmer re-verification brief in Requirement 4 keep seed 209's existing duties (rerun the original reproduction, the adjacent legitimate-state controls and the replacement-defect check), which need more than the repair diff?
5. 24jwf: under a heading-scoped strip, `### Windows path normalisation changes` nested under `## Platform Behaviour` is stripped as well. Is a nested subsection, or a "cross-platform" phrase inside the section, meant to be ignored?

## efficacy_replay

- 24jwf (executed with `review_policy.extract_full_council_triggers` on canonical bodies, with a fence-aware strip for any heading level): 41 of 60 recent waves have the trigger before the strip and 39 after it. This wave keeps the trigger: 24jwf names the tokens in its Rationale and contains an explicit `cross_platform_changed: true`. 24jwe alone loses it.
- 24jwe (computed from `test-cache.json` `durations_s`): the name rule plus the extras gives 19 files, 136 s CPU in total, and a wall time bounded by `test_line_ending_census` at 66.8 s, so "about 72 s" is roughly right. Replaying 24i2t, the **name rule alone catches 0 of the 2 failures**; both are caught only because they were hand-added to `GUARD_TEST_EXTRA`. The replay is therefore circular for future pins.
- Fix-absent: 24jwe AC-1 and 24jwf AC-1 fail today (good). 24jwf AC-2 is a no-regression test, and AC-3 passes with only the version bump, so neither proves the strip.

## candidate findings

1. **The decision rationale rests on a false premise.** Evidence: `run_tests._execute_files` (as_completed loop, `flush=True` per-file status). execution_status: executed (code read). Non-blocking. Repair: correct the Decision Log row; optionally put guards first in `_schedule_order` (note the 1tm6d schedule-control decision).
2. **24jwf efficacy is low against the real corpus.** Evidence: replay above; inline "Platform behavior:" pattern. execution_status: executed. Blocking for intent-fit unless addressed. Repair: adopt the explicit-false override, or also match an inline label paragraph (`^\*{0,2}platform behaviou?r:?\*{0,2}`); restate the expected effect honestly in the Product Intent.
3. **Union semantics conflict with duplicate-selector refusal.** Evidence: `_selector_format_error`, `_parse_args`. execution_status: inferred. Non-blocking. Repair: AC-1 states dedupe and a deterministic order, with a test for overlap.
4. **Requirement 2 holds only because `small_change_lane` passes the whole normalized spec.** Evidence: `small_change_lane` line ~355, `normalized_review_text(spec) + intended_diff`; headings survive, so the strip applies. The legacy fallback in `lifecycle_gate_support` (~214) passes wave.md text. execution_status: executed (code read). Non-blocking. Repair: one test for the small lane with a platform-only spec.
5. **The name rule is noisy.** It includes behaviour suites (`test_run_tests_repo_guard` 20 s, `test_index_upgrade_guard` 16.5 s, `test_server_startup_guards`) and misses scan-style tests whose names do not say so. execution_status: executed (listing). Non-blocking. Repair: state the rule as a heuristic plus an explicit list, or replace it with a module-level `GUARD_TEST = True` marker in each guard file.
6. **Requirement 3 and Requirement 4 conflict on the full-run cadence**, and Requirement 5 recommends `--no-cache` where a bare run already writes the receipt. execution_status: inferred. Non-blocking. Repair: "once per wave, after the last repair"; prefer the bare run.
7. **AC-3 seed neutrality.** Seed 180 is consumed through a thin pointer (`docs/prompts/implement-spec.prompt.md` refers to the seed), so the text reaches targets as written. The oracle must also forbid `--guards` and `GUARD_TEST_EXTRA`, not just `run_tests.py`. execution_status: executed (read). Non-blocking.

Evaluator bump safety: every other 24* wave is closed, so only this wave re-Prepares, which confirms Requirement 3.
