# 24jwg readiness: qa-reviewer

Verdict: **BLOCKING. Not approved; no approval event recorded.**

## Prediction (before primer and code)

Weakest: 24jwf AC-1. The guess was that `cross_platform_changed: false` might match the "cross platform" phrase token and defeat itself. Runner-up: 24jwe AC-6's "within about a minute" has no oracle.

Outcome: the self-match is **refuted**. The tokens are `cross-platform` and `cross platform`, and the underscore form matches neither. 24jwf AC-1 is still the weakest, for a different reason (below).

## Blocking finding: the override leaks across specs (24jwf Requirement 1 and AC-1)

- Anchor: `lifecycle_gate_support.py:1393-1399` passes **all** admitted change texts in one call. `review_policy.extract_full_council_triggers` (`review_policy.py:1358-1369`) joins them into a single `corpus`.
- Requirement 1 does not say whether a declaration applies to one spec or the whole wave. The simplest implementation, a `false` check added next to the existing `true` regex on `corpus`, lets one spec's `false` suppress the OS names in another admitted spec.
- Executed probe (`scratchpad/leak.py`, two texts):
  - Spec A: docs-only, "identical on Windows, macOS, Linux", `cross_platform_changed: false`.
  - Spec B: "Change Windows path normalisation ... on Windows only".
  - Today: `('cross_platform_changed',)`. Naive joined-corpus implementation: `()`.
  - The ACs as written would all pass, but a real Windows-only change would lose its delivery Council.
- This contradicts the Product Intent ("A change that alters platform-specific behaviour still triggers it"). Seed 170 review of A's `false` would not catch it, because the declaration is honest for A.
- Reach: my replay of the last 60 waves found 39 with the trigger, and 19 of those have more than one spec.
- Narrowing repair, done as a spec edit before readiness:
  1. Requirement 1: the declaration applies only to the text it appears in. Evaluate the override per admitted spec, then take the union.
  2. AC-1 gains one case: two texts, one declaring `false` and one naming Windows with no declaration. Expected result: `cross_platform_changed` is selected.
  - The small lane passes one text (`small_change_lane.py:355-356`), so it is unaffected.
- Recommend recording this as a typed readiness finding before the spec is repaired.

## Non-blocking (fix in the same edit if cheap)

1. **24jwe AC-6 oracle.** `_schedule_order` is shared with the schedule-control benchmark (`run_tests.py:1710`). The production call site is `run_tests.py:2549`, which passes `"alphabetical"`. A unit test of a new mode passes even if line 2549 never uses it. The oracle should drive the default and `--no-cache` order through the production path, or assert the call site. It should also say whether schedule-control order changes (Requirement 3 says "full runs" only).
2. **24jwe Requirement 1 and AC-2.** The spec does not say which runs perform the stale-name check (only `--guards`, or full runs too). Either choice is fine; it should be stated.
3. **24jwe Requirement 2.** The deduplicated union must bypass `_selector_format_error`'s duplicate refusal only for guard/`--file` overlap; repeated `--file X --file X` should still fail. AC-1's overlap case covers the first half. The second half is worth one assertion.

## Checked and sound

- Known-bad status:
  - 24jwe AC-1 fails today (unknown option), as does AC-6 (alphabetical order).
  - 24jwf AC-1's first case fails today.
  - 24jwf AC-3 builds on the existing 7-to-8 transition tests (`test_review_policy.py:673`, `test_lifecycle_golden.py:525`). Its oracle is sound.
- 24jwe AC-3's absence-of-names oracle answers primer item 7.
- Primer items 1, 3, 4 and 6 are repaired in the Requirements and Decision Log. Item 2 is repaired except for non-blocking point 3. Item 5 is moot under the override design.
- AC-5 is change-local in both specs. The priorities are justified.
- 24jwf efficacy holds up. In my replay, 36 of the 39 triggering waves trigger only through OS names (3 contain "cross-platform"), so the declaration can reach most of them. The adoption caveat in the Product Intent is honest. AC-1 and AC-2 establish the mechanism, not adoption, and the spec says so.
- 24jwe ACs establish the maintainer outcome and the seed guidance. The downstream behaviour claim is correctly deferred to observation.
- The wave Objective is established once the blocking repair lands.

## Focused reverification

Context: `24jwg-readiness-qa-2`. Fresh and independent: I did not perform the repair. Receipt: `review-policy-14e0261b782c1d39230f`.

- **24jwf Requirement 1 and AC-1 repair holds.**
  - Requirement 1 now evaluates `cross_platform_changed` once per element of `texts` and takes the union.
  - AC-1 adds the two-text case and states that it fails against a corpus-level override.
  - `scratchpad/leak2.py` ran six fixtures. For the two-text A+B case, the naive override gave `()` and the repaired one gave `('cross_platform_changed',)`, so the new case is a known-bad oracle that separates the two.
  - The other fixtures matched the spec:
    - A alone: suppressed.
    - A plus "cross-platform", A plus an explicit `true`, and no declaration: all re-select the field.
    - A plus "trust boundary": `trust_boundary_changed` only, so AC-2 holds.
- **Replacement-defect check:** none found.
  - An explicit `true` still wins within each text.
  - The other trigger fields still match on the joined corpus.
  - Requirement 2 now states the small-lane Progress Log difference and pins it with a test.
- **Non-blocking notes landed in 24jwe:**
  1. AC-6 drives the production full-run path, and schedule-control order is unchanged (Requirement 3).
  2. The stale-name check applies to `--guards` runs only, plus a static existence test. Full runs skip missing guard files (Requirement 1 and AC-2).
  3. A repeated `--file X --file X` is still refused (Requirement 2).

### Recorded

- Reverification of `QA-RDY-1-false-override-leak`: committed. The finding is terminal.
- Reverification of `CODE-RDY-1-false-override-leak`, clearing the qa-reviewer lane: committed. The code-reviewer lane had already cleared concurrently, so I retried with an empty list after the first attempt was refused. The finding is terminal.
- qa-reviewer readiness approval on the current receipt: committed.

Verdict: **APPROVED.**

## Re-record after evaluator-only rotation

The receipt rotated from `review-policy-14e0261b782c1d39230f` to `review-policy-d213add1300766776f3e` because the evaluator version went from 8 to 9.

What I checked:
- wf_review_wave reports no changed specs and no changed sections. My lane's `section_changes` list is empty and `full_review_required` is false.
- Comparing the two receipts:
  - The per-change canonical hashes match.
  - The lanes, `delivery_council_required` and `primer_depth` match.
  - Only `evaluator_version`, `policy_input_digest` and `project_policy_sha256` differ. That last hash covers a payload that includes the evaluator version.

I re-recorded the approval by reference to my prior evidence, under context `24jwg-readiness-qa-3`. It committed.
