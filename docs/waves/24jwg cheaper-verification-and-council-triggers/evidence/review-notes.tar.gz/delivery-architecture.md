# 24jwg delivery: architecture-reviewer

Verdict: **approve, no blocking defect.** Context `24jwg-delivery-arch-1`, fresh and independent. Execution status: the fingerprint was recomputed by command; everything else is inferred from read-only diff and code reads. No tests were run. Only 24jwg hunks in shared files were reviewed.

Packet: tree_fingerprint `4c9612c34274a219` was recomputed over the 20 paths (`git hash-object` piped to sha256) and **matches**. The tree did not move.

## Readiness notes: all landed

- `testing-architecture.md`:
  - The 1tmtx A-T-T-A comparison is kept as history ("Alphabetical was the MEASURED schedule").
  - The text states that production runs `GUARD_TEST_FILES` first and then alphabetical order.
  - It states that the wall-time effect was not measured.
  - It states that `--schedule-control alphabetical` no longer matches production order.
- The stale call-site comment in `run_tests.py` (now near line 2593) was rewritten. `_guard_first` is applied only at the production site, and `_schedule_order` is unchanged.
- `mcp-tool-surface.md:2188` reports evaluator `9`, per-text evaluation and one re-Prepare from v8.
- `data-and-control-flow.md:920` has the per-text sentence: union per text, every other field on the joined texts.
- CHANGELOG tells target projects that readied or open declared waves need one re-Prepare after upgrade. It says the declaration rules out the delivery-Council trigger for that spec only, and that the seed 209 booleans are unchanged.
- Evaluator flow:
  - `REVIEW_POLICY_EVALUATOR_VERSION = 9` has a bump-history line.
  - The receipt and digest carry the version as before, so `review_policy_upgrade` marks re-Prepare with no new code.
  - The reserved-module boundary is unchanged.
- The small lane makes the two-text call (`[normalized_review_text(spec), intended_diff]`), so declarations no longer cross between spec and diff (F1). `_EFFECT` still scans the joined effect, which is correct because it is a separate check.
- Layering is sound:
  - Prepare passes one canonical text per change.
  - The legacy no-receipt fallback stays wave-wide and compatibility-only.
  - The close gate and receipt scope are untouched.

## Non-blocking notes

1. **The contract docs omit the line-anchored rule for `false` (F2).** Seed 170 says the declaration must be "on a line of its own", but `mcp-tool-surface.md:2188` and `data-and-control-flow.md:921` only say "an explicit `cross_platform_changed: false`". The code (`_declares_field_false`) accepts only a standalone line, with an optional bullet or backticks. The drift runs to the safe side: the docs promise more suppression than the code gives. Suggested fix: add "on a line of its own" to both sentences, and to the CHANGELOG line. This moves the fingerprint, so it needs a new packet if it is applied before close.
2. The `_schedule_order` docstring (`run_tests.py:1573`) still says "the production default until the measured schedule winner is recorded". The function itself is still alphabetical, so the sentence is not false. It is stale, though, because production now wraps the function in `_guard_first`. This is a nit.
