# Implementer brief: wave 249ar (track 4 of arc 244cm)

Wave `249ar memory-maintenance-by-signal` is OPEN (implementing). It has two admitted changes, and you implement both in one session because they share files:
- `246to-enh memory-revalidation-by-signal`
- `24885-bug memory-withhold-and-markup-case`

Both specs are in `docs/waves/249ar memory-maintenance-by-signal/`. Read every Requirement, AC, Task, Decision Log row and Progress Log row before editing. The Progress Log rows written after readiness are binding implementation notes; in 24885 that is "Readiness repair cycle 3".

Track 3 (wave `249as`, change `249aq`) is closed and committed as `eba56ca5`. Its primitive `memory_records.resolve_memory_refs(root, *, evidence=(), targets=(), tree=None)` and `memory_ref_tree(root)` are delivered. The contract is the AC-10 row in the 249aq Progress Log, under `docs/waves/249as memory-admission-hardening/`. Read each ref's `state`, never `blocking`.

## Carry-forwards (from readiness councils)
Read `.wavefoundry/work/249ar/review/council-chair-readiness.md` (246to) and `council-chair-readiness-v3.md` (24885, once written). The items below are known.

For 246to:
1. `_memory_ranked` looks up commit times by canonical (resolved) path.
2. AC-1 goes through the public path.
3. A superseded Decision Log row gets a Progress Log note rather than an edit.
4. The churn baseline is 97 of 174 records.
5. Re-derive every census figure with the shipped primitive. The planner census used the old first-token rule, and `target_unresolved` is now about 7, not 13. State each difference in the Progress Log.
6. AC-3's missing evidence ref `zzzzz` is now `unchecked`, because a wave id needs a digit. Pick a fixture ref that is still a checkable missing ref, and note the change in the Progress Log.
7. A supplied `memory_ref_tree` caches record ids, so build one tree per batch.

For 24885, see the cycle-3 Progress Log row and the round-2 notes `*-readiness-24885-r2.md` and `red-team-readiness-24885-r3.md`. In short:
1. Render the `Source event:` line with the same f-string `memory_records` uses to write it.
2. Do not copy the lint's prohibition-line skip.
3. Rewrite still proceeds on a matching stored title, summary or ref. Pin that with one assertion.
4. The anchor refusal still refuses when every anchor is withheld.
5. Controls (the AC-1.3 clean twin and the AC-3 negatives) pass before the fix; note that.

## Rules
1. Load MCP tools via ToolSearch first and use the code_* tools MCP-first. Record a `Gapfill:` note in the Progress Log when you fall back to shell.
2. Gates: call `wf_open_gate(gate="framework_edit_allowed")` before any edit under `.wavefoundry/framework/` (shell edits included) and `seed_edit_allowed` before seed edits. Close each gate when you finish.
3. Import form in `wf_server/`: `import wf_server.X as X`, never `from wf_server import X`.
4. Preserve each file's line endings.
5. No test writes under this repository's `docs/agents/memory/` or `docs/evals/`; use temporary roots. Do not mutate real memory records. `git status --porcelain docs/agents/memory` must stay empty.
6. Never edit docs while `wf_memory_eval` runs.
7. After readiness, edit only the Progress Log of each spec. Flip checkboxes with `wf_mark_ac` / `wf_mark_task` as each item completes, and set Change Status in the spec and `wave.md` when done.
8. Every new test must fail before its fix, except the named controls. Run `run_tests.py --file <f>` for each touched test file under the default profile and `--profile second`. Do NOT run the full suite; the coordinator runs it.
9. If you edit a handler, refresh its pin in `tests/fixtures/register-surface-handler-digests.json`, only for the handlers you changed. If a tool's input schema changes, regenerate the tool-surface goldens with `WF_UPDATE_TOOL_SURFACE_GOLDEN=1`.
10. Bytecode: run Python with `PYTHONPYCACHEPREFIX` unset and `-B`, or through `run_tests.py`, so no `__pycache__` lands under `.wavefoundry/framework/`.
11. Put scratch scripts and measurement outputs under `.wavefoundry/work/249ar/evidence/`, because they are archived at close.
12. Never commit, close the wave or upgrade the repo. No em-dashes.
13. For AC-11 the MCP server must load the new code: call `wf_reload_mcp` before measuring.

When done, report in under 150 words: what changed, the deviations, the test results, and anything left open.
