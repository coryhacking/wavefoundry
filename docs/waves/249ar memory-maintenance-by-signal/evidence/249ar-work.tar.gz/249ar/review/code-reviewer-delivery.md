# Code reviewer delivery: wave 249ar (246to + 24885)

Context: `249ar-code-reviewer-delivery`. Fresh and independent; I wrote no spec, code or repair. No repo edits, no full suite, no `wf_memory_eval`, no write under `docs/agents/memory/` or `docs/evals/` (`git status --porcelain` on both empty). MCP tools loaded via ToolSearch. Gapfill: the diff, test listing and line-ending scan used `git diff`, `grep` and `sed` on known files, because the review target is the uncommitted diff, which the index does not hold as a diff.

## Verdict

APPROVE. No blocking defect.

## Executed evidence

1. Focused default profile, `run_tests.py --file` over `test_memory_records.py`, `test_memory_eval.py`, `test_handler_modules.py`, `test_line_ending_census.py`, `test_server_package.py`, `test_tool_surface_golden.py`: OK, 451 tests, 0 skipped.
2. `--profile second` over the same six files: 0 of 6 failed.
3. Known-bad controls. Scratch copy of `.wavefoundry/framework` and `docs/` in the session scratchpad (`cr249ar/tree`), the 23 new tests of `RevalidationSignalTests`, `MemoryStoredFieldWithholdTests`, `MemoryMarkupCaseTests`, `MaintenanceSignalTests` and `VersionedQuerySetTests` pass unmutated. Each of 16 mutants, applied one at a time and restored, is caught by at least one test:
   1. `last_check_ts` ignores `Checked at:` (same-day check test).
   2. Churn counted with `>=` and a one-day slack (same-day check test).
   3. Churn path from the raw ref instead of `resolved_path` (AC-1 bare name).
   4. Keep refusal on `target_unresolved` removed (AC-6).
   5. Signal rank dropped from the audit sort (AC-5).
   6. `record_source_event` dropped from `_WITHHELD_VIEW_KEYS` (AC-1.1, AC-2).
   7. `(?i:` replaced by `(?:` in the markup pattern (AC-3, 6 failures).
   8. Keep without a note allowed (AC-6).
   9. `suffix_only` treated as unresolved, the `blocking` reading (6 tests).
   10. `Updated:` stamped on every transition (AC-6.5, AC-7).
   11. `memory_validation_write_failed` echoes `str(exc)` on a matching id (AC-2).
   12. Reused `rewrite_record` not checked (AC-1 reused rewrite).
   13. Withheld anchors listed in `original_anchors` (anchor refusal test).
   14. `no_rationale` disabled (AC-14, AC-8).
   15. Parent lock check removed from the v2 freeze (AC-9).
   16. `source_event` checked with raw content reasons instead of `_memory_forbidden_match` (AC-1.3 clean twin).
4. Line endings: no modified file holds CR at HEAD or in the working tree; `git diff --check` clean. The new `build_corpus` fixture writer is classified in the census.

## Code reads against the lane focus

- `apply_decay`: flags read `state` only through `revalidation_state`; ambiguous and over-long refs set `target_unresolved`; `symbol:` unresolved flags, `community:`/`uri`/`unchecked` do not; churn and halving use canonical paths; `needs_reverification` excludes `target_not_canonical`; no churn attenuation for any kind; time decay from `last_check_ts`.
- `_memory_ranked`: one `memory_ref_tree` per batch; commit times fetched and the override filtered by canonical path (carry-forward 1); churn strictly after the instant (`t > since_ts`).
- Reconcile: refusals run inside the serialized lock before the fence and before any write; status normalization matches the writer's; archival with a note is refused; `Check flags:` are computed before the write; earlier check lines are deleted then inserted, so the note is literal.
- `memory_eval`: `maintenance_signals` is counts only and set before every early return in `run_curated`; `check_outcomes` reads live and archived bodies and skips register entries; freeze v2 checks the parent hash before reading v2 and writes LF bytes through the existing writer.
- 24885: `_stored_record_reasons` covers all seven fields plus the rendered `Source event:` line via `_memory_forbidden_match`; each view is checked against its own record; fallback id and write-failure text withheld; markup pattern uses one inline `(?i:...)` group, other patterns unchanged.
- Imports use `import wf_server.memory_handlers as memory_handlers` and `import wave_lint_lib.wave_validators as wave_validators`. Handler-digest pins change only `memory_reconcile`, `memory_search` and `memory_brief`, the three handlers the diff edits.

## Advisories (non-blocking)

1. DO candidate: `_memory_ranked` now builds `memory_ref_tree(root)` eagerly, a whole-repository walk, on every ranked call, including the hot-path advisories in `_memory_advisories_for_path` and `_memory_advisories_for_wave` (which calls it twice). Measured 0.027 s for 4,803 files here; it grows linearly on large targets. A lazy shared tree, built only when a bare-name ref needs it, keeps the one-walk-per-batch rule at no cost when every ref is exact. The spec Task asked for one tree per batch, so this is a follow-up, not a defect.
2. DECLINE candidate: `parse_memory_record` finds `Checked at:` anywhere in the text, so a hand-edited body line or a future timestamp suppresses churn and time decay. The same whole-text search already applies to `Updated:`; admission keeps summaries single-line.
3. DECLINE candidate: `check_note` has no length cap. It is single-line and content-checked; a cap is a policy choice outside this change.
4. DECLINE candidate: the `memory_target_unresolved` diagnostic names stored target refs without a content check. `memory_reconcile`'s success view already repeats targets, and 24885 scoped withholding to `memory_validate`.
