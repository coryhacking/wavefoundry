# Red-team: delivery fixes re-check (wave 249ar)

Seat: fresh, independent red-team. Notes only, no ledger event. No repo edits.

## Method

- Read `_reconcile_check_refusal` (`wf_server/memory_handlers.py` 2397-2479), `reconcile_memory_record` (`memory_records.py` 1215-1278), `_LazyMemoryRefTree` and `_RefContext` (`memory_records.py` 2146-2320) and `_memory_ranked` (`memory_handlers.py` 270-300).
- Executed probe on temporary roots: a scratchpad subclass of `RevalidationSignalTests` (`probe.py` in the session scratchpad, not in the repo), run with `python3 -B`.
- `run_tests.py --file test_memory_records.py`: 317 tests OK (default profile); `--profile second`: 0 of 1 files failed.

## Fix 1: bypasses (other transitions that act as a keep)

Known-bad control: `stale -> active` with `check_note` on a `gone.py` target returns `memory_target_unresolved` (fix holds).

Finding RT-1 (advisory, medium): two-step bypass reproduces the refused state.
1. `stale -> stale` with `check_note="lesson still holds"` returns ok. It is neither a keep nor a revive, so no target check runs, and it writes `Checked at`, `Check note` and `Check flags: target_unresolved`, and re-stamps `Updated:`.
2. `stale -> active` with no note returns ok and changes only `Status:`.
Result: an `active` record with a fresh recorded check and "lesson still holds" on an unresolved target, the exact state fix 1 refuses in one call. Same with `rejected -> rejected` + note, then `rejected -> active`. Mitigations: `target_unresolved` is computed live, so the flag still surfaces and ranks first, and `Check flags:` honestly records `target_unresolved`. The fresh `Checked at` also resets the churn baseline. Not blocking, because no signal is hidden. Possible fixes, for the coordinator to choose: run the unresolved-target refusal on any transition to `active` from a retired status, with or without a note (this changes the Progress Log line "Without a note it still changes only `Status:`"), or refuse a same-status `check_note` on a non-active record.

Finding RT-2 (advisory, low): `candidate -> active` with a `check_note` on an unresolved target returns ok and writes a full recorded check (`Check flags: target_unresolved`). The spec says promotion "runs no keep refusal", so this matches the spec, but a promotion that carries a note looks the same as a keep in the record. Option: refuse or ignore a note on promotion when a target is unresolved.

Covered and holding: an ambiguous target (`c.py` in `x/` and `y/`) on a keep is refused. `active -> stale` with a note is allowed, which is correct for retirement.

## Fix 2: echo paths

- The refusal view keeps only `ref`, `form` and `state`, so `resolved_path` and candidate lists are not echoed.
- `named` is built from the shown entries only.
- Probe: an ambiguous bare-name target whose name embeds a generated `ghp_` token returns `unresolved_targets: []`, `withheld_target_count: 1`, and the token is absent from the JSON envelope.
- `memory_check_required` and the note refusals echo no refs; the note refusal returns reason codes only.
No remaining echo path found in this refusal.

## Fix 5: laziness

- `_RefContext` reads the tree only through `by_name` (line 2317, suffix match). Both `files` and `by_name` are properties that call `_walk()`, so no bare-name path can read an unwalked tree. `ids` caching uses the plain attribute, which is initialized to None as in the base class.
- Probe: a batch with a bare `b.py` (unique under `pkg/`) and a bare `c.py` (ambiguous) walks exactly once. Lazy flags (`target_not_canonical` and `target_unresolved`) match an eager `memory_ref_tree` resolution (`canonical_paths ['pkg/b.py']` and `ambiguous`).
No skipped walk found.

## Verdict

No blocking defect. RT-1 is the one worth a DO or DECLINE: fix 1 closes the single-call path, but the two-call path through a same-status note still records the check fix 1 refuses.
