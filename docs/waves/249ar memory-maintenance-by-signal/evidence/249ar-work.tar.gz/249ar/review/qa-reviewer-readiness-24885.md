# qa-reviewer readiness, change 24885 (wave 249ar)

Context: `249ar-qa-reviewer-readiness-24885`, fresh and independent. Verdict: WITHHELD, two blocking findings recorded. The `246to` verdict is unchanged: 246to adds only a derived `revalidation_reasons` key to `_memory_view`, which does not conflict with withholding.

Retrieval: MCP tools loaded via ToolSearch. Gapfill: used shell `grep`/`sed` for line-exact reads of known files and a read-only Python probe from the scratchpad (no repo writes, no bytecode written).

## Blocking findings

1. `24885-source-event-exemption`, executed. The record lint exempts a match that ends at the hash separator of a generated `decision-log:` source event (`wave_validators.py:119-164`); the handler path passes `exempt_end=None`. Probe: `decision-log:1abcd-feat rotate-refresh-token:0123456789abcdef` gives `{'source_event': ['secret']}` on the handler path and `set()` in the lint. As written, Req 1 and Req 3 make promote and retain refuse a lint-clean generated candidate whose change slug ends in token, secret, password, passwd or api-key. AC-4 cannot catch it: 0 of 162 current source events hit. Fix: apply the decision-log exemption to `source_event`, and add a negative control to AC-1.
2. `24885-rewrite-copies-source-event`, inferred. Rewrite passes `_source_event=record["source_event"]` to `_memory_add_response_locked`, which does not content-check it. The credential would therefore be written into a new active record and echoed through `data.rewrite_record`, a field that `_withhold_view` never touches. Req 3 ("rewrite proceeds and withholds") does not cover this case, and AC-1's no-echo clause for rewrite cannot be met as specified. Fix: refuse rewrite on a matching stored `source_event`, keep reject as the recovery path, and have AC-1 assert that no new record is written.

code-reviewer independently recorded the same pair as `cr-24885-source-event-lint-exemption-and-rewrite-inherit`.

## Probes (scratch, read-only)

- Case-insensitive tag group over all 198 files under `docs/agents/memory/`: 0 new hits. AC-3 positives match and negatives stay clean under the widened pattern.
- Keyword-assignment `secret` and every other content reason over the stored `source_event`, `action_delta`, `validation_rationale`, `memory_id`, `title` and `summary` of all 197 records: 0 hits. No existing record is newly refused. 0 records are pending.
- `git status --porcelain docs/agents/memory`: empty.
- AC-2 is feasible: `xoxb-1234567890abcdef` satisfies `MEMORY_ID_RE` and matches `secret`; `sk-ant-`/`glpat-` slugs fit too. The fixture must be a hand-written file, because admission refuses the title.

## Existing tests the change would break

None found. The `NEGATIVE` list (`the invoke method`, `<invoker>`), `test_tool_markup_pattern_is_linear` (`<a:` runs stay clean) and `test_reject_and_rewrite_withhold_a_stored_secret` (clean `finding:` source event) all stay valid. Second profile: no path, platform or ordering sensitivity is introduced; AC-5 already names `--profile second`.

## Advisories

- DO: AC-1 is partly vacuous for `action_delta` and `validation_rationale`. `record_memory_validation` overwrites both with the caller's checked values on every successful verdict, so the stored value never reaches a success response even before the fix. Masking on success would hide clean new values. The real echo path for these two fields is the `memory_validation_not_pending` error view of a finalized record. Point AC-1 at that path for these fields, and keep the success-path assertion for `source_event`.
- DO: AC-1's clean twin should include a generated `decision-log:` source event (see finding 1).
- DECLINE: withhold `pointer_to`, `superseded_by` and `archive_path` slugs. They are not set on a pending record, and an archived record exits through the not-pending view; the risk is low.
