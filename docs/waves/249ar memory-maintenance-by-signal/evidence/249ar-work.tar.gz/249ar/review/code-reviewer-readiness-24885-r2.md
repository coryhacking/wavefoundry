# Code reviewer, readiness round 2, change 24885 (wave 249ar)

Context: `249ar-code-reviewer-readiness-24885-r2`, fresh and independent; I did not write the repair. Retrieval: MCP tools loaded via ToolSearch. Gapfill: shell `grep`/`sed` for line-precise reads of already-located files, and an in-process Python probe (read-only, no repo writes).

## Verdict

Finding `cr-24885-source-event-lint-exemption-and-rewrite-inherit` is resolved by the repaired spec. Readiness approval recorded.

## Item 1: decision-log exemption

Requirement 1 now routes `source_event` through `wave_validators._memory_forbidden_match` on the rendered `` Source event: `<value>` `` line, the exact form `memory_records.py:977` writes and the lint at `wave_validators.py:2518` reads. Probe (in-process):

- Plain `forbidden_content_reasons({'source_event': ['decision-log:24885-bug rotate-api-token:0123456789abcdef']})` returns `{'source_event': ['secret']}` (the round-1 defect).
- `_memory_forbidden_match` on the rendered line returns `set()` for slugs ending in `-token`, `-secret`, `-password`, `-api-key`.
- It still returns `{'secret'}` for `decision-log:... x:xoxb-...`, for a `finding:` event with a `-token` slug, and for a decision-log line with trailing text. So the exemption is narrow and credentials still match.

AC-1.3 adds the `-token` clean-twin fixture that promotes. Resolved.

## Item 2: rewrite inherits stored source_event

Requirement 3 now makes rewrite refuse on a matching stored `action_delta`, `validation_rationale` or `source_event`, and a refused rewrite writes no new record. In the tree, the stored-field check (`memory_handlers.py` ~1692) runs before the rewrite branch, and both the `existing_rewrite` reuse and `_memory_add_response_locked(_source_event=record["source_event"])` come after it (~1755-1790), so the refusal can sit beside the promote/retain refusal with no write. AC-1.1 asserts refusal and no new record file. Resolved.

## New defects

None blocking.

## Advisories

- DECLINE: Requirement 1 says "a lint-clean record is never refused by the handler". The lint also skips any line that `_line_forbids_content` treats as a prohibition line; a hand-edited `source_event` containing a negation marker would be lint-clean yet refused by the handler. This is the stricter, safer direction and generated source events never carry such text, so no spec change is needed; the implementer should not add the negation skip to the handler.
- DO (implementation note, no spec edit): when the handler checks the rendered line, build it with the same f-string as `memory_records.py:977` so the anchored `_DECISION_LOG_SOURCE_EVENT_RE` matches.

## 246to

Unchanged since my prior approval; verdict unchanged.
