# qa-reviewer: delivery fixes re-check (wave 249ar)

Context `249ar-qa-reviewer-delivery-fixes`, fresh and independent. Verdict: approve. No blocking finding.

## Focused runs (repo tree, no edits)
- `run_tests.py --file test_memory_records.py --file test_memory_eval.py`: OK, 370 tests, 0 skipped.
- Same files with `--profile second`: 0 of 2 files failed.

## Mutation probes (scratch copy of `.wavefoundry/framework`, `python3 -B -m unittest`)
Baseline: `RevalidationSignalTests` and `GoldenCadenceInvariantTests` OK (14 tests). Each mutant was restored before the next one, and the restore was checked with `diff`.

| Fix | Mutant | Killing test |
| --- | --- | --- |
| 1 | `revive = False` | `test_reactivation_with_a_note_is_refused_on_an_unresolved_target` |
| 1 | `revalidation_state` drops `ambiguous` | `test_ac3_each_resolution_state_sets_its_flag`, `test_ranked_batch_walks_the_tree_lazily_and_once` |
| 2 | no ref filtering (every ref shown) | `test_target_unresolved_refusal_withholds_a_matching_stored_ref` |
| 2 | `withheld_target_count` dropped | same test (error) |
| 3 | `invariant_falsy_id` check disabled | `GoldenCadenceInvariantTests.test_fast_record_must_stay_unflagged` |
| 5 | eager `memory_ref_tree` per batch | `test_ranked_batch_walks_the_tree_lazily_and_once` |
| 5 | one lazy tree per record | same test |
| 5 | lazy walk never caches | same test |

Extra probe (scratch only): a `stale` record whose target is the ambiguous bare name `dup.py` (in `x/` and `y/`) is refused with `memory_target_unresolved` on `active` + `check_note`, its state is reported as `ambiguous`, and the bytes are unchanged. Control: a resolved target revives with `ok`. Known bad: with `revive = False` the probe fails.

## Fix 4 note
24885 Progress Log row "Delivery note 4" matches `test_ac2_matching_id_and_path_are_withheld_from_every_surface`: the record is written under `docs/agents/memory/<token>/mem-nested-clean.md`, so only `path` is withheld. The reasoning holds, because a record is looked up by an id that must equal the filename stem.

## Advisory (non-blocking)
- The fix 1 test covers only an `unresolved` target on revive. The `ambiguous` branch is protected indirectly through the shared `revalidation_state`. My probe shows it works, but no committed test pins ambiguous-on-revive.
