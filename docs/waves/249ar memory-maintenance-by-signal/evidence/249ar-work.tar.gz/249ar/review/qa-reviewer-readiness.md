# qa-reviewer readiness notes, wave 249ar (change 246to)

Fresh, independent context. No repository edits. Probes ran on a throwaway copy under the session scratchpad.

## Verdict

Not ready. There are two new blocking findings. I also concur with `blocking-contract-mismatch` (docs-contract-reviewer) and `249ar-rt-bare-target-churn-blind` (red-team).

## Verified against the code

- `apply_decay` (memory_records.py 1667) divides by `1 + churn/halving` for the tactical kinds, applies `BRIEFING_CONFIDENCE_FLOOR` 0.2, counts churn from `created_at`, and flags `fragile_file` on any churn. With no history, `adaptive_churn_halving_commits` returns 10. The AC-1 known bad, 0.8/2.2 = 0.3636, holds.
- The time decay is hyperbolic, `base/(1+age/halving)`. AC-2.2 gives 0.8/(1+22/180) = 0.7129, which is correct.
- `reconcile_memory_record` stamps `Updated:` on every transition. The AC-7 known bad holds. The AC-5 known-bad order R3, R4, R2, R1, R5 matches the 244fh sort.
- `apply_decay` has no `root` or `tree` parameter. The implementer must add one; the Tasks imply it.
- The AC-11 figures reproduce: 31 active records have neither `Validation rationale:` nor `Action delta:`, and 4 + 31 - 32 = 3 records carry both reasons.

## Concurrence: blocking-contract-mismatch

A read-only count on this tree found 47 of 174 active records (27%) with at least one file target that is not an exact path. Under 249aq's `blocking` (which includes `suffix_only` targets), all 47 would be `target_unresolved`. They would take rank 0 in the audit, and every keep of them would be refused. Missing evidence refs would also raise a reason named `target_unresolved`.

## Finding qa-249ar-keep-note-breaks-candidate-paths (blocking)

Requirement 6.1 makes every transition to `active` require `check_note`, candidate promotion included. Two shipped instructions still send that call without a note:

- Seed 190 step 12 tells close to promote hand-authored candidates "through the existing `memory_reconcile` status transition to active".
- Seed 240 step 2 says `memory_reconcile(memory_id=..., status="active"|"rejected")`. The render test pins that literal at `test_render_agent_surfaces.py` line 64. Seed 240 step 3 is pinned at line 85.

The spec edits seed 240 step 3 only, and seed 190 is out of scope. After this change, a hand-authored candidate cannot be promoted by following either prompt.

I probed the rule on a throwaway copy (reconcile to active refused, and `Updated:` no longer stamped). Two existing tests failed that the spec does not name: `LeastRecentlyReviewedOrderTests.test_keep_stamp_rotates_the_record_to_the_end` and `SameStatusKeepStampTests.test_same_status_reconcile_stamps_updated_only`.

Fix: put seed 190 step 12, seed 240 step 2, their rendered copies and both pins in scope, or exempt candidate to active from the note. Name the two tests in Tasks.

## Finding qa-249ar-eval-ids-break-aggregate-only (blocking)

Requirement 7 adds `coverage_gap_ids` and `uncoverable_ids` (memory ids) to `wf_memory_eval`. The shipped contract says it must not contain them. The `run_curated` docstring (memory_eval.py 1350) says "Aggregate-only: no ... memory ids". The `wf_memory_eval_response` docstring (memory_handlers.py 2383) says "never record bodies or ids". `test_memory_eval_tool_reports_aggregate_only` walks the envelope for per-record keys. The spec neither acknowledges nor decides this reversal.

Fix: either record a decision and update both docstrings, the test and the tool-surface doc, or keep the tool aggregate and expose the ids only through `memory_eval.uncoverable_records` or the CLI. Requirement 7 also says `memory_eval.py --json` reports the signals. That CLI runs the hermetic fixture pass unless `--curated-root` is given, so the spec should name which root it uses.

## Smaller notes

- AC-9.4 "the 245sp metrics" is not a checkable value. Name the fields.
- AC-6.2 pins the date, but `memory_reconcile_response` has no date parameter, so the test must patch time.
- AC-14 is listed before AC-13.

## Measurement

The signals are honest and model-free. AC-11's ordering check is true by construction of the sort. It shows wiring, not value. The spec says the value is measured after release through `check_outcomes`, which is fair.

## Size

The change is large: 14 ACs. Versioned freezing (Requirement 8, AC-9) is separable, but it is needed for the post-close re-freeze, so the size is acceptable.

## Tests run (unchanged tree)

The four memory test files: 372 OK under the default profile and under `--profile second`.
