# Code-reviewer readiness notes, wave 249ar (change 246to)

Reviewer: code-reviewer, fresh and independent context. Receipt `review-policy-853a27f7da7e8def650b`.

## Verdict

Not ready. One blocking finding, recorded in the ledger: `cr-249ar-blocking-semantics-contradiction`. It overlaps `blocking-contract-mismatch` from docs-contract and adds the code-level counts below.

## Anchors checked against the tree

| Spec claim | Result |
| --- | --- |
| `apply_decay` divides tactical confidence by `1 + churn / halving` | Holds (`memory_records.py:1667-1745`, `CHURN_DECAYED_KINDS` at `:88`). The AC-1 known-bad value is 0.8 / 2.2 = 0.3636, and AC-2.2 gives 0.8 / (1 + 22/180) = 0.7129. |
| Churn and age are counted from `created_at` | Holds (`created_ts`). |
| `reconcile_memory_record` re-stamps `Updated:` on every call | Holds (`:1155`), including same-status keeps. |
| The 244fh order is `updated_at`, then effective confidence, then id | Holds (`memory_handlers.py:1854`). The AC-5 known-bad order, R3, R4, R2, R1, R5, is correct. |
| Only `memory_validate` calls `_memory_file_target_exists` | Holds. |
| `memory_eval` already uses `memory_records` and `_memory_ranked` | Holds (`memory_eval.py:610`, `:653`). `freeze_query_set` is at `:1577`. |

## Blocking: `blocking` means two different things

249ar Requirement 1.1 says `target_unresolved` fires when `resolve_memory_refs` lists a ref in `blocking` "(state `unresolved` or `ambiguous`)". The 2026-11-24 Progress Log row says the same. In 249as as now decided, `blocking` also contains every `suffix_only` target (Decision Log 2026-11-24). 249aq Requirement 1 also says callers that judge existing records "read each ref's `state` rather than `blocking`".

Measured on this repository's 174 active records, read-only:

- Under 249as's `blocking`, 47 records get `target_unresolved` (73 suffix-only targets, 4 ambiguous, 9 unresolved), and AC-6.3 refuses every keep on them with `memory_target_unresolved`.
- Under 249ar's own reading, 13 records are flagged.
- Evidence refs add more under both readings, because 249ar passes `evidence=` and `blocking` includes unresolved evidence. Examples are the missing wave id `240wz` and the 9 missing evidence paths. The reason name `target_unresolved` then misnames an evidence failure.

Fix: choose one rule and state it in both specs. Either 249ar reads `state` and counts `unresolved` or `ambiguous` targets only, or it accepts `blocking` and accepts that suffix-only records are flagged and cannot be kept until they are rewritten. Then decide whether evidence refs contribute, and under which reason name.

## Callers that break when a keep without `check_note` is refused (counted in a throwaway copy)

I ran the probe on a private copy at `scratchpad/cr249/probe2`. It refused `status="active"` in `memory_reconcile` and removed the `Updated:` re-stamp. I ran it over `test_memory_records`, `test_memory_backfill`, `test_lifecycle_mutation_lock`, `test_archive_memory_backfill` and `test_memory_eval`.

Tests: 2 break. Both are 244fh tests that the Tasks do not name:

- `LeastRecentlyReviewedOrderTests.test_keep_stamp_rotates_the_record_to_the_end`
- `SameStatusKeepStampTests.test_same_status_reconcile_stamps_updated_only`

The second test also calls `mem.reconcile_memory_record(..., "active", date=...)` directly (`test_memory_records.py:5460`), so the spec should say whether the refusal lives in the handler or in the low-level writer.

Guidance and strings that tell agents to keep without a note:

| Location | In 249ar's plan |
| --- | --- |
| Seed 240 and its 2 copies | Yes |
| Seed 190 item 12, plus `docs/prompts/close-wave.prompt.md` and the install template | No (3 places) |
| `server_impl.py:14909`, the `memory_validation_required` recovery_usage | No |
| `server_impl.py:27423`, the `memory_search` docstring | No |

That is 5 unplanned places. A manual candidate promoted at close (candidate to active) now needs `check_note`, and seed 190 does not say so. This overlaps `qa-249ar-keep-note-breaks-candidate-paths`.

There are no production internal callers that move a record to `active`. `memory_add(supersedes=...)` and `memory_consolidate` move records only to `superseded`, which Requirement 6.3 covers.

## Non-blocking, should be settled in the Progress Log

- `check_note` is a new caller-controlled field persisted into the record. It must pass the same pre-write forbidden-content scan as every other persisted field: 249aq's `forbidden_content_reasons`, and the invariant comment at `memory_handlers.py:1440`. Otherwise the record lint flags the file only after it has been written.
- `apply_decay` gains no `root` or `tree` argument in the plan. The single-record callers (`memory_handlers.py:770`, `:2100`) will not report the flag unless they are updated.
- Churn is read from `index_state_store` by the literal target string, so bare-name targets never churn-flag. This overlaps the red-team finding `249ar-rt-bare-target-churn-blind`.
- Removing churn attenuation and the tactical briefing floor changes `_memory_ranked` order, so the frozen-set metrics can move. AC-11 should record them before and after.
- `Updated:` has day granularity, so commits made earlier on the day of a check count as churn after it.
