# Focused readiness brief (wave 249ar, added change 24885)

Wave `249ar` was readied with one change, `246to-enh memory-revalidation-by-signal`. The prior approvals and notes are in this folder (`*-focused-r2.md`, `council-chair-readiness.md`). On 2026-11-24 the operator closed wave `249as` (commit `eba56ca5`) and moved two declined delivery advisories into this wave. A new change carries them, `24885-bug memory-withhold-and-markup-case`, at `docs/waves/249ar memory-maintenance-by-signal/24885-bug memory-withhold-and-markup-case.md`. Admitting it rotated the receipt, so every readiness approval is stale. The `246to` spec text is unchanged; `wf_review_wave(wave_id='249ar', phase='prepare')` shows only `24885` as changed.

The two items:
1. `memory_validate`'s record view (`_memory_view`, `_withhold_view`, `_WITHHELD_VIEW_KEYS`, the `stored_reasons` check in `memory_validate_response`, all in `.wavefoundry/framework/scripts/wf_server/memory_handlers.py`) copies stored `action_delta`, `validation_rationale` and `source_event` unchecked, and `memory_id`/`path` carry the title slug.
2. The tool-call markup pattern in `MEMORY_CONTROL_TOKEN_PATTERNS` (`.wavefoundry/framework/scripts/wave_lint_lib/constants.py`) is case-sensitive.

## Your task, as a FRESH, independent reviewer of your lane
1. Load MCP tools via ToolSearch first; use code_* MCP-first. Record a `Gapfill:` note if you fall back to shell search.
2. Review the new `24885` spec against the actual tree: do its claims hold in the code, are its ACs testable and sufficient, does it conflict with `246to` (both touch `memory_handlers.py` and `test_memory_records.py`)? Do not redo a full sweep of `246to`; confirm only that the addition does not change your earlier verdict.
3. Useful probes (on a scratch copy, read-only for the repo): would a case-insensitive tag group newly match any line in `docs/agents/memory/` or in a record's stored `action_delta`, `validation_rationale` or `source_event`? Would the keyword-assignment `secret` pattern fire on any existing record's stored `source_event` or `action_delta` (which would make promote or retain refuse a legitimate record)?
4. Make NO repo edits. Never run the full suite. Do not run `wf_memory_eval`. Do not mutate `docs/agents/memory/`.
5. Record with `wf_review_event(wave_id='249ar', ...)`, dry-run first, then create:
   - A blocking defect: a finding with `run_kind='readiness'`, `cycle=0`, `actor=<lane>`, `context_id='249ar-<lane>-readiness-24885'`, honest `execution_status`.
   - Otherwise (code-reviewer, qa-reviewer, docs-contract-reviewer): a readiness approval, `signoff_key=<lane>`, `approval_phase='readiness'`, `actor=<lane>`, `context_id='249ar-<lane>-readiness-24885'`, `fresh_context=true`, `independent=true`, your OWN honest `integrity_checks` (a readiness approval attests the plan review; a refuted plan claim or rejected bad input is a valid known-bad control).
   - red-team: notes only, plus a finding for a blocking defect.
6. Write notes to `.wavefoundry/work/249ar/review/<lane>-readiness-24885.md`, listing advisories as DO or DECLINE candidates. No em-dashes.
7. Reply in under 80 words.
