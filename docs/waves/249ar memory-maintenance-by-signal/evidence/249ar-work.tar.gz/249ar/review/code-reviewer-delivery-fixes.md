# code-reviewer: delivery fixes re-check (wave 249ar)

Verdict: APPROVE. No blocking defect. Recorded `ev-approval-code-reviewer-4` (delivery, context `249ar-code-reviewer-delivery-fixes`).

## Scope
Fixes 1, 2 and 5 in `.wavefoundry/framework/scripts/wf_server/memory_handlers.py` (`_reconcile_check_refusal`, `_memory_ranked`) and `.wavefoundry/framework/scripts/memory_records.py` (`_LazyMemoryRefTree`, `lazy_memory_ref_tree`).

## Reading
1. Fix 1: `revive` is `status == "active"`, the record is not `candidate`, and a note is present. So `stale -> active` and `superseded -> active` with a note take the same `memory_target_unresolved` refusal as a keep. A reactivation without a note writes no check and is not gated, which matches the stated fix.
2. Fix 2: the refusal filters each unresolved entry through `forbidden_content_reasons({"ref": ...})`. Only `ref`, `form` and `state` of shown entries reach `unresolved_targets` and the message. Hidden entries are counted in `withheld_target_count`, which is omitted when zero.
3. Fix 5: `_memory_ranked` builds one lazy tree per non-empty batch and passes it to every `resolve_memory_refs` call. `files` and `by_name` are properties that walk on first read. `ids` stays a plain attribute, so the record-id cache on the tree does not trigger a walk. In `_RefContext`, the only tree read is the bare-name suffix lookup, so exact refs never walk.

## Executed evidence
1. `run_tests.py --file test_memory_records.py`: 317 tests OK under the default profile. Under `--profile second`, 0 of 1 files failed.
2. Mutation controls ran on a scratch copy of the framework tree, not the repo. The unmutated copy passes the three new tests. Each mutant fails its target test:
   1. `if keep or revive:` changed to `if keep:` fails `test_reactivation_with_a_note_is_refused_on_an_unresolved_target`.
   2. The withholding filter changed to `shown = list(unresolved)` fails `test_target_unresolved_refusal_withholds_a_matching_stored_ref`.
   3. An eager `memory_ref_tree(root)` in `_memory_ranked` fails `test_ranked_batch_walks_the_tree_lazily_and_once`.
   4. A per-record lazy tree fails the same test (its walk count goes above one).

## Advisory (non-blocking)
A `candidate -> active` promotion with a note skips the target check. This is out of scope for fix 1, because promotion goes through admission.
