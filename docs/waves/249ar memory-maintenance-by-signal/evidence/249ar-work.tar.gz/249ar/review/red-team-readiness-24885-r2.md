# Red-team readiness re-check, round 2: 24885 (wave 249ar)

Context: `249ar-red-team-readiness-24885-r2`. Fresh and independent; I did not write the repair. Repo read-only. Gapfill: MCP tools loaded; I read known paths with shell `sed`/`grep` for speed. The probes ran in process against temporary trees, using a subclass of `tests/test_memory_records._AdmissionCase` (scratchpad `rt24885/probe_rt.py`) and generated fake tokens.

## Verdict

`rt-24885-rewrite-propagates-stored-source-event` is resolved at plan level, and I cleared the red-team lane. One new blocking finding was recorded: `rt-24885-rewrite-residual-stored-echo`.

## Original finding: resolved

1. Known bad, current tree: a rewrite of a pending record whose stored `source_event` holds a token returns `ok`, and the token appears in the response. The planned AC-1.1 test is therefore non-vacuous.
2. Requirement 1's matcher: `_memory_forbidden_match` on a rendered `Source event:` line returns `set()` for the slugs `rotate-session-token` and `log-tenant-secret`. Raw `memory_line_reasons` returns `{secret}` for both. The matcher still flags `xoxb-` or `sk-proj-` in a slug, a token after the hash, and `finding:... token: ...`.
3. Requirement 3 refuses rewrite before any write, and AC-1.1 asserts that no new record file is written and nothing is echoed.

## New finding: rt-24885-rewrite-residual-stored-echo (blocking, do_now)

Two rewrite responses still repeat stored text. Both were executed.

1. Reused rewrite: when a prior partial rewrite shares the `source_event`, kind, summary and refs, `rewrite_record = _memory_view(existing_rewrite, {})` runs with no content check. Probe C returned `ok`, and `rewrite_record.title` carried the token. Requirement 2 enumerates only the stored-record view and the updated-record view. Requirement 2 should also name `rewrite_record`, whether fresh or reused, as a view checked against the record it was built from.
2. Anchor refusal: `_anchor_refusal` puts the pending record's stored targets that still resolve into `original_anchors` and into the `memory_rewrite_anchor_dropped` message. Rewrite is not refused on a matching stored target. Probe B returned that error with the token in the response. The fix is to leave out or withhold an anchor whose ref matched the stored check.

Both paths need a record that was hand-edited or written by older code, which is the threat model in the spec's own Rationale. Path 2 predates 24885 and comes from the 249aq anchor check. The repair is one Requirement 2 clause and one AC-1 sub-item per path.

## Advisories

- DO: Reword Requirement 3's "the same as for a matching stored title or summary". Today only promote and retain refuse on those fields. Rewrite proceeds and withholds them, and `test_reject_and_rewrite_withhold_a_stored_secret` pins that behavior. Suggested wording: "as promote and retain already refuse a matching stored title, summary or ref; rewrite still proceeds on those."
- DECLINE: `memory_add` names the ids of other records in its `possible_duplicate` diagnostic. A memory_validate rewrite drops those diagnostics on success, and they are never built on its early-error paths. Direct `memory_add` is outside this spec.
- DECLINE: The decision-log exemption hides a match that ends exactly at the `:` separator. A credential pattern that ends at the separator, inside the slug grammar, is flagged anyway, because `xoxb-`/`sk-proj-` slugs matched in the probe. Nothing more is needed.
