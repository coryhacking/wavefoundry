# Delivery review brief (wave 249ar)

The wave is implementing. Its code is in the working tree and uncommitted; `git diff` and `git status` show it. Wave 249as is already committed as `eba56ca5`, so the diff against HEAD is this wave alone.

Changes and specs, under `docs/waves/249ar memory-maintenance-by-signal/`:
- `246to-enh memory-revalidation-by-signal`: derived revalidation flags, decay from the last check, signal-first audit order, `check_note` on `memory_reconcile`, `maintenance_signals`, `--uncoverable-records`, versioned freezing.
- `24885-bug memory-withhold-and-markup-case`: `memory_validate` withholds every matching stored field; tool-call tag names match in any case.

Read each spec's Requirements, ACs and Progress Log. The Progress Log holds the deviations, the binding cycle-3 row in 24885, and the AC-11 measurements. The readiness notes and carry-forward list are in `.wavefoundry/work/249ar/review/` (`council-chair-readiness.md`, `council-chair-readiness-v3.md`).

Coordinator evidence:
- Full suite `run_tests.py --no-cache`: OK, 13,502 tests across 258 files (`.wavefoundry/work/249ar/full-suite.log`).
- `--profile second`: 0 of 258 files failed (`second-profile.log`).
- The initial_delivery run is recorded.

## Your task, as a FRESH, independent reviewer of your lane
1. Load MCP tools via ToolSearch first and use the code_* tools MCP-first. If you fall back to shell search, add a `Gapfill:` note to your notes.
2. Verify the delivered code against each AC and the carry-forwards, not against the Progress Log's claims. Use executed probes: `run_tests.py --file <f>` under the default profile and `--profile second`, and throwaway-copy probes. An executed approval needs a known-bad control: a mutant on a scratch copy that your check catches. Run Python with `-B` or through `run_tests.py`, so no `__pycache__` lands under `.wavefoundry/framework/`.
3. Make NO repo edits. Never run the full suite. Do not run `wf_memory_eval`. Do not mutate `docs/agents/memory/` or `docs/evals/`.
4. Record your result with `wf_review_event(wave_id='249ar', ...)`. Dry-run first, then create.
   - For a blocking defect, record a finding: `run_kind='initial_delivery'`, `cycle=0`, `actor=<lane>`, `context_id='249ar-<lane>-delivery'`, with an honest `execution_status`.
   - Otherwise, record a delivery approval: `signoff_key=<lane>`, `approval_phase='delivery'`, `fresh_context=true`, `independent=true`, executed, with your OWN honest `integrity_checks`.
   - red-team records notes only, plus a finding for any blocking defect.
5. Write notes to `.wavefoundry/work/249ar/review/<lane>-delivery.md`. List non-blocking advisories as DO or DECLINE candidates. No em-dashes.
6. Reply in under 80 words.

## Lane focus
- **code-reviewer:**
  - correctness of `apply_decay`'s flags, churn on canonical paths from the check instant, `_memory_ranked` with one tree per batch, the reconcile check lines and keep refusals, and `memory_eval` aggregates and versioned freeze;
  - the 24885 withholding across every view and response surface, the `source_event` check through `_memory_forbidden_match`, and the case-insensitive pattern;
  - the import form `import wf_server.X as X`, preserved line endings, and handler-digest pins matching the edited handlers only.
- **qa-reviewer:**
  - every AC of both changes has a test that checks something real;
  - fixture changes, including the golden cadence case, the AC-3 `zzzzz` replacement and the DST-safe 22 days, repair the tests rather than weaken them;
  - controls are named;
  - second-profile behavior;
  - no test touches real memory records or `docs/evals/`.
- **docs-contract-reviewer:**
  - seeds 240 and 190 and their four rendered copies, with the render pins;
  - `docs/specs/mcp-tool-surface.md` for both changes;
  - the ADR `1sk58` amendment and the CHANGELOG;
  - the tool goldens match the docs.
- **red-team:**
  - remaining secret-echo paths in `memory_validate`, `memory_reconcile` (`check_note`) and `memory_eval` output (no memory ids in the envelope);
  - bypasses of the keep refusal;
  - mixed-case markup bypasses;
  - pathological check notes.
