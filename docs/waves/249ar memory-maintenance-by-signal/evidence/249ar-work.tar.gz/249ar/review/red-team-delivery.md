# Red-team delivery notes (wave 249ar)

Lane: red-team. Context: `249ar-red-team-delivery`. Fresh and independent; I did not implement any part of this wave.

Verdict: no blocking defect. No finding recorded. Four non-blocking advisories follow, as DO or DECLINE candidates.

## Method

- I loaded the MCP tools with ToolSearch. I read the diff with `git diff` and `grep` because a working-tree diff has no `code_*` equivalent. Gapfill: shell reads were used for the uncommitted diff only.
- I ran executed probes as throwaway subclasses of `RevalidationSignalTests` in the session scratchpad (`rt/probe_rt.py`, `rt/probe_rt2.py`), with `python3 -B` and `PYTHONPYCACHEPREFIX` pointed at the scratchpad. All probe roots were temp dirs. I made no repo edits, ran no full suite and did not run `wf_memory_eval`, and I did not touch `docs/agents/memory/` or `docs/evals/`.
- Known-bad control for markup case: I loaded the HEAD `constants.py` from `git show HEAD:` and ran it beside the working-tree pattern. HEAD misses `<INVOKE name=x>`, `<Ns:Tool_Result>` and `</Parameter>`; the new pattern catches all three. `<invoker>`, `<PARAMETERS>` and bare `INVOKE` stay clean under both.
- Known-bad control for the keep refusal: a same-status keep with no note returns `memory_check_required`, and one on an unresolved target returns `memory_target_unresolved`. A padded `' active '` is stripped and still refused. `ACTIVE` and `Active` fail as unknown statuses (`memory_reconcile_failed`), so case games do not skip the keep check.

## What held

- `check_note` is never echoed in any response. A refused note returns only reason codes (`invalid_arguments` with `rejected_reasons`).
- Mixed-case markup in a note (`<INVOKE name=x>`, `<Function_Calls>`, `<ns:Tool_Use>`, `</PARAMETER>`) is refused. Per 24885 Out of scope, `<System-Reminder>` is still accepted.
- Multi-line injection is refused: U+2028 and vertical tab both fail `memory_single_line`. The replacement-template text `\g<0> \1 $& \\` is written literally. `Status: archived` and `a ## Summary b` inside a note do not change the parsed status or the section split.
- `memory_eval` `maintenance_signals` holds counts only. Ids come only from `uncoverable_records` and `--uncoverable-records`.
- `memory_validate`: `_stored_record_reasons` covers the five new fields. `source_event` goes through `_memory_forbidden_match`, whose only exemption is the decision-log hash separator. The write-failure detail drops the exception text when the id or path matched. `_anchor_refusal` drops matching anchors.

## Advisories (non-blocking)

1. **DO candidate: a reactivation can stand in for a keep.** `active -> stale` (no note) followed by `stale -> active` with `check_note="ok"` succeeds on a record whose target is `gone.py`. It writes `Updated:`, `Checked at:` and `Check flags: target_unresolved`, and resets the churn baseline. Spec Requirement 5.1 defines a keep as same-status only, so this matches the spec. Two things contain it: `target_unresolved` is still derived and ranks first, and `Check flags:` records the flag in the audit trail. Possible fix: apply the unresolved refusal to any `stale -> active` transition that carries a note.
2. **DO candidate: `memory_target_unresolved` echoes stored target refs.** A hand-edited record whose target is a `ghp_` token shape returns that token in both the diagnostic message and `data.unresolved_targets`. The exposure is not new, since the `memory_reconcile` success view and `memory_search` already show `target_refs`. 249as admission also refuses such refs on `memory_add`. Possible fix: withhold matching refs and add a count, the way 24885 changed `_anchor_refusal`.
3. **DECLINE candidate: notes are not checked for control characters.** NUL, ESC (`\x1b[31m`) and U+202E bidi override are all accepted and written to the record file. The note never appears in a response. The same is true of summary and rationale today.
4. **DECLINE candidate: note length is unbounded.** A 200,000-character note is accepted on a single line. Summary and rationale have no cap either. Only refs are capped, at `MEMORY_REF_MAX_CHARS`.
