# Red-team readiness notes: 24885 (wave 249ar)

Context: `249ar-red-team-readiness-24885`. Fresh, independent. Read-only for the repo. Gapfill: MCP tools loaded; most reads used shell `sed`/`grep` for speed over known paths, and the probes ran as a scratch script under the session scratchpad.

## Verdict

The case-insensitive markup change is sound. Requirement 3 has two defects, so 24885 is not ready as written. My earlier verdict on `246to` stands: its only `_memory_view` addition, `revalidation_reasons`, holds derived codes, and nothing in 24885 conflicts with it.

## Finding recorded

`rt-24885-rewrite-propagates-stored-source-event` (blocking, do_now). A rewrite passes `_source_event=record["source_event"]` into `_memory_add_response_locked`, and `memory_add`'s content check does not cover `_source_event`. A stored credential in `source_event` is therefore written into a new active record and returned in `rewrite_record`. Neither path goes through `_withhold_view`, and `memory_search` and `memory_brief` would later show the value. Fix: refuse a rewrite when the stored `source_event` matches. Reject remains the recovery path.

Correction to the ledger record: its `execution_status` defaulted to `executed`. The honest value is `inferred`, because the claim rests on a code trace and I ran no fixture. The record cannot be changed without a conflicting retry.

This finding duplicates `24885-rewrite-copies-source-event` (qa-reviewer) and part of `cr-24885-source-event-lint-exemption-and-rewrite-inherit` (code-reviewer). The repairs can share one fix.

## Confirmed independently, not refiled (already `24885-source-event-exemption`)

The record lint exempts the `:` separator in a `decision-log:<id> <slug>:<hash>` source event (wave 1zbrr). The handler's `forbidden_content_reasons` passes no exemption. In my probe, `memory_line_reasons("decision-log:2500x-enh rotate-session-token:0123456789abcdef")` returned `{'secret'}`, and the test suite already holds a real slug of this kind, `...-log-tenant-secret`. Under Requirement 3 as written, promote and retain would refuse such a legitimate record. AC-4 would not catch this, because no current record has such a slug.

## Probes (scratch, read-only)

1. Widened tag group over 198 record files: 0 new matching lines.
2. Stored `Source event`, `Action delta` and `Validation rationale` values (163 source events) checked with `memory_line_reasons`: 0 hits. Record filenames used as ids: 0 hits. Today, no legitimate record would be refused.
3. AC-3 strings behave as the spec states. Other inputs:
   1. `<Invoke-Command>` and `<tool_use-x>` match, because `\b` accepts `-`. The lowercase forms already matched, so this is not a new class.
   2. `<İnvoke>` (U+0130) matches through Unicode case folding. It is harmless because it makes the check stricter.
   3. A fullwidth `<ＩNVOKE>` and a zero-width-split `<inv​oke>` bypass the pattern. Both fall under the spec's out-of-scope invisible or confusable characters.
4. The namespace prefix `[A-Za-z]...` already ignores case, so Requirement 4's "and the optional namespace prefix" is a no-op.

## Advisories

- DO: AC-2 needs an id that the memory id grammar `[a-z0-9][a-z0-9-]*` can hold, and only `xox[abprs]-`, `sk-ant-`, `sk-proj-` and `glpat-` fit. `AKIA`, `ghp_`, JWT and keyword assignments cannot occur in an id. Name the shape in the AC so the test is not vacuous.
- DO: `memory_id` also reaches responses outside the view, so withholding it only in the view leaves echoes:
  1. Exception text in the `memory_validation_write_failed` diagnostic (`f"{memory_id}: malformed memory record"` from `record_memory_validation`).
  2. The `{"memory_id": memory_id}` fallback when `parse_memory_record` returns None.
  Either cover both paths or scope Requirement 2's "never repeats" to the view.
- DO: Check `path` on its own merits instead of tying it to `memory_id`. `path` comes from the filename and `memory_id` from the file body, so a hand-edited file can have a clean id and a dirty filename.
- DECLINE: `archive_reason` is free text that the view copies unchecked, and the not-pending path can reach it. Current values are tool-written. Accept it as residual unless a hand edit becomes a concern.
- DECLINE: Withholding the caller's new `action_delta` after reject or rewrite, keyed on the old stored reasons, is conservative and harmless.
