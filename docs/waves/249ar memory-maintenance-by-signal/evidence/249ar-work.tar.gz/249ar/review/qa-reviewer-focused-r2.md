# qa-reviewer focused readiness verification, round 2, wave 249ar (change 246to)

Fresh, independent context (`249ar-qa-reviewer-focused-r2`). No repository edits. Every probe ran on a scratch copy of the tree in the session scratchpad (`qa249/base`). Receipt reviewed: `review-policy-4ed936f0857f3aed8580`.

## Verdict

Both qa findings are repaired. Readiness approval recorded.

## qa-249ar-keep-note-breaks-candidate-paths: repaired

The repaired rule:

- Requirement 6.1 requires `check_note` only for a keep, which is a same-status `active` reconcile of an already active record.
- Requirement 6.3 exempts a candidate promotion.
- Requirement 6.4 leaves `Updated:` alone on a transition without a note.

Requirement 9 and AC-10 cover all eight guidance places:

- seed 240 steps 2 and 3 and its read-only procedure;
- seed 190 step 12;
- the four rendered copies of those two seeds;
- two strings in `server_impl.py`.

AC-10 also names the pins at lines 64 and 85 of `test_render_agent_surfaces.py`.

Probe on the scratch copy:

- `reconcile_memory_record` stamps `Updated:` only when it is given a note;
- `memory_reconcile_response` refuses a keep (active to active) with `memory_check_required`.

Results of `run_tests.py --file` over `test_memory_records`, `test_memory_eval`, `test_memory_backfill`, `test_archive_memory_backfill`, `test_lifecycle_mutation_lock` and `test_handler_modules`:

- Exactly two tests fail, both named in Tasks: `LeastRecentlyReviewedOrderTests.test_keep_stamp_rotates_the_record_to_the_end` and `SameStatusKeepStampTests.test_same_status_reconcile_stamps_updated_only`.
- Every candidate-promotion test and every retirement test passes.
- The baseline on the unchanged copy was 263 OK.

## qa-249ar-eval-ids-break-aggregate-only: repaired

- Requirement 7 keeps `wf_memory_eval` aggregate-only, and `maintenance_signals.uncoverable_records` is a count.
- Requirement 8 moves the ids to `memory_eval.uncoverable_records` and `--uncoverable-records`.
- The CLI root is now named with `--curated-root ROOT`.
- AC-8 and AC-14 assert that no memory id appears in the envelope.
- Both shipped docstrings already say aggregate-only and stay true.

Known-bad probe: I injected `maintenance_signals.coverage_gap_ids = ["mem-leaked-id"]` into `wf_memory_eval_response` on the scratch copy. `test_memory_eval.py` still gave 48 OK. Today's test walks keys only, so the planned extension is needed, and AC-8's stated known bad is real.

## Cross-spec agreement

The flag mapping in Requirement 1 covers every state 249aq defines. File targets map as follows:

- `unresolved` and `ambiguous` set `target_unresolved`;
- `suffix_only` sets `target_not_canonical`;
- `resolved` and `unchecked` set no flag.

A `symbol:` target that is `unresolved` also sets `target_unresolved`. Evidence refs are excluded. The flags read `state`, never `blocking`, and churn uses `resolved_path`. Both specs read "at HEAD" as the working tree.

## Non-blocking notes

- The Decision Log row "Consume track 3's ... a ref in `blocking` sets `target_unresolved`" (2026-11-24) contradicts the later state-based row, and it is not marked superseded as 249aq marks its own rows. This belongs to the docs-contract lane, and the later row governs.
- Process: my first reverification here, for `qa-249ar-keep-note-breaks-candidate-paths`, was created without a preceding dry run. The record itself validated cleanly.
