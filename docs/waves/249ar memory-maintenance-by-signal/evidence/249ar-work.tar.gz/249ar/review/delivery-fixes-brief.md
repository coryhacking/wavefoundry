# Focused delivery re-check (wave 249ar)

The code-reviewer, qa-reviewer and docs-contract-reviewer lanes approved delivery with no blocking finding, and red-team found none either. Their notes are in `.wavefoundry/work/249ar/review/*-delivery.md`. After those approvals the coordinator ruled DO on five advisories, and the implementer fixed them. Each fix has a Progress Log row in its owning spec:
1. (246to) A `stale -> active` `memory_reconcile` that carries a `check_note` is refused with `memory_target_unresolved` on an unresolved or ambiguous target, the same as a keep.
2. (246to) That refusal withholds stored target refs that match the content check and reports `withheld_target_count`.
3. (246to) The golden `adaptive_cadence` case also requires the fast record to stay unflagged.
4. (24885) A Progress Log note on the AC-2 folder-versus-filename form.
5. (246to) `_memory_ranked` shares one lazily built tree per batch through `lazy_memory_ref_tree`, which walks the repo only when a bare-name ref needs it.

Coordinator evidence after the fixes: the full suite `run_tests.py --no-cache` passed 13,506 tests across 258 files (`.wavefoundry/work/249ar/full-suite-2.log`).

## Your task, as a FRESH, independent reviewer
1. Load MCP tools via ToolSearch first, and use the code_* tools before shell.
2. Verify each fix that touches your lane in the working tree. Use an executed probe on a throwaway copy or a temporary root, plus a known-bad control.
   - Run only `run_tests.py --file`, under the default profile and `--profile second`. Never run the full suite.
   - Make no repo edits. Do not run `wf_memory_eval`. Do not mutate `docs/agents/memory/` or `docs/evals/`.
   - Run Python with `-B`.
3. Record your result.
   - code-reviewer and qa-reviewer: dry-run, then create, a delivery approval: `wf_review_event(wave_id='249ar', event='approval', signoff_key=<lane>, approval_phase='delivery', actor=<lane>, context_id='249ar-<lane>-delivery-fixes', fresh_context=true, independent=true)`. Mark it executed and give your OWN honest `integrity_checks`.
   - red-team: write notes only.
   - Any lane that finds a blocking defect records a finding instead: `run_kind='initial_delivery'`, cycle 0.
4. Write notes to `.wavefoundry/work/249ar/review/<lane>-delivery-fixes.md`. No em-dashes. Reply in under 60 words.

Lane focus:
- code-reviewer: fixes 1, 2 and 5.
- qa-reviewer: the tests for fixes 1, 2, 3 and 5, and the note for fix 4.
- red-team: bypasses of fix 1 (other transitions that act as a keep), echo paths left after fix 2, and whether fix 5's laziness skips a needed walk.
