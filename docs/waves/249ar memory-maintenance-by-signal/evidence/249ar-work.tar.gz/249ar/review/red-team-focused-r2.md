# Red-team focused reverification, round 2: wave 249ar (change 246to)

Seat: red-team, fresh and independent context `249ar-red-team-focused-r2`. No repository edits, no memory-record changes. Probes live in the session scratchpad under `rt-r2/` (`churn.py`, `sameday.py`, `spaces.py`) and read the live index store read-only. I record no approval.

## Verdict

`249ar-rt-bare-target-churn-blind`: the repair holds. Reverification recorded with `blocking_required_lanes=[]`.

## Flags come from each ref's state (Requirement 1)

The two specs agree on the states: `resolved`, `suffix_only`, `ambiguous`, `unresolved` and `unchecked`. 249aq Requirement 1 tells track 4 to read `state` rather than `blocking`. 249ar Requirement 1 maps the states exhaustively:

- `unresolved` or `ambiguous` sets `target_unresolved`.
- `suffix_only` sets `target_not_canonical`.
- `resolved` and `unchecked` set nothing.
- Evidence sets nothing.

AC-3 carries the `blocking` known bad.

Note: the Decision Log row dated 2026-11-24 that reads "a ref in `blocking` sets `target_unresolved`" still stands. It is not marked superseded by the later row that says to read each ref's state. Requirement 1 is unambiguous, so this is not blocking, but the row should be marked superseded in the Progress Log or Decision Log.

## Churn on the canonical path (Requirement 1.4, AC-1)

Executed against the live index for the 36 active records that have a `suffix_only` target:

- With commit times fetched and looked up by canonical path, 21 of them reach their halving.
- Looking up by raw ref (today's code) finds 0 rows for every bare name. This is the round-1 defect, and AC-1's raw-ref known bad detects it.

Implementation note (non-blocking): the batch fetch also has to move. `_memory_ranked` collects `file_targets` from the raw refs, both for the `file_commit_times` query and for the `commit_times_override` filter that `memory_eval` uses. Suppose an implementation canonicalizes only inside `apply_decay`, and the batch still fetches raw refs. Then 18 of the 21 records reach their halving and 6 lose all their churn: rows survive only where another record names the full path. AC-1 catches this only if it runs through `memory_search` or `_memory_ranked` with a seeded store, not through `apply_decay` with a hand-built `commit_times` dict. The `_memory_ranked` Task names only the shared tree. Recommend that the AC-1 test take the public path, or that the Task say the batch query collects canonical paths.

## A same-day check clears the flag (Requirement 3, AC-6.2)

Executed with commit times `t` compared against the `Checked at:` instant, counting only `t > checked_at`:

| Scenario | Flagged |
| --- | --- |
| 12 commits at 09:00Z, then a keep at 10:00Z | no |
| One more commit at 11:00Z | no |
| 10 commits after the check | yes |
| A commit at the exact check second | not counted |

The known bad is detected. The current day-granular `_date_ts` boundary counts the 09:00 commits and keeps the flag, in each of three host time zones (offsets of 7, 0 and -9 hours).

Note (non-blocking): a record with no `Checked at:` falls back to `Updated:`, which `_date_ts` reads as local midnight. Until each record's first check, its churn boundary depends on the host time zone, on every platform. The Windows paragraph covers only `Checked at:`.

## Inherited from 249aq: spaced paths (owned by `arch-249as-path-form-truncates-spaced-paths`)

Under the primitive's first-whitespace-token rule, 6 of the 13 predicted `target_unresolved` records name existing files in folders whose names contain spaces. With the shipped rule they would be refused a keep and ranked first. The fix belongs in 249aq. Once it lands, AC-11 should expect 7 rather than 13, and the AC already asks the implementer to state any difference.
