# qa-reviewer readiness round 2, change 24885 (wave 249ar)

Context: `249ar-qa-reviewer-readiness-24885-r2`, fresh and independent (did not write the repair). Verdict: both qa findings RESOLVED by the repaired spec; readiness approval recorded.

Retrieval: MCP tools loaded via ToolSearch (`wf_review_wave`, `wf_review_event`, `code_*`). Gapfill: used shell `grep`/`sed` for line-exact reads of known files and read-only in-process Python probes run with `-B` from the scripts directory (no repo writes).

## 24885-source-event-exemption: resolved (executed)

Req 1 now checks `source_event` with `wave_validators._memory_forbidden_match` on the rendered `` Source event: `<value>` `` line, the exact form `memory_records.py:977` writes and the lint reads. Probe, lint form vs a raw `forbidden_content_reasons` check:

- `decision-log:1abcd-feat rotate-refresh-token:0123456789abcdef`: lint `set()`, raw `secret`.
- `decision-log:24885-bug rotate-api-key:0123456789abcdef`: lint `set()`, raw `secret`.
- `finding:x password=hunter2hunter2`: lint `secret`.
- `finding:xoxb-1234567890abcdef`: lint `secret`.
- decision-log line with a trailing `password=...`: lint `secret` (exemption is the separator only).
- decision-log line with a non-hex hash and `-token` slug: lint `secret` (no exemption without the full shape).

So the specified check refuses real credentials and never refuses a lint-clean generated event. AC-1.3 is the negative control that catches a raw-check implementation. Replay over the 197 current records (162 with a source event): 0 lint hits on `source_event`; 0 hits on `action_delta`, `validation_rationale`, id and path. `git status --porcelain docs/agents/memory` empty.

## 24885-rewrite-copies-source-event: resolved (executed known-bad plus spec)

Executed probe on a temp tree (`_AdmissionCase` fixture, scratchpad `qa24885r2/probe_rewrite.py`): a pending candidate with `source_event=finding:<ghp_ token>` and clean title and summary. Current code: rewrite returns `ok`, writes 1 new record file, and the serialized response and `data.rewrite_record` both contain the token; promote alone also returns `ok` and echoes it. AC-1.1's assertions (refusal code, no new record file, no part of the credential in any response) fail on exactly this tree, so the AC oracle detects the known-bad.

`memory_handlers.py` rewrite passes `_source_event=record["source_event"]` to `_memory_add_response_locked`, which does not content-check it. Req 3 now refuses rewrite on a matching stored `source_event` (and `action_delta`, `validation_rationale`) before any write, and AC-1.1 asserts "rewrite writes no new record file" and no serialized response contains any part of the credential. The refusal precedes the `existing_rewrite` reuse branch and the `rewrite_record` echo, so neither path is reachable with a matching stored field. Reject stays the recovery path. The behavior is not yet implemented, so this is a plan-level verification; the AC is the executable oracle.

## AC testability

- AC-1.1: testable (refusal codes, file-count before/after, substring scan of serialized responses); fails before the fix (current rewrite writes the record and echoes `source_event`).
- AC-1.2: testable; fails before the fix (`memory_validation_not_pending` view copies `action_delta` unchecked).
- AC-1.3: non-vacuous as a control: it fails a raw-check implementation. It passes before the fix, so it is a regression control, not a fail-first test.
- AC-2: testable; `xoxb-1234567890abcdef` fits `MEMORY_ID_RE` and matches `secret` (round 1 probe). Forced write failure and forced unparseable record are injectable via `record_memory_validation` and `parse_memory_record` patches. The fixture must be hand-written, since admission refuses the title.
- AC-3, AC-4, AC-5: unchanged from round 1 and testable; AC-4 now names `source_event` through the lint checker, matching the probe above.

No new defect found in the repair.

## Advisories

- DO: Req 3 says rewrite refuses "the same as for a matching stored title or summary", but today rewrite does not refuse on a stored title or summary (only promote and retain do, `memory_handlers.py` stored_reasons branch). The implementer should record in the Progress Log whether rewrite also refuses on stored title, summary and refs, and add one assertion for the choice. Either choice is safe, since rewrite replaces title and summary with caller-checked values.
- DO: the Task "each failing before its fix" should exempt the AC-1.3 clean twin and the AC-3 negatives, which are controls that pass before the fix. Note this in the Progress Log at implementation rather than reopening readiness.
- DO (hygiene, not this change): `.wavefoundry/framework/scripts/__pycache__/` and `wave_lint_lib/__pycache__/` exist with `cpython-314` files dated 11:33, before this lane ran. Per AGENTS.md a stray `__pycache__` under the framework is a defect to report; this lane did not create or delete it.
