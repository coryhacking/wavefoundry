# Red-team readiness notes: wave 249ar (change 246to)

Seat: red-team (fixed, primer, standard depth). Fresh, independent context. I made no repository edits and changed no memory record. The probes are scratch scripts under the session scratchpad `redteam-249/`.

## Verdict

One blocking finding is recorded: `249ar-rt-bare-target-churn-blind` (do_now). It complements the docs-contract reviewer's `blocking-contract-mismatch`, and the two should be fixed together. I record no approval.

## Claim attacked: after this wave, memory is properly maintained

### Blocking: target_unresolved and target_churn are both wrong for bare-name targets

- **The contract contradiction.** Requirement 1.1 derives `target_unresolved` from 249aq's `blocking`. Since the 2026-11-24 decision, `blocking` also holds `suffix_only` targets and every unresolved evidence ref, and 249aq tells track 4 to read `state` instead. Census of the 174 active records (`rt_census.py`):
  1. 56 records have a non-empty `blocking` list.
  1. 13 have a target that is really missing or ambiguous.
  1. 34 are flagged only because a target is a bare name that resolves uniquely.
  1. 9 are flagged only for evidence problems.
- **Effect of the literal reading.** The literal rule floods rank 0, and Requirement 6.2 refuses keeps of 43 records whose targets exist.
- **Churn blindness (new).** `_memory_ranked` looks up churn by the raw ref. `index_state_store.file_commit_times` matches exact paths only. Executed against the live index: `review_evidence.py` has 0 rows, and `.wavefoundry/framework/scripts/review_evidence.py` has 51. `memory_backfill.py` has 0 rows, and the full path has 11.
- **Effect of the state reading.** Under this reading the same 34 records get no reason at all.
- **The fix.** Name the states that set each reason, and count churn on `resolved_path`. Add a bare-name fixture to AC-1 and AC-3. All AC fixtures today use exact paths, so no planned test detects either defect.

### Can an agent re-stamp without a real check? Yes

`check_note` is any non-empty single line, so `check_note="ok"` is a recorded check. The refusal on an unresolved target is the only mechanical floor. The `Check flags:` line keeps the attempt visible, but nothing ties the note to the target. A cheap floor would require the note to name one of the record's resolved target paths. A stronger floor is a blob hash per target (see the alternative below).

### Same-day re-flag (note, not blocking)

`Updated:` is a date, `_date_ts` is local midnight, and churn counts commits with `t > since_ts`. Executed (`rt_sameday.py`): a record checked today with 6 commits earlier today still returns `needs_reverification: true` (`target_churn:6`, and the minimum adaptive halving is 5). Hot files get the smallest adaptive halving, so they are exactly the files that stay flagged after a real check until the next day. AC-6.2 passes only because its fixture commits fall before the check date. Fix: store a check timestamp, or count only commits after the check's commit.

### Does deriving the flags make the audit order unstable?

The order is deterministic for a given working tree and index: rank, then `updated_at`, then confidence, then id, sorted before the cap. It does depend on state outside the record:

- **Index freshness.** `file_commit_times` returns `{}` when the store is missing or unreadable, so every churn flag silently disappears and the order changes with no record edit.
- **Uncommitted deletions.** A file deleted in the working tree moves its records to rank 0.

Both effects are acceptable, but the spec should say that flags vanish without an index, and the order should carry a diagnostic.

The walk cost on this repository is 5,158 files in 0.07 s. In a JavaScript target repository the walk includes `node_modules`, because it skips only `.git` and `.wavefoundry`, and it runs on every ranked batch. Consider honoring `.gitignore`, or skipping the untrusted dependency directories that 249aq already names.

### Does dropping churn decay surface stale records more often? Yes, by intent

Tactical records no longer drop below the briefing floor, so every churned record now reaches briefings at full confidence. Its only protection is the flag in the view. Together with churn blindness, the 34 bare-name records surface at full confidence with no flag and no decay. Today they are not decayed either, because their churn already reads 0, but the spec's claim that every kind is revalidated on churn does not hold for them.

## Strongest alternative design

Persist a per-target blob hash at each recorded check, and derive `target_churn` from "hash differs" instead of commit counts since a date. This removes the dependency on the index and the date granularity. A bare or renamed path is unresolved instead of quietly blind to churn. A note-free re-stamp becomes detectable as a keep that recorded no new hash. It adds one line per record, which Requirement 1 currently avoids by persisting nothing. That trade is worth it here.
