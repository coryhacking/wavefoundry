# Council chair: delivery council (wave 249ar)

Moderator: council-chair. Seats: red-team (fixed), docs-contract-reviewer (rotating). Context `249ar-council-chair-delivery`, fresh and independent: I wrote no code and no earlier review notes for this wave.

Verdict: PASS. No blocking defect. intent_fit: establishes.

## Fix 6 verification (executed)

Read `_reconcile_check_refusal` in `wf_server/memory_handlers.py` (2397-2481) with `code_read`. The keep test is now `status == "active" and record.get("status") != "candidate"`, read from the stored record inside the publication lock, so every reactivation needs a `check_note` and takes the unresolved or ambiguous target refusal.

Probe: `probe_chair.py` in the session scratchpad, a subclass of `RevalidationSignalTests` on temp roots, run with `python3 -B` against two scratch copies of `.wavefoundry/framework`.

1. Good copy (byte-identical to the working tree, checked with `diff -r`): 19 tests OK.
   1. RT-1 two-call path: `active -> stale`, then `stale -> stale` with "lesson still holds" (ok), then a note-less `stale -> active` returns `memory_check_required`; the record bytes are unchanged and `Status: stale` stays.
   1. A note-less `rejected -> active` on a resolved target returns `memory_check_required` and writes nothing.
   1. A clean `stale -> active` with a note on `pkg/b.py` returns ok and writes `Status: active`, `Checked at: 2026-11-24T12:00:00Z`, the note and `Check flags: none`.
2. Known-bad control: the bad copy restores fix 1's narrower rule (a reactivation is a keep only when a note is present). The two-call bypass returns ok, the note-less reactivation returns ok, and 3 tests fail: my two probes and the committed `test_reactivation_is_a_keep`. The committed test therefore detects the RT-1 regression.
3. `run_tests.py --file test_memory_records.py`: 318 tests OK (default); `--profile second`: 0 of 1 files failed. `git status --porcelain docs/agents/memory docs/evals` is empty.
4. Coordinator full suite after fix 6: `full-suite-3.log`, 13,507 tests OK, 12 skipped. I did not run the full suite.
5. Docs: the `memory_reconcile` docstring (`server_impl.py` 27512) and `docs/specs/mcp-tool-surface.md` line 2441 state the reactivation rule. Seed 240 steps and its copies name `status="active"` only for keeps, which now need a note, so they stay accurate.

## Synthesis across changes and the Objective

1. 246to: AC-11 measured the audit batch with the 7 `target_unresolved` records in positions 1 to 7, with reasons shown. `Updated:` moves only with a note (AC-7). The measurement was read-only. Fix 6 makes the reactivation path consistent with the keep rule.
2. 24885: red-team's HEAD-pattern control and the code and qa approvals cover the withholding and markup-case ACs; nothing in fix 6 touches them.
3. Objective: establishes. Track 4 item 7 (the batch review of this repository's records) runs after close by design and is not a gap.

Strongest challenge: candidate remains an unguarded door. `memory_reconcile` still accepts any status to `candidate`, and a `candidate -> active` promotion runs no keep refusal. My probe: `active -> candidate -> active` on a `gone.py` target, both note-less, returns ok twice. The record ends `active` with no recorded check. It is not a bypass of the Objective: no `Checked at:` is written, `Updated:` does not move, and `target_unresolved` is derived live and ranks it first. A promotion with a note (RT-2) writes a recorded check, but `Check flags: target_unresolved` states the flag honestly.

Strongest alternative: make the keep rule one invariant on the record rather than on the transition, so any write that leaves a record `active` with a target that does not resolve is refused (or refuse `-> candidate` from a non-candidate status). That would close the candidate door too. It was not chosen because candidate promotion is admission owned by 249as (Decision Log 2026-11-24), and refusing it would break the seed 190 and seed 240 promotion paths that `qa-249ar-keep-note-breaks-candidate-paths` protected.

## Residual advisories (rulings)

| Item | Source | Ruling | Reason |
| --- | --- | --- | --- |
| C-1: `active -> candidate -> active` launders a record back to active with no check | chair probe | DECLINE | No check or `Updated:` is recorded and the live flag ranks first; candidate transitions belong to 249as admission. Overrule to refuse `-> candidate` from a non-candidate status. |
| RT-2: candidate promotion with a note on an unresolved target writes a recorded check | red-team fixes, code-reviewer fixes | DECLINE | Matches spec Requirement 5.1 and the Decision Log; `Check flags: target_unresolved` records the flag and it stays live. Overrule to refuse or ignore a note on such a promotion. |
| RT-3: `check_note` accepts control characters (NUL, ESC, U+202E) | red-team delivery | DECLINE | The note is never echoed in a response; summary and rationale behave the same, so a fix belongs to one shared content rule, not this wave. |
| RT-4: `check_note` length is unbounded | red-team delivery | DECLINE | Same as summary and rationale today; a cap is a shared content-rule change. |
| DC-1: CHANGELOG wording differs from the spec sentence | docs-contract delivery | DECLINE | Both statements are true and consistent. |
| DC-2: seed 240 and its docs copy differ on an older sentence | docs-contract delivery | DECLINE | Pre-existing, not introduced by this wave. |
| QA: no committed ambiguous-on-revive test | qa fixes | DONE | Fix 7 added it to `test_reactivation_is_a_keep`. |

Gapfill: shell reads were used for the spec Progress Log, review notes and the working-tree diff stat, which have no `code_*` equivalent; code reads used `code_read` first.
