# qa-reviewer delivery: wave 249ar (246to + 24885)

Context: `249ar-qa-reviewer-delivery`. Fresh and independent; I wrote no code, spec or repair. No repo edits, no full suite, no `wf_memory_eval`, no write under `docs/agents/memory/` or `docs/evals/`.

Verdict: APPROVE. No blocking defect.

## Executed

1. `run_tests.py --file` over `test_memory_records.py`, `test_memory_eval.py`, `test_render_agent_surfaces.py`, `test_line_ending_census.py`, `test_handler_modules.py`, `test_tool_surface_golden.py`: OK, 664 tests, 0 skipped (default profile).
2. Same six files with `--profile second`: 0 of 6 files failed.
3. On a scratch copy of the framework (rsync of the working tree into a throwaway git repo under the session scratchpad, run with `python3 -B` and `PYTHONDONTWRITEBYTECODE=1`), the new classes `RevalidationSignalTests`, `MemoryStoredFieldWithholdTests`, `MemoryMarkupCaseTests`, `MaintenanceSignalTests`, `VersionedQuerySetTests` and the changed `DecayTests`, `LeastRecentlyReviewedOrderTests`, `SameStatusKeepStampTests`, aggregate-only and hermetic-digest tests: all pass, no skips.
4. `git status --porcelain docs/agents/memory docs/evals` empty after every run.

## Known-bad controls (mutants on the scratch copy; each CAUGHT)

| Mutant | Caught by |
| --- | --- |
| M1 markup pattern case-sensitive again | `MemoryMarkupCaseTests` (6 failures) |
| M2 churn on raw ref, not `resolved_path` | AC-1 test (the `b.py` record) |
| M3 signal rank dropped from the audit sort | AC-5 test |
| M4 `source_event` not checked | AC-1.1 test |
| M5 day-granular `Checked at:` boundary | AC-6.3 same-day test |
| M6 keep allowed without `check_note` | AC-6 keep test |
| M7 keep allowed on an unresolved target | AC-6 keep test |
| M8 `no_rationale` reason dropped | AC-14 test |
| M9 parent-lock check disabled | AC-9 test |
| M10 churn attenuates confidence again | AC-1 and AC-4 tests (4 failures) |
| M11 `action_delta` not checked | AC-1.2 test |
| M12 path not checked | AC-2 test |
| M13 `suffix_only` treated as unresolved (blocking-style) | AC-3 test |
| M15 `Updated:` stamped on every transition | AC-7 and AC-6.5 tests |
| M16 churn never flags | golden `test_all_policy_invariants_pass` |
| M18 memory ids added to the eval envelope | extended `test_memory_eval_tool_reports_aggregate_only` |
| M19 decay measured from `Created:` | AC-2 test |

## Fixture changes: repairs, not weakenings

1. Golden `adaptive_cadence`: the old `ranked_above` became an id tie once churn stopped attenuating (vacuous); the new `record_truthy` on `needs_reverification` of the slow record is live (M16 caught). `fragile_reverification` gets a five-commit history so the shared threshold is reached; still live.
2. AC-3 `9zzzz` for `zzzzz`: the test asserts the ref's form and state (`wave_id`, `unresolved`) before relying on it, so the "evidence sets no flag" claim is exercised on a checkable unresolved ref rather than an `unchecked` one. Stronger than the spec text.
3. AC-2.2 22 elapsed days from the `Updated:` instant: the expected 0.7129 equals 0.8 / (1 + 22/180); host-DST independent; M19 caught.
4. Old churn-floor tests in `DecayTests` were rewritten to the new rule with exact values, not loosened.

## Controls named

The AC-1.3 clean decision-log twin, the rewrite-on-title pin and the AC-3 negatives are labelled controls that pass before the fix (test comments and the 24885 Progress Log).

## Isolation

Every new test uses a `TemporaryDirectory` root (`_MemoryCase`, `MaintenanceSignalTests`, `VersionedQuerySetTests`); `docs/agents/memory/...` and `docs/evals/...` strings in tests are relative paths inside those roots.

## Advisories (non-blocking)

1. DO: the golden `adaptive_cadence` note says 5 commits flag the slow target "and not the fast one", but the invariant checks only the slow record. A fixed-halving mutant (M17) survives the golden test (it is caught elsewhere, by `DecayTests` adaptive tests and AC-1). Either add the fast-record negative or trim the note.
2. DO: 24885 AC-2 says "a clean id and a credential-shaped filename"; the test uses a credential-shaped parent folder, because lookup by id ties the filename stem to the id. The reachable form is tested; record the deviation in the 24885 Progress Log.
3. DECLINE: AC-14's envelope check matches quoted ids (`"u1"`) only, because short ids collide with other text; AC-8's test covers unquoted, longer ids, which together suffice.
4. DECLINE: AC-8's "same with the embedding model unavailable" compares two model-free computations rather than a model-available run; `maintenance_signals` never touches the index, so the contract holds by construction.
