# Council chair readiness notes, wave 249ar (change 246to)

Chair: council-chair, fresh and independent context `249ar-council-chair-readiness`. Receipt `review-policy-4ed936f0857f3aed8580`. No repository edits and no memory-record changes. The executed check ran on a `git archive` copy of HEAD `4bbbac10` in the session scratchpad (`chair249ar/`).

## Verdict

Ready, with an implementation dependency on wave 249as. `council-readiness` approval recorded with intent_fit `partially`.

## Ledger state

- code-reviewer, qa-reviewer and docs-contract-reviewer readiness approvals are current on the receipt above.
- All 5 readiness findings are terminal (completed repair, no unresolved lanes): `blocking-contract-mismatch`, `249ar-rt-bare-target-churn-blind`, `qa-249ar-keep-note-breaks-candidate-paths`, `qa-249ar-eval-ids-break-aggregate-only` and `cr-249ar-blocking-semantics-contradiction`.

## Seats

| Seat | Evidence | Result |
| --- | --- | --- |
| red-team (fixed) | `red-team-readiness.md`, `red-team-focused-r2.md` | `249ar-rt-bare-target-churn-blind` repaired: churn counts on the canonical path, flags read each ref's state, and a timestamped check clears same-day churn. |
| docs-contract-reviewer (rotating) | `docs-contract-reviewer-readiness.md`, `docs-contract-reviewer-focused-r2.md` | `blocking-contract-mismatch` repaired: the state-to-flag mapping is exhaustive and matches 249aq Requirement 1, and all eight guidance places are listed. |

## Dependency on 249as

249as still has `arch-249as-path-form-truncates-spaced-paths` open, pending the architecture-reviewer lane. I judge that 249ar can be readied now:

- The fix changes how the primitive picks the path token. It does not change the five states (`resolved`, `suffix_only`, `ambiguous`, `unresolved`, `unchecked`) that 249ar Requirement 1 maps, so 249ar's text stays valid.
- The flag workstream already depends on "wave 249as delivered", the first Task confirms the delivered signature, and AC-11 requires re-deriving every count with the shipped primitive.
- Readiness does not take the OPEN slot. 249ar must not be opened until 249as is delivered with that finding terminal.

## Executed check

`census.py` applied an approximation of 249aq Requirement 1 to the targets of the active records in the HEAD copy, in two path forms:

| Path form | `target_unresolved` | `target_not_canonical` |
| --- | --- | --- |
| First whitespace token (249aq as written) | 13 | 36 |
| Longest existing whitespace-joined prefix (the suggested repair) | 7 | 36 |

The 6 records that drop (`1vpm4`, `1wgg5`, `1wiaj`, `1ybvy`, `1yg3q`, `240wz`) name existing ADR, change-doc or wave files whose paths contain spaces. This reproduces the code-reviewer and red-team figures and confirms that the fix changes 249ar's live counts, not its text. The census is not the shipped primitive.

## Strongest challenge

Churn signals vanish silently when the index state store is missing or unreadable, so the signal-first order can change with no record edit. The spec accepts this in Risks and records index health with the AC-11 run. No diagnostic is planned on the order itself. This is not a blocker because no confidence is lowered: only a queueing signal is lost.

## Strongest alternative

Red-team's per-target blob hash stored at each check, with churn derived from a changed hash. Declined by coordinator decision on 2026-11-24, because it adds persisted per-target state and the `Checked at:` timestamp closes the measured same-day gap. I accept the decline for this wave.

## intent_fit: partially

Track 4's core goal holds in the spec:

- signals drive the audit order;
- churn flags a record and never lowers its confidence;
- decay resets only on a recorded check, never on read;
- a keep needs a `check_note` and is refused on an unresolved target.

The wave Objective is established. Against the arc row the verdict is partial: the "disputed in a session" signal is declined, and the item 7 batch review and the v2 re-freeze run after close by coordinator decision.

## Carry-forwards for implementation

1. `_memory_ranked` fetches commit times by canonical path, for both the `file_commit_times` query and the `commit_times_override` filter.
1. AC-1 runs through the public path (`memory_search` or `_memory_ranked` with a seeded store), not `apply_decay` with a hand-built `commit_times` dict.
1. Add a Progress Log note that the first 2026-11-24 Decision Log row ("a ref in `blocking` sets `target_unresolved`") is superseded by the later state-based row.
1. The churn-threshold baseline is 97 of 174 records reaching their halving since `Updated:` (day-granular, no `Checked at:` lines yet).
1. Re-derive the AC-11 flag counts after 249as lands. Expect 7 `target_unresolved` rather than 13.
