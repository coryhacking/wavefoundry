# docs-contract-reviewer readiness notes, change 24885

Verdict: approve. No blocking defect. Earlier 246to verdict unchanged (its text is untouched).

Gapfill: used shell grep/python probes in addition to MCP reads (MCP code_read loaded but cross-file greps were quicker in shell).

## Checks
- Spec claims hold: `_WITHHELD_VIEW_KEYS`, `_withhold_view` and `stored_reasons` (memory_handlers.py ~576, ~1692) cover only title, summary, evidence, targets; the markup pattern (constants.py 271-276) is case-sensitive. AC-3 examples agree with the `\b` suffix (`<PARAMETERS>`, `<Tool_Calls>` stay clean).
- Probe 1: a case-insensitive version of the markup pattern newly matches 0 lines across 198 files under docs/agents/memory/, and no filename (slug) draws any content reason.
- Probe 2: no secret-group pattern (keyword assignment included) matches any line of any record, so promote/retain refuse no existing record.
- Seeds, prompts, docs/agents and cross-cutting-concerns.md (line 248) state reason codes only, not case rules or view withholding. "Affected Architecture Docs: N/A" holds.
- docs-lint --changed: ok.

## Advisories
1. DO: The spec names `docs/specs/mcp-tool-surface.md` but no anchor. Edit three places: the memory_validate bullet "whose stored refs are content-checked first so no refusal names a stored secret" (~line 2556: extend to action_delta, validation_rationale, source_event, memory_id, and say the record view withholds a matching field as `[withheld: <codes>]` with `withheld_reasons`); the "Content reasons" `model_control_token` text (~2578: say tag names match case-insensitively); the memory_add scan list is unchanged.
2. DO: The mcp spec does not currently document 249aq's stored-field withholding in the view at all; document both stored-field sets together.
3. DO: Add a CHANGELOG bullet in the style of line 15 (no build numbers, ends "Wave 249ar / 24885").
4. DECLINE candidate: a cross-cutting-concerns.md edit; it names no case rule.
