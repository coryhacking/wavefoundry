# Focused readiness re-check, round 2 (wave 249ar, change 24885)

Round 1 notes and brief: `.wavefoundry/work/249ar/review/readiness-24885-brief.md` and `*-readiness-24885.md` in this folder. Round 1 recorded four blocking findings against `24885-bug memory-withhold-and-markup-case`:
- `cr-24885-source-event-lint-exemption-and-rewrite-inherit` (code-reviewer)
- `24885-source-event-exemption` (qa-reviewer)
- `24885-rewrite-copies-source-event` (qa-reviewer)
- `rt-24885-rewrite-propagates-stored-source-event` (red-team)

The coordinator recorded `repair_start` in cycle 2 (context `249ar-planner-repair-24885`) and rewrote the spec's Requirements 1 to 3, AC-1, AC-2, AC-4, Tasks and Decision Log. The spec is at `docs/waves/249ar memory-maintenance-by-signal/24885-bug memory-withhold-and-markup-case.md`. The repair also took the round-1 DO advisories:
- each view is checked against the record it shows;
- the `memory_validation_not_pending` path;
- `memory_id`/`path` withheld from the fallback and diagnostic text;
- `path` checked on its own;
- id-compatible credential shapes;
- the tool-surface edit anchors and the CHANGELOG.

The 246to spec is unchanged. `wf_review_wave(wave_id='249ar', phase='prepare')` lists the pending actions.

## Your task, as a FRESH, independent reviewer of your lane (you did not write the repair)
1. Load MCP tools via ToolSearch first; use code_* MCP-first. Record a `Gapfill:` note if you fall back to shell.
2. Check the repaired 24885 spec against the tree. For each finding your lane owns, say whether the repair resolves it, backed by an executed probe on a scratch copy or in-process (for example `_memory_forbidden_match` on a rendered `decision-log:` source-event line with a `-token` slug, and the rewrite path's handling of `source_event`). Also check that the repair introduced no new defect. No repo edits. No full suite. No `wf_memory_eval`. Do not mutate `docs/agents/memory/`.
3. Record with `wf_review_event(wave_id='249ar', ...)`, dry-run first, then create, using context `249ar-<lane>-readiness-24885-r2`:
   - For each finding your lane owns, one `event='finding'`, `run_kind='reverification'`, `cycle=2`, `actor=<lane>`, `fresh_context=true`, `independent=true`. Take the judgment from the `judgment_template` in `wf_review_wave`'s review_actions, add your own honest evidence and `integrity_checks`, and set `blocking_required_lanes=[]` to clear your lane only if the repair resolves it with executed evidence.
   - Then (code-reviewer, qa-reviewer, docs-contract-reviewer) a readiness approval: `signoff_key=<lane>`, `approval_phase='readiness'`, `fresh_context=true`, `independent=true`, with your OWN honest `integrity_checks`.
   - A new blocking defect is a new finding (`run_kind='readiness'`, `cycle=0`) instead.
   - red-team: reverification only, no approval.
4. Notes to `.wavefoundry/work/249ar/review/<lane>-readiness-24885-r2.md`, with advisories as DO or DECLINE candidates. No em-dashes. Reply in under 70 words.
