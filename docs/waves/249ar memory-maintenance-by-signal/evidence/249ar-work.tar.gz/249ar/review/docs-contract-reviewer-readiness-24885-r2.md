# docs-contract-reviewer readiness 24885 round 2

Owns no finding. Checked the repaired spec's documented-contract tasks against the tree.

- wf_validate_docs (full): passed, no errors or warnings.
- Tool-surface anchors exist in docs/specs/mcp-tool-surface.md: the memory_validate bullet "whose stored refs are content-checked first so no refusal names a stored secret", and the model_control_token Content reasons text ("tool-call markup with or without a namespace prefix"). The Task names both edits and the CHANGELOG bullet; the 249aq CHANGELOG entry (line 15) is the style model.
- Probe: wave_validators._memory_forbidden_match on a rendered Source event line with a decision-log change slug ending -token returns set() (exempt); a decision-log line with `token: abc12345` returns {secret}; a wave: line with xoxb- returns {secret}. The rendered format matches memory_records line 977, so Requirement 1 is consistent with the lint.
- Rewrite path (memory_handlers ~1780) passes _source_event=record["source_event"], confirming the inherit defect; Requirement 3 (refuse rewrite on a matching stored field) closes it.
- memory_line_reasons('<INVOKE ...>') is empty on the current tree, the known gap the change fixes.

Advisories (DO candidates, none blocking):
- DO: when Task 4 edits the Content reasons bullet, also say the record lint exempts only the decision-log hash separator for source_event, so the documented handler and lint contracts agree.
- DECLINE: further architecture doc edits (already declined in the Decision Log).
