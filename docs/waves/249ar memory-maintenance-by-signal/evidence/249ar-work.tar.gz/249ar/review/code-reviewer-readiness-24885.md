# Code reviewer, readiness, change 24885 (wave 249ar)

Context: `249ar-code-reviewer-readiness-24885`, fresh and independent. Retrieval: MCP tools loaded; `code_*` used for schema, then shell `grep`/`sed` for line-precise reads. Gapfill: shell reads used for speed on files already located; no index gaps.

## Verdict

BLOCKING finding `cr-24885-source-event-lint-exemption-and-rewrite-inherit`. No approval recorded.

## Claims checked against the tree

- Item 1 holds. `_memory_view` (memory_handlers.py ~219) copies `source_event`, `action_delta`, `validation_rationale`, `memory_id`, `path` as stored. `_WITHHELD_VIEW_KEYS` maps only title, summary, evidence and target refs. `stored_reasons` (~1692) checks only those four.
- Item 2 holds. The markup pattern in `MEMORY_CONTROL_TOKEN_PATTERNS` (constants.py 271-276) has no IGNORECASE.
- Memory id grammar is `[a-z0-9-]` (memory_records.py 479), so AC-2 needs a lowercase credential shape (`xoxb-...`, `sk-ant-...`, `glpat-...`); feasible.

## Probes (read-only, scratch script)

- Widened markup with `re.IGNORECASE` or a scoped `(?i:...)` group: 0 new hits over 197 records' stored fields and every line of the 176 files under `docs/agents/memory/`. AC-3 positive and negative strings all behave as the spec states.
- Keyword `secret` pattern over every stored `source_event` (162, 60 decision-log) and `action_delta`: 0 hits today.
- Synthetic `decision-log:24885-bug rotate-api-key:0123456789abcdef`: `forbidden_content_reasons` returns `secret`; the record lint `_memory_forbidden_match` on the `Source event:` line returns nothing (it exempts the match ending at the hash separator).

## Blocking defect

1. Requirement 1 and 3 check `source_event` with the plain handler checker, which lacks the lint's decision-log exemption. Any future change whose slug ends in `token`, `secret`, `password`, `passwd` or `api-key` yields a candidate that promote and retain refuse while the lint accepts it. AC-4 cannot catch it because no current record hits. Fix: apply the same exemption for the bare value (share the recognizer), and add a fixture that promotes cleanly.
2. Requirement 3 says rewrite proceeds, but rewrite passes the stored `source_event` into `_memory_add_response_locked`, which does not content-check it. The new promoted record inherits the matched value, and `rewrite_record` (and the `existing_rewrite` retry view) returns it unwithheld. Fix: rewrite refuses on a matching stored `source_event` (it admits a record; reject stays the recovery), or the spec states the withholding for `rewrite_record`; extend AC-1 either way.

## Interaction with 246to

No conflict. 246to adds `revalidation_reasons` to `_memory_view` and changes `memory_reconcile_response`; 24885 changes `_withhold_view`, `_WITHHELD_VIEW_KEYS` and `memory_validate_response`. Same implementer session per the execution graph is right. My earlier 246to verdict is unchanged.

## Advisories

- DO: the final `record` view after reject or rewrite is built from the updated record, whose `action_delta` and `validation_rationale` are now the caller's checked values; withholding them by the pre-write `stored_reasons` hides clean values. State whether AC-1 expects the withheld marker there (it does as written) or the new values.
- DO: name the `memory_validation_not_pending` response in AC-1 too, since it also carries a view.
- DECLINE: making the other control-token patterns case-insensitive (out of scope, as stated).
