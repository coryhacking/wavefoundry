# Council chair readiness v3: wave 249ar (246to + 24885)

Context: `249ar-council-chair-readiness-v3`. Fresh and independent; I wrote no spec, repair or seat note. Repo read-only; no full suite, no `wf_memory_eval`, no write under `docs/agents/memory/`. MCP tools loaded via ToolSearch; `wf_review_wave(phase='prepare')` confirmed code, qa and docs-contract readiness approvals current, all 10 findings terminal, and `council-readiness` stale only because the receipt rotated when 24885 was admitted.

Seats: red-team (fixed), docs-contract-reviewer (rotating). Primer depth: standard.

## Verdict

PASS. No blocker. intent_fit: partially (worst across both changes and the Objective; the partial is carried from 246to against the arc row, unchanged by 24885).

## Executed probes (my own)

Script: scratchpad `chair249ar_v3/probe.py`, run with `python3 -B` and `PYTHONDONTWRITEBYTECODE=1`.

1. Case-insensitive markup census. The current `MEMORY_CONTROL_TOKEN_PATTERNS` markup pattern misses all five AC-3 positives (`<INVOKE name="x">`, `</Invoke>`, `<Function_Calls>`, `<ns:TOOL_USE>`, `<PARAMETER name="a">`). A widened copy with an inline `(?i:...)` group over the prefix and tag names matches all five and none of the five AC-3 negatives (`<invoker>`, `<PARAMETERS>`, `<Tool_Calls>`, `the INVOKE step`, `a < INVOKE b`). Over 198 files and 7072 lines under `docs/agents/memory/`, the widened pattern hits 0 lines, so Requirement 6 and AC-4 hold for the markup half. The only line any current lint reason matches is `docs/agents/memory/README.md:181` (`transcript_or_personal`), the README, not a record. No record filename stem matches a content reason.
2. Source-event matcher. `_memory_forbidden_match` on `` Source event: `decision-log:24885-bug rotate-session-token:<16 hex>` `` returns `set()` while raw `memory_line_reasons` returns `{secret}`, so the Requirement 1 exemption is real. Appending `token: abc12345` returns `{secret}`, and a `wave:` event with `xoxb-` returns `{secret}`: the exemption is only the hash separator.
3. `git status --porcelain docs/agents/memory` empty before and after.

Code reads confirming seat claims: `_WITHHELD_VIEW_KEYS` covers only title, summary, evidence and targets (`wf_server/memory_handlers.py:576`); the reused rewrite builds `_memory_view(existing_rewrite, {})` with no check (line 1774); `_anchor_refusal` puts `sorted(original)` into `original_anchors` and the message text (line 608 onward); rewrite passes `_source_event=record["source_event"]`. The red-team round-3 probes A to C therefore have real known-bad paths.

## Strongest challenge

Requirement 2 binds "every record view" and "no response repeats the matched text" in general terms, and two of the binding paths (reused `rewrite_record`, `_anchor_refusal`) are named only in a Progress Log row, not in the Requirements. An implementer who reads only Requirements and ACs could miss a path such as `memory_state_unwritable` carrying `rewrite_record`. Not a blocker: Requirement 2's general clause binds every path, the Progress Log row names the two concrete ones with a failing-first test each, and red-team cleared on that reading. Delivery review should test the response surfaces, not the list.

## Strongest alternative

A single egress scrubber that runs every serialized `memory_validate` response through `memory_line_reasons` and withholds any matching string field before return, instead of per-view field checks. It would close unnamed paths by construction. I accept the spec's per-field design for this change: the scrubber would also scan caller-supplied and tool-written text, would need its own exemption for the decision-log separator, and would hide which stored field failed, while the per-field `withheld_reasons` keeps the reason contract 249aq shipped.

## Does 24885 change the 246to verdict?

No. 24885 shares `memory_handlers.py` and `test_memory_records.py` with 246to and runs in the same implementer session, which removes the serialization risk. It touches admission and validation responses, not the revalidation signals, decay or audit order, and its AC-4 replay is read-only, consistent with the Objective's "does not rewrite this repository's memory records". The prior v2 strongest challenge, alternative and partial verdict stand.

## Carry-forward list for the implementer

From the v2 council (246to):

1. `_memory_ranked` fetches commit times by canonical path, for both the `file_commit_times` query and the `commit_times_override` filter.
2. AC-1 (246to) runs through the public path (`memory_search` or `_memory_ranked` with a seeded store), not `apply_decay` with a hand-built `commit_times` dict.
3. Add a Progress Log note that the first 2026-11-24 Decision Log row ("a ref in `blocking` sets `target_unresolved`") is superseded by the later state-based row.
4. The churn-threshold baseline is 97 of 174 records reaching their halving since `Updated:`.
5. Re-derive the AC-11 flag counts after 249as lands; expect 7 `target_unresolved` rather than 13.

For 24885:

6. When every still-resolving original anchor matched the stored check, `_anchor_refusal` still refuses, and its message says withheld anchors exist rather than listing nothing. Anchor semantics do not change because a ref is withheld (red-team r3).
7. Render the handler's `Source event:` line with the same f-string as `memory_records.py:977`, so the anchored `_DECISION_LOG_SOURCE_EVENT_RE` matches; do not copy the lint's prohibition-line skip (code-reviewer r2, Progress Log).
8. Rewrite still proceeds on a matching stored title, summary or ref (it replaces them with caller-checked values); pin that with one assertion (red-team r2, qa r2).
9. The AC-1.3 clean twin and the AC-3 negatives are controls that pass before the fix; note that against the "each failing before its fix" Task in the Progress Log (qa r2).
10. In `docs/specs/mcp-tool-surface.md`, document the 249aq and 24885 stored-field sets together with the `[withheld: <codes>]` view, say tag names match case-insensitively, and say the decision-log hash separator is the only source-event exemption; add a CHANGELOG bullet in the 249aq style (docs-contract r1 and r2).
11. Implement the case-insensitive group inline (`(?i:...)`) or with an explicit flag on that one pattern only, so the other control-token patterns keep their case rules (Requirement 4); my probe used the inline form.
12. Wave record hygiene: `wave.md` Wave Summary still says "One change"; name 24885 there when the record is next edited (wave records are not digested change docs).
13. Hygiene report, not this change: stray `__pycache__` directories exist at `.wavefoundry/framework/scripts/__pycache__` and `.wavefoundry/framework/scripts/wave_lint_lib/__pycache__` (qa r2 reported them; still present; my probes ran with bytecode writing disabled). Report to the operator; do not clean up under this wave without authorization.
