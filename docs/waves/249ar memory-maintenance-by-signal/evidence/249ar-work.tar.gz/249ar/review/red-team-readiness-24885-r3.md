# Red-team readiness re-check, round 3: 24885 (wave 249ar)

Context: `249ar-red-team-readiness-24885-r3`. Fresh and independent; I wrote no repair. Repo read-only. Gapfill: MCP tools loaded; I read known paths with shell `sed`/`grep` for speed, and ran the round-2 probe script (scratchpad `rt24885/probe_rt.py`, subclass of `tests/test_memory_records._AdmissionCase`, temporary trees, generated fake tokens) in process.

## Verdict

`rt-24885-rewrite-residual-stored-echo` is resolved at plan level. I cleared the red-team lane. No new blocking finding.

## Plan sufficiency

1. Requirement 2 opens with "Every record view that `memory_validate` returns is content-checked against the record it was built from". `rewrite_record` is a record view that `memory_validate` returns, and the reused one is built from `existing_rewrite`, so the clause binds it, fresh or reused. The reused record's own fields are the ones checked.
2. Requirement 2 closes with "No response repeats the matched text". A stored target that matched the stored check is matched text, so the `memory_rewrite_anchor_dropped` `original_anchors` list and message are bound.
3. The Progress Log row "Readiness repair cycle 3" names both paths, the expected behavior (withhold each matching field; leave matched refs out of `original_anchors` and the message) and an AC-1 test per path that fails before the fix. The Tasks line "each failing before its fix" carries the same obligation. That is unambiguous enough for an implementer and a delivery reviewer.

## Known bad, current tree (executed)

- Probe A (round-1 path, control): rewrite with a token in stored `source_event` returns `ok` and echoes the token.
- Probe B: stored target file named with a fake AWS key id; rewrite to another target returns `memory_rewrite_anchor_dropped` and the token appears in the response.
- Probe C: a prior partial rewrite with a token in its title and `action_delta`; rewrite returns `ok` and `rewrite_record.title` carries the token.

All three reproduce, so the planned tests are non-vacuous.

## Other echo paths checked

- Promote and retain refuse on `stored_reasons` before stored refs are resolved, so `_ref_unresolved_response` never names a matching stored ref.
- `memory_rewrite_create_failed` embeds the `memory_add` response; rewrite refuses on a matching stored `source_event` first (Requirement 3), and the other add inputs are caller-checked.
- `memory_state_unwritable` and `memory_validation_write_failed` carry `rewrite_record`; Requirement 2 binds that view on every response, and the write-failure text is already named.

## Advisory

- DO (implementation note): when every still-resolving original anchor matched the stored check, the anchor refusal should still refuse, and its message should say that withheld anchors exist rather than list nothing silently. Anchor semantics must not change because a ref is withheld.
