# AC-11 measurement (246to), 2026-11-24, read-only

- Before: wf_memory_eval on the old loaded code (no maintenance_signals in report). After: wf_reload_mcp, then wf_memory_eval.
- Frozen-set metrics (query set v1, sha 34afd084..., 606 scored): identical before and after for every arm and split.
  Held-out production recall@5 0.6729, MRR 0.7122, precision 0.3939, false-show 0.3889; hybrid_no_rerank 0.8567; bm25_only 0.7824; grep 0.5188.
- Sanity floor moved (churn attenuation removed): baseline MRR 0.2628 -> 0.3054; candidate MRR 0.5403 -> 0.5819;
  semantic_only recall 0.6667 -> 0.75, MRR 0.4958 -> 0.5444; lexical_only unchanged (0.5 / 0.5194).
- maintenance_signals: active 174, unresolved 7 (fraction 0.0402), not_canonical 36, churn_flagged 98,
  coverage_gap 4, uncoverable 32, check_outcomes all 0.
- memory_eval.py --uncoverable-records .: 32 entries (28 no_rationale, 3 both, 1 coverage_gap); coverage gaps 1t78a, 1vo1a, 1ydvk, 21rnt.
- memory_search(status=active, order=least_recently_reviewed, limit=15): positions 1-7 are the 7 target_unresolved records
  (Updated 07-21 .. 11-22 ascending), positions 8-15 are target_churn records ascending by Updated. Rank order holds.
- index: memory_vector_coverage 174/174, 0 stale, 0 missing; setup_readiness ready after reload.
- git status --porcelain docs/agents/memory docs/evals: empty.
