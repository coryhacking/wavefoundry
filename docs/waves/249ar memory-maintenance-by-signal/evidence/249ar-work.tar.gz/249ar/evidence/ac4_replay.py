"""24885 AC-4: content-reason replay over every record under docs/agents/memory/.

Usage: python3 -B ac4_replay.py SCRIPTS_DIR REPO_ROOT. Read-only; prints counts only.
"""
import sys
from pathlib import Path

scripts, root = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
sys.path.insert(0, str(scripts))
import memory_records as mem  # noqa: E402
import wave_lint_lib.wave_validators as wv  # noqa: E402

records = mem.load_memory_records(root, statuses=None)
hits = {}
files = 0
for record in records:
    files += 1
    path = Path(record["path"]).resolve().relative_to(root).as_posix()
    reasons = mem.forbidden_content_reasons({
        "title": [record.get("title") or ""], "summary": [record.get("summary") or ""],
        "evidence": list(record.get("evidence_refs") or []),
        "targets": list(record.get("target_refs") or []),
        "action_delta": [record.get("action_delta") or ""],
        "validation_rationale": [record.get("validation_rationale") or ""],
        "memory_id": [record["memory_id"]], "path": [path],
    })
    if record.get("source_event"):
        codes = wv._memory_forbidden_match(f"Source event: `{record['source_event']}`")
        if codes:
            reasons["source_event"] = sorted(codes)
    for field in reasons:
        hits[field] = hits.get(field, 0) + 1
print({"records": files, "records_with_reasons": sum(hits.values()), "by_field": hits})
